# ===========================================================================
# Shared plot palettes
# ===========================================================================

#' Journal colour palette (internal)
#'
#' Single source of truth for the "journal" plotting theme: a sober,
#' print-oriented palette in the style of economics/finance journals (white
#' ground, near-black navy ink, hairline grid, muted categorical hues).
#' Individual plot methods map these roles onto their own local colour
#' variables so the theme stays consistent across every figure.
#'
#' @return A named list with scalar colour roles (\code{background},
#'   \code{text}, \code{grid}, \code{primary}, \code{positive},
#'   \code{negative}, \code{neutral}) and two colour vectors:
#'   \code{categorical} (eight hues ordered for maximum separation, including
#'   in grayscale) and \code{sequential} (a light-to-dark blue ramp for
#'   gradients and heatmaps).
#' @noRd
.journal_palette <- function() {
  list(
    background  = "#FFFFFF",
    text        = "#1A1A2E",
    grid        = "#E4E4E4",
    primary     = "#1F4E79",
    positive    = "#2E7D32",
    negative    = "#B2182B",
    neutral     = "#5B6770",
    categorical = c("#1F4E79", "#B2182B", "#2A7F7F", "#C08A1E",
                    "#5B6770", "#6A4C93", "#3A7CA5", "#7A5C3E"),
    sequential  = c("#EAF2F8", "#D3E3F0", "#A9C7E0", "#6FA0C8",
                    "#3A7CA5", "#1F4E79", "#14385B")
  )
}


#' Plot method for meta_dataframe objects
#'
#' @title Plot meta_dataframe
#' @description
#' S4 \code{plot} method for \code{\link{meta_dataframe}} objects. Produces a variety of diagnostic
#' and summary visualisations (time series, cross-sectional, histogram, boxplot, composition,
#' regression, density2d, correlogram, radar, waterfall, tile heatmap, frequency). The function
#' performs internal filtering and summarisation before rendering a \code{ggplot} (or base plot
#' for radar charts).
#'
#' @param x A \code{meta_dataframe} object.
#' @param type Character. Plot type. One of \code{"cross_sectional"}, \code{"time_series"},
#'   \code{"histogram"}, \code{"boxplot"}, \code{"composition"}, \code{"regression"},
#'   \code{"density2d"}, \code{"correlogram"}, \code{"radar"}, \code{"waterfall"},
#'   \code{"tile_heatmap"}, \code{"frequency"}.
#' @param clustering_variables Character vector or \code{"auto"}. Columns to group/facet by (e.g.
#'   \code{"dates"}, \code{"tickers"}). Use \code{NULL} for no clustering.
#' @param variable Character vector. Main numeric variable(s) to analyse or visualise (must be
#'   column names of \code{x@data}). For bivariate plots, supply two variables when appropriate.
#' @param tickers Character vector or \code{"all"}. Tickes to include (default \code{"all"}).
#' @param dates Either a single \code{Date}, vector of \code{Date}, a date range, or \code{"all"}.
#' @param calc_stat Character. Summary statistic or metric to compute (e.g. \code{"mean"},
#'   \code{"sd"}, \code{"median"}, \code{"cor"}, \code{"beta"}, \code{"alpha"}, quantiles like
#'   \code{"q05"}, etc.). Defaults vary by \code{type}.
#' @param custom_filter Character or character vector. Column(s) to filter on (e.g. \code{"sector"}).
#' @param filter_values A vector or list of values used to filter \code{custom_filter} columns.
#' @param dep_y Optional character. Dependent variable used for bivariate statistics (required when
#'   \code{calc_stat} is \code{"cor"}, \code{"beta"}, \code{"alpha"} or \code{type} is \code{"regression"}).
#' @param numeric_aggregation Character. How to discretize numeric clustering variables: one of
#'   \code{"decile"}, \code{"quartile"}, \code{"tercile"}, \code{"median"}. Default: \code{"decile"}.
#' @param palette Character. Colour palette to use for the plot (e.g. \code{"cyberpunk"}, \code{"br"}).
#'
#' @return A \code{ggplot} object (or base plot for radar). The plot is printed as a side-effect.
#'
#' @details
#' - Univariate plots use \code{variable}. Bivariate plots require \code{dep_y} or two variables.
#' - \code{tile_heatmap} and \code{composition} perform internal quantile binning and aggregation.
#' - When \code{clustering_variables="auto"} the function will interactively prompt for sensible defaults
#'   if run in an interactive session. Many arguments can be selected interactively when omitted.
#' - Required plotting packages: \pkg{ggplot2}, \pkg{gridExtra}, \pkg{scales}, \pkg{ggdist}, \pkg{ggraph},
#'   \pkg{ggrepel}, \pkg{igraph}, \pkg{RColorBrewer}. The method stops if dependencies are missing.
#'
#' @examples
#' \dontrun{
#' # Cross-sectional mean of 'score' by tickers on a given date
#' plot(mdf, type = "cross_sectional", variable = "score", calc_stat = "mean",
#'      clustering_variables = "tickers", dates = as.Date("2026-07-01"))
#'
#' # Time series of 'momentum' for a specific ticker
#' plot(mdf, type = "time_series", variable = "momentum",
#'      clustering_variables = "dates", tickers = "AAPL")
#'
#' # Histogram of a signal distribution
#' plot(mdf, type = "histogram", variable = "signal", clustering_variables = "tickers")
#'
#' # Boxplot of a signal across tickers
#' plot(mdf, type = "boxplot", variable = "signal", clustering_variables = "tickers")
#'
#' # Composition of themes (uses calc_stat = "mean")
#' plot(mdf, type = "composition", variable = "theme")
#'
#' # Regression of signal_x against return_1m (bivariate)
#' plot(mdf, type = "regression", variable = "signal_x", dep_y = "return_1m",
#'      clustering_variables = "tickers")
#'
#' # 2D density of two signals
#' plot(mdf, type = "density2d", variable = c("signal_x", "signal_y"), tickers = "all")
#'
#' # Correlogram across several metrics
#' plot(mdf, type = "correlogram", variable = c("signal_a", "signal_b", "signal_c"))
#'
#' # Radar chart (requires >= 3 variables)
#' plot(mdf, type = "radar", variable = c("IR", "alpha", "turnover"))
#'
#' # Waterfall (e.g., cumulative contribution)
#' plot(mdf, type = "waterfall", variable = "exp_ret", calc_stat = "sum",
#'      clustering_variables = "tickers")
#'
#' # Tile heatmap over dates × groups (quantile-binned)
#' plot(mdf, type = "tile_heatmap", variable = "score", clustering_variables = c("dates", "tickers"))
#'
#' # Frequency plot for categorical/count diagnostics
#' plot(mdf, type = "frequency", variable = "sector")
#' }
#'
#' @name plot-meta_dataframe
#' @rdname plot-meta_dataframe
#' @aliases plot,meta_dataframe,missing-method
#' @exportMethod plot
setMethod(
  "plot",
  signature(x = "meta_dataframe", y = "missing"),
  function(x, type = NULL, clustering_variables = "auto", variable = NULL, tickers = NULL, dates = NULL, calc_stat = NULL,
           custom_filter = NULL, filter_values = NULL, dep_y = NULL, numeric_aggregation = "decile", palette = "cyberpunk") {

    # Check for required packages for plotting
    required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

    missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

    df <- x@data
    date_range_text <- ""
    tickers_text <- ""

    if (length(missing_pkgs) > 0) {
      stop(
        sprintf(
          "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
          paste(missing_pkgs, collapse = ", ")
        ),
        call. = FALSE
      )
    }


    # Prompt for 'type' if not specified
    if (is.null(type)) {
      if(inherits(x, "groups_m_df")){
      available_types <- c("frequency", "composition", "tile_heatmap")
      } else {
      available_types <- c("cross_sectional", "time_series", "histogram", "boxplot", "composition",
                           "regression", "density2d", "correlogram", "radar", "waterfall", "tile_heatmap")
      }
      cat("\nPlease choose a plot type:\n")
      for (i in seq_along(available_types)) {
        cat(paste0(i, ": ", available_types[i], "\n"))
      }
      selection <- readline(prompt = "Enter the number of your choice: ")
      selection <- as.numeric(selection)
      if (is.na(selection) || selection < 1 || selection > length(available_types)) {
        stop("Invalid selection.")
      }
      type <- available_types[selection]
    }

    if(inherits(x, "groups_m_df") && !type %in% c("frequency", "composition", "tile_heatmap")){
      stop("Only composition and tile_heatmaps are avaiable for groups_m_df objects.")
    }

    # Prompt for 'variables' if not specified
    if (is.null(variable)) {
      available_variables <- setdiff(names(x@data), c("id", "tickers", "dates"))
      cat("\nPlease choose variable(s) (separated by commas, or press Enter to skip):\n")
      for (i in seq_along(available_variables)) {
        cat(paste0(i, ": ", available_variables[i], "\n"))
      }
      selection <- readline(prompt = "Enter your choices (e.g., 1,2): ")
      if (nzchar(selection)) {
        indices <- as.numeric(strsplit(selection, ",")[[1]])
        if (any(is.na(indices)) || any(indices < 1 | indices > length(available_variables))) {
          stop("Invalid selection for variable.")
        }
        variable <- available_variables[indices]
      }
    }


    #Check number of variables provided
    if(length(variable) == 0){
      stop("Please select at least one variable.")
    }
    if(length(variable) > 1 && !type %in% c("density2d", "correlogram", "radar", "waterfall")){
      if(!type == "regression"){
        stop("Currently, only one variable can be selected for the chosen plot type.")
      } else {
        stop("For regression, set only one variable (the independent variable) and then set dep_y (the dependent variable).")
      }
    }
    if(length(variable) < 3 && type == "radar"){
      stop("For radar plots, select at least three variables.")
    }


    # Prompt for 'clustering_variables' if not specified
    if (identical(clustering_variables, "auto") && !type %in% c("composition")) {
      available_clustering_vars <- setdiff(names(x@data), c("id", variable))
      cat("\nPlease choose clustering variables (separated by commas, or press Enter to skip):\n")
      for (i in seq_along(available_clustering_vars)) {
        cat(paste0(i, ": ", available_clustering_vars[i], "\n"))
      }
      selection <- readline(prompt = "Enter your choices (e.g., 1,2): ")
      if (nzchar(selection)) {
        indices <- as.numeric(strsplit(selection, ",")[[1]])
        if (any(is.na(indices)) || any(indices < 1 | indices > length(available_clustering_vars))) {
          stop("Invalid selection for clustering variables.")
        }
        clustering_variables <- available_clustering_vars[indices]
      } else {

        # user pressed Enter: no clustering
        clustering_variables <- NULL

      }
    }

    if (type %in% c("histogram", "boxplot", "regression", "correlogram", "radar") &&
        length(clustering_variables) > 1) {
      stop("This plot type currently supports only one clustering variable.")
    }

    # Prompt for 'tickers' if not specified
    if (is.null(tickers)) {
      cat("\nDo you want to include all tickers or select specific ones? (Type 'all' or enter tickers separated by commas):\n")
      selection <- readline(prompt = "Enter your choice: ")
      if (nzchar(selection) && selection != "all") {
        tickers <- strsplit(selection, ",")[[1]]
      }
    }
    if (is.null(tickers)) {
      tickers <- "all"
    }

    # Prompt for 'dates' if not specified
    if (is.null(dates)) {
      cat("\nDo you want to include all dates or select a date range? (Type 'all' or enter range in 'YYYY-MM-DD,YYYY-MM-DD' format):\n")
      selection <- readline(prompt = "Enter your choice: ")
      if (nzchar(selection) && selection != "all") {
        date_range <- strsplit(selection, ",")[[1]]
        if (length(date_range) > 2 || any(!grepl("^\\d{4}-\\d{2}-\\d{2}$", date_range))) {
          stop("Invalid date range format. Use 'YYYY-MM-DD,YYYY-MM-DD'.")
        }
        if (length(date_range) == 1) {
          dates <- as.Date(date_range)
        } else {
          dates <- seq.Date(as.Date(date_range[1]), as.Date(date_range[2]), by = "day")
        }
      }
    }
    if (is.null(dates)) {
      dates <- sort(unique(df$dates))
    }

    # Prompt for 'calc_stat' if not specified
    if (is.null(calc_stat)) {

      if (type %in% c("cross_sectional", "time_series", "waterfall")) {

        available_stats <- c(
          "mean","sd","median","min","max","sum","n",
          "q05","q10","q25","q75","q90","q95",
          "cor","beta","beta_tstat","alpha","alpha_tstat"
        )

        cat("\nPlease choose a calculation statistic (calc_stat):\n")

        for (i in seq_along(available_stats)) {
          cat(paste0(i, ": ", available_stats[i], "\n"))
        }

        selection <- readline(prompt = "Enter the number of your choice: ")
        selection <- as.numeric(selection)

        if (is.na(selection) || selection < 1 || selection > length(available_stats)) {
          stop("Invalid selection for calc_stat.")
        }

        calc_stat <- available_stats[selection]

      } else {

        calc_stat <- if(type %in% c("waterfall","signal_evolution")) "sum" else "mean"

      }

    }

    # Prompt for 'dep_y' if applicable
    if (is.null(dep_y) && (calc_stat %in% c("cor", "beta", "beta_tstat", "alpha", "alpha_tstat") || type == "regression")) {
      available_variables <- setdiff(names(x@data), c("id", "tickers", "dates", variable))
      cat("\nPlease choose a dependent variable (dep_y):\n")
      for (i in seq_along(available_variables)) {
        cat(paste0(i, ": ", available_variables[i], "\n"))
      }
      selection <- readline(prompt = "Enter the number of your choice: ")
      selection <- as.numeric(selection)
      if (is.na(selection) || selection < 1 || selection > length(available_variables)) {
        stop("Invalid selection for dep_y.")
      }
      dep_y <- available_variables[selection]
    }

    # Set default clustering_variables based on plot type
    if (is.null(clustering_variables)) {
      if (type == "cross_sectional"){
        clustering_variables <- "tickers"
      }
      if (type == "time_series"){
        clustering_variables <- "dates"
      }
    }

    #Treatment for composition plot
    if(type == "composition"){
      if(!is.null(clustering_variables)){
        clustering_variables <- NULL
      }

      if(calc_stat != "mean"){
        stop("Composition plot does not support custom calc_stat.")
      }
    }

    #Check if variable and dep_y are set as character
    if(any(!is.character(variable)) && !type %in% c("tile_heatmap")){
      stop("variable must be set as character values describing colnames in the data.frame.")
    }

    if(!all(variable %in% colnames(x@data))){
      stop("variable must be present in the data.frame.")
    }

    #Check for dep_y adequacy
    if(!is.null(dep_y)){
      if(any(!is.character(dep_y))){
        stop("dep_y must be set as character values describing colnames in the data.frame.")
      }

      if(!all(dep_y %in% colnames(x@data))){
        stop("dep_y must be present in the data.frame.")
      }

      if((type == "composition" || type == "histogram" || type == "density2d")){
        stop("dep_y is not supported for this plot type.")
      }

    }

    if (!palette %in% c("cyberpunk","br","journal")) {
      stop("palette must be 'cyberpunk', 'br' or 'journal'")
    }

    # Define colors for plotting
    black <- "#000000"
    white <- "#FFFFFF"

    if (palette == "cyberpunk") {

      deep_navy      <- "#000033"
      black          <- "#000000"
      white          <- "#FFFFFF"
      vibrant_purple <- "#6A0DAD"
      neon_green     <- "#39FF14"
      neon_orange    <- "#FF5F1F"
      blue_bg        <- "#001f3f"
      neon_yellow    <- "#FFDC00"
      neon_pink      <- "#FF007F"
      cyan           <- "#7FDBFF"
      neon_red       <- "#FF4136"

      col_primary   <- "#6A0DAD"
      col_positive  <- "#39FF14"
      col_negative  <- "#FF5F1F"
      col_background <- "#001f3f"
      col_text      <- "#FFFFFF"

      neon_palete <- c(vibrant_purple, neon_green, neon_orange, neon_yellow, neon_pink, cyan, neon_red)

    }

    if (palette == "br") {

      br_palette <- c(
        "#94E1D6",
        "#49479D",
        "#7DB61C",
        "#003641",
        "#00C9B8",
        "#2F2D6F",
        "#FF5F1F",
        "#39FF14",
        "#C9D200",
        "#00A091",
        "#3FB7C4",
        "#EBEEF1",
        "#98B2B6",
        "#6E8B91",
        "#4C7C83",
        "#A8A600",
        "#3E3C8A",
        "#5A58B5",
        "#6E6CC4",
        "#002C33",
        "#004F57",
        "#8E9400",
        "#EBEEA8",
        "#D6E266",
        "#CEE2A2",
        "#B6B300",
        "#A5CD5C",
        "#0A3D62",
        "#006D77",
        "#1B8A9B",
        "#0F4C81",
        "#1B4F8C",
        "#2E6F95",
        "#3A7CA5",
        "#4A90C2"
      )

      col_primary   <- "#00A091"
      col_positive  <- "#7DB61C"
      col_negative  <- "#C2185B"
      col_background <- "#FFFFFF"
      col_text      <- "#002C33"

    }

    if (palette == "journal") {

      ### The journal theme shares the br (light-theme) code paths below; the
      ### shared branches test `palette %in% c("br", "journal")` and read the
      ### same variables, so populate them with the journal role colours.
      jp <- .journal_palette()

      br_palette <- jp$categorical

      col_primary    <- jp$primary
      col_positive   <- jp$positive
      col_negative   <- jp$negative
      col_background <- jp$background
      col_text       <- jp$text

    }



    # Define statistic function based on user choice
    FUN <- switch(calc_stat,
                  mean = function(x) mean(x, na.rm = TRUE),
                  sd = function(x) sd(x, na.rm = TRUE),
                  median = function(x) median(x, na.rm = TRUE),
                  min = function(x) min(x, na.rm = TRUE),
                  max = function(x) max(x, na.rm = TRUE),
                  sum = function(x) sum(x, na.rm = TRUE),
                  n = function(x) length(x),
                  q05 = function(x) quantile(x, 0.05, na.rm = TRUE),
                  q10 = function(x) quantile(x, 0.10, na.rm = TRUE),
                  q25 = function(x) quantile(x, 0.25, na.rm = TRUE),
                  q75 = function(x) quantile(x, 0.75, na.rm = TRUE),
                  q90 = function(x) quantile(x, 0.90, na.rm = TRUE),
                  q95 = function(x) quantile(x, 0.95, na.rm = TRUE),
                  cor = function(x, dep_y) {
                    if (missing(dep_y)) stop("dep_y is required for correlation calculation")
                    stats::cor(x, dep_y, use = "complete.obs")
                  },
                  beta = function(x, dep_y) {
                    if (missing(dep_y)) stop("dep_y is required for beta calculation")
                    stats::lm(dep_y ~ x)$coefficients[2]
                  },
                  beta_tstat = function(x, dep_y) {
                    if (missing(dep_y)) stop("dep_y is required for beta t-stat calculation")
                    summary(stats::lm(dep_y ~ x))$coefficients[2, 3]
                  },
                  alpha = function(x, dep_y) {
                    if (missing(dep_y)) stop("dep_y is required for alpha calculation")
                    stats::lm(dep_y ~ x)$coefficients[1]
                  },
                  alpha_tstat = function(x, dep_y) {
                    if (missing(dep_y)) stop("dep_y is required for alpha t-stat calculation")
                    summary(stats::lm(dep_y ~ x))$coefficients[1, 3]
                  },
                  stop("Invalid function")
    )

    # Filter based on tickers
    if (!identical(tickers, "all")) {
      tickers_clean <- gsub(pattern = '[\"[:space:]]', replacement = '', x = tickers)
      df <- df %>% dplyr::filter(tickers %in% tickers_clean)
      tickers_text <- if (length(tickers) > 10) "> 10 tickers" else paste("Tickers:", paste(tickers, collapse = ", "))
    } else {
      tickers_text <- "All tickers"
    }

    # Filter based on dates
    if (!identical(dates, "all")) {
      selected_dates <- dates
      df <- df %>% dplyr::filter(dates %in% selected_dates)
    }
    date_range_text <- paste("Dates:", paste(unique(range(dates)), collapse = " - "))

    # Apply custom filters if specified
    if (!is.null(custom_filter) && !is.null(filter_values)) {
      if (is.character(custom_filter) && is.list(filter_values) && length(custom_filter) == length(filter_values)) {
        df <- purrr::reduce2(custom_filter, filter_values, .init = df, ~ .x %>% dplyr::filter(!!rlang::sym(.y) %in% .z))
      } else if (is.character(custom_filter) && is.vector(filter_values)) {
        df <- df %>% dplyr::filter(!!rlang::sym(custom_filter) %in% filter_values)
      } else {
        stop("custom_filter and filter_values must be compatible: custom_filter should be a vector of column names, and filter_values a list or vector.")
      }
    }

    # Stop if no data after filtering
    if (nrow(df) == 0) stop("No data available for the specified filters.")

    # Identify numeric clustering variables and create decile-based factors if needed
    # Set number of bins and labels based on chosen aggregation
    bins <- switch(numeric_aggregation,
                   decile = 10,
                   quartile = 4,
                   tercile = 3,
                   median = 2,
                   stop("Invalid numeric_aggregation. Choose from 'decile', 'quartile', 'tercile', or 'median'."))

    # Pre-compute labels once
    label_list <- switch(numeric_aggregation,
                         decile = sprintf("d%02d", 1:10),
                         quartile = sprintf("q%02d", 1:4),
                         tercile = sprintf("t%02d", 1:3),
                         median = c("below_median", "above_median"))

    numeric_clustering_variables <- purrr::keep(clustering_variables, ~ is.numeric(df[[.x]]))

    if (length(numeric_clustering_variables) > 0) {

      # Check if any date has fewer observations than the number of bins
      insufficient_obs <- df %>%
        dplyr::group_by(dates) %>%
        dplyr::summarise(n_obs = dplyr::n(), .groups = 'drop') %>%
        dplyr::filter(n_obs < bins)

      if (nrow(insufficient_obs) > 0) {
        # Create a descriptive error message listing problematic dates and their observation counts
        error_message <- paste0(
          "Not enough observations to create '", numeric_aggregation, "' bins on the following date(s): ",
          paste(insufficient_obs$dates, collapse = ", "),
          ".\nRequested: ", bins, " bins. Available: ", insufficient_obs$n_obs,
          " observation(s) each.\nConsider using a less granular 'numeric_aggregation' or providing more data."
        )
        stop(error_message, call. = FALSE)
      }

      # Mutate to create factor-based categorization with proper labels (date-wise)
      df <- df %>%
        dplyr::group_by(dates) %>%
        dplyr::mutate(
          dplyr::across(
            dplyr::all_of(numeric_clustering_variables),
            ~ {
              var_name <- dplyr::cur_column()
              var_labels <- paste0(label_list, "_", var_name)
              factor_val <- dplyr::ntile(., bins)
              factor(factor_val, levels = seq_len(bins), labels = var_labels)
            },
            .names = "{numeric_aggregation}_{col}"
          )
        ) %>%
        dplyr::ungroup()

      # Update clustering variables to include the new categorized columns
      clustering_variables <- purrr::map_chr(clustering_variables, ~ if (.x %in% numeric_clustering_variables) {
        paste0(numeric_aggregation, "_", .x)
      } else .x)
    }

    # Logic for cross-sectional plot
    if (type == "cross_sectional") {
      if (is.null(variable)) stop("Please specify the 'variable' argument for cross-sectional plot.")

      # Group by clustering variable and calculate the statistic
      if (calc_stat %in% c("cor", "beta", "beta_tstat", "alpha", "alpha_tstat")) {
        if (is.null(dep_y)) stop(paste(calc_stat, "requires dependent variable 'dep_y'."))
        df_fun <- df %>%
          dplyr::group_by(dplyr::across(dplyr::all_of(clustering_variables))) %>%
          dplyr::summarize(Calc_Stat = FUN(!!rlang::sym(variable), !!rlang::sym(dep_y))) %>%
          dplyr::ungroup()
      } else {
        df_fun <- df %>%
          dplyr::group_by(dplyr::across(dplyr::all_of(clustering_variables))) %>%
          dplyr::summarize(Calc_Stat = FUN(!!rlang::sym(variable))) %>%
          dplyr::ungroup()
      }

      # Remove rows with NaN in the Calc_Stat column
      df_fun <- df_fun %>% dplyr::filter(!is.nan(Calc_Stat))

      # Stop if no data remains after filtering
      if (nrow(df_fun) == 0) stop("No data available after removing NaN values from Calc_Stat.")

      # Cross-sectional bar plot
      p <-
        ggplot2::ggplot(df_fun, ggplot2::aes(x = interaction(!!!rlang::syms(clustering_variables)), y = Calc_Stat)) +
        ggplot2::geom_bar(stat = "identity", fill = col_primary, color = col_text) +
        ggplot2::geom_text(ggplot2::aes(label = scales::scientific(Calc_Stat, digits = 2)), vjust = -0.5, color = col_text) +
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.grid.major = ggplot2::element_blank(),
          panel.grid.minor = ggplot2::element_blank(),
          axis.text = ggplot2::element_text(color = col_text),
          axis.title = ggplot2::element_text(color = col_text),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic")
        ) +
        ggplot2::labs(
          title = paste("Cross-section of", variable, "by", paste(clustering_variables, collapse = ", ")),
          subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
          x = paste(clustering_variables, collapse = ", "),
          y = paste(calc_stat, variable)
        )

      print(p)

    }

    #Time series
    if (type == "time_series") {
      # Ensure 'dates' is included in clustering_variables for time series
      if (is.null(variable)) stop("Please specify the 'variable' argument for the time series plot.")

      clustering_variables <- c("dates", setdiff(clustering_variables, "dates"))

      # Calculate the statistic based on user-specified function
      if (calc_stat %in% c("cor", "beta", "beta_tstat", "alpha", "alpha_tstat")) {
        if (is.null(dep_y)) stop(paste(calc_stat, "requires a secondary variable 'dep_y'."))
        df_fun <- df %>%
          dplyr::group_by(dplyr::across(dplyr::all_of(clustering_variables))) %>%
          dplyr::summarize(Calc_Stat = FUN(!!rlang::sym(variable), !!rlang::sym(dep_y)), .groups = "drop")
      } else {
        df_fun <- df %>%
          dplyr::group_by(dplyr::across(dplyr::all_of(clustering_variables))) %>%
          dplyr::summarize(Calc_Stat = FUN(!!rlang::sym(variable)), .groups = "drop")
      }

      # Remove rows with NaN in the Calc_Stat column
      df_fun <- df_fun %>% dplyr::filter(!is.nan(Calc_Stat))

      # Stop if no data remains after filtering
      if (nrow(df_fun) == 0) stop("No data available after removing NaN values from Calc_Stat.")

      # If clustering variables include more than just 'dates', create separate columns for each unique combination
      if (length(clustering_variables) > 1) {

        # Pivot wider to have one column per unique group of clustering variables, excluding 'dates'
        df_wide <- df_fun %>%
          tidyr::pivot_wider(names_from = setdiff(clustering_variables, "dates"),
                             values_from = Calc_Stat,
                             names_sep = "_")

        # Choose a color palette (e.g., "Set3" for distinct colors) or any other palette with enough colors
        num_series <- ncol(df_wide) - 1  # Number of unique time series (columns in df_wide excluding 'dates')
        if (palette %in% c("br", "journal")) {
          color_palette <- br_palette
        } else {
          color_palette <- suppressWarnings(RColorBrewer::brewer.pal(min(num_series, 12), "Set3"))  # Adjust palette size to number of series
        }

        # If more than 12 series, extend the palette by repeating colors (or use a larger palette if available)
        if (num_series > 12) {
          if (palette %in% c("br", "journal")){
            color_palette <- rep(br_palette, length.out = num_series)
          } else {
            color_palette <- grDevices::colorRampPalette(RColorBrewer::brewer.pal(12, "Set3"))(num_series)
          }
        }

        # Pivot df_wide to long format for easier plotting with legend
        df_long <- df_wide %>%
          tidyr::pivot_longer(cols = -dates, names_to = "Group", values_to = "Calc_Stat")

        # Plot each time series with a unique color and include legend
        custom_title <- if(all(clustering_variables == c("dates", "tickers"))){
          paste("Time Series of", variable, "by", paste(setdiff(clustering_variables, "dates"), collapse = ", "))
        } else {
          paste("Time Series of", calc_stat, variable, "by", paste(setdiff(clustering_variables, "dates"), collapse = ", "))
        }

        p <-
          ggplot2::ggplot(df_long, ggplot2::aes(x = dates, y = Calc_Stat, color = Group, group = Group)) +
          ggplot2::geom_line(size = 1.25) +
          ggplot2::scale_y_continuous(labels = scales::scientific) +
          ggplot2::scale_color_manual(values = color_palette) +  # Apply custom color palette
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.grid.major = ggplot2::element_blank(),
            panel.grid.minor = ggplot2::element_blank(),
            axis.text = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text),
            plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic"),
            legend.position = "bottom",
            legend.title = ggplot2::element_text(color = col_text),
            legend.text = ggplot2::element_text(color = col_text)
          ) +
          ggplot2::labs(
            title = custom_title,
            subtitle = date_range_text,
            x = "Date",
            y = paste(calc_stat, variable),
            color = paste(setdiff(clustering_variables, "dates"), collapse = ", ")
          )

        print(p)
      } else {
        # Single time series line plot for Calc_Stat over dates
        p <-
          ggplot2::ggplot(df_fun, ggplot2::aes(x = dates, y = Calc_Stat)) +
          ggplot2::geom_line(size = 1, color = col_primary) +
          ggplot2::scale_y_continuous(labels = scales::scientific) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.grid.major = ggplot2::element_blank(),
            panel.grid.minor = ggplot2::element_blank(),
            axis.text = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text),
            plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic")
          ) +
          ggplot2::labs(
            title = paste("Time Series of", calc_stat, variable),
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = "Date",
            y = paste(calc_stat, variable),
            color = if (!identical(clustering_variables, "tickers")) paste(clustering_variables, collapse = ", ") else NULL
          )
        print(p)
      }
    }

    # histogram Plot
    if (type == "histogram") {
      if (is.null(variable)) stop("Please specify the 'variable' argument for histogram plot.")

      # Filter out rows with NA in the specified variable
      df <- dplyr::filter(df, !is.na(!!rlang::sym(variable)))

      # Check if clustering_variables is empty or NULL, in which case we create a single plot
      if (is.null(clustering_variables) || length(clustering_variables) == 0) {
        # Single histogram plot with classic histogram
        p <-
          ggplot2::ggplot(df, ggplot2::aes_string(x = variable)) +
          ggplot2::geom_histogram(bins = 30, fill = col_primary, color = black, alpha = 0.7) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.grid.major = ggplot2::element_blank(),
            panel.grid.minor = ggplot2::element_blank(),
            axis.text = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text),
            plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic")
          ) +
          ggplot2::labs(
            title = paste("histogram of", variable),
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = variable,
            y = "Frequency"
          )
        print(p)
      } else {

        # Generate color palette based on the number of unique categories
        num_categories <- length(unique(df[[clustering_variables]]))
        if (palette %in% c("br", "journal")){
          base_palette <- br_palette
        } else {
          base_palette <- suppressWarnings(RColorBrewer::brewer.pal(min(num_categories, 12), "Set3"))
        }
        color_palette <- if (num_categories > 12) {
          if (palette %in% c("br", "journal")){
           rep(br_palette, length.out = num_categories)
          } else {
            grDevices::colorRampPalette(base_palette)(num_categories)
          }
        } else {
          base_palette
        }

        # histogram plot faceted by clustering variables with classic histogram
        p <-
          ggplot2::ggplot(df, ggplot2::aes_string(x = variable, fill = clustering_variables)) +
          ggplot2::geom_histogram(bins = 30, color = black, alpha = 0.7, position = "identity") +
          ggplot2::facet_wrap(ggplot2::vars(interaction(!!!rlang::syms(clustering_variables))), scales = "free") +
          ggplot2::scale_fill_manual(values = color_palette) +  # Apply custom color palette
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.grid.major = ggplot2::element_blank(),
            panel.grid.minor = ggplot2::element_blank(),
            axis.text = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text),
            plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic"),
            strip.text = ggplot2::element_text(color = col_text),  # Set facet label color to white
            legend.position = "none" #Exclude legend
          ) +
          ggplot2::labs(
            title = paste("histogram of", variable, "by", paste(clustering_variables, collapse = ", ")),
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = variable,
            y = "Frequency"
          )
        print(p)
      }
    }

    # Boxplot
    if (type == "boxplot") {
      if (is.null(variable)) stop("Please specify the 'variable' argument for the boxplot.")
      if (is.null(clustering_variables) || length(clustering_variables) == 0) {
        stop("Please specify 'clustering_variables' for the boxplot.")
      }

      # Filter out rows with NA in the specified variable
      df <- df %>% dplyr::filter(!is.na(!!rlang::sym(variable)))

      # Generate color palette based on the number of unique categories
      num_categories <- length(unique(df[[clustering_variables]]))
      if (palette %in% c("br", "journal")){
        base_palette <- br_palette
      } else {
        base_palette <- neon_palete
      }

      color_palette <- if (num_categories > 12) {
        if (palette %in% c("br", "journal")){
          rep(br_palette, length.out = num_categories)
        } else {
          rep(neon_palete, length.out = num_categories)
        }
      } else {
        base_palette
      }

      # Create the boxplot
      if (!is.factor(df[[clustering_variables]])) {
        df[[clustering_variables]] <- as.factor(df[[clustering_variables]])
      }

      p <- ggplot2::ggplot(df, ggplot2::aes_string(x = clustering_variables, y = variable, fill = clustering_variables)) +
        ggplot2::geom_boxplot() +
        ggplot2::scale_fill_manual(values = color_palette) +
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.grid.major = ggplot2::element_blank(),
          panel.grid.minor = ggplot2::element_blank(),
          axis.text = ggplot2::element_text(color = col_text),
          axis.title = ggplot2::element_text(color = col_text),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic"),
          legend.position = "none"
        ) +
        ggplot2::labs(
          title = paste("Boxplot of", variable, "by", paste(clustering_variables, collapse = ", ")),
          subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
          x = paste(clustering_variables, collapse = ", "),
          y = variable
        )
      print(p)
    }


    # Composition plot
    if (type == "composition") {
      if (is.null(variable)) stop("Please specify the 'variable' argument for the composition plot.")

      # Ensure 'dates' is included in clustering_variables for time series composition
      clustering_variables <- c("dates", setdiff(clustering_variables, "dates"))

      # Filter out rows with NA in the specified variable
      df <- df %>% dplyr::filter(!is.na(!!rlang::sym(variable)))

      # Check if variable is numeric, and if so, create deciles or other aggregation
      if (is.numeric(df[[variable]])) {
        # Set number of bins and labels based on chosen aggregation
        bins <- switch(numeric_aggregation,
                       decile = 10,
                       quartile = 4,
                       tercile = 3,
                       median = 2,
                       stop("Invalid numeric_aggregation. Choose from 'decile', 'quartile', 'tercile', or 'median'."))

        # Create decile-based factor for the variable
        df <- df %>%
          dplyr::mutate(
            Composition_Group = factor(
              dplyr::ntile(!!rlang::sym(variable), bins),
              labels = switch(numeric_aggregation,
                              decile = sprintf("D%02d", 1:10),
                              quartile = sprintf("Q%02d", 1:4),
                              tercile = sprintf("T%02d", 1:3),
                              median = c("Below Median", "Above Median"))
            )
          )
      } else {
        # If variable is not numeric, use it directly for composition
        df <- df %>% dplyr::mutate(Composition_Group = as.factor(!!rlang::sym(variable)))
      }

      # Aggregate the data by dates and Composition_Group to get the counts per group over time
      df_fun <- df %>%
        dplyr::group_by(dates, Composition_Group) %>%
        dplyr::summarize(Count = dplyr::n(), .groups = "drop")

      # Generate color palette based on the number of unique categories
      num_categories <- length(unique(df_fun$Composition_Group))
      if (palette %in% c("br", "journal")){
        base_palette <- br_palette
      } else {
        base_palette <- RColorBrewer::brewer.pal(min(num_categories, 3), "Set3")
      }
      color_palette <- if (num_categories > 3) {
        if (palette %in% c("br", "journal")){
          rep(br_palette, length.out = num_categories)
        } else {
          grDevices::colorRampPalette(base_palette)(num_categories)
        }
      } else {
        base_palette
      }

      # Create the composition area plot
      p <-
        ggplot2::ggplot(df_fun, ggplot2::aes(x = dates, y = Count, fill = Composition_Group)) +
        ggplot2::geom_area(position = "fill", alpha = 0.7) +
        ggplot2::scale_fill_manual(values = color_palette) +
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.grid.major = ggplot2::element_blank(),
          panel.grid.minor = ggplot2::element_blank(),
          axis.text = ggplot2::element_text(color = col_text),
          axis.title = ggplot2::element_text(color = col_text),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic"),
          legend.position = "bottom",
          legend.title = ggplot2::element_text(color = col_text),
          legend.text = ggplot2::element_text(color = col_text)
        ) +
        ggplot2::labs(
          title = paste("Composition of", variable, "by", paste(clustering_variables, collapse = ", ")),
          subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
          x = "Date",
          y = "Proportion",
          fill = "Composition Group"
        )

      print(p)
    }

    # Regression plot
    if (type == "regression") {
      # Ensure that y is provided
      if (is.null(dep_y)) stop("Please provide a dependent variable (dep_y) for the regression plot.")


      # Check if clustering variables are provided
      if (is.null(clustering_variables)) {
        # Single regression line
        p <- ggplot2::ggplot(df, ggplot2::aes_string(x = variable, y = dep_y)) +
          ggplot2::geom_point(color = col_positive, alpha = 0.8) +
          ggplot2::geom_smooth(method = "lm", se = FALSE, formula = y ~ x, color = col_primary, size = 1.2) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.grid.major = ggplot2::element_blank(),
            panel.grid.minor = ggplot2::element_blank(),
            axis.text = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text, face = "bold"),
            plot.title = ggplot2::element_text(color = col_text, size = 18, face = "bold", hjust = 0), # Left-aligned title
            plot.subtitle = ggplot2::element_text(color = col_text, size = 10, face = "italic", hjust = 0) # Left-aligned subtitle
          ) +
          ggplot2::labs(
            title = paste("Regression of", variable, "on", dep_y),
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = variable,
            y = dep_y
          )
      } else {
        if (clustering_variables == "dates") df$dates <- as.factor(df$dates)
        # Grouped regression lines
        p <- ggplot2::ggplot(df, ggplot2::aes_string(x = variable, y = dep_y, color = clustering_variables)) +
          ggplot2::geom_point(alpha = 0.8) +
          ggplot2::geom_smooth(method = "lm", se = FALSE, size = 1.2) +
          ggplot2::scale_color_manual(values = grDevices::colorRampPalette(
            c(col_positive, col_primary, col_negative))(length(unique(df[[clustering_variables]])))) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.grid.major = ggplot2::element_blank(),
            panel.grid.minor = ggplot2::element_blank(),
            axis.text = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text, face = "bold"),
            plot.title = ggplot2::element_text(color = col_text, size = 18, face = "bold", hjust = 0),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 10, face = "italic", hjust = 0),
            legend.position = "bottom",
            legend.title = ggplot2::element_text(color = col_text),
            legend.text = ggplot2::element_text(color = col_text)
          ) +
          ggplot2::labs(
            title = paste("Regression of", variable, "on", dep_y, "by", paste(clustering_variables, collapse = ", ")),
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = variable,
            y = dep_y,
            color = clustering_variables
          )
      }

      print(p)
    }

    # 2d density
    if (type == "density2d") {

      #Check for the number of variables provided
      if (length(variable) != 2 && type == "density2d"){
        stop("For a 2d density plot, two variables must be provided.")
      } else {
        x_1 <- variable[1]
        x_2 <- variable[2]
      }

      # Check if clustering variables are provided for faceted density plots
      if (is.null(clustering_variables)) {
        # Single 2D density plot without faceting
        p <- ggplot2::ggplot(df, ggplot2::aes(x = !!rlang::sym(x_1), y = !!rlang::sym(x_2))) +
          ggplot2::geom_point(color = col_positive, alpha = 0.6) +
          ggplot2::geom_density_2d(color = col_primary, linewidth = 0.7) +
          ggplot2::scale_fill_viridis_d(option = "plasma") +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.grid.major = ggplot2::element_blank(),
            panel.grid.minor = ggplot2::element_blank(),
            axis.text = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text, face = "bold"),
            plot.title = ggplot2::element_text(color = col_text, size = 18, face = "bold", hjust = 0),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 10, face = "italic", hjust = 0),
            legend.position = "bottom",                     # Place legend at the bottom
            legend.title = ggplot2::element_text(color = col_text),
            legend.text = ggplot2::element_text(color = col_text)  # Set legend text color to white
          ) +
          ggplot2::labs(
            title = paste("2D Density Plot of", x_1, "and", x_2),
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = x_1,
            y = x_2
          )
      } else {
        # Faceted 2D density plot by each category in clustering_variables
        p <- ggplot2::ggplot(df, ggplot2::aes(x = !!rlang::sym(x_1), y = !!rlang::sym(x_2))) +
          ggplot2::geom_point(color = col_positive, alpha = 0.6) +
          ggplot2::geom_density_2d(color = col_primary, linewidth = 0.7) +
          ggplot2::facet_wrap(ggplot2::vars(!!!rlang::syms(clustering_variables)), scales = "free") +
          ggplot2::scale_fill_viridis_d(option = "plasma") +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.grid.major = ggplot2::element_blank(),
            panel.grid.minor = ggplot2::element_blank(),
            axis.text = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text, face = "bold"),
            plot.title = ggplot2::element_text(color = col_text, size = 18, face = "bold", hjust = 0),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 10, face = "italic", hjust = 0),
            legend.position = "bottom",                       # Place legend at the bottom
            legend.title = ggplot2::element_text(color = col_text),
            legend.text = ggplot2::element_text(color = col_text), # Set legend text color to white
            strip.text = ggplot2::element_text(color = col_text)  # Facet label text color
          ) +
          ggplot2::labs(
            title = paste("2D Density Plot of", x_1, "and", x_2, "by", paste(clustering_variables, collapse = ", ")),
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = x_1,
            y = x_2
          )
      }

      print(p)
    }

    #Correlogram
    if (type == "correlogram") {
      # Check if variables are provided
      if (is.null(variable) || length(variable) < 2) {
        stop("Please provide at least two variables in 'variable' for the correlogram.")
      }

      # Check for clustering variables and adapt accordingly
      if (!is.null(clustering_variables)) {

        unique_clusters <- unique(df[[clustering_variables]])

        # Initialize a list to store correlation data
        corr_data_all <- data.frame()

        # Loop over each unique value of clustering variable
        for (cluster in unique_clusters) {
          df_cluster <- dplyr::filter(df, !!rlang::sym(clustering_variables) == cluster)

          # Check if df_cluster contains the specified variables
          if (all(variable %in% colnames(df_cluster)) && nrow(df_cluster) > 0) {
            # Calculate correlation matrix for the specific cluster
            corr_matrix <- stats::cor(df_cluster[variable], use = "pairwise.complete.obs")
            corr_data <- as.data.frame(as.table(corr_matrix)) %>%
              dplyr::rename(Var1 = Var1, Var2 = Var2, Correlation = Freq) %>%
              dplyr::filter(as.numeric(factor(Var1)) < as.numeric(factor(Var2))) %>%
              dplyr::mutate(Cluster = as.factor(cluster))  # Add cluster label

            # Combine data for all clusters
            corr_data_all <- rbind(corr_data_all, corr_data)
          } else {
            message(paste("Skipping cluster", cluster, "- No data available for the specified variables"))
          }
        }

        # Plotting with facet_wrap for each cluster
        if (nrow(corr_data_all) > 0) {

          p <- ggplot2::ggplot(data = corr_data_all) +
            ggplot2::geom_tile(
              ggplot2::aes(x = Var1, y = Var2, fill = Correlation),
              color = col_text
            ) +
            ggplot2::geom_text(
              ggplot2::aes(x = Var1, y = Var2, label = sprintf("%.2f", Correlation)),
              color = col_text, size = 4
            ) +
            ggplot2::scale_fill_gradient2(
              low = col_negative,
              mid = if (palette %in% c("br", "journal")) "#EBEEF1" else "#8A03C9",
              high = col_positive, midpoint = 0,
              limits = c(-1, 1), guide = ggplot2::guide_colorbar(title = "Correlation")
            ) +
            ggplot2::theme_minimal() +
            ggplot2::theme(
              plot.background = ggplot2::element_rect(fill = col_background, color = NA),
              panel.background = ggplot2::element_rect(fill = col_background, color = NA),
              panel.grid = ggplot2::element_blank(),
              axis.text = ggplot2::element_text(color = col_text),
              axis.title = ggplot2::element_text(color = col_text, face = "bold"),
              plot.title = ggplot2::element_text(color = col_text, size = 20, face = "bold", hjust = 0),
              plot.subtitle = ggplot2::element_text(color = col_text, size = 12, face = "italic"),
              legend.position = "bottom",
              legend.title = ggplot2::element_text(color = col_text),
              legend.text = ggplot2::element_text(color = col_text),
              strip.text = ggplot2::element_text(color = col_text, size = 9, face = "bold")  # Smaller titles for each facet
            ) +
            ggplot2::labs(
              title = "Correlogram",
              subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
              x = NULL, y = NULL
            ) +
            ggplot2::facet_wrap(
              ~ Cluster,
              scales = "free",
              labeller = ggplot2::labeller(
                Cluster = function(x) {
                  if (clustering_variables == "dates") {
                    format(as.Date(as.numeric(x), origin = "1970-01-01"), "%b %Y")
                  } else {
                    x
                  }
                }
              )
            )  # Custom labels for each cluster

          print(p)
        } else {
          stop("No valid data available for any of the clusters.")
        }

      } else {
        # Single correlogram code
        corr_matrix <- stats::cor(df[variable], use = "pairwise.complete.obs")
        corr_data <- as.data.frame(as.table(corr_matrix)) %>%
          dplyr::rename(Var1 = Var1, Var2 = Var2, Correlation = Freq) %>%
          dplyr::filter(as.numeric(factor(Var1)) < as.numeric(factor(Var2)))

        # Plotting
        p <- ggplot2::ggplot(data = corr_data) +
          ggplot2::geom_tile(
            ggplot2::aes(x = Var1, y = Var2, fill = Correlation),
            color = col_text
          ) +
          ggplot2::geom_text(
            ggplot2::aes(x = Var1, y = Var2, label = sprintf("%.2f", Correlation)),
            color = col_text, size = 4
          ) +
          ggplot2::scale_fill_gradient2(
            low = col_negative,
            mid = if (palette %in% c("br", "journal")) "#EBEEF1" else "#8A03C9",
            high = col_positive, midpoint = 0,
            limits = c(-1, 1), guide = ggplot2::guide_colorbar(title = "Correlation")
          ) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.grid = ggplot2::element_blank(),
            axis.text = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text, face = "bold"),
            plot.title = ggplot2::element_text(color = col_text, size = 18, face = "bold", hjust = 0),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 12, face = "italic"),
            legend.position = "bottom",
            legend.title = ggplot2::element_text(color = col_text),
            legend.text = ggplot2::element_text(color = col_text)
          ) +
          ggplot2::labs(
            title = "Correlogram",
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = NULL, y = NULL
          )

        print(p)
      }
    }

    # Radar Plot
    if (type == "radar") {
      if (is.null(variable) || length(variable) < 1) {
        stop("Please specify at least one variable for the radar plot.")
      }

      # Ensure clustering variables are set appropriately
      if (is.null(clustering_variables)) {
        stop("clustering_variables can't be missing when type = 'radar'.")  # Default value if not provided
      }

      # Save current graphical parameters
      old_par <- graphics::par(no.readonly = TRUE)

      # Set global graphical parameters for your plot
      if (palette == "br"){
        graphics::par(fg = "#003641", col.axis = "#003641", col.lab = "#003641",
                      col.main = "#003641", col.sub = "#003641", bg = col_background)
      } else if (palette == "journal"){
        graphics::par(fg = jp$text, col.axis = jp$text, col.lab = jp$text,
                      col.main = jp$text, col.sub = jp$text, bg = col_background)
      } else {
        graphics::par(fg = "white", col.axis = "white", col.lab = "white",
                      col.main = "white", col.sub = "white", bg = col_background)
      }

      # Prepare the data for the radar plot
      df_radar <- df %>%
        dplyr::select(!!rlang::sym(clustering_variables), !!!rlang::syms(variable)) %>%
        dplyr::group_by(!!rlang::sym(clustering_variables)) %>%
        dplyr::summarize(dplyr::across(dplyr::where(is.numeric), ~ mean(., na.rm = TRUE)), .groups = "drop")  # Calculate mean, ignoring NAs

      # Dynamically filter out rows with NA or NaN values for specified variables
      na_filter <- purrr::reduce(variable, function(acc, var) {
        acc & !is.na(df_radar[[var]]) & !is.nan(df_radar[[var]])
      }, .init = TRUE)

      df_radar <- df_radar[na_filter, ]  # Apply the filter

      # Check if there's data available for the radar plot
      if (nrow(df_radar) == 0) {
        stop("No data available for the specified clustering variables and variable.")
      }

      # Normalize the data
      df_radar <- df_radar %>%
        dplyr::mutate(dplyr::across(dplyr::where(is.numeric), ~ ( . - min(., na.rm = TRUE)) / ( max(., na.rm = TRUE) - min(., na.rm = TRUE))))  # Normalization

      # Ensure the first column is treated as a factor for the radar chart
      df_radar[[clustering_variables]] <- as.character(df_radar[[clustering_variables]])

      # Prepare the data frame for the radar chart
      max_row <- as.data.frame(t(rep(1, length(variable))))  # Row of maximum values
      min_row <- as.data.frame(t(rep(0, length(variable))))  # Row of minimum values
      actual_data <- df_radar %>% dplyr::select(!!!rlang::syms(variable))  # Actual data for the radar plot

      # Set column names for max_row and min_row to match the actual data
      colnames(max_row) <- variable
      colnames(min_row) <- variable

      # Combine into one data frame
      df_radar_chart <- rbind(max_row, min_row, actual_data)

      # Set the colors for each row (example: generate colors)
      num_rows <- nrow(actual_data)
      colors <- if (palette %in% c("br", "journal")) {

        br_palette[seq_len(num_rows)]

      } else {

        scales::hue_pal()(num_rows)

      }  # Generate distinct colors for each row

      # Set background color
      graphics::par(bg = col_background)  # Set background color to col_background

      # Create the radar plot using fmsb
      if (!requireNamespace("fmsb", quietly = TRUE)) {
        stop("The 'fmsb' package is required for radar plots. Please install it.")
      }

      fmsb::radarchart(df_radar_chart, axistype = 1,
                       pcol = colors, pfcol = scales::alpha(colors, 0.5), plwd = 2, plty = 1,
                       axislabcol = col_text
                       # Set the main title color to white
      )

      # Title
      graphics::mtext(side = 3, line = 2.5, adj = 0, cex = 1.25,  # Align to the left
                      paste("Radar Plot of", paste(variable, collapse = ", "), "by", clustering_variables),
                      font = 2, col = col_text)

      # Subtitle
      graphics::mtext(side = 3, line = 1, adj = 0, cex = 0.75,  # Align to the left
                      paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
                      font = 2, col = col_text)


      # Add legend with white text color at the bottom
      graphics::legend("bottomleft", legend = df_radar[[clustering_variables]], col = colors, pch = 16, bty = "n", text.col = col_text)

      # Restore the original graphical parameters
      graphics::par(old_par)

    }



    # Waterfall Plot
    if (type == "waterfall") {

      # Check variables
      if (is.null(variable) || length(variable) < 2) {
        stop("Please specify at least two numeric variables for the waterfall plot.")
      }

      # Check all variables are present and numeric
      if (!all(variable %in% names(df))) {
        stop("Some specified variables not found in the dataframe.")
      }

      # Check numeric
      if (any(!sapply(variable, function(v) is.numeric(df[[v]])))) {
        stop("All variables must be numeric for the waterfall plot.")
      }

      # Check clustering_variables
      if (is.null(clustering_variables) || length(clustering_variables) == 0) {
        clustering_variables <- "tickers"
      }

      # If calc_stat is not specified, use sum by default
      if (is.null(calc_stat)) {
        calc_stat <- "sum"
      }

      # Define the function for calc_stat
      FUN <- switch(calc_stat,
                    mean = function(x) mean(x, na.rm = TRUE),
                    sd = function(x) sd(x, na.rm = TRUE),
                    median = function(x) median(x, na.rm = TRUE),
                    min = function(x) min(x, na.rm = TRUE),
                    max = function(x) max(x, na.rm = TRUE),
                    sum = function(x) sum(x, na.rm = TRUE),
                    stop("Invalid calc_stat for waterfall plot. Please use sum, mean, sd, median, min, or max.")
      )

      # Aggregate data by clustering variables and apply FUN to each variable
      agg_data <- df %>%
        dplyr::group_by(dplyr::across(dplyr::all_of(clustering_variables))) %>%
        dplyr::summarize(dplyr::across(dplyr::all_of(variable), FUN), .groups = "drop")

      if (nrow(agg_data) == 0) {
        stop("No data available for the specified filters.")
      }

      # Pivot from wide to long so that each chosen variable is now a row called "Component"
      agg_long <- agg_data %>%
        tidyr::pivot_longer(cols = dplyr::all_of(variable), names_to = "Component", values_to = "Value")

      # Make Component a factor with the order given by the user
      agg_long <- agg_long %>%
        dplyr::mutate(Component = factor(Component, levels = variable))

      # Now compute the cumulative sums by each cluster combination, in the order of "Component"
      # Group by clustering_variables (the facets), and then arrange by Component to ensure correct order
      agg_long <- agg_long %>%
        dplyr::group_by(dplyr::across(dplyr::all_of(clustering_variables))) %>%
        dplyr::arrange(Component, .by_group = TRUE) %>%
        dplyr::mutate(
          Cumulative_Start = dplyr::lag(cumsum(Value), default = 0),
          Cumulative_End = Cumulative_Start + Value,
          Sign = ifelse(Value >= 0, "Positive", "Negative")
        ) %>%
        dplyr::ungroup()

      # Choose colors for positive and negative contributions
      pos_color <- col_positive
      neg_color <- col_negative

      # If we have more than one clustering variable, we facet by them
      # If we have just one, it's still a single facet but shows a single plot
      # The x-axis now is Component
      main_plot <- ggplot2::ggplot(agg_long, ggplot2::aes(x = Component, ymin = Cumulative_Start, ymax = Cumulative_End, fill = Sign)) +
        ggplot2::geom_rect(
          xmin = as.numeric(agg_long$Component) - 0.4,
          xmax = as.numeric(agg_long$Component) + 0.4,
          color = black
        ) +
        ggplot2::scale_fill_manual(values = c(Positive = pos_color, Negative = neg_color)) +
        ggplot2::geom_hline(yintercept = 0, color = col_text, linetype = "dashed") +
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.grid.major = ggplot2::element_blank(),
          panel.grid.minor = ggplot2::element_blank(),
          axis.text = ggplot2::element_text(color = col_text),
          axis.title = ggplot2::element_text(color = col_text),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic"),
          legend.position = "bottom",
          legend.title = ggplot2::element_text(color = col_text),
          legend.text = ggplot2::element_text(color = col_text),
          strip.text = ggplot2::element_text(color = col_text)
        ) +
        ggplot2::labs(
          title = paste("Waterfall Plot of", paste(variable, collapse = ", "), "Components"),
          subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
          x = "Components",
          y = paste(calc_stat, "of", paste(variable, collapse = ", ")),
          fill = "Contribution"
        )

      # If more than one clustering variable, facet by them
      # If exactly one clustering variable, it will just show one facet (one plot)
      if (length(clustering_variables) > 1) {
        facet_clusters <- clustering_variables
        main_plot <- main_plot + ggplot2::facet_wrap(facets = facet_clusters, scales = "free_x")
      } else if (length(clustering_variables) == 1) {
        # One clustering variable means multiple categories produce multiple rows.
        main_plot <- main_plot + ggplot2::facet_wrap(facets = clustering_variables, scales = "free_x")
      }
      print(main_plot)
    }

    # Tile Heatmap
    if (type == "tile_heatmap") {

      # Ensure 'variable' is specified and is numeric
      if (is.null(variable) || length(variable) != 1) {
        stop("Please specify exactly one numeric 'variable' for the tile heatmap plot.")
      }

      # Determine y-axis variable based on clustering_variables
      if (!is.null(clustering_variables) && length(clustering_variables) > 0) {
        # Check if clustering_variables exist in the dataframe
        missing_vars <- setdiff(clustering_variables, names(df))
        if (length(missing_vars) > 0) {
          stop("The following clustering_variables are missing from the dataframe: ", paste(missing_vars, collapse = ", "))
        }
        y_vars <- clustering_variables
      } else {
        y_vars <- "tickers"
        if (!"tickers" %in% names(df)) {
          stop("'tickers' column is not present in the dataframe, and clustering_variables is NULL.")
        }
      }

      # Create an interaction term if multiple clustering variables are provided
      if (length(y_vars) > 1) {
        df <- df %>%
          dplyr::mutate(Cluster = interaction(!!!rlang::syms(y_vars), sep = "_"))
      } else {
        df <- df %>%
          dplyr::mutate(Cluster = !!rlang::sym(y_vars))
      }

      # Group by Cluster and Dates, then apply calc_stat on variable if numeric
      if(is.numeric(df[[variable]])){
        df_summary <- df %>%
          dplyr::group_by(Cluster, dates) %>%
          dplyr::summarize(
            Calc_Stat = FUN(!!rlang::sym(variable)),
            .groups = "drop"
          )

        # Check if there are valid rows to process
        if (nrow(df_summary) == 0) stop("No data available after filtering or summarization.")

        # Define the number of bins and labels based on numeric_aggregation
        bins <- switch(numeric_aggregation,
                       decile = 10,
                       quartile = 4,
                       tercile = 3,
                       median = 2,
                       stop("Invalid numeric_aggregation. Choose from 'decile', 'quartile', 'tercile', or 'median'."))

        label_list <- switch(numeric_aggregation,
                             decile = sprintf("D%02d", 1:10),
                             quartile = sprintf("Q%02d", 1:4),
                             tercile = sprintf("T%02d", 1:3),
                             median = c("Below_Median", "Above_Median"))


        # Categorize each Cluster by Calc_Stat for each date
        df_summary <- df_summary %>%
          dplyr::group_by(dates) %>%
          dplyr::mutate(
            bin = dplyr::ntile(Calc_Stat,
                               switch(numeric_aggregation,
                                      decile = 10,
                                      quartile = 4,
                                      tercile = 3,
                                      median = 2)),
            bin_label = dplyr::case_when(
              numeric_aggregation == "decile" ~ sprintf("D%02d", bin),
              numeric_aggregation == "quartile" ~ sprintf("Q%02d", bin),
              numeric_aggregation == "tercile" ~ sprintf("T%02d", bin),
              numeric_aggregation == "median" ~ ifelse(bin == 1, "Below_Median", "Above_Median")
            )
          ) %>%
          dplyr::ungroup()

        # Color palette for bins
        if (palette == "br"){
          color_palette <- c("#49479D", "#4C7C83", "#00C9B8", "#00AE9D", "#94E1D6", "#EBEEA8", "#EBEEA8", "#D6E266", "#A5CD5C", "#7DB61C")
        } else if (palette == "journal"){
          ### Ordered bins get the sequential ramp (light-to-dark blue)
          color_palette <- grDevices::colorRampPalette(jp$sequential)(10)
        } else {
          color_palette <- c(vibrant_purple, cyan, neon_green, neon_yellow, neon_yellow, neon_yellow, neon_orange, neon_red, neon_pink, "#E75480")
        }

        # Create the plot
        color_palette <- rep(color_palette, length.out = bins)
        p <- ggplot2::ggplot(df_summary, ggplot2::aes(x = dates, y = Cluster, fill = bin_label)) +
          ggplot2::geom_tile(color = col_text) +
          ggplot2::scale_fill_manual(
            values = setNames(color_palette, label_list),
            na.value = "grey50"
          ) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            axis.text.x = ggplot2::element_text(color = col_text, angle = 45, hjust = 1),
            axis.text.y = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text),
            plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 12, face = "italic"),
            legend.position = "bottom",
            legend.title = ggplot2::element_text(color = col_text),
            legend.text = ggplot2::element_text(color = col_text),
            panel.grid = ggplot2::element_blank()
          ) +
          ggplot2::labs(
            title = paste("Tile Heatmap of", variable," by dates and", clustering_variables),
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = "Dates",
            y = clustering_variables,
            fill = variable
          )
      } else {
        #Treatment for character
        df_summary <- df %>% dplyr::select(Cluster, dates, !!rlang::sym(variable)) %>% dplyr::rename(bin_label = !!rlang::sym(variable))
        # Color palette for bins
        if (palette == "br"){
          color_palette <- c("#7DB61C", "#A5CD5C",  "#EBEEA8","#94E1D6", "#00C9B8")
        } else if (palette == "journal"){
          color_palette <- jp$categorical[1:5]
        } else {
          color_palette <- c(cyan, neon_green, vibrant_purple, neon_pink, vibrant_purple)
        }
        # Define theme colors based on common labels for character variables
        if (all(df_summary$bin_label %in% c("elected", "not_elected"))){
          theme_colors <- c("not_elected" = col_negative, "elected" = col_positive)
        } else {
          unique_labels <- unique(df_summary$bin_label)
          theme_colors <- stats::setNames(color_palette[seq_along(unique_labels)], unique_labels)
        }


        # Create the plot
        p <-
          ggplot2::ggplot(df_summary, ggplot2::aes(x = dates, y = Cluster, fill = bin_label)) +
          ggplot2::geom_tile(color = col_text) +
          ggplot2::scale_fill_manual(
            values = theme_colors,
            na.value = "grey50"
          ) +
          ggplot2::theme_minimal() +
          ggplot2::theme(
            plot.background = ggplot2::element_rect(fill = col_background, color = NA),
            panel.background = ggplot2::element_rect(fill = col_background, color = NA),
            axis.text.x = ggplot2::element_text(color = col_text, angle = 45, hjust = 1),
            axis.text.y = ggplot2::element_text(color = col_text),
            axis.title = ggplot2::element_text(color = col_text),
            plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
            plot.subtitle = ggplot2::element_text(color = col_text, size = 12, face = "italic"),
            legend.position = "bottom",
            legend.title = ggplot2::element_text(color = col_text),
            legend.text = ggplot2::element_text(color = col_text),
            panel.grid = ggplot2::element_blank()
          ) +
          ggplot2::labs(
            title = paste("Tile Heatmap of", variable, "by dates and", clustering_variables),
            subtitle = paste(date_range_text, ifelse(tickers_text != "", paste("|", tickers_text), "")),
            x = "Dates",
            y = clustering_variables,
            fill = variable
          )
      }
      print(p)
    }

    # Frequency
    if (type == "frequency") {

      # Identify categorical columns (excluding 'id', 'tickers', and 'dates')
      categorical_cols <- sapply(df, function(col) is.factor(col) || is.character(col))
      categorical_data <- df[, categorical_cols, drop = FALSE]
      categorical_data <- categorical_data[, !(names(categorical_data) %in% c("id", "tickers", "dates")), drop = FALSE]

      if (!is.null(categorical_data) && ncol(categorical_data) > 0) {
        for (col_name in names(categorical_data)) {
          col_data <- categorical_data[[col_name]]
          freq_table <- as.data.frame(table(col_data, useNA = "ifany"))
          names(freq_table) <- c("Category", "Frequency")

          # Create a bar plot using the specified colors
          plot <- ggplot2::ggplot(freq_table, ggplot2::aes(x = stats::reorder(Category, -Frequency), y = Frequency)) +
            ggplot2::geom_bar(stat = "identity", fill = col_primary, color = col_text, size = 0.5) +
            ggplot2::geom_text(ggplot2::aes(label = Frequency), vjust = -0.5, color = col_text, size = 4) +
            ggplot2::theme_minimal() +
            ggplot2::theme(
              plot.background = ggplot2::element_rect(fill = col_background, color = NA),    # Deep Navy background outside plot area
              panel.background = ggplot2::element_rect(fill = col_background, color = NA),   # Blue background inside plot area
              panel.grid.major = ggplot2::element_blank(),                              # Remove major grid lines
              panel.grid.minor = ggplot2::element_blank(),                              # Remove minor grid lines
              axis.text = ggplot2::element_text(color = col_text),
              axis.title = ggplot2::element_text(color = col_text),
              axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),
              plot.title = ggplot2::element_text(size = 16, face = "bold", color = col_text, hjust = 0.5),
              plot.caption = ggplot2::element_text(color = col_text),
              legend.position = "none"
            ) +
            ggplot2::labs(
              title = paste(x@meta_dataframe_name, ": Frequency Plot for", col_name),
              x = col_name,
              y = "Frequency"
            ) +
            ggplot2::expand_limits(y = max(freq_table$Frequency) * 1.1)  # Add more space above bars

          # Display the plot
          print(plot)
        }
      } else {
        cat("\nNo additional categorical columns to plot.\n")
      }


    }

  }

)

#' @title Plot Method for meta_xts
#' @description
#' Plots time series or performance summaries from a `meta_xts` (or subclass) object using `ggplot2`.
#' Offers interactive prompts for series selection, cumulative return computation, faceting, and more.
#'
#' @details
#' The function behaves differently depending on whether the object is a subclass like `returns_meta_xts`.
#' It includes:
#' \enumerate{
#'   \item Interactive column selection.
#'   \item Optional performance metric visualization for returns objects.
#'   \item Optional cumulative return computation.
#'   \item Option to facet plots by year.
#'   \item Option to overlay horizontal mean lines.
#'   \item Option to add vertical reference lines.
#'   \item Neon color palette and dark theme styling.
#' }
#'
#' @param x A `meta_xts` or subclass object to be plotted.
#' @param y Not used. Included for S4 method compatibility.
#' @param clustering_list Optional named list assigning column names to cluster groups. Used to vary linetype by group.
#' @param facet_by_year Logical. Whether to facet plots by calendar year. If `NULL`, user is prompted interactively.
#' @param add_overall_means Logical. Whether to add dashed horizontal lines representing series-wide means.
#' Only applies if `cumulative = FALSE`. If `NULL`, user is prompted.
#' @param vertical_lines Optional vector of Dates or POSIXct timestamps at which to draw vertical dashed lines.
#' @param cumulative Logical. If `TRUE` and object is of class `returns_meta_xts`, plots cumulative returns (in %). If `NULL`, prompts the user.
#' @param plot_perf_metric Logical. For `returns_meta_xts` only. If `TRUE`, plots bar chart of selected performance metric instead of time series. If `NULL`, user is prompted.
#' @param benchmark_returns_m_xts Optional `meta_xts` object (single-column) with benchmark returns. Required if `active_returns = TRUE`.
#' @param active_returns Logical or `"yes"/"no"` string. Whether to compute active returns relative to the benchmark when `plot_perf_metric = TRUE`.
#' @param variable Variable to plot. If `NULL`, user is prompted to select from available columns.
#' @param chosen_metric Character. Performance metric to plot when `plot_perf_metric = TRUE`. Options include "CAGR", "Volatility", "Sharpe Ratio", etc. If `NULL`, user is prompted.
#' @param palette Character. One of `"cyberpunk"` (default; dark background,
#'   neon series colors), `"br"` (light background, brand palette) or
#'   `"journal"` (white background, sober print-oriented colours).
#' @param ... Currently unused.
#'
#' @return Invisibly returns the generated `ggplot` object.
#'
#' @section Requirements:
#' Requires the suggested packages `gridExtra`, `scales`, `ggdist`, `ggraph`,
#' `ggrepel`, `igraph`, and `RColorBrewer`; if any are missing, an informative
#' `stop()` is raised rather than a cryptic failure.
#'
#' @section Interactivity:
#' Any of `variable`, `facet_by_year`, `cumulative`, `plot_perf_metric`,
#' `active_returns`, or `chosen_metric` left as `NULL` triggers an interactive
#' `readline()` prompt. Supply all of them explicitly to use this method in
#' non-interactive contexts (scripts, `knitr`, tests).
#'
#' @seealso [create_performance_m_df()]
#'
#' @rdname plot_meta_xts
#' @export
setMethod("plot", signature = c(x = "meta_xts", y = "missing"),
          function(x, y, variable = NULL, clustering_list = NULL, facet_by_year = NULL,
                   add_overall_means = NULL, vertical_lines = NULL, cumulative = NULL,
                   plot_perf_metric = NULL, benchmark_returns_m_xts = NULL, active_returns = FALSE,
                   chosen_metric = NULL,
                   palette = "cyberpunk", ...) {

            # Check for required packages for plotting
            required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

            missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

            if (length(missing_pkgs) > 0) {
              stop(
                sprintf(
                  "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
                  paste(missing_pkgs, collapse = ", ")
                ),
                call. = FALSE
              )
            }

            # Palette
            black <- "#000000"
            white <- "#FFFFFF"

            if (palette == "cyberpunk") {

              light_gray <- "#003641"

              col_background <- "#001f3f"
              col_text       <- "#FFFFFF"
              col_primary    <- "#6A0DAD"
              col_positive   <- "#39FF14"
              col_negative   <- "#FF5F1F"
              vertical_line_color <- "#FF69B4"

              palette_colors  <- c(
                "#00BFFF", "#FF1493", "#FFFF00", "#8A2BE2",
                "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500"
              )

            }
            if (palette == "br") {

              light_gray <- "#EBEEF1"

              col_background <- "#FFFFFF"
              col_text       <- "#003641"
              col_primary   <- "#00A091"
              col_positive   <- "#7DB61C"
              col_negative   <- "#C2185B"
              vertical_line_color <- "#003641"

              palette_colors  <- c(
                "#94E1D6","#49479D","#7DB61C",
                "#00C9B8", "#98B2B6","#C9D200",
                "#003641", "#00A091", "#4C7C83",
                "#FF5F1F", "#EBEEA8", "#A5CD5C",
                "#8A03C9", "#00AE9D", "#EBEEA8",
                "#D6E266", "#00C9B8", "#7DB61C",
                "#A5CD5C", "#003641", "#00A091",
                "#4C7C83", "#FF5F1F"
              )

            }
            if (palette == "journal") {

              jp <- .journal_palette()

              light_gray <- jp$grid

              col_background <- jp$background
              col_text       <- jp$text
              col_primary    <- jp$primary
              col_positive   <- jp$positive
              col_negative   <- jp$negative
              vertical_line_color <- jp$text

              ### Recycle the eight journal hues to match the br palette length
              palette_colors <- rep(jp$categorical, length.out = 23)

            }


            #Prompt for column selection
            # Get available column names
            cols <- colnames(x@data)

            # Display available options to the user
            numbered_cols <- paste0(seq_along(cols), ": ", cols)
            message("Available columns:\n", crayon::white(paste(numbered_cols, collapse = "\n")))

            # Prompt the user interactively
            if (is.null(variable)){
              input <- readline(prompt = "Enter column names or numbers separated by commas or 'all' for all columns: ")

              # Remove any leading/trailing whitespace
              input <- base::trimws(input)

              # If user types 'all', return all columns
              if (tolower(input) %in% c("all", "")) {
                selected_cols <- cols
              } else {
                # Split the input by commas and trim whitespace on each token
                tokens <- unlist(base::strsplit(input, split = ","))
                tokens <- base::trimws(tokens)

                # Initialize vector to store the selected column names
                selected_cols <- character(0)

                for (token in tokens) {
                  # Try converting token to numeric. If it is numeric, use it as an index.
                  num_token <- suppressWarnings(as.numeric(token))

                  if (!is.na(num_token)) {
                    # Check if the index is within the valid range.
                    if (num_token < 1 || num_token > base::length(cols)) {
                      stop("The column index ", token, " is out of range. Available indices are 1 to ", base::length(cols), ".")
                    }
                    selected_cols <- c(selected_cols, cols[num_token])
                  } else {
                    # If not numeric, assume token is a column name.
                    if (!(token %in% cols)) {
                      stop("The column name '", token, "' does not exist in the data.")
                    }
                    selected_cols <- c(selected_cols, token)
                  }
                }
              }
            } else {
              selected_cols <- variable
            }

            # Ask user if they want to facet by year if the argument is not provided
            if (is.null(facet_by_year)) {
              if (is.null(vertical_lines)) {
                response_facet <- readline(prompt = "Do you want to facet the plot by year? (yes/no): ")
                facet_by_year <- tolower(response_facet) == "yes"
              } else {
                message("Faceting by year is disabled when vertical lines are specified to avoid clutter.")
                facet_by_year <- FALSE
              }
            }

            #Check if there is more than one year in the data. If not, go back to FALSE if user said TRUE
            if (facet_by_year && length(unique(lubridate::year(zoo::index(x@data)))) <= 1) {
              message("Faceting by year is not possible because there is only one year in the data. Disabling faceting.")
              facet_by_year <- FALSE
            }

           #Filter xts
            x@data <- x@data[, selected_cols]

            # If x is returns_meta_xts, decide if user wants to plot performance metric
            is_returns_xts <- methods::is(x, "returns_meta_xts")

            if (is_returns_xts) {
              if (is.null(plot_perf_metric) && length(unique(lubridate::year(zoo::index(x@data)))) > 1) {
                resp_perf <- readline(prompt = "Do you want to plot a performance metric? (yes/no): ")
                plot_perf_metric <- tolower(resp_perf) == "yes"
              }
            } else {
              # If not returns_meta_xts, ignore
              plot_perf_metric <- FALSE
            }

            if (plot_perf_metric) {
              #Check benchmark_returns_m_xts
              if (!is.null(benchmark_returns_m_xts) && !methods::is(benchmark_returns_m_xts, "meta_xts")) {
                stop("benchmark_returns_m_xts must be a meta_xts object.")
              }

              # Prompt for active_returns
              if (is.null(active_returns)){
                active_returns <- readline(prompt = "Compute active returns relative to the benchmark? (yes/no): ")
                if (active_returns == "yes") {
                  if (is.null(benchmark_returns_m_xts)){
                    stop("You must provide a 'benchmark_returns_m_xts' object to compute active returns.")
                  }
                  if (ncol(benchmark_returns_m_xts@data) > 1){
                    stop("The 'benchmark_returns_m_xts' object must have only one column.")
                  }
                  active_returns <- TRUE
                } else {
                  active_returns <- FALSE
                }
              }

              #Full sample performance metric
              if (!isTRUE(facet_by_year)){

                # Generate performance data
                performance_df <- create_performance_m_df(
                  selected_backtest_returns_corrected_positions_m_xts_upd_ref = x@data,
                  selected_market_factor_proxy_m_xts_upd_ref = if (is.null(benchmark_returns_m_xts)) NULL else benchmark_returns_m_xts@data,
                  active_returns = active_returns,
                  verbose = TRUE
                )

                # Identify the unique tickers
                unique_tickers <- unique(performance_df$tickers)
                # Create a map from ticker -> integer
                ticker_map <- stats::setNames(seq_along(unique_tickers), unique_tickers)
                # Replace each ticker in performance_df with its numeric code
                performance_df$tickers <- ticker_map[performance_df$tickers]

                # Pivot to wide (tickers = columns), ignoring 'id'/'dates'
                perf_wide <- performance_df %>%
                  dplyr::select(-id, -dates) %>%
                  tidyr::pivot_longer(
                    cols = -tickers,
                    names_to = "metric",
                    values_to = "value"
                  ) %>%
                  tidyr::pivot_wider(
                    names_from = tickers,
                    values_from = value
                  )

                # Prompt user to pick a metric
                if (is.null(chosen_metric)){
                  all_metrics <- unique(perf_wide$metric)
                  cat("\nAvailable performance metrics:\n")
                  for (i in seq_along(all_metrics)) {
                    cat(i, ":", all_metrics[i], "\n")
                  }
                  sel <- readline(prompt = "Enter the number of your choice: ")
                  sel_num <- as.numeric(sel)
                  if (is.na(sel_num) || sel_num < 1 || sel_num > length(all_metrics)) {
                    stop("Invalid selection.")
                  }
                  chosen_metric <- all_metrics[sel_num]
                } else {
                  chosen_metric <- as.character(chosen_metric)
                  if (!chosen_metric %in% perf_wide$metric) {
                    stop("The specified 'chosen_metric' is not available in the performance data.")
                  }
                }

                # Subset data for that single metric
                metric_data <- perf_wide %>%
                  dplyr::filter(metric == chosen_metric) %>%
                  dplyr::select(-metric)

                # Convert to numeric vector with ticker columns
                #    One row, multiple columns
                # Ticker columns might be in alphabetical or original order
                # Gather them into a data.frame for ggplot
                metric_data_long <- metric_data %>%
                  tidyr::pivot_longer(
                    cols = -character(0),
                    names_to = "ticker",
                    values_to = "val"
                  )

                # Round data to 4 decimals
                metric_data_long$val <- round(metric_data_long$val, 4)

                # If there are more tickers than colors, repeat as needed
                color_mapping <- rep(palette_colors , length.out = nrow(metric_data_long))

                # ggplot bar chart
                #    x = ticker, y = val
                p <- ggplot2::ggplot(metric_data_long, ggplot2::aes(x = ticker, y = val, fill = ticker)) +
                  ggplot2::geom_bar(stat = "identity", color = col_text) +
                  ggplot2::scale_fill_manual(values = rep(palette_colors , length.out = length(unique(metric_data_long$ticker)))) +
                  ggplot2::theme_minimal() +
                  ggplot2::labs(
                    title = paste("Performance Metric:", chosen_metric),
                    x = "Series",
                    y = chosen_metric,
                    fill = "Series"
                  ) +
                  ggplot2::theme(
                    plot.background  = ggplot2::element_rect(fill = col_background, color = NA),
                    panel.background = ggplot2::element_rect(fill = col_background, color = NA),
                    plot.title       = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
                    axis.text        = ggplot2::element_text(color = col_text),
                    axis.title       = ggplot2::element_text(color = col_text),
                    legend.position  = "none",
                    panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
                    panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1)
                  )

                # Print plot
                print(p)
                # Print the mapping for reference
                cat("Legend:\n")
                for (original_name in names(ticker_map)) {
                  cat(ticker_map[original_name], ":", original_name, "\n")
                }
                return(invisible(p))


              } else {

                ##Facet by year
                years_available <- sort(unique(lubridate::year(zoo::index(x@data))))

                performance_list <- lapply(years_available, function(curr_year) {

                  year_idx <- lubridate::year(zoo::index(x@data)) == curr_year
                  x_year <- x@data[year_idx, , drop = FALSE]

                  if (nrow(x_year) == 0) {
                    return(NULL)
                  }

                  benchmark_year <- NULL
                  if (!is.null(benchmark_returns_m_xts)) {
                    benchmark_idx <- lubridate::year(zoo::index(benchmark_returns_m_xts@data)) == curr_year
                    benchmark_year <- benchmark_returns_m_xts@data[benchmark_idx, , drop = FALSE]
                  }

                  perf_year <- create_performance_m_df(
                    selected_backtest_returns_corrected_positions_m_xts_upd_ref = x_year,
                    selected_market_factor_proxy_m_xts_upd_ref = benchmark_year,
                    active_returns = active_returns,
                    verbose = FALSE
                  )

                  perf_year$year <- curr_year
                  perf_year
                })

                performance_df <- dplyr::bind_rows(performance_list)

                if (nrow(performance_df) == 0) {
                  stop("No yearly performance data could be computed.")
                }

                # Identify the unique tickers
                unique_tickers <- unique(performance_df$tickers)

                # Create a map from ticker -> integer
                ticker_map <- stats::setNames(seq_along(unique_tickers), unique_tickers)

                # Replace each ticker in performance_df with its numeric code
                performance_df$tickers <- ticker_map[performance_df$tickers]

                # Pivot to wide (tickers = columns), ignoring 'id'/'dates'
                perf_wide <- performance_df %>%
                  dplyr::select(-id, -dates) %>%
                  tidyr::pivot_longer(
                    cols = -c(tickers, year),
                    names_to = "metric",
                    values_to = "value"
                  ) %>%
                  tidyr::pivot_wider(
                    names_from = tickers,
                    values_from = value
                  )

                # Prompt user to pick a metric
                if (is.null(chosen_metric)) {
                  all_metrics <- unique(perf_wide$metric)
                  cat("\nAvailable performance metrics:\n")
                  for (i in seq_along(all_metrics)) {
                    cat(i, ":", all_metrics[i], "\n")
                  }
                  sel <- readline(prompt = "Enter the number of your choice: ")
                  sel_num <- as.numeric(sel)
                  if (is.na(sel_num) || sel_num < 1 || sel_num > length(all_metrics)) {
                    stop("Invalid selection.")
                  }
                  chosen_metric <- all_metrics[sel_num]
                } else {
                  chosen_metric <- as.character(chosen_metric)
                  if (!chosen_metric %in% perf_wide$metric) {
                    stop("The specified 'chosen_metric' is not available in the performance data.")
                  }
                }

                # Subset data for that single metric
                metric_data <- perf_wide %>%
                  dplyr::filter(metric == chosen_metric) %>%
                  dplyr::select(-metric)

                # Convert to long format while keeping year
                metric_data_long <- metric_data %>%
                  tidyr::pivot_longer(
                    cols = -year,
                    names_to = "ticker",
                    values_to = "val"
                  )

                # Round data to 4 decimals
                metric_data_long$val <- round(metric_data_long$val, 4)

                # ggplot bar chart with yearly facets
                p <- ggplot2::ggplot(metric_data_long, ggplot2::aes(x = ticker, y = val, fill = ticker)) +
                  ggplot2::geom_bar(stat = "identity", color = col_text) +
                  ggplot2::scale_fill_manual(values = rep(palette_colors, length.out = length(unique(metric_data_long$ticker)))) +
                  ggplot2::facet_wrap(~year, scales = "free_y") +
                  ggplot2::theme_minimal() +
                  ggplot2::labs(
                    title = paste("Performance Metric:", chosen_metric),
                    x = "Series",
                    y = chosen_metric,
                    fill = "Series"
                  ) +
                  ggplot2::theme(
                    plot.background  = ggplot2::element_rect(fill = col_background, color = NA),
                    panel.background = ggplot2::element_rect(fill = col_background, color = NA),
                    plot.title       = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
                    axis.text        = ggplot2::element_text(color = col_text),
                    axis.title       = ggplot2::element_text(color = col_text),
                    strip.text       = ggplot2::element_text(color = col_text, face = "bold"),
                    legend.position  = "none",
                    panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
                    panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1)
                  )

                # Print plot
                print(p)

                # Print the mapping for reference
                cat("Legend:\n")
                for (original_name in names(ticker_map)) {
                  cat(ticker_map[original_name], ":", original_name, "\n")
                }

                return(invisible(p))
              }

            } else {

              # If x is returns_meta_xts, ask about cumulative if not specified
              if (methods::is(x, "returns_meta_xts")) {
                # If user didn't specify 'cumulative', prompt them
                if (is.null(cumulative)) {
                  response_cum <- readline(prompt = "Do you want to plot cumulative returns? (yes/no): ")
                  cumulative <- tolower(response_cum) == "yes"
                }
              } else {
                # If x is not returns_meta_xts, ignore 'cumulative' (force it to FALSE)
                cumulative <- FALSE
              }

              # Ask user if they want to add overall mean lines if the argument is not provided
              if (is.null(add_overall_means)) {
                if (!cumulative) {
                  response_means <- readline(prompt = "Do you want to add overall mean lines? (yes/no): ")
                  add_overall_means <- tolower(response_means) == "yes"
                } else {
                  message("Overall mean lines are not meaningful when plotting cumulative returns, so they will not be added.")
                  add_overall_means <- FALSE
                }
              }


              # Extract slots
              frequency <- x@frequency
              metric_name <- x@metric_name
              main_xts <- x@data

              # Convert xts -> data frame -> long format
              df_data <- as.data.frame(main_xts)
              df_data$dates <- as.Date(zoo::index(main_xts))
              df_data$year <- lubridate::year(df_data$dates)

              # Convert to long format
              long_data <- tidyr::pivot_longer(
                df_data,
                cols = -c(dates, year),  # Keep date and year as identifiers
                names_to = "series",
                values_to = "value"
              ) %>% as.data.frame()


              # Sort by date to ensure correct plotting order
              long_data <- long_data[order(long_data$dates), ]

              # Validate user-specified dates for vertical lines
              if (!is.null(vertical_lines)) {
                if (!all(class(vertical_lines) %in% c("Date", "POSIXt"))) {
                  stop("The 'vertical_lines' argument must be a Date or POSIXct vector.")
                }
                vertical_lines <- as.Date(vertical_lines)  # Convert to Date if not already
              }

              # Remove missing values and single-observation series
              series_counts <- long_data %>%
                dplyr::group_by(series) %>%
                dplyr::summarize(non_na_count = sum(!is.na(value)), .groups = "drop")

              multi_obs_series <- series_counts %>%
                dplyr::filter(non_na_count > 1) %>%
                dplyr::pull(series)

              # Print series filtering
              if (length(multi_obs_series) < length(unique(long_data$series))) {
                warning(
                  sprintf(
                    "The following series have only one or zero non-NA observations and will be excluded from the plot: %s",
                    paste(setdiff(unique(long_data$series), multi_obs_series), collapse = ", ")
                  )
                )
              }

              plot_data_multi <- dplyr::filter(long_data, series %in% multi_obs_series & !is.na(value))

              # If cumulative = TRUE and x is returns_meta_xts, compute cumulative returns
              if (cumulative && methods::is(x, "returns_meta_xts")) {

                if (isTRUE(facet_by_year)){
                  # Restart cumulative returns from zero inside each year
                  plot_data_multi <- plot_data_multi %>%
                    dplyr::group_by(series, year) %>%
                    dplyr::arrange(dates, .by_group = TRUE) %>%
                    dplyr::mutate(value = (cumprod(1 + value/100) - 1) * 100) %>%
                    dplyr::ungroup()

                  # Add an anchor row at 0 for the start of each year
                  zero_rows <- plot_data_multi %>%
                    dplyr::group_by(series, year) %>%
                    dplyr::summarise(
                      dates = as.Date(paste0(dplyr::first(year), "-01-01")),
                      value = 0,
                      .groups = "drop"
                    )

                  plot_data_multi <- dplyr::bind_rows(plot_data_multi, zero_rows) %>%
                    dplyr::arrange(series, dates)

                } else {
                  # Transform each series by cumulative product
                  plot_data_multi <- plot_data_multi %>%
                    dplyr::group_by(series) %>%
                    dplyr::arrange(dates) %>%
                    dplyr::mutate(value = (cumprod(1 + value/100) - 1)*100) %>%
                    dplyr::ungroup()

                  # Add a zero anchor just before the first observed date of each series
                  zero_rows <- plot_data_multi %>%
                    dplyr::group_by(series) %>%
                    dplyr::summarise(
                      dates = dplyr::first(dates) - 1,
                      year  = lubridate::year(dplyr::first(dates) - 1),
                      value = 0,
                      .groups = "drop"
                    )

                  plot_data_multi <- dplyr::bind_rows(plot_data_multi, zero_rows) %>%
                    dplyr::arrange(series, dates)
                }

                # Also rename the y-label so user sees it's cumulative
                metric_name <- paste0("cumulative ", metric_name)
              }

              # Compute overall mean per series if requested
              if (add_overall_means) {
                overall_means <- plot_data_multi %>%
                  dplyr::group_by(series) %>%
                  dplyr::summarize(overall_mean = mean(value, na.rm = TRUE), .groups = "drop") %>%
                  dplyr::mutate(series = as.factor(series))
              }

              # Apply clustering if provided
              if (!is.null(clustering_list)) {
                plot_data_multi$group <- NA
                for (grp in names(clustering_list)) {
                  assigned_series <- clustering_list[[grp]]
                  plot_data_multi$group[plot_data_multi$series %in% assigned_series] <- grp
                }

                unique_groups <- unique(plot_data_multi$group)

                if (length(unique_groups) == 1) {
                  warning("Only one group detected, plotting without grouping.")
                  plot_data_multi$group <- plot_data_multi$series
                  linetype_legend_title <- NULL
                } else {
                  linetype_legend_title <- "Group"
                }
              } else {
                plot_data_multi$group <- plot_data_multi$series
                linetype_legend_title <- NULL
              }

              # Assign colors to series
              unique_series <- unique(plot_data_multi$series)
              color_mapping <- stats::setNames(rep(palette_colors, length.out = length(unique_series)), unique_series)

              # Create a mapping from unique series to numbers
              series_mapping <- stats::setNames(seq_along(unique(plot_data_multi$series)), unique(plot_data_multi$series))
              plot_data_multi$series <- factor(series_mapping[plot_data_multi$series])
              color_mapping <- color_mapping[names(series_mapping)]
              names(color_mapping) <- series_mapping

              # Create the ggplot object
              plot_obj <- ggplot2::ggplot(plot_data_multi, ggplot2::aes(
                x = dates,
                y = value,
                color = series,
                group = series
              )) +
                ggplot2::geom_line(size = 0.8, na.rm = TRUE) +
                ggplot2::labs(
                  title = paste("Time series of", metric_name, "for", frequency, "frequency"),
                  x = "Date",
                  y = metric_name,
                  color = "Series Label",
                  linetype = linetype_legend_title
                ) +
                ggplot2::scale_color_manual(values = color_mapping) +
                ggplot2::theme_minimal() +
                ggplot2::theme(
                  plot.background  = ggplot2::element_rect(fill = col_background, color = NA),
                  panel.background = ggplot2::element_rect(fill = col_background, color = NA),
                  plot.title       = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
                  axis.text        = ggplot2::element_text(color = col_text),
                  axis.title       = ggplot2::element_text(color = col_text),
                  legend.title     = ggplot2::element_text(color = col_text),
                  legend.text      = ggplot2::element_text(color = col_text),
                  panel.grid.major = ggplot2::element_line(color = col_background, size = 0.2),
                  panel.grid.minor = ggplot2::element_line(color = col_background, size = 0.1)
                ) +
                ggplot2::scale_x_date(labels = scales::date_format("%b-%y"))

              # Add faceting if enabled
              if (facet_by_year) {
                plot_obj <- plot_obj +
                  ggplot2::facet_wrap(~year, scales = "free") +
                  ggplot2::theme(
                    strip.text = ggplot2::element_text(color = col_text, face = "bold"),
                    legend.position = "right"
                  )
              }

              # Add overall mean lines if requested
              if (add_overall_means) {
                overall_means <- plot_data_multi %>%
                  dplyr::group_by(series) %>%
                  dplyr::summarize(overall_mean = mean(value, na.rm = TRUE), .groups = "drop")

                # Match the factor levels so geom_hline uses the same color mapping
                # 'series' in plot_data_multi is a factor with custom numeric labels, e.g. 1,2,3,...
                # Make sure overall_means$series has the exact same factor levels
                overall_means$series <- factor(overall_means$series,
                                               levels = levels(plot_data_multi$series))

                # Then add dashed lines colored by 'series'
                plot_obj <- plot_obj +
                  ggplot2::geom_hline(data = overall_means,
                                      ggplot2::aes(yintercept = overall_mean, color = series),
                                      linetype = "dashed", show.legend = FALSE)
              }

              # Add vertical dashed lines at specified timestamps
              if (!is.null(vertical_lines)) {
                # Create a data frame for annotations
                vline_data <- data.frame(
                  x = vertical_lines,
                  y = max(plot_data_multi$value, na.rm = TRUE) * 0.95,
                  label = format(vertical_lines, "%Y-%m-%d")
                )

                # Add vertical lines and their labels using geom_vline and geom_text
                plot_obj <- plot_obj +
                  ggplot2::geom_vline(xintercept = as.numeric(vertical_lines),
                                      linetype = "dashed", color = vertical_line_color, size = 0.5) +
                  ggplot2::geom_text(data = vline_data,
                                     ggplot2::aes(x = x, y = y, label = label),
                                     inherit.aes = FALSE,
                                     color = vertical_line_color,
                                     angle = 90,
                                     vjust = 0.5,
                                     size = 1)
              }

              # Print the legend mapping Backtest labels to identifiers
              cat("\nLegend:\n")
              for (i in seq_along(series_mapping)) {
                cat(paste(series_mapping[i], ":", names(series_mapping)[i], "\n"))
              }

              print(plot_obj)
              invisible(plot_obj)
            }
          })




#' @title Plot Method for `grid_search_strategy`
#' @description Plot the values selected for each hyperparameter in `hyper_grid_domain` for grid search strategy.
#' @param x An object of class `grid_search_strategy`.
#' @param y Unused. Included for consistency with the generic `plot` method.
#' @param palette Character. Color palette to use for the plot. Options include "cyberpunk", "br" and "journal". Default is "cyberpunk".
#' @return Invisibly returns the `ggplot` object visualizing the hyperparameter grid and its predefined limits (also printed as a side effect).
#' @section Requirements:
#' Requires the suggested packages `gridExtra`, `scales`, `ggdist`, `ggraph`,
#' `ggrepel`, `igraph`, and `RColorBrewer`; if any are missing, an informative
#' `stop()` is raised.
#' @export
setMethod("plot", signature(x = "grid_search_strategy", y = "missing"), function(x, y, palette = "cyberpunk") {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  # Define colors for plotting
  # Palette
  black <- "#000000"
  white <- "#FFFFFF"
  cyan <- "#00FFFF"


  if (palette == "cyberpunk") {

    light_gray <- "#003641"

    col_background <- "#001f3f"
    col_text       <- "#FFFFFF"
    col_primary    <- "#00FFFF"
    col_positive   <- "#39FF14"
    col_negative   <- "#FF1493"
    vertical_line_color <- "#FF69B4"

    palette_colors  <- c(
      "#00BFFF", "#FF1493", "#FFFF00", "#8A2BE2", "#00FFFF",
      "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500"
    )

  }
  if (palette == "br") {

    light_gray <- "#EBEEF1"

    col_background <- "#FFFFFF"
    col_text       <- "#003641"
    col_primary   <- "#00A091"
    col_positive   <- "#7DB61C"
    col_negative   <- "#C2185B"
    vertical_line_color <- "#003641"

    palette_colors  <- c(
      "#94E1D6", "#49479D", "#7DB61C",
      "#00C9B8", "#98B2B6", "#C9D200",
      "#00FFFF", "#003641", "#00A091",
      "#4C7C83", "#FF5F1F", "#EBEEA8",
      "#A5CD5C", "#8A03C9", "#00AE9D",
      "#EBEEA8", "#D6E266", "#00C9B8",
      "#7DB61C", "#A5CD5C", "#003641",
      "#00A091", "#4C7C83", "#FF5F1F"
    )

  }
  if (palette == "journal") {

    jp <- .journal_palette()

    light_gray <- jp$grid

    col_background <- jp$background
    col_text       <- jp$text
    col_primary    <- jp$primary
    col_positive   <- jp$positive
    col_negative   <- jp$negative
    vertical_line_color <- jp$text

    ### Recycle the eight journal hues to match the br palette length
    palette_colors <- rep(jp$categorical, length.out = 24)

  }

  # Extract the hyperparameters and grid values
  hyper_list <- x@hyper_grid_domain@hyperparameter_list
  if (length(hyper_list) == 0) {
    stop("No hyperparameters found in the grid domain.")
  }

  # Define the predefined min and max ranges for certain hyperparameters
  predefined_limits <- list(
    "alpha" = c(0, 1),
    "lambda.min.ratio" = c(0, 1),
    "mtry" = c(0, 1),
    "eta" = c(0, 1),
    "colsample_bytree" = c(0, 1),
    "subsample" = c(0, 1),
    "droprate" = c(0, 1)
  )

  # Define transformations for specific hyperparameters
  transformation_rules <- list(
    "num.trees" = function(x) x / 100,
    "max.depth" = function(x) x / 10,
    "min.bucket" = function(x) x / 10,
    "min_child_weight" = function(x) x / 10,
    "gamma" = function(x) x / 10,
    "nrounds" = function(x) x / 100,
    "regularizer_l1" = function(x) x / 10,
    "regularizer_l2" = function(x) x / 10,
    "size_of_batch" = function(x) log(x, base = 2),
    "number_of_epochs" = function(x) x / 100
  )

  # Define labels for each transformation
  transformation_labels <- list(
    "num.trees" = "/10\u00b2",           # ²
    "max.depth" = "/10",
    "min.bucket" = "/10",
    "min_child_weight" = "/10",
    "gamma" = "/10",
    "nrounds" = "/10\u00b2",             # ²
    "regularizer_l1" = "/10",
    "regularizer_l2" = "/10",
    "size_of_batch" = "(log\u2082)",     # ₂
    "number_of_epochs" = "/10\u00b2"     # ²
  )

  # Apply transformations to hyperparameters if applicable
  transformed_hyper_list <- list()
  for (hp_name in names(hyper_list)) {
    if (hp_name %in% names(transformation_rules)) {
      # Apply the transformation
      transformed_hyper_list[[hp_name]] <- sapply(hyper_list[[hp_name]], transformation_rules[[hp_name]])
      # Update the hyperparameter name to reflect the transformation
      names(transformed_hyper_list)[names(transformed_hyper_list) == hp_name] <- paste0(hp_name, transformation_labels[[hp_name]])
    } else {
      transformed_hyper_list[[hp_name]] <- hyper_list[[hp_name]]  # No transformation
    }
  }

  # Prepare data for actual grid values
  plot_data <- data.frame(
    Hyperparameter = rep(names(transformed_hyper_list), sapply(transformed_hyper_list, length)),
    Value = unlist(transformed_hyper_list)
  )

  # Prepare data for predefined limits
  predefined_data <- data.frame(
    Hyperparameter = character(),
    MinAllowed = numeric(),
    MaxAllowed = numeric()
  )

  # Loop through each hyperparameter and check if predefined limits exist
  for (hp_name in names(hyper_list)) {
    if (hp_name %in% names(predefined_limits)) {
      predefined_data <- rbind(predefined_data, data.frame(
        Hyperparameter = if (hp_name %in% names(transformation_labels)) {
          paste0(hp_name, transformation_labels[[hp_name]])
        } else {
          hp_name
        },
        MinAllowed = predefined_limits[[hp_name]][1],
        MaxAllowed = predefined_limits[[hp_name]][2]
      ))
    }
  }

  # Create the plot with hyperparameters on the y-axis
   p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = Value, y = Hyperparameter, color = Hyperparameter)) +
    ggplot2::geom_point(size = 4, colour = col_primary, shape = 4) +  # Points for actual grid values in white
    ggplot2::geom_point(data = predefined_data, ggplot2::aes(x = MinAllowed, y = Hyperparameter), shape = 124, size = 5, color = col_negative) +  # Min always closed
    ggplot2::geom_point(data = predefined_data, ggplot2::aes(x = MaxAllowed, y = Hyperparameter), shape = 124, size = 5, color = col_positive) +  # Max always closed
    ggplot2::labs(title = "Grid Search: Hyperparameter Grid Values",
                  y = "Hyperparameter",
                  x = "Selected Values") +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = col_background, color = NA),
      panel.background = ggplot2::element_rect(fill = col_background, color = NA),
      plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
      axis.text = ggplot2::element_text(color = col_text),
      axis.title = ggplot2::element_text(color = col_text),
      legend.position = "bottom",  # Adjust legend position if needed
      legend.title = ggplot2::element_text(color = col_text),
      legend.text = ggplot2::element_text(color = col_text),
      panel.grid.major = ggplot2::element_line(color = light_gray),  # Set major grid lines to light gray
      panel.grid.minor = ggplot2::element_line(color = light_gray)   # Set minor grid lines to light gray
    ) +
    ggplot2::guides(fill = ggplot2::guide_none(), shape = ggplot2::guide_none())  # Remove legend for color and shape

  print(p)
})


#' @title Plot Method for `random_search_strategy`
#' @description Draw a fresh random sample from each hyperparameter's assigned
#'   distribution and plot the resulting histograms/violins for random search.
#' @param x An object of class `random_search_strategy`.
#' @param y Unused. Included for consistency with the generic `plot` method.
#' @param palette Character. Color palette to use for the plot. Options include "cyberpunk", "br" and "journal". Default is "cyberpunk".
#' @return Invisibly returns the `ggplot` object visualizing the hyperparameter histograms and their predefined limits (also printed as a side effect).
#' @section Requirements:
#' Requires the suggested packages `gridExtra`, `scales`, `ggdist`, `ggraph`,
#' `ggrepel`, `igraph`, and `RColorBrewer`; if any are missing, an informative
#' `stop()` is raised.
#' @section Note:
#' Samples are drawn fresh on every call (no seed control) purely to
#' illustrate the shape of each distribution -- they are **not** the actual
#' draws `hyper_tune()` will use during tuning, and repeated calls can look
#' different, especially for small `n_iter`.
#' @export
setMethod("plot", signature(x = "random_search_strategy", y = "missing"), function(x, y, palette = "cyberpunk") {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  # Define colors for plotting
  # Palette
  black <- "#000000"
  white <- "#FFFFFF"

  if (palette == "cyberpunk") {

    light_gray <- "#003641"

    col_background <- "#001f3f"
    col_text       <- "#FFFFFF"
    col_primary    <- "#00FFFF"
    col_positive   <- "#39FF14"
    col_negative   <- "#FF1493"
    vertical_line_color <- "#FF69B4"
    cyan <- "#00FFFF"

    palette_colors  <- c(
      "#00BFFF", "#FF1493", "#FFFF00", "#8A2BE2", "#00FFFF",
      "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500"
    )

  }
  if (palette == "br") {

    light_gray <- "#EBEEF1"

    col_background <- "#FFFFFF"
    col_text       <- "#003641"
    col_primary   <- "#00A091"
    col_positive   <- "#7DB61C"
    col_negative   <- "#C2185B"
    vertical_line_color <- "#003641"
    cyan <- "#94E1D6"

    palette_colors  <- c(
      "#94E1D6", "#49479D", "#7DB61C",
      "#00C9B8", "#98B2B6", "#C9D200",
      "#00FFFF", "#003641", "#00A091",
      "#4C7C83", "#FF5F1F", "#EBEEA8",
      "#A5CD5C", "#8A03C9", "#00AE9D",
      "#EBEEA8", "#D6E266", "#00C9B8",
      "#7DB61C", "#A5CD5C", "#003641",
      "#00A091", "#4C7C83", "#FF5F1F"
    )

  }
  if (palette == "journal") {

    jp <- .journal_palette()

    light_gray <- jp$grid

    col_background <- jp$background
    col_text       <- jp$text
    col_primary    <- jp$primary
    col_positive   <- jp$positive
    col_negative   <- jp$negative
    vertical_line_color <- jp$text
    cyan <- jp$sequential[3]

    ### Recycle the eight journal hues to match the br palette length
    palette_colors <- rep(jp$categorical, length.out = 24)

  }

  # Extract n_iter from the object
  n_iter <- x@n_iter

  # Extract the hyperparameters and histograms
  hyper_list <- x@hyper_grid_domain@hyperparameter_list
  if (length(hyper_list) == 0) {
    stop("No hyperparameters found in the grid domain.")
  }

  # Define the predefined min and max ranges for certain hyperparameters
  predefined_limits <- list(
    "alpha" = c(0, 1),
    "lambda.min.ratio" = c(0, 1),
    "mtry" = c(0, 1),
    "eta" = c(0, 1),
    "colsample_bytree" = c(0, 1),
    "subsample" = c(0, 1),
    "droprate" = c(0, 1)
  )

  # Define transformations for specific hyperparameters
  transformation_rules <- list(
    "num.trees" = function(x) x / 100,
    "max.depth" = function(x) x / 10,
    "min.bucket" = function(x) x / 10,
    "min_child_weight" = function(x) x / 10,
    "gamma" = function(x) x / 10,
    "nrounds" = function(x) x / 100,
    "regularizer_l1" = function(x) x / 10,
    "regularizer_l2" = function(x) x / 10,
    "size_of_batch" = function(x) log(x, base = 2),
    "number_of_epochs" = function(x) x / 100
  )

  # Define labels for each transformation
  transformation_labels <- list(
    "num.trees" = "/10\\u00b2",
    "max.depth" = "/10",
    "min.bucket" = "/10",
    "min_child_weight" = "/10",
    "gamma" = "/10",
    "nrounds" = "/10\\u00b2",
    "regularizer_l1" = "/10",
    "regularizer_l2" = "/10",
    "size_of_batch" = "(log\\u2082)",
    "number_of_epochs" = "/10\\u00b2"
  )

  # Apply transformations to hyperparameters if applicable
  transformed_hyper_list <- list()
  for (hp_name in names(hyper_list)) {
    if (hp_name %in% names(transformation_rules)) {
      # Apply the transformation
      transformed_hyper_list[[hp_name]] <- hyper_list[[hp_name]]
      transformed_hyper_list[[hp_name]]$pars <- sapply(hyper_list[[hp_name]]$pars, transformation_rules[[hp_name]])
      # Update the hyperparameter name to reflect the transformation
      names(transformed_hyper_list)[names(transformed_hyper_list) == hp_name] <- paste0(hp_name, transformation_labels[[hp_name]])
    } else {
      transformed_hyper_list[[hp_name]] <- hyper_list[[hp_name]]  # No transformation
    }
  }

  # Prepare a data frame to store the samples
  plot_data <- data.frame(
    Hyperparameter = character(),
    Value = numeric(),
    histogram = character()
  )

  # Prepare a data frame for predefined limits
  predefined_data <- data.frame(
    Hyperparameter = character(),
    MinAllowed = numeric(),
    MaxAllowed = numeric()
  )

  # Loop through each hyperparameter to generate samples and check predefined limits
  for (hp_name in names(transformed_hyper_list)) {
    dist_choice <- transformed_hyper_list[[hp_name]]$distribution_choice
    if (dist_choice == "uniform") {
      pars <- transformed_hyper_list[[hp_name]]$pars
      samples <- stats::runif(n_iter, min = pars["min"], max = pars["max"])
    } else if (dist_choice == "normal") {
      pars <- transformed_hyper_list[[hp_name]]$pars
      samples <- stats::rnorm(n_iter, mean = pars["mean"], sd = pars["sd"])
    } else if (dist_choice == "lognormal") {
      pars <- transformed_hyper_list[[hp_name]]$pars
      samples <- stats::rlnorm(n_iter, meanlog = pars["meanlog"], sdlog = pars["sdlog"])
    } else if (dist_choice == "constant") {
      samples <- rep(transformed_hyper_list[[hp_name]]$value, n_iter)  # Constant value
    } else {
      stop(paste("Unsupported histogram:", dist_choice))
    }

    # Add the samples to the plot_data
    plot_data <- rbind(plot_data, data.frame(
      Hyperparameter = rep(hp_name, length(samples)),
      Value = samples,
      histogram = rep(dist_choice, length(samples))
    ))

    # If predefined limits exist, add them to predefined_data
    if (hp_name %in% names(predefined_limits)) {
      predefined_data <- rbind(predefined_data, data.frame(
        Hyperparameter = hp_name,
        MinAllowed = predefined_limits[[hp_name]][1],
        MaxAllowed = predefined_limits[[hp_name]][2]
      ))
    }
  }

  # Create the plot with hyperparameters on the y-axis
  hp_levels <- sort(unique(plot_data$Hyperparameter))
  colors_used <- rep(palette_colors, length.out = length(hp_levels))
  fill_map <- stats::setNames(colors_used, hp_levels)

  p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = Value, y = Hyperparameter)) +
    ggplot2::geom_violin(data = plot_data[plot_data$histogram != "constant", ], alpha = 0.7, color = cyan) +  # Violin for non-constant histograms
    ggplot2::geom_point(data = plot_data[plot_data$histogram == "constant", ], size = 3, color = col_primary, shape = 4) +  # Points for constant in white
    ggplot2::geom_point(data = predefined_data, ggplot2::aes(x = MinAllowed, y = Hyperparameter), shape = 124, size = 5, color = col_negative) +  # Min always closed
    ggplot2::geom_point(data = predefined_data, ggplot2::aes(x = MaxAllowed, y = Hyperparameter), shape = 124, size = 5, color = col_positive) +  # Max always closed
    ggplot2::labs(title = "Random Search: Hyperparameter histograms",
                  y = "Hyperparameter",
                  x = "Sampled Values") +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = col_background, color = NA),
      panel.background = ggplot2::element_rect(fill = col_background, color = NA),
      plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
      axis.text = ggplot2::element_text(color = col_text),
      axis.title = ggplot2::element_text(color = col_text),
      legend.position = "bottom",  # Adjust legend position if needed
      legend.title = ggplot2::element_text(color = col_text),
      legend.text = ggplot2::element_text(color = col_text),
      panel.grid.major = ggplot2::element_line(color = light_gray),  # Set major grid lines to light gray
      panel.grid.minor = ggplot2::element_line(color = light_gray)   # Set minor grid lines to light gray
    ) +
    #ggplot2::scale_fill_manual(values = fill_map) +  # Use defined colors
    ggplot2::guides(fill = ggplot2::guide_none())  # Remove legend for fill and shape

  print(p)
})


#' @title Plot Method for `bayesian_opt_strategy`
#' @description Plot the lower/upper bounds for each hyperparameter in `bayesian_opt_strategy`.
#' @param x An object of class `bayesian_opt_strategy`.
#' @param y Unused. Included for consistency with the generic `plot` method.
#' @param palette Character. Color palette to use for the plot. Options include "cyberpunk", "br" and "journal". Default is "cyberpunk".
#' @param ... Additional arguments passed to the plotting method (currently unused).
#' @return Invisibly returns the `ggplot` object visualizing the bounds (also printed as a side effect).
#' @section Requirements:
#' Requires the suggested packages `gridExtra`, `scales`, `ggdist`, `ggraph`,
#' `ggrepel`, `igraph`, and `RColorBrewer`; if any are missing, an informative
#' `stop()` is raised.
#' @export
setMethod("plot", signature(x = "bayesian_opt_strategy", y = "missing"), function(x, y, palette = "cyberpunk", ...) {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }


  # Define colors for plotting
  # Palette
  black <- "#000000"
  white <- "#FFFFFF"



  if (palette == "cyberpunk") {

    light_gray <- "#003641"

    col_background <- "#001f3f"
    col_text       <- "#FFFFFF"
    col_primary    <- "#00FFFF"
    col_positive   <- "#39FF14"
    col_negative   <- "#FF1493"
    vertical_line_color <- "#FF69B4"
    cyan <- "#00FFFF"

    palette_colors  <- c(
      "#00BFFF", "#FF1493", "#FFFF00", "#8A2BE2", "#00FFFF",
      "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500"
    )

  }
  if (palette == "br") {

    light_gray <- "#EBEEF1"

    col_background <- "#FFFFFF"
    col_text       <- "#003641"
    col_primary   <- "#00A091"
    col_positive   <- "#7DB61C"
    col_negative   <- "#C2185B"
    vertical_line_color <- "#003641"
    cyan <- "#94E1D6"

    palette_colors  <- c(
      "#94E1D6", "#49479D", "#7DB61C",
      "#00C9B8", "#98B2B6", "#C9D200",
      "#00FFFF", "#003641", "#00A091",
      "#4C7C83", "#FF5F1F", "#EBEEA8",
      "#A5CD5C", "#8A03C9", "#00AE9D",
      "#EBEEA8", "#D6E266", "#00C9B8",
      "#7DB61C", "#A5CD5C", "#003641",
      "#00A091", "#4C7C83", "#FF5F1F"
    )

  }
  if (palette == "journal") {

    jp <- .journal_palette()

    light_gray <- jp$grid

    col_background <- jp$background
    col_text       <- jp$text
    col_primary    <- jp$primary
    col_positive   <- jp$positive
    col_negative   <- jp$negative
    vertical_line_color <- jp$text
    cyan <- jp$sequential[3]

    ### Recycle the eight journal hues to match the br palette length
    palette_colors <- rep(jp$categorical, length.out = 24)

  }



  # Extract hyper_grid_domain and the hyperparameter list
  hyper_grid <- x@hyper_grid_domain
  hyper_list <- hyper_grid@hyperparameter_list

  if (length(hyper_list) == 0) {
    stop("No hyperparameters found in the grid domain.")
  }

  # Define the predefined min and max ranges for certain hyperparameters
  predefined_limits <- list(
    "alpha" = c(0, 1),
    "lambda.min.ratio" = c(0, 1),
    "mtry" = c(0, 1),
    "eta" = c(0, 1),
    "colsample_bytree" = c(0, 1),
    "subsample" = c(0, 1),
    "droprate" = c(0, 1)
  )

  # Define transformations for specific hyperparameters
  transformation_rules <- list(
    "num.trees" = function(x) x / 100,
    "max.depth" = function(x) x / 10,
    "min.bucket" = function(x) x / 10,
    "min_child_weight" = function(x) x / 10,
    "gamma" = function(x) x / 10,
    "nrounds" = function(x) x / 100,
    "regularizer_l1" = function(x) x / 10,
    "regularizer_l2" = function(x) x / 10,
    "size_of_batch" = function(x) log(x, base = 2),
    "number_of_epochs" = function(x) x / 100
  )

  # Define labels for each transformation
  transformation_labels <- list(
    "num.trees" = "/10\u00b2",           # ² -> \u00b2
    "max.depth" = "/10",
    "min.bucket" = "/10",
    "min_child_weight" = "/10",
    "gamma" = "/10",
    "nrounds" = "/10\u00b2",             # ² -> \u00b2
    "regularizer_l1" = "/10",
    "regularizer_l2" = "/10",
    "size_of_batch" = "(log\u2082)",     # ₂ -> \u2082
    "number_of_epochs" = "/10\u00b2"     # ² -> \u00b2
  )


  # Apply transformations to hyperparameters if applicable
  transformed_hyper_list <- list()
  for (hp_name in names(hyper_list)) {
    if (hp_name %in% names(transformation_rules)) {
      # Apply the transformation
      transformed_hyper_list[[hp_name]] <- sapply(hyper_list[[hp_name]], transformation_rules[[hp_name]])
      # Update the hyperparameter name to reflect the transformation
      names(transformed_hyper_list)[names(transformed_hyper_list) == hp_name] <- paste0(hp_name, transformation_labels[[hp_name]])
    } else {
      transformed_hyper_list[[hp_name]] <- hyper_list[[hp_name]]  # No transformation
    }
  }

  # Prepare the data frame for plotting
  plot_data <- do.call(rbind, lapply(names(transformed_hyper_list), function(hp) {
    bounds <- transformed_hyper_list[[hp]]

    # Check if there are predefined limits
    if (hp %in% names(predefined_limits)) {
      limits <- predefined_limits[[hp]]
      min_val <- limits[1]
      max_val <- limits[2]

      data.frame(
        hyperparameter = hp,
        lower = bounds[1],
        upper = bounds[2],
        min_val = min_val,
        max_val = max_val
      )
    } else {
      data.frame(
        hyperparameter = hp,
        lower = bounds[1],
        upper = bounds[2],
        min_val = NA,
        max_val = NA
      )
    }
  }))

  # Create the ggplot
  p <- ggplot2::ggplot(plot_data, ggplot2::aes(y = hyperparameter)) +
    # Add segments for bounds with neon blue lines
    ggplot2::geom_segment(ggplot2::aes(x = lower, xend = upper, yend = hyperparameter), color = col_primary, size = 0.8) +
    # Add points for bounds
    ggplot2::geom_point(ggplot2::aes(x = lower), size = 3, color = col_negative, shape = 16) +  # Closed for lower bounds
    ggplot2::geom_point(ggplot2::aes(x = upper), size = 3, color = col_positive, shape = 16) +  # Closed for upper bounds
    # Add predefined limits (min and max)
    ggplot2::geom_point(data = plot_data[!is.na(plot_data$min_val), ], ggplot2::aes(x = min_val, y = hyperparameter), size = 5, color = col_negative, shape = 124) +  # Neon pink for predefined min
    ggplot2::geom_point(data = plot_data[!is.na(plot_data$max_val), ], ggplot2::aes(x = max_val, y = hyperparameter), size = 5, color = col_positive, shape = 124) +  # Neon pink for predefined max
    # Adjust plot labels
    ggplot2::labs(
      title = "Bayesian Optimization: Hyperparameter Bounds",
      x = "Bounded Intervals",
      y = "Hyperparameter"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = col_background, color = NA),
      panel.background = ggplot2::element_rect(fill = col_background, color = NA),
      plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
      axis.text = ggplot2::element_text(color = col_text),
      axis.title = ggplot2::element_text(color = col_text),
      legend.position = "bottom",  # Adjust legend position if needed
      legend.title = ggplot2::element_text(color = col_text),
      legend.text = ggplot2::element_text(color = col_text),
      panel.grid.major = ggplot2::element_line(color = light_gray),  # Set major grid lines to light gray
      panel.grid.minor = ggplot2::element_line(color = light_gray)   # Set minor grid lines to light gray
    )

  print(p)
})


#' @title Plot Method for `sb_backtest_config`
#' @description Calls the appropriate plot method for `tuning_strategy`.
#' @param x An object of class `sb_backtest_config`.
#' @param y Unused. Included for consistency with the generic `plot` method.
#' @param palette Character. Color palette to use for the plot. Options include "cyberpunk", "br" and "journal". Default is "cyberpunk".
#' @return A `ggplot` object visualizing the hyperparameter histograms with possible limits.
#' @export
setMethod("plot", signature(x = "sb_backtest_config", y = "missing"), function(x, y, palette = "cyberpunk"){

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  if(!x@sb_algorithm %in% c("ols", "sw", "ew", "rp", "mvo", "custom_weights")){
    plot(x@tuning_strategy, palette = palette)
  } else {
    message("Plot method not avaiable for `ols`, `sw`, `ew`, `rp` or `mvo` sb_algorithm.")
  }

})



#' @title Plot Method for 'sb_model' Objects
#' @description This method dispatches plotting to the underlying model stored in the \code{model} slot of a \code{sb_model} object.
#'
#' @param x An object of class \code{sb_model}.
#' @param type Currently unused. Included for compatibility with other plot methods.
#' @param palette Character. Color palette to use for the plot. Options include "cyberpunk", "br" and "journal". Default is "cyberpunk". This will be passed to the underlying model's plot method if applicable.
#' @param ... Additional arguments passed to the plot method of the underlying model.
#'
#' @export
setMethod(
  "plot",
  signature(x = "sb_model", y = "missing"),
  function(x, type = NULL, palette = "cyberpunk", ...) {

    ##Try to get sb_algorithm slot in x
     sb_algorithm <- tryCatch({
      x@sb_algorithm
    }, error = function(e) {
      NULL
    })

    ##If the algo is one of 'rp', 'ew', 'sw', 'cs', 'mmaf', 'mvo', 'hrp', pass palette
    if (!is.null(sb_algorithm) && sb_algorithm %in% c("rp", "ew", "sw", "cs", "mmaf", "mvo", "hrp")) {
      return(plot(x@model, palette = palette, ...))
    } else {
      plot(x@model)
    }

  }
)


# Define the plot method for sb_backtest_results
#' Plot Signal Blending Walk-Forward Validation Results
#'
#' This method generates various plots to visualize the performance of machine learning models using walk-forward validation metrics.
#' Users can select which plot to display by specifying the `plot_id` parameter,
#' either by name or by number.
#'
#' @param x An object of class \code{sb_backtest_results} containing the results of the walk-forward validation.
#' @param plot_id A character string or numeric value specifying which plot to display.
#'   Available plots depend on `sb_algorithm`. For ML algorithms ("glmnet", "rf", "xgb", "nn"):
#'   - `"Chosen Evaluation Metric Over Time"`
#'   - `"Test vs Validation Chosen Evaluation Metric Over Time"`
#'   - `"Best Hyperparameters Over Time"`
#'   - `"Hyperparameters vs Error"`
#'   - `"All Evaluation Metrics Over Time"`
#'   - `"Consolidated OOS Testing Metrics"`
#'   - `"OOS Predictions, Errors and Targets"`
#'   - `"Consolidated OOS Testing Metrics vs Average Validation"`
#'   - `"Final Signal-Blending Model"`
#'   - `"Time-Series Feature Importance by Signal"`
#'   - `"Average Time-Series Feature Importance by Theme"`
#'   - `"Compare Feature Importance Side-by-Side by Signal"`
#'   - `"Compare Feature Importance Side-by-Side by Theme"`
#'   - `"Feature Importance Box-Plot by Signal"`
#'   - `"Feature Importance Box-Plot by Theme"`
#'   - `"Feature Importance Heatmap by Signal"`
#'   - `"Feature Importance Heatmap by Theme"`
#'   - `"Explain Prediction"`
#'   For "ols" and heuristic/portfolio algorithms, the tuning-specific plots (chosen-metric,
#'   test-vs-validation, hyperparameter, and consolidated-vs-validation plots) are omitted.
#'   Provide a number (index into the list shown when `plot_id` is `NULL`), or `NULL` (default) to list them.
#' @param features_m_df A \code{meta_dataframe} containing features used in the backtest. Required for plots like `"Explain Prediction"`.
#' @param palette Character. Color palette to use for the plot. Options include "cyberpunk", "br" and "journal". Default is "cyberpunk".
#' @param ticker_to_explain Character. Ticker symbol to explain in the "Explain Prediction" plot.
#' @param date_to_explain Date. Date to explain in the "Explain Prediction" plot.
#' @return Invisibly returns the input \code{x}.
#' @export

setMethod("plot", "sb_backtest_results", function(x, plot_id = NULL, features_m_df = NULL, palette = "cyberpunk", ticker_to_explain = NULL, date_to_explain = NULL) {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  # List of available plots
  rebalance_dates <- purrr::map(x@sb_backtest_workflow, function(x) x$rebalance_dates) %>% unlist() %>% as.Date()
  sb_backtest_workflow <- x@sb_backtest_workflow[[length(x@sb_backtest_workflow)]]
  if(sb_backtest_workflow$sb_algorithm %in% c("glmnet", "rf", "xgb", "nn")){
    available_plots <- c(
      "Chosen Evaluation Metric Over Time",
      "Test vs Validation Chosen Evaluation Metric Over Time",
      "Best Hyperparameters Over Time",
      "Hyperparameters vs Error",
      "All Evaluation Metrics Over Time",
      "Consolidated OOS Testing Metrics",
      "OOS Predictions, Errors and Targets",
      "Consolidated OOS Testing Metrics vs Average Validation",
      "Final Signal-Blending Model",
      "Time-Series Feature Importance by Signal",
      "Average Time-Series Feature Importance by Theme",
      "Compare Feature Importance Side-by-Side by Signal",
      "Compare Feature Importance Side-by-Side by Theme",
      "Feature Importance Box-Plot by Signal",
      "Feature Importance Box-Plot by Theme",
      "Feature Importance Heatmap by Signal",
      "Feature Importance Heatmap by Theme",
      "Explain Prediction"
    )
  }

  if(sb_backtest_workflow$sb_algorithm %in% c("ols", "ew_ensemble", "optimal_ensemble", "ew", "sw", "rp", "hrp", "mvo", "mmaf", "custom_weights")){
    available_plots <- c(
      "All Evaluation Metrics Over Time",
      "Consolidated OOS Testing Metrics",
      "OOS Predictions, Errors and Targets",
      "Final Signal-Blending Model",
      "Time-Series Feature Importance by Signal",
      "Average Time-Series Feature Importance by Theme",
      "Compare Feature Importance Side-by-Side by Signal",
      "Compare Feature Importance Side-by-Side by Theme",
      "Feature Importance Box-Plot by Signal",
      "Feature Importance Box-Plot by Theme",
      "Feature Importance Heatmap by Signal",
      "Feature Importance Heatmap by Theme",
      "Explain Prediction"
    )
  }


  if (is.null(plot_id)) {
    cat("\nPlease choose a plot to display:\n")
    for (i in seq_along(available_plots)) {
      cat(paste0(i, ": ", available_plots[i], "\n"))
    }
    selection <- readline(prompt = "Enter the number of your choice: ")
    plot_id <- as.numeric(selection)
    if (is.na(plot_id) || plot_id < 1 || plot_id > length(available_plots)) {
      stop("Invalid selection.")
    }
  }

  # Determine if plot_id is numeric (index) or character (name)
  if (is.numeric(plot_id)) {
    if (plot_id >= 1 && plot_id <= length(available_plots)) {
      plot_name <- available_plots[plot_id]
    } else {
      stop("Invalid plot number. Please select a number between 1 and ", length(available_plots), ".")
    }
  } else if (is.character(plot_id)) {
    if (plot_id %in% available_plots) {
      plot_name <- plot_id
    } else {
      stop("Invalid 'plot_id' specified. Available options are:\n",
           paste(available_plots, collapse = ", "))
    }
  } else {
    stop("'plot_id' must be either a string or a number corresponding to the plot.")
  }

  # Extract relevant data from the S4 object
  oos_testing_eval_metrics <- if (!is.null(x@oos_testing_eval_metrics_m_xts)) x@oos_testing_eval_metrics_m_xts@data %>% as.data.frame() else NULL
  validation_eval_metrics_hyper_choice <- if (!is.null(x@validation_eval_metrics_hyper_choice_m_xts)) x@validation_eval_metrics_hyper_choice_m_xts@data %>% as.data.frame() else NULL
  consolidated_eval_metrics <- x@consolidated_eval_metrics
  hyper_choice_df <- if (!is.null(x@best_hyperparameters_m_xts)) x@best_hyperparameters_m_xts@data %>% as.data.frame() else NULL
  chosen_eval_metric <- sb_backtest_workflow$chosen_eval_metric
  chosen_eval_metric_validation <- x@chosen_eval_metric_validation
  sb_algorithm <- sb_backtest_workflow$sb_algorithm


  # Define colors for plotting
  # Palette
  black <- "#000000"
  white <- "#FFFFFF"

  if (palette == "cyberpunk") {

    light_gray <- "#003641"

    col_background <- "#001f3f"
    col_text       <- "#FFFFFF"
    col_primary    <- "#00FFFF"
    col_secondary <- "#FF69B4"      # Hot Pink
    col_terciary <-  "#FF1493" # Lime Green
    col_quarternary <-  "#FFA500"
    col_quinternary <- "#FF4500"
    col_sextenary <- "#32CD32"
    col_positive   <- "#39FF14"
    col_negative   <- "#FF1493"
    vertical_line_color <- "#FF69B4"
    cyan <- "#00FFFF"

    palette_colors  <- c(
      "#00BFFF", "#FF1493", "#FFFF00",  "#00FFFF", "#8A2BE2",
      "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500"
    )

  }
  if (palette == "br") {

    light_gray <- "#EBEEF1"

    col_background <- "#FFFFFF"
    col_text       <- "#003641"
    col_primary   <- "#00A091"
    col_secondary  <- "#4C7C83"
    col_terciary   <- "#49479D"
    col_quarternary <- "#7DB61C"
    col_quinternary <- "#003641"
    col_sextenary  <- "#D6E266"
    col_positive   <- "#7DB61C"
    col_negative   <- "#C2185B"
    vertical_line_color <- "#003641"
    cyan <- "#94E1D6"

    palette_colors  <- c(
      "#94E1D6", "#49479D", "#FF5F1F",
      "#7DB61C", "#98B2B6", "#8A03C9",
      "#00C9B8", "#C9D200", "#C2185B",
      "#00FFFF", "#003641", "#00A091",
      "#4C7C83", "#FF5F1F", "#EBEEA8",
      "#A5CD5C", "#00AE9D",
      "#EBEEA8", "#D6E266", "#00C9B8",
      "#7DB61C", "#A5CD5C", "#003641",
      "#00A091", "#4C7C83"
    )

  }
  if (palette == "journal") {

    jp <- .journal_palette()

    light_gray <- jp$grid

    col_background <- jp$background
    col_text       <- jp$text
    col_primary    <- jp$primary
    col_secondary  <- jp$categorical[3]
    col_terciary   <- jp$categorical[6]
    col_quarternary <- jp$positive
    col_quinternary <- jp$sequential[7]
    col_sextenary  <- jp$categorical[4]
    col_positive   <- jp$positive
    col_negative   <- jp$negative
    vertical_line_color <- jp$text
    cyan <- jp$sequential[3]

    ### Recycle the eight journal hues to match the br palette length
    palette_colors <- rep(jp$categorical, length.out = 25)

  }


  # Define global variables to pass R CMD check
  dates <- value <- year <- overall_mean <- yearly_mean <- quantile <- concatenation <- median <- lambda.min.ratio <- alpha <- q75 <- median_chosen_eval_metric <-
    q25 <- variable_mean <- x_coord <- y_coord <- label <- variable <- mtry <- num.trees <- min.bucket <- max.depth <- eta <- max_depth <- colsample_bytree <-
    lr <- droprate <- regularizer_l2 <- regularizer_l1 <- min_child_weight <- subsample <- gamma <- nrounds <- NULL

  # Get 'consolidated' row
  consolidated_oos_testing_metrics <- consolidated_eval_metrics %>% dplyr::select(metric, cons_oos)

  # Get 'average' row from validation_eval_metrics_hyper_choice before time series plots
  if (length(validation_eval_metrics_hyper_choice) > 0) {
    average_validation_metrics <-  consolidated_eval_metrics %>% dplyr::select(metric, avg_val)
  } else {
    average_validation_metrics <- NULL
  }

  # Prepare data for plotting

  # Some treatments to oos_testing_eval_metrics
  # Change colnames
  if (!is.null(oos_testing_eval_metrics)){
    colnames(oos_testing_eval_metrics) <- paste("oos_testing_", colnames(oos_testing_eval_metrics), sep = "")
    # Add dates column
    oos_testing_eval_metrics <- oos_testing_eval_metrics %>% dplyr::mutate(dates = rownames(oos_testing_eval_metrics))
    oos_testing_eval_metrics$dates <- as.Date(oos_testing_eval_metrics$dates, format = "%Y-%m-%d") # Coerce to dates
  }

  if (!sb_algorithm %in% c("ols", "rp", "sw", "ew", "hrp", "mvo", "mmaf", "custom_weights")) {
    # Some treatments to validation_eval_metrics_hyper_choice
    # Change colnames
    colnames(validation_eval_metrics_hyper_choice) <- paste("validation_", colnames(validation_eval_metrics_hyper_choice), sep = "")
    # Add dates column
    validation_eval_metrics_hyper_choice <- validation_eval_metrics_hyper_choice %>% dplyr::mutate(dates = rownames(validation_eval_metrics_hyper_choice))
    validation_eval_metrics_hyper_choice$dates <- as.Date(validation_eval_metrics_hyper_choice$dates, format = "%Y-%m-%d") # Coerce to dates

    # Join test and validation
    if (!is.null(oos_testing_eval_metrics)){
      oos_testing_and_validation <- dplyr::left_join(oos_testing_eval_metrics, validation_eval_metrics_hyper_choice, by = 'dates')
      # Melt
      oos_testing_and_validation <- oos_testing_and_validation %>%
        tidyr::pivot_longer(
          cols = -dates,
          names_to = "variable",
          values_to = "value"
        )

      oos_testing_and_validation$dates <- as.Date(oos_testing_and_validation$dates, format = "%Y-%m-%d")

      # OOS test data
      oos_testing_data <-  oos_testing_and_validation %>%
        dplyr::filter(stringr::str_detect(variable, "oos_testing_")) %>% # Filter only OOS test
        dplyr::mutate(year = lubridate::year(dates)) %>% # Using lubridate::year() to extract year
        dplyr::group_by(variable) %>% # Group by variable
        dplyr::mutate(variable_mean = mean(value, na.rm = TRUE)) %>% # Take variable mean
        dplyr::ungroup() # Ungroup

      # Chosen eval metric - test data
      chosen_eval_testing_data <- oos_testing_and_validation %>%
        dplyr::filter(variable == paste("oos_testing_", chosen_eval_metric, sep = "")) %>% # Filter only OOS test chosen eval metric
        dplyr::mutate(year = lubridate::year(dates)) %>% # Using lubridate::year() to extract year
        dplyr::mutate(overall_mean = mean(value, na.rm = TRUE)) %>% # Add overall mean
        dplyr::group_by(year) %>% # Group by year
        dplyr::mutate(yearly_mean = mean(value, na.rm = TRUE)) %>% # Take yearly mean
        dplyr::ungroup() # Ungroup

      # Validation data
      validation_data <- oos_testing_and_validation %>%
        dplyr::filter(stringr::str_detect(variable, "validation_")) %>% # Filter only validation
        dplyr::mutate(year = lubridate::year(dates)) %>% # Using lubridate::year() to extract year
        dplyr::filter(!is.na(value)) # Filter out NAs

      # Chosen eval metric - validation data
      chosen_eval_validation_data <- oos_testing_and_validation %>%
        dplyr::filter(variable == paste("validation_", chosen_eval_metric, sep = "")) %>% # Filter only chosen validation metric
        dplyr::filter(!is.na(value)) # Filter out NAs

    } else {
      if (plot_name %in% c("Chosen Evaluation Metric Over Time", "Test vs Validation Chosen Evaluation Metric Over Time",
                           "All Evaluation Metrics Over Time", "Consolidated OOS Testing Metrics")){
        stop("Chosen evaluation metric over time plot requires a non NULL oos_testing_eval_metrics.")
      }
    }
  }

  # Initialize plots list
  plots_list <- list()

  # Now generate the selected plot
  if (plot_name == "Chosen Evaluation Metric Over Time") {
    # PLOT 1: Test chosen evaluation metric over time
    plots_list$chosen_eval_metric_over_time <- ggplot2::ggplot(
      chosen_eval_testing_data,
      ggplot2::aes(x = dates, y = value, color = paste(chosen_eval_metric))
    ) +
      ggplot2::geom_line(color = col_primary, alpha = 0.7) +  # Neon cyan line
      ggplot2::geom_point(color = col_positive) +  # Neon green points
      ggplot2::labs(x = "Date", y = chosen_eval_metric) +
      ggplot2::ggtitle(paste("Test", chosen_eval_metric, "over time")) +
      ggplot2::facet_wrap(~year, scales = "free") +
      ggplot2::scale_x_date(labels = scales::date_format("%b-%y")) +
      ggplot2::geom_hline(
        data = chosen_eval_testing_data %>%
          dplyr::select(year, overall_mean, yearly_mean) %>%
          dplyr::distinct(),
        ggplot2::aes(yintercept = overall_mean),
        color = col_secondary,
        linetype = "dashed"
      ) +
      ggplot2::geom_hline(
        data = chosen_eval_testing_data %>%
          dplyr::select(year, overall_mean, yearly_mean) %>%
          dplyr::distinct(),
        ggplot2::aes(yintercept = yearly_mean),
        color = col_terciary,
        linetype = "dashed"
      ) +
      #ggplot2::scale_color_manual(values = c("Metric" = neon_blue)) +
      ggplot2::guides(color = ggplot2::guide_legend(title = "")) +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
        axis.text = ggplot2::element_text(color = col_text),
        axis.title = ggplot2::element_text(color = col_text),
        strip.text = ggplot2::element_text(color = col_text, face = "bold"),  # White facet labels
        legend.position = "bottom",
        legend.title = ggplot2::element_text(color = col_text),
        legend.text = ggplot2::element_text(color = col_text),
        panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),  # Blended blue for major grid
        panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1)   # Blended blue for minor grid
      )

    print(plots_list$chosen_eval_metric_over_time)

  } else if (plot_name == "Test vs Validation Chosen Evaluation Metric Over Time") {
    # PLOT 2: Test vs Validation chosen eval metric over time
    plots_list$test_vs_val_chosen_eval_metric_over_time <- ggplot2::ggplot() +
      ggplot2::geom_line(
        data = chosen_eval_testing_data,
        ggplot2::aes(x = dates, y = value, color = "Test"),
        alpha = 0.5
      ) +
      ggplot2::geom_point(
        data = chosen_eval_testing_data,
        ggplot2::aes(x = dates, y = value, color = "Test"),
        size = 2,
        color = col_positive
      ) +
      ggplot2::geom_point(
        data = chosen_eval_validation_data,
        ggplot2::aes(x = dates, y = value, color = "Validation"),
        size = 3,
        color = col_negative
      ) +
      ggplot2::geom_text(
        data = chosen_eval_validation_data,
        ggplot2::aes(x = dates, y = value, label = dates),
        vjust = -0.5, hjust = 0, size = 3, color = col_negative
      ) +  # Display dates next to validation points
      ggplot2::labs(x = "Date", y = chosen_eval_metric, color = "") +
      ggplot2::ggtitle(paste("Test and Validation", chosen_eval_metric, "over time")) +
      ggplot2::scale_color_manual(values = c("Test" = col_primary, "Validation" = col_secondary)) +
      ggplot2::geom_vline(
        data = chosen_eval_validation_data,
        ggplot2::aes(xintercept = dates),
        linetype = "dashed",
        color = col_terciary
      ) +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
        axis.text = ggplot2::element_text(color = col_text),
        axis.title = ggplot2::element_text(color = col_text),
        strip.text = ggplot2::element_text(color = col_text, face = "bold"),
        legend.position = "bottom",
        legend.title = ggplot2::element_text(color = col_text),
        legend.text = ggplot2::element_text(color = col_text),
        panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),  # Blended grid lines
        panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1)
      )

    print(plots_list$test_vs_val_chosen_eval_metric_over_time)

  } else if (plot_name == "Best Hyperparameters Over Time") {
    # PLOT 3: Best Hyperparameters over time
    plots_list$best_hyper_over_time <- ggplot2::ggplot(
      hyper_choice_df %>%
        dplyr::mutate(dates = as.Date(rownames(hyper_choice_df), format = "%Y-%m-%d")) %>%
        tidyr::pivot_longer(
          cols = -dates,
          names_to = "variable",
          values_to = "value"
        ),
      ggplot2::aes(x = dates, y = value, color = variable)
    ) +
      ggplot2::geom_line(alpha = 0.5) +
      ggplot2::geom_point(color = col_positive) +  # Neon green points
      ggplot2::geom_text(
        ggplot2::aes(label = round(value, 2)),
        vjust = -0.5, size = 3, color = col_text
      ) +  # Display values next to points
      ggplot2::labs(x = "Date", y = "Best Hyperparameter") +
      ggplot2::ggtitle("Best Hyperparameters Over Time") +
      ggplot2::facet_wrap(~variable, scales = "free") +  # Create subplots for each hyperparameter
      ggplot2::scale_x_date(labels = scales::date_format("%b-%y")) +
      ggplot2::scale_color_manual(values = palette_colors) +
      ggplot2::guides(color = ggplot2::guide_legend(title = "")) +
      ggplot2::theme_minimal() +
      ggplot2::coord_cartesian(clip = "off") +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
        axis.text = ggplot2::element_text(color = col_text),
        axis.title = ggplot2::element_text(color = col_text),
        strip.text = ggplot2::element_text(color = col_text, face = "bold"),  # col_text facet labels
        legend.position = "bottom",
        legend.title = ggplot2::element_text(color = col_text),
        legend.text = ggplot2::element_text(color = col_text),
        panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),  # Blended grid lines
        panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1)
      )

    # Print the plot
    suppressMessages(
      print(plots_list$best_hyper_over_time)
    )

  } else if (plot_name == "Hyperparameters vs Error") {
    # PLOT 4: Hyperparameters vs Error
    plots_list$hyper_vs_error <- NULL  # Initialize

    # Transform the list into a big rbinded data frame
    chosen_eval_metric_validation_df <- do.call(rbind, chosen_eval_metric_validation)

    # For each column of hyperparameters, turn into categories
    hyper_cols <- setdiff(names(chosen_eval_metric_validation_df), "chosen_eval_metric")
    for (j in hyper_cols) {
      tryCatch({
        chosen_eval_metric_validation_df[, j] <- as.factor( # As category
          cut(
            chosen_eval_metric_validation_df[, j],
            breaks = unique(stats::quantile(chosen_eval_metric_validation_df[, j], probs = seq(0, 1, by = 0.1), na.rm = TRUE)),
            include.lowest = TRUE
          )
        )
      }, error = function(e) {
        message(paste("Only one unique value identified for", j))
        chosen_eval_metric_validation_df[, j] <- chosen_eval_metric_validation_df[, j]
      })
    }

    # Concatenation based on algorithm
    if (sb_algorithm == "glmnet") {
      chosen_eval_metric_validation_df$concatenation <- paste(
        chosen_eval_metric_validation_df$alpha,
        chosen_eval_metric_validation_df$lambda.min.ratio,
        sep = "_"
      )
    } else if (sb_algorithm == "rf") {
      chosen_eval_metric_validation_df$concatenation <- paste(
        chosen_eval_metric_validation_df$mtry,
        chosen_eval_metric_validation_df$num.trees,
        chosen_eval_metric_validation_df$max.depth,
        chosen_eval_metric_validation_df$min.bucket,
        sep = "_"
      )
    } else if (sb_algorithm == "xgb") {
      chosen_eval_metric_validation_df$concatenation <- paste(
        chosen_eval_metric_validation_df$eta,
        chosen_eval_metric_validation_df$gamma,
        sep = "_"
      )
    } else if (sb_algorithm == "nn") {
      chosen_eval_metric_validation_df$concatenation <- paste(
        chosen_eval_metric_validation_df$lr,
        chosen_eval_metric_validation_df$droprate,
        sep = "_"
      )
    } else {
      # For other algorithms, concatenate all hyperparameters
      chosen_eval_metric_validation_df$concatenation <- apply(
        chosen_eval_metric_validation_df[, hyper_cols],
        1,
        paste,
        collapse = "_"
      )
    }

    # Summarize main quantiles
    chosen_eval_metric_validation_summary <- as.data.frame(
      chosen_eval_metric_validation_df %>%
        dplyr::group_by(concatenation) %>% # Take by group of hyper combinations
        dplyr::summarise(
          median_chosen_eval_metric = stats::median(chosen_eval_metric, na.rm = TRUE), # Q50
          q25 = stats::quantile(chosen_eval_metric, 0.25, na.rm = TRUE),              # Q25
          q75 = stats::quantile(chosen_eval_metric, 0.75, na.rm = TRUE),              # Q75
          max = max(chosen_eval_metric, na.rm = TRUE),                               # Q100
          min = min(chosen_eval_metric, na.rm = TRUE),                               # Q0
          .groups = 'drop'
        )
    )
    # Join with summary
    chosen_eval_metric_validation_df <- chosen_eval_metric_validation_df %>%
      dplyr::left_join(chosen_eval_metric_validation_summary, by = "concatenation")

    # Take last hyper tuning
    total_rows <- nrow(chosen_eval_metric_validation_df)
    tuning_period <- nrow(chosen_eval_metric_validation[[length(chosen_eval_metric_validation)]])
    start_row <- max(total_rows - tuning_period + 1, 1)
    chosen_eval_metric_validation_last_tuning <- chosen_eval_metric_validation_df[start_row:total_rows, ]

    # Generate Hyperparameters vs Error plot based on algorithm
    if (sb_algorithm == "glmnet") {
      # Ensure there are enough colors
      num_alphas <- length(unique(chosen_eval_metric_validation_last_tuning$alpha))
      fill_colors <- palette_colors[1:num_alphas]

      plots_list$hyper_vs_error <- ggplot2::ggplot(
        chosen_eval_metric_validation_last_tuning,
        ggplot2::aes(x = lambda.min.ratio, y = chosen_eval_metric, fill = as.factor(alpha))
      ) +
        ggplot2::geom_bar(stat = "identity", position = "dodge", alpha = 0.7) +
        ggplot2::facet_grid(rows = ggplot2::vars(alpha)) +
        ggplot2::geom_point(
          ggplot2::aes(y = max),
          color = col_quarternary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = q75),
          color = col_terciary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = median_chosen_eval_metric),
          color = col_positive,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = q25),
          color = col_secondary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = min),
          color = col_quinternary,
          size = 2
        ) +
        ggplot2::ggtitle(paste("Validation", chosen_eval_metric, "by alpha and lambda.min.ratio")) +
        ggplot2::scale_fill_manual(values = fill_colors) +
        ggplot2::guides(fill = ggplot2::guide_legend(title = NULL)) +  # Remove legend title
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          axis.text = ggplot2::element_text(color = col_text),
          axis.title = ggplot2::element_text(color = col_text),
          strip.text = ggplot2::element_text(color = col_text, face = "bold"),
          legend.position = "bottom",
          legend.title = ggplot2::element_text(color = col_text),
          legend.text = ggplot2::element_text(color = col_text),
          panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
          panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1),
          plot.caption = ggplot2::element_text(color = col_text, hjust = 0)
        ) +
        ggplot2::labs(caption = "Dots represent quantiles (min, Q25, Q50, Q75, max) of all rebalancing periods.")

      print(plots_list$hyper_vs_error)
    }

    # RF case
    if (sb_algorithm == "rf") {
      # Ensure there are enough colors
      num_mtrys <- length(unique(chosen_eval_metric_validation_last_tuning$mtry))
      fill_colors <- palette_colors[1:num_mtrys]

      plots_list$hyper_vs_error <- ggplot2::ggplot(
        chosen_eval_metric_validation_last_tuning,
        ggplot2::aes(x = mtry, y = chosen_eval_metric, fill = as.factor(mtry))
      ) +
        ggplot2::geom_bar(stat = "identity", position = "dodge", alpha = 0.7) +
        ggplot2::facet_grid(rows = ggplot2::vars(max.depth), cols = ggplot2::vars(min.bucket)) +
        ggplot2::geom_point(
          ggplot2::aes(y = max),
          color = col_quarternary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = q75),
          color = col_terciary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = median_chosen_eval_metric),
          color = col_positive,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = q25),
          color = col_secondary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = min),
          color = col_sextenary,
          size = 2
        ) +
        ggplot2::ggtitle(paste("Validation", chosen_eval_metric, "by max.depth and min.bucket")) +
        ggplot2::scale_fill_manual(values = fill_colors) +
        ggplot2::guides(fill = ggplot2::guide_legend(title = NULL)) +  # Remove legend title
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          axis.text = ggplot2::element_text(color = col_text),
          axis.title = ggplot2::element_text(color = col_text),
          strip.text = ggplot2::element_text(color = col_text, face = "bold"),
          legend.position = "bottom",
          legend.title = ggplot2::element_text(color = col_text),
          legend.text = ggplot2::element_text(color = col_text),
          panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
          panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1),
          plot.caption = ggplot2::element_text(color = col_text, hjust = 0)
        ) +
        ggplot2::labs(caption = "Dots represent quantiles (min, Q25, Q50, Q75, max) of all rebalancing periods.")

      print(plots_list$hyper_vs_error)
    }

    # XGB case
    if (sb_algorithm == "xgb") {
      # Ensure there are enough colors
      num_etas <- length(unique(chosen_eval_metric_validation_last_tuning$eta))
      fill_colors <- palette_colors[1:num_etas]

      plots_list$hyper_vs_error <- ggplot2::ggplot(
        chosen_eval_metric_validation_last_tuning,
        ggplot2::aes(x = eta, y = chosen_eval_metric, fill = as.factor(eta))
      ) +
        ggplot2::geom_bar(stat = "identity", position = "dodge", alpha = 0.7) +
        ggplot2::facet_grid(rows = ggplot2::vars(max_depth), cols = ggplot2::vars(colsample_bytree)) +
        ggplot2::geom_point(
          ggplot2::aes(y = max),
          color = col_quarternary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = q75),
          color = col_terciary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = median_chosen_eval_metric),
          color = col_positive,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = q25),
          color = col_secondary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = min),
          color = col_quinternary,
          size = 2
        ) +
        ggplot2::ggtitle(paste("Validation", chosen_eval_metric, "by max_depth and colsample_bytree")) +
        ggplot2::scale_fill_manual(values = fill_colors) +
        ggplot2::guides(fill = ggplot2::guide_legend(title = NULL)) +  # Remove legend title
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          axis.text = ggplot2::element_text(color = col_text),
          axis.title = ggplot2::element_text(color = col_text),
          strip.text = ggplot2::element_text(color = col_text, face = "bold"),
          legend.position = "bottom",
          legend.title = ggplot2::element_text(color = col_text),
          legend.text = ggplot2::element_text(color = col_text),
          panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
          panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1),
          plot.caption = ggplot2::element_text(color = col_text, hjust = 0)
        ) +
        ggplot2::labs(caption = "Dots represent quantiles (min, Q25, Q50, Q75, max) of all rebalancing periods.")

      print(plots_list$hyper_vs_error)
    }

    # NN case
    if (sb_algorithm == "nn") {
      # Ensure there are enough colors
      num_lrs <- length(unique(chosen_eval_metric_validation_last_tuning$lr))
      fill_colors <- palette_colors[1:num_lrs]

      plots_list$hyper_vs_error <- ggplot2::ggplot(
        chosen_eval_metric_validation_last_tuning,
        ggplot2::aes(x = lr, y = chosen_eval_metric, fill = as.factor(lr))
      ) +
        ggplot2::geom_bar(stat = "identity", position = "dodge", alpha = 0.7) +
        ggplot2::facet_grid(rows = ggplot2::vars(droprate), cols = ggplot2::vars(regularizer_l1)) +
        ggplot2::geom_point(
          ggplot2::aes(y = max),
          color = col_quarternary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = q75),
          color = col_terciary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = median_chosen_eval_metric),
          color = col_positive,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = q25),
          color = col_secondary,
          size = 2
        ) +
        ggplot2::geom_point(
          ggplot2::aes(y = min),
          color = col_quinternary,
          size = 2
        ) +
        ggplot2::ggtitle(paste("Validation", chosen_eval_metric, "by droprate and regularizer_l1")) +
        ggplot2::scale_fill_manual(values = fill_colors) +
        ggplot2::guides(fill = ggplot2::guide_legend(title = NULL)) +  # Remove legend title
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          axis.text = ggplot2::element_text(color = col_text),
          axis.title = ggplot2::element_text(color = col_text),
          strip.text = ggplot2::element_text(color = col_text, face = "bold"),
          legend.position = "bottom",
          legend.title = ggplot2::element_text(color = col_text),
          legend.text = ggplot2::element_text(color = col_text),
          panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
          panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1),
          plot.caption = ggplot2::element_text(color = col_text, hjust = 0)
        ) +
        ggplot2::labs(caption = "Dots represent quantiles (min, Q25, Q50, Q75, max) of all rebalancing periods.")

      print(plots_list$hyper_vs_error)
    }

  } else if (plot_name == "All Evaluation Metrics Over Time") {
    # PLOT 5: All Evaluation Metrics Over Time
    plots_list$all_eval_metrics_over_time <- ggplot2::ggplot(
      oos_testing_eval_metrics %>%
        tidyr::pivot_longer(
          cols = -dates,
          names_to = "variable",
          values_to = "value"
        ) %>%
        dplyr::mutate(variable = gsub("^oos_testing_", "", variable)) %>%  # Remove prefix
        dplyr::filter(!is.na(value)),
      ggplot2::aes(x = dates, y = value, color = variable)
    ) +
      ggplot2::geom_line(alpha = 0.5, show.legend = FALSE) +
      ggplot2::geom_point(size = 2, show.legend = FALSE) +
      ggplot2::labs(x = "Date", y = "Metric") +
      ggplot2::ggtitle("All Evaluation Metrics Over Time") +
      ggplot2::facet_wrap(~variable, scales = "free") +  # Create subplots for each metric with simplified titles
      ggplot2::scale_x_date(labels = scales::date_format("%b-%y")) +
      ggplot2::scale_color_manual(values = palette_colors) +
      ggplot2::geom_vline(xintercept = as.numeric(rebalance_dates), color = col_quarternary, linetype = "dashed") +
      ggplot2::geom_text(
        data = data.frame(x = rebalance_dates, y = -Inf, label = rebalance_dates),
        ggplot2::aes(x = x, y = y, label = label),
        vjust = -0.5, hjust = -0.5, size = 3, color = col_text
      ) +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
        axis.text = ggplot2::element_text(color = col_text),
        axis.title = ggplot2::element_text(color = col_text),
        strip.text = ggplot2::element_text(color = col_text, face = "bold"),
        legend.position = "none",
        panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
        panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1)
      )

    # Add horizontal lines for variable means
    # Create a summary data frame for variable means
    summary_data <- oos_testing_eval_metrics %>%
      tidyr::pivot_longer(
        cols = -dates,
        names_to = "variable",
        values_to = "value"
      ) %>%
      dplyr::mutate(variable = gsub("^oos_testing_", "", variable)) %>%
      dplyr::group_by(variable) %>%
      dplyr::summarise(variable_mean = mean(value, na.rm = TRUE))

    plots_list$all_eval_metrics_over_time <- plots_list$all_eval_metrics_over_time +
      ggplot2::geom_hline(
        data = summary_data,
        ggplot2::aes(yintercept = variable_mean, color = variable),
        linetype = "dashed",
        show.legend = FALSE
      )

    print(plots_list$all_eval_metrics_over_time)

  } else if (plot_name == "Consolidated OOS Testing Metrics") {


    # Add an ID column
    consolidated_oos_testing_metrics$id <- "Consolidated OOS"

    # Melt the consolidated data
    consolidated_data <- tidyr::pivot_longer(
      data = consolidated_oos_testing_metrics,
      cols = -c(metric, id),
      names_to = "Discard_Column",
      values_to = "Value"
    )
    # Remove the unneeded column
    consolidated_data$Discard_Column <- NULL

    # Rename columns for clarity
    colnames(consolidated_data) <- c("Metric", "Type", "Value")

    # Convert Type to a factor with only "Consolidated OOS"
    consolidated_data$Metric <- factor(
      consolidated_data$Metric,
      levels = unique(consolidated_data$Metric)
    )

    # Create the facetted bar chart using only consolidated_data
    plots_list$consolidated_oos_faceted <- ggplot2::ggplot(
      consolidated_data,
      # Notice we use fill = Metric so each metric gets a different color
      ggplot2::aes(x = Type, y = Value, fill = Metric)
    ) +
      ggplot2::geom_bar(stat = "identity", alpha = 0.9) +
      ggplot2::facet_wrap(
        ~ Metric,
        scales = "fixed",
        strip.position = "bottom"
      ) +
      ggplot2::labs(
        title = "Consolidated OOS Testing Metrics",
        x = NULL,
        y = "Metric Value",
        fill = "Metric"
      ) +
      # Manual color scale with your neon palette
      ggplot2::scale_fill_manual(values = palette_colors) +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        strip.placement = "outside",  # Put metric labels below the facets
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold", hjust = 0.5),
        axis.text = ggplot2::element_text(color = col_text),
        axis.title = ggplot2::element_text(color = col_text),
        legend.title = ggplot2::element_text(color = col_text),
        legend.text = ggplot2::element_text(color = col_text),
        legend.position = "bottom",
        strip.text = ggplot2::element_text(color = col_text, face = "bold"),
        panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
        panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1)
      )

    print(plots_list$consolidated_oos_faceted)


  } else if (plot_name == "OOS Predictions, Errors and Targets"){

    #Ask if the user wants to plot a regression-scatterplot
    resp_scat <- readline(prompt = "Do you want to plot a regression scatterplot? (yes/no): ")

    if (resp_scat %in% c("yes", "y")){
      dep_y <- readline(prompt = "Which variable do you want to be the dependent one? Choose between error, target and pred:")

      ##Check
      if (!dep_y %in% c("error", "target", "pred")){
        stop("Please choose between error, target and pred.")
      }
      #Plot scatter
      plot(x@oos_sb_outputs_m_df, dep_y = dep_y, type = "regression", palette = palette)
    } else {
      #Plot others
      plot(x@oos_sb_outputs_m_df, dep_y = NULL, palette = palette)
    }


  } else if (plot_name == "Consolidated OOS Testing Metrics vs Average Validation") {
    # PLOT 6: Compare Average Validation Metrics with Consolidated OOS Testing Metrics

    # Check if both metrics are available
    if (is.null(consolidated_oos_testing_metrics) || is.null(average_validation_metrics)) {
      cat("Both consolidated OOS testing metrics and average validation metrics are required for this plot.\n")
    } else {
      # Add an id column to prevent the melt warning
      consolidated_oos_testing_metrics$id <- "Consolidated OOS"
      average_validation_metrics$id <- "Average Validation"


      # Melt both data frames to long format with specified id.vars
      consolidated_data <- tidyr::pivot_longer(
        data = consolidated_oos_testing_metrics,
        cols = -c(metric, id),
        names_to = "Discard_Column",
        values_to = "Value"
      )

      average_data <- tidyr::pivot_longer(
        data = average_validation_metrics,
        cols = -c(metric, id),
        names_to = "Discard_Column",
        values_to = "Value"
      )


      consolidated_data$Discard_Column <- NULL
      average_data$Discard_Column <- NULL

      # Bind the two data frames together
      plot_data <- dplyr::bind_rows(consolidated_data, average_data)
      colnames(plot_data) <- c("Metric", "Type", "Value")

      # Create the facetted bar chart
      plots_list$comparison_avg_val_oos_faceted <- ggplot2::ggplot(
        plot_data,
        ggplot2::aes(x = Type, y = Value, fill = Type)
      ) +
        ggplot2::geom_bar(
          stat = "identity",
          position = ggplot2::position_dodge(width = 0.8),
          alpha = 0.8
        ) +
        # Facet by Metric, with the strip label on the bottom:
        ggplot2::facet_wrap(
          ~ Metric,
          scales = "free_y",
          strip.position = "bottom"  # put the metric label beneath each plot
        ) +
        ggplot2::labs(
          title = "Consolidated OOS Testing Metrics vs Average Validation",
          # We remove the x-axis label to avoid duplication with the facet label
          x = NULL,
          y = "Metric Value",
          fill = "Metric Type"
        ) +
        ggplot2::scale_fill_manual(
          # Adjust to your custom color palette:
          values = c(col_negative, col_positive)
        ) +
        ggplot2::theme_minimal() +
        ggplot2::theme(
          # Ensure the facet labels are placed outside the panel:
          strip.placement = "outside",

          # Keep your existing background and text coloring:
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          plot.title = ggplot2::element_text(
            color = col_text,
            size = 16,
            face = "bold",
            hjust = 0.5
          ),
          axis.text = ggplot2::element_text(color = col_text),
          axis.title = ggplot2::element_text(color = col_text),
          legend.title = ggplot2::element_text(color = col_text),
          legend.text = ggplot2::element_text(color = col_text),
          legend.position = "bottom",
          strip.text = ggplot2::element_text(color = col_text, face = "bold"),
          panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
          panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1)
        )

      print(plots_list$comparison_avg_val_oos_faceted)
    }
  } else if (plot_name == "Final Signal-Blending Model"){

    tryCatch(
      {
        tryCatch(
          sb_algo <- x@final_sb_model@sb_algorithm,
          error = function(e){
            #Assign as null
            sb_algo <- NULL
          }
        )
        if (is.null(sb_algo) %in% c("rp", "hrp", "mvo", "mmaf", "sw", "ew", "cs")){
          plot(x@final_sb_model@model, palette = palette)
        } else {
          plot(x@final_sb_model@model)
        }

      }, error = function(e){
        warning("Error when plotting subjacent final signal-blending model. The following message was displayed by subjacent function: \n",
                e$message, "\n")
      })

    #Feature Importance Plots
    ########################
  } else if (plot_name == "Time-Series Feature Importance by Signal"){

    plot_type <- "time_series"
    clustering_variables <- "tickers"
    calc_stat <- "mean"
    variable <- "normalized_importance"

    plot(x@feature_importance_m_df, variable = variable, type = plot_type, clustering_variables = clustering_variables, palette = palette)

  } else if (plot_name == "Average Time-Series Feature Importance by Theme"){

    if(!"theme" %in% colnames(x@feature_importance_m_df@data)){
      stop("The feature importance data does not contain a 'theme' column. Please review the signal selection process to ensure a 'theme' classification is provided. \n")
    }

    plot_type <- "time_series"
    clustering_variables <- "theme"
    calc_stat <- "mean"
    variable <- "normalized_importance"

    plot(x@feature_importance_m_df, variable = variable, type = plot_type, clustering_variables = clustering_variables, palette = palette)

  } else if (plot_name == "Compare Feature Importance Side-by-Side by Signal"){

    plot_type <- "cross_sectional"
    clustering_variables <- "tickers"
    calc_stat <- "mean"
    variable <- "normalized_importance"

    plot(x@final_feature_importance_m_d_ref, variable = variable, type = plot_type, clustering_variables = clustering_variables, calc_stat = calc_stat, palette = palette)

  } else if (plot_name == "Compare Feature Importance Side-by-Side by Theme"){

    if(!"theme" %in% colnames(x@feature_importance_m_df@data)){
      stop("The feature importance data does not contain a 'theme' column. Please review the signal selection process to ensure a 'theme' classification is provided. \n")
    }

    plot_type <- "cross_sectional"
    clustering_variables <- "theme"
    calc_stat <- "mean"
    variable <- "normalized_importance"

    plot(x@final_feature_importance_m_d_ref, variable = variable, type = plot_type, clustering_variables = clustering_variables, calc_stat = calc_stat, palette = palette)

  } else if (plot_name == "Feature Importance Box-Plot by Signal"){

    plot_type <- "boxplot"
    clustering_variables <- "tickers"
    variable <- "normalized_importance"

    plot(x@feature_importance_m_df, variable = variable, type = plot_type, clustering_variables = clustering_variables, palette = palette)

  } else if (plot_name == "Feature Importance Box-Plot by Theme"){

    if(!"theme" %in% colnames(x@feature_importance_m_df@data)){
      stop("The feature importance data does not contain a 'theme' column. Please review the signal selection process to ensure a 'theme' classification is provided. \n")
    }

    plot_type <- "boxplot"
    clustering_variables <- "theme"
    variable <- "normalized_importance"

    plot(x@final_feature_importance_m_d_ref, variable = variable, type = plot_type, clustering_variables = clustering_variables, palette = palette)

  } else if (plot_name == "Feature Importance Heatmap by Signal"){

    plot_type <- "tile_heatmap"
    clustering_variables <- "tickers"
    variable <- "normalized_importance"
    calc_stat <- "mean"

    plot(x@feature_importance_m_df, variable = variable, type = plot_type, clustering_variables = clustering_variables, calc_stat = calc_stat, palette = palette)

  } else if (plot_name == "Feature Importance Heatmap by Theme"){

    if(!"theme" %in% colnames(x@feature_importance_m_df@data)){
      stop("The feature importance data does not contain a 'theme' column. Please review the signal selection process to ensure a 'theme' classification is provided. \n")
    }

    plot_type <- "tile_heatmap"
    clustering_variables <- "theme"
    variable <- "normalized_importance"
    calc_stat <- "mean"

    plot(x@feature_importance_m_df, variable = variable, type = plot_type, clustering_variables = clustering_variables, calc_stat = calc_stat, palette = palette)

  } else if (plot_name == "Explain Prediction"){

    #Check for features_m_df
    if (is.null(features_m_df)){
      stop("The 'features_m_df' argument is required for this plot. Please provide a meta dataframe with the features used to implement the backtest \n")
    } else {
      if (!is_meta_dataframe(features_m_df)){
        stop("The 'features_m_df' argument must be a meta dataframe. Please review the documentation for more information \n")
      }
    }

    # Prompt for 'ticker'
    if (is.null(ticker_to_explain)){
      cat("Which ticker predictions do you want to explain? (Please select just one) \n")
      selection <- readline(prompt = "Enter your choice: ")
      if (length(selection) == 1 && nzchar(selection)) {
        selected_ticker <- selection
      } else {
        stop("Invalid ticker selection. Please select just one ticker. \n")
      }
    } else {
      ticker_to_explain <- as.character(ticker_to_explain)
      if (length(ticker_to_explain) == 1 && nzchar(ticker_to_explain)) {
        selected_ticker <- ticker_to_explain
      } else {
        stop("Invalid 'ticker_to_explain' argument. Please provide a single ticker as a character string. \n")
      }
    }


    # Prompt for 'date'
    if (is.null(date_to_explain)){
      cat("Which date? (Please select just one in format YYYY-MM-DD) \n")
      selection <- readline(prompt = "Enter your choice: ")
      if (!grepl("^\\d{4}-\\d{2}-\\d{2}$", selection)) {
        stop("Invalid date format. Use 'YYYY-MM-DD'.")
      }
      if (length(selection) == 1 && nzchar(selection)) {
        selected_date <- as.Date(selection)
      } else {
        stop("Invalid date selection. Please select just one date. \n")
      }
    } else {
      if (!grepl("^\\d{4}-\\d{2}-\\d{2}$", date_to_explain)) {
        stop("Invalid 'date_to_explain' format. Use 'YYYY-MM-DD'.")
      }
      if (length(date_to_explain) == 1 && nzchar(date_to_explain)) {
        selected_date <- as.Date(date_to_explain)
      } else {
        stop("Invalid 'date_to_explain' argument. Please provide a single date in 'YYYY-MM-DD' format. \n")
      }
    }

    #Explain
    explain_prediction(x, features_m_df = features_m_df, selected_ticker = selected_ticker, selected_date = selected_date, palette = palette)

  }

  invisible(x)
})



#' @title Plot Method for sb_metabacktest_results Class
#' @description Generates various plots to visualize the performance and metrics of meta-learning backtest results.
#' Users can select which plot to display by specifying the `plot_id` parameter,
#' either by name or by number.
#' The plots include comparisons between base learners and meta learners over time.
#'
#' @param x An object of class \code{sb_metabacktest_results} containing the results of the meta-learning backtests.
#' @param plot_id A character string or numeric value specifying which plot to display.
#'   - By name: Options are:
#'     - `"Combined and Consolidated OOS Testing Metrics - All Dates"`
#'     - `"Combined and Averaged OOS Testing Metrics - Common Dates"`
#'     - `"Time Series OOS Testing Metrics"`
#'     - `"Mean Validation Metrics Comparison"`
#'     - `"Time Series Validation Metrics"`
#'     - `"Prediction Error Correlation"`
#'     - `"Base Learners vs Meta Learners Over Time"`
#'     - `"Hierarchical Feature Importance"`
#'   - By number: Provide a number corresponding to the plot (as listed when `plot_id` is `NULL`).
#'   If `NULL` (default), the method lists available plots.
#' @param palette Character. Color palette to use for the plot. Options include "cyberpunk", "br" and "journal". Default is "cyberpunk".
#' @param chosen_metric Character. The specific metric to plot (e.g., "rmse", "mae"). Required for certain plots.
#' @param chosen_backtests Character vector. Specific backtests to include in the plot.
#' @param top_n Numeric. If specified, limits the plot to the top N backtests based on the chosen metric.
#' @param facet_by_year Logical. If `TRUE`, facets the plot by year.
#' @param add_overall_means Logical. If `TRUE`, adds horizontal lines representing the overall mean of the chosen metric.
#' @return Invisibly returns the input \code{x}.
#' @export
setMethod("plot", "sb_metabacktest_results", function(x, plot_id = NULL, palette = "cyberpunk", chosen_metric = NULL, chosen_backtests = NULL, top_n = NULL,
                                                      facet_by_year = NULL, add_overall_means = NULL) {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  # List of available plots
  available_plots <- c(
    "Combined and Consolidated OOS Testing Metrics - All Dates",
    "Combined and Averaged OOS Testing Metrics - Common Dates",
    "Time Series OOS Testing Metrics",
    "Mean Validation Metrics Comparison",
    "Time Series Validation Metrics",
    "Prediction Error Correlation",
    "Base Learners vs Meta Learners Over Time",
    "Hierarchical Feature Importance"
  )

  # Display the available plots and prompt the user if plot_id is NULL
  if (is.null(plot_id)) {
    cat("\nPlease choose a plot to display:\n")
    for (i in seq_along(available_plots)) {
      cat(paste0(i, ": ", available_plots[i], "\n"))
    }
    selection <- readline(prompt = "Enter the number of your choice: ")
    plot_id <- as.numeric(selection)
    if (is.na(plot_id) || plot_id < 1 || plot_id > length(available_plots)) {
      stop("Invalid selection.")
    }
  }

  # Determine if plot_id is numeric (index) or character (name)
  if (is.numeric(plot_id)) {
    if (plot_id >= 1 && plot_id <= length(available_plots)) {
      plot_name <- available_plots[plot_id]
    } else {
      stop("Invalid plot number. Please select a number between 1 and ", length(available_plots), ".")
    }
  } else if (is.character(plot_id)) {
    if (plot_id %in% available_plots) {
      plot_name <- plot_id
    } else {
      stop("Invalid 'plot_id' specified. Available options are:\n",
           paste(available_plots, collapse = ", "))
    }
  } else {
    stop("'plot_id' must be either a string or a number corresponding to the plot.")
  }

  # Palette
  black <- "#000000"
  white <- "#FFFFFF"

  if (palette == "cyberpunk") {

    light_gray <- "#003641"

    col_background <- "#001f3f"
    col_text       <- "#FFFFFF"
    col_primary    <- "#6A0DAD"
    col_positive   <- "#39FF14"
    col_negative   <- "#FF5F1F"
    col_secondary <- "#FF69B4"      # Hot Pink
    col_terciary <-  "#FF1493" # Lime Green
    col_quarternary <-  "#FFA500"
    col_quinternary <- "#FF4500"
    col_sextenary <- "#32CD32"
    vertical_line_color <- "#FF69B4"

    palette_colors <- c(
      "#00BFFF", "#FF1493", "#FFFF00", "#8A2BE2",
      "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500",
      "#30D5C8", "#FF00FF", "#FF073A", "#00FFFF",
      "#7FFF00", "#EE82EE", "#00FFEF", "#FFD700", "#87CEFA"
    )


  }
  if (palette == "br") {

    light_gray <- "#EBEEF1"

    col_background <- "#FFFFFF"
    col_text       <- "#003641"
    col_primary   <- "#00A091"
    col_secondary  <- "#4C7C83"
    col_terciary   <- "#49479D"
    col_quarternary <- "#7DB61C"
    col_quinternary <- "#003641"
    col_sextenary  <- "#D6E266"
    col_positive   <- "#7DB61C"
    col_negative   <- "#C2185B"
    vertical_line_color <- "#003641"

    palette_colors  <- c(
      "#94E1D6","#49479D","#7DB61C",
      "#00C9B8", "#98B2B6","#C9D200",
      "#003641", "#00A091", "#4C7C83",
      "#FF5F1F", "#EBEEA8", "#A5CD5C",
      "#8A03C9", "#00AE9D", "#EBEEA8",
      "#D6E266", "#00C9B8", "#7DB61C",
      "#A5CD5C", "#003641", "#00A091",
      "#4C7C83", "#FF5F1F"
    )

  }
  if (palette == "journal") {

    jp <- .journal_palette()

    light_gray <- jp$grid

    col_background <- jp$background
    col_text       <- jp$text
    col_primary    <- jp$primary
    col_secondary  <- jp$categorical[3]
    col_terciary   <- jp$categorical[6]
    col_quarternary <- jp$positive
    col_quinternary <- jp$sequential[7]
    col_sextenary  <- jp$categorical[4]
    col_positive   <- jp$positive
    col_negative   <- jp$negative
    vertical_line_color <- jp$text

    ### Recycle the eight journal hues to match the br palette length
    palette_colors <- rep(jp$categorical, length.out = 23)

  }


  # Extract data from the sb_metabacktest_results object
  combined_metrics <- x@combined_oos_testing_metrics
  time_series_oos_testing_metrics <- x@time_series_oos_testing_metrics
  mean_validation_metrics <- x@mean_validation_metrics
  time_series_validation_metrics <- x@time_series_validation_metrics
  base_learners <- x@base_sb_backtest_results_list
  meta_learner <- x@meta_sb_backtest_results

  if (plot_name %in% available_plots[c(1:6)]){

    #Call method to general consolidate sb_backtest_results plots
    plot_consolidated_sb_backtest_results(combined_metrics = combined_metrics, mean_validation_metrics = mean_validation_metrics,
                                          time_series_oos_testing_metrics = time_series_oos_testing_metrics, time_series_validation_metrics = time_series_validation_metrics,
                                          base_learners = base_learners, plot_name = plot_name, chosen_backtests = chosen_backtests,
                                          palette = palette
    )

  } else if (plot_name == "Base Learners vs Meta Learners Over Time") {
    # Plot comparison of base learners and meta learners over time for a selected metric

    # Prompt user to select a metric
    available_metrics <- names(time_series_oos_testing_metrics)
    if (is.null(chosen_metric)){
      cat("\nAvailable metrics:\n")
      for (i in seq_along(available_metrics)) {
        cat(paste0(i, ": ", available_metrics[i], "\n"))
      }
      metric_selection <- readline(prompt = "Please select a metric by number: ")
      metric_selection <- as.numeric(metric_selection)
      if (is.na(metric_selection) || metric_selection < 1 || metric_selection > length(available_metrics)) {
        stop("Invalid metric selection.")
      }
      metric_name <- available_metrics[metric_selection]
    } else {
      if (chosen_metric %in% available_metrics) {
        metric_name <- chosen_metric
      } else {
        stop("Invalid 'chosen_metric' specified. Available options are:\n",
             paste(available_metrics, collapse = ", "))
      }
    }

    # Prepare data
    meta_xts <- time_series_oos_testing_metrics[[metric_name]]

    if (is.null(meta_xts@data)) {
      cat("Metric", metric_name, "not found in time series OOS testing metrics.\n")
      return(invisible(x))
    }

    base_learner_ids <- sapply(base_learners, function(bl) bl@backtest_identifier) #Get bae learner ids
    meta_learner_id <- meta_learner@backtest_identifier #Get meta learner id

    clustering_list <- list("meta_learner" = meta_learner_id, "base_learners" = base_learner_ids)

    # Use all names in meta_xts if chosen_backtests is "all"
    if (chosen_backtests == "all") {
      chosen_backtests <- names(meta_xts@data)
    }

    # Use meta_xts plot method
    plot(x = meta_xts, clustering_list = clustering_list, palette = palette, facet_by_year = facet_by_year,
         add_overall_means = add_overall_means, variable = chosen_backtests)

  }  else if (plot_name == "Hierarchical Feature Importance"){

    # Prompt User for Number of Top Features**
    if (is.null(top_n)){
      num_features <- as.integer(readline(prompt = "Enter the number of top features to display: "))
    } else {
      num_features <- as.integer(top_n)
    }

    # Ensure valid input
    if (is.na(num_features) || num_features <= 0) {
      stop("Invalid input. Please enter a positive integer.")
    }

    # Extract Meta-Learner Feature Importances**
    meta_importance_df <- x@meta_sb_backtest_results@final_feature_importance_m_d_ref@data

    # Filter Meta-Learner Features Based on Importance**
    meta_importance_df <- meta_importance_df %>%
      dplyr::slice_max(order_by = abs(importance), n = num_features)
    ##Change tickers for backtest id with config_name
    # Get the list of base learners
    base_learners_feature_imp_list <- x@base_sb_backtest_results_list
    base_model_configs <- sapply(base_learners_feature_imp_list, function(x) x@sb_backtest_config@config_name)
    meta_importance_df <- meta_importance_df %>%
      dplyr::mutate(
        tickers = ifelse(
          tickers %in% names(base_model_configs),
          base_model_configs[tickers],
          tickers
        ),
        id = paste0(tickers, "-", dates)
      )
    base_model_configs <- unname(base_model_configs)
    # **2. Extract Base Learners' Feature Importances**
    # Check if we have repeated configs
    if (any(duplicated(base_model_configs))) {
      warning("There are repeated base model configurations. Base learner IDs will be assigned as 'model_1', 'model_2', etc. to ensure uniqueness.")
      base_model_ids <- paste0("model_", seq_along(base_learners_feature_imp_list))
    } else {
      base_model_ids <- base_model_configs
    }

    # If base_model_ids are NULL or empty, assign default names
    if (is.null(base_model_ids) || any(base_model_ids == "")) {
      base_model_ids <- paste0("BaseLearner", seq_along(base_learners_feature_imp_list))
      names(base_learners_feature_imp_list) <- base_model_ids
    }

    # Filter Each Base Learner's Feature Importance
    base_learners_feature_imp <- lapply(base_learners_feature_imp_list, function(bl) {
      bl@final_feature_importance_m_d_ref@data %>%
        dplyr::slice_max(order_by = abs(importance), n = num_features)
    })

    # **3. Normalize Base Models' Relative Importances**
    base_importances_sum <- sapply(base_learners_feature_imp, function(df) {
      sum(abs(df$importance))
    })

    total_importance_sum <- sum(base_importances_sum)
    base_importances_norm <- base_importances_sum / total_importance_sum

    # **4. Prepare Links from Features to Base Learners**
    links_base <- mapply(
      FUN = function(base_df, base_model_id) {
        base_df %>%
          dplyr::mutate(
            from = tickers,  # Feature name
            to = base_model_id,  # Base learner ID
            value = importance  # Importance value
          ) %>%
          dplyr::select(from, to, value)
      },
      base_df = base_learners_feature_imp,
      base_model_id = base_model_ids,
      SIMPLIFY = FALSE
    ) %>%
      dplyr::bind_rows()

    # **5. Prepare Links from Features Directly to Meta-Learner**
    links_direct <- meta_importance_df %>%
      dplyr::mutate(
        from = tickers,  # Feature name
        to = "meta_learner",  # Meta-learner node
        value = importance  # Importance value
      ) %>%
      dplyr::select(from, to, value)

    # **6. Prepare Links from Base Learners to Meta-Learner**
    links_meta <- data.frame(
      from = base_model_ids,  # Base learner IDs
      to = "meta_learner",  # Meta-learner node
      value = base_importances_norm,  # Normalized importance values
      stringsAsFactors = FALSE
    )

    # **7. Combine All Links**
    links <- dplyr::bind_rows(links_base, links_direct, links_meta)

    # **8. Define Nodes for the Hierarchical Tree**
    features <- unique(c(links_base$from, links_direct$from))
    features <- setdiff(features, base_model_ids)
    base_learners <- base_model_ids
    meta_learner <- "meta_learner"

    nodes <- data.frame(
      name = unique(c(features, base_learners, meta_learner)),
      stringsAsFactors = FALSE
    )

    # **10. Categorize Nodes into Types**
    nodes <- nodes %>%
      dplyr::mutate(type = dplyr::case_when(
        name %in% features ~ "Feature",
        name %in% base_learners ~ "Base Learner",
        name == meta_learner ~ "Meta Learner",
        TRUE ~ "Other"
      ))

    # Get colors
    type_colors <- c(
      "Feature" = col_primary,
      "Base Learner" = col_secondary,
      "Meta Learner" = col_terciary,
      "Other" = col_quarternary
    )

    # **12. Create the Graph Object with igraph**
    graph <- igraph::graph_from_data_frame(d = links, vertices = nodes, directed = TRUE)

    # Extract unique base model IDs
    base_model_ids <- unique(igraph::V(graph)$name[grepl("^c:", igraph::V(graph)$name)])

    # Create a mapping (model_1, model_2, ...)
    base_model_mapping <- stats::setNames(paste0("model_", seq_along(base_model_ids)), base_model_ids)

    # Rename the nodes in the graph
    igraph::V(graph)$name <- ifelse(igraph::V(graph)$name %in% names(base_model_mapping),
                                    base_model_mapping[igraph::V(graph)$name],
                                    igraph::V(graph)$name)

    # **13. Adjust Layout to Position Meta-Learner Below Base Models**
    layout <- ggraph::create_layout(graph, layout = "tree")
    layout$y <- ifelse(layout$name == "meta_learner", min(layout$y) - 1, layout$y)

    # **14. Generate Graph Plot**
    p <- ggraph::ggraph(layout) +
      ggraph::geom_edge_link(
        ggplot2::aes(width = value, color = value, alpha = value),
        arrow = ggplot2::arrow(length = grid::unit(4, 'mm')),
        end_cap = ggraph::circle(3, 'mm')
      ) +
      ggraph::geom_node_point(ggplot2::aes(color = type), size = 5) +
      ggraph::geom_node_text(
        ggplot2::aes(label = name),
        color = col_text,
        hjust = 0.5,
        vjust = -1.2,
        size = 2,
        fontface = "bold"
      ) +
      ggraph::scale_edge_width(range = c(0.5, 3)) +
      ggplot2::scale_color_manual(values = type_colors) +
      ggraph::scale_edge_color_continuous(
        low = col_negative,
        high = col_positive,
        name = "Importance",
        guide = ggraph::guide_edge_colorbar()
      ) +
      ggraph::scale_edge_alpha_continuous(range = c(0.0001, 0.8)) +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        legend.position = "bottom",
        plot.margin = ggplot2::margin(5, 40, 5, 5),
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.grid = ggplot2::element_blank(),
        axis.text = ggplot2::element_blank(),
        axis.title = ggplot2::element_blank(),
        axis.ticks = ggplot2::element_blank(),
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
        plot.subtitle = ggplot2::element_text(color = col_text, size = 12, face = "italic"),
        legend.text = ggplot2::element_text(color = col_text),
        legend.title = ggplot2::element_text(color = col_text)
      ) +
      ggplot2::labs(
        title = "Hierarchical Feature Importance",
        subtitle = x@meta_sb_backtest_results@backtest_identifier,
        edge_width = "Importance",
        edge_color = "Importance",
        edge_alpha = "Importance",
        color = "Node Type"
      )

    print(p)


  }

  invisible(x)
})


#' @title Plot Priors from ss_backtest_config
#' @description Plots the distribution curves (normal, student_t, cauchy, lognormal, beta, or exponential) for
#' each user prior in \code{x@@alpha_test_strategy@@bayesian_model_parameters@@user_priors}. \code{"lkj"} correlation
#' priors and unparseable/unsupported prior strings are skipped with a message. Requires a \code{bayesian_alpha_test_strategy}
#' with non-empty \code{user_priors}; otherwise prints a message and returns invisibly.
#' @param x An object of class `ss_backtest_config` with a `bayesian_alpha_test_strategy` alpha test strategy.
#' @param palette A character string specifying the color palette. \code{"cyberpunk"} produces a dark theme; any other value produces a light theme. Default is `"cyberpunk"`.
#' @param ... Additional arguments (currently unused).
#' @rdname plot_ss_backtest_config
#' @export
setMethod("plot", "ss_backtest_config", function(x, palette = "cyberpunk", ...) {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  # Validate input object
  if (!inherits(x@alpha_test_strategy, "bayesian_alpha_test_strategy")) {
    stop("This plot method is only applicable to 'bayesian_alpha_test_strategy' subclass.")
  }

  # Extract user priors
  user_priors <- x@alpha_test_strategy@bayesian_model_parameters@user_priors
  if (is.null(user_priors) || nrow(user_priors) == 0) {
    cat("No user priors available to plot.\n")
    return(invisible(NULL))
  }

  # Convert priors to data frame
  priors_df <- as.data.frame(user_priors, stringsAsFactors = FALSE)

  # Define color palette
  if (palette == "cyberpunk"){
    col_background <- "#001f3f"
    col_text       <- "#FFFFFF"
    light_gray <- "#003641"

    class_colors <- c(
      b = "#FF1493",  # Neon Pink
      sd = "#FFFF00", # Neon Yellow
      sigma = "#8A2BE2" # Neon Purple
    )
  } else {

    col_background <- "#FFFFFF"
    light_gray <- "#EBEEF1"
    col_text      <- "#002C33"

    class_colors <- c(
      b = "#003641",
      sd =  "#7DB61C",
      sigma = "#49479D"
    )
  }

  # Helper function to parse prior strings
  parse_prior_string <- function(prior_str) {
    prior_str <- gsub(" ", "", prior_str)
    regex <- "^([a-zA-Z_]+)\\((.*)\\)$"
    matches <- regmatches(prior_str, regexec(regex, prior_str))[[1]]

    if (length(matches) < 3) return(NULL)

    dist_name <- matches[2]
    params_str <- matches[3]
    params <- strsplit(params_str, ",")[[1]]
    param_list <- as.numeric(gsub(".*=", "", params))

    list(dist = dist_name, params = param_list)
  }

  # Helper function to generate plot data
  generate_plot_data <- function(dist_name, params) {
    x_seq <- seq(-3, 3, length.out = 1000)
    density <- switch(
      dist_name,
      "normal" = stats::dnorm(x_seq, mean = params[1], sd = params[2]),
      "student_t" = stats::dt((x_seq - params[2]) / params[3], df = params[1]) / params[3],
      "cauchy" = stats::dcauchy(x_seq, location = params[1], scale = params[2]),
      "lognormal" = stats::dlnorm(x_seq, meanlog = params[1], sdlog = params[2]),
      "beta" = stats::dbeta(x_seq, shape1 = params[1], shape2 = params[2]),
      "exponential" = stats::dexp(x_seq, rate = params[1]),
      NULL
    )
    if (is.null(density)) return(NULL)
    data.frame(x = x_seq, density = density)
  }

  # Prepare an empty list to store plots
  plot_list <- list()

  common_x_range <- seq(-3, 3, length.out = 1000)

  # Iterate over each prior
  for (i in seq_len(nrow(priors_df))) {
    prior_row <- priors_df[i, ]

    prior_str <- prior_row$prior
    class_str <- prior_row$class
    coef_str <- prior_row$coef
    group_str <- prior_row$group

    # Create identification string by concatenating class, coef, and group
    id_components <- c(
      paste0("class: ", class_str),
      if (!is.na(coef_str) && coef_str != "") paste0("coef: ", coef_str) else NULL,
      if (!is.na(group_str) && group_str != "") paste0("group: ", group_str) else NULL
    )
    id_str <- paste(id_components, collapse = ", ")

    # Parse the prior string to extract distribution and parameters
    parsed_prior <- parse_prior_string(prior_str)
    if (is.null(parsed_prior)) {
      message(sprintf("Could not parse prior: '%s'. Skipping.", prior_str))
      next
    }

    dist_name <- parsed_prior$dist
    params <- parsed_prior$params

    # Handle 'lkj' distribution separately
    if (dist_name == "lkj") {
      # Provide an informative message
      message(sprintf("The 'lkj' prior (prior '%s' with %s) will be skipped.", prior_str, id_str))
      next
    }

    # Generate data for plotting based on distribution
    plot_data <- generate_plot_data(dist_name, params)
    if (is.null(plot_data)) {
      message(sprintf("Unsupported distribution '%s' for prior '%s' with %s. Skipping.", dist_name, prior_str, id_str))
      next
    }

    # Ensure the x-axis matches the common range
    plot_data <- merge(data.frame(x = common_x_range), plot_data, by = "x", all.x = TRUE)
    plot_data$density[is.na(plot_data$density)] <- 0

    # Create the plot with cyberpunk style
    p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = x, y = density)) +
      ggplot2::geom_line(color = class_colors[class_str], size = 1) +
      ggplot2::labs(
        title = paste0(prior_str, "\n", id_str),
        x = "Value", y = "Density"
      ) +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        plot.title = ggplot2::element_text(color = col_text, size = 14, face = "bold"),
        axis.text = ggplot2::element_text(color = col_text),
        axis.title = ggplot2::element_text(color = col_text),
        legend.position = "none",
        panel.grid.major = ggplot2::element_line(color = light_gray, size = 0.2),
        panel.grid.minor = ggplot2::element_line(color = light_gray, size = 0.1)
      )

    # Store the plot in the list
    plot_list[[length(plot_list) + 1]] <- p
  }

  # Arrange and display the plots
  if (length(plot_list) > 0) {
    gridExtra::grid.arrange(grobs = plot_list, ncol = 1)
  } else {
    cat("No valid priors to plot.\n")
  }

  invisible(NULL)
})




#' @title Plot Bayesian Alpha Test Strategy Priors
#' @description Plots the prior distributions defined in a `bayesian_alpha_test_strategy` object.
#' @param x A `bayesian_alpha_test_strategy` object.
#' @param y Ignored. Included for S3 compatibility.
#' @param ... Additional arguments (currently unused).
#' @method plot bayesian_alpha_test_strategy
#' @export
setMethod("plot", "bayesian_alpha_test_strategy", function(x, ...) {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  if (is.null(x@bayesian_model_parameters)) {
    cat("No Bayesian model parameters to plot.\n")
    return(invisible(NULL))
  }

  # Call the plot method of bayesian_model_parameters
  plot(x@bayesian_model_parameters, ...)
})


#' @title Plot Method for ss_backtest_results Class
#' @description Generates various plots to visualize metrics from the `ss_backtest_results` object.
#' Users can select which plot to display by specifying the `plot_id` parameter (numeric index or exact name);
#' if omitted, an interactive menu is shown. Available plots for every `ss_backtest_results` object:
#' \code{"Time-Series Metrics by Signal"}, \code{"Average Time-Series Metrics by Theme"},
#' \code{"Compare Metrics Side-by-Side by Signals"}, \code{"Compare Metrics Side-by-Side by Theme"},
#' \code{"Box-Plot by Theme"}, \code{"Box-Plot by Eligibility"}, \code{"Waterfall Plot by Signal"},
#' \code{"Waterfall Plot by Theme"}, \code{"Eligibility by Theme"}. When \code{x@@p_correction_method == "bayesian"},
#' the following posterior-diagnostic plots are also available: \code{"Posterior Individual Alphas"},
#' \code{"Posterior Individual Betas"}, \code{"Posterior Random Effects"},
#' \code{"Waterfall Plot of Posterior Variance Components"}, \code{"Posterior Regression Lines"},
#' \code{"Waterfall Plot of Return Decomposition by Signal"},
#' \code{"Posterior Individual Alpha Distributions by Theme and Signal"}.
#' @param x An object of class `ss_backtest_results`.
#' @param plot_id A character string or numeric value specifying which plot to display (see `@description` for the full list of names).
#' @param palette A character string specifying the color palette. Must be one of `"cyberpunk"` (dark theme), `"br"` (light theme) or `"journal"` (sober, print-oriented light theme); any other value is not handled and will error. Default is `"cyberpunk"`.
#' @param variable Character vector of tickers to include, used only by the Bayesian posterior-diagnostic plots (\code{plot_id} 10 and above). If `NULL`, an interactive ticker-selection prompt is shown. Ignored for the other plot types.
#' @return Invisibly returns the input object.
#' @export
setMethod("plot", "ss_backtest_results", function(x, plot_id = NULL, palette = "cyberpunk", variable = NULL) {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  # Define colors for plotting
  # Palette
  black <- "#000000"
  white <- "#FFFFFF"

  if (palette == "cyberpunk") {

    light_gray <- "#003641"

    col_background <- "#001f3f"
    col_text       <- "#FFFFFF"
    col_primary    <- "#FF1493"
    col_secondary <- "#FF69B4"      # Hot Pink
    col_terciary <-  "#00FFFF" # Lime Green
    col_quarternary <-  "#FFA500"
    col_quinternary <- "#FF4500"
    col_sextenary <- "#32CD32"
    pos_color   <- "#39FF14"
    neg_color   <- "#FF1493"
    vertical_line_color <- "#FF69B4"
    cyan <- "#00FFFF"

    palette_colors  <- c(
      "#00BFFF", "#FF1493", "#FFFF00",  "#00FFFF", "#8A2BE2",
      "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500",
      "#FF10F0", "#00FFF7", "#FF4500",  "#FF1493",  "#00CED1",
      "#00FA9A",  "#DC143C", "#FF69B4"
    )


  }
  if (palette == "br") {

    light_gray <- "#EBEEF1"

    col_background <- "#FFFFFF"
    col_text       <- "#003641"
    col_primary   <- "#00A091"
    col_secondary  <- "#4C7C83"
    col_terciary   <- "#49479D"
    col_quarternary <- "#39FF14"
    col_quinternary <- "#003641"
    col_sextenary  <- "#D6E266"
    pos_color   <- "#7DB61C"
    neg_color   <- "#C2185B"
    vertical_line_color <- "#003641"
    cyan <- "#94E1D6"

    palette_colors  <- c(
      "#94E1D6",
      "#49479D",
      "#7DB61C",
      "#003641",
      "#00C9B8",
      "#2F2D6F",
      "#FF5F1F",
      "#39FF14",
      "#C9D200",
      "#00A091",
      "#3FB7C4",
      "#EBEEF1",
      "#98B2B6",
      "#6E8B91",
      "#4C7C83",
      "#A8A600",
      "#3E3C8A",
      "#5A58B5",
      "#6E6CC4",
      "#002C33",
      "#004F57",
      "#8E9400",
      "#EBEEA8",
      "#D6E266",
      "#CEE2A2",
      "#B6B300",
      "#A5CD5C",
      "#0A3D62",
      "#006D77",
      "#1B8A9B",
      "#0F4C81",
      "#1B4F8C",
      "#2E6F95",
      "#3A7CA5",
      "#4A90C2"
    )

  }
  if (palette == "journal") {

    jp <- .journal_palette()

    light_gray <- jp$grid

    col_background <- jp$background
    col_text       <- jp$text
    col_primary    <- jp$primary
    col_secondary  <- jp$categorical[3]
    col_terciary   <- jp$categorical[6]
    col_quarternary <- jp$positive
    col_quinternary <- jp$sequential[7]
    col_sextenary  <- jp$categorical[4]
    pos_color   <- jp$positive
    neg_color   <- jp$negative
    vertical_line_color <- jp$text
    cyan <- jp$sequential[3]

    ### Recycle the eight journal hues to match the br palette length
    palette_colors <- rep(jp$categorical, length.out = 35)

  }

  # SS Workflow
  ss_backtest_workflow <- x@ss_backtest_workflow[[length(x@ss_backtest_workflow)]]

  # List of available plots
  if(ss_backtest_workflow$p_correction_method == "bayesian"){
    available_plots <- c(
      "Time-Series Metrics by Signal",
      "Average Time-Series Metrics by Theme",
      "Compare Metrics Side-by-Side by Signals",
      "Compare Metrics Side-by-Side by Theme",
      "Box-Plot by Theme",
      "Box-Plot by Eligibility",
      "Waterfall Plot by Signal",
      "Waterfall Plot by Theme",
      "Eligibility by Theme",
      "Posterior Individual Alphas",
      "Posterior Individual Betas",
      "Posterior Random Effects",
      "Waterfall Plot of Posterior Variance Components",
      "Posterior Regression Lines",
      "Waterfall Plot of Return Decomposition by Signal",
      "Posterior Individual Alpha Distributions by Theme and Signal"
    )
  } else {
    available_plots <- c(
      "Time-Series Metrics by Signal",
      "Average Time-Series Metrics by Theme",
      "Compare Metrics Side-by-Side by Signals",
      "Compare Metrics Side-by-Side by Theme",
      "Box-Plot by Theme",
      "Box-Plot by Eligibility",
      "Waterfall Plot by Signal",
      "Waterfall Plot by Theme",
      "Eligibility by Theme"
    )
  }

  if (is.null(plot_id)) {
    cat("\nPlease choose a plot to display:\n")
    for (i in seq_along(available_plots)) {
      cat(paste0(i, ": ", available_plots[i], "\n"))
    }
    selection <- readline(prompt = "Enter the number of your choice: ")
    plot_id <- as.numeric(selection)
    if (is.na(plot_id) || plot_id < 1 || plot_id > length(available_plots)) {
      stop("Invalid selection.")
    }
  }

  # Determine plot name from the selection
  if (is.numeric(plot_id)) {
    if (plot_id >= 1 && plot_id <= length(available_plots)) {
      plot_name <- available_plots[plot_id]
    } else {
      stop("Invalid plot number. Please select a valid plot.")
    }
  } else if (is.character(plot_id)) {
    if (plot_id %in% available_plots) {
      plot_name <- plot_id
    } else {
      stop("Invalid 'plot_id' specified. Available options are:\n",
           paste(available_plots, collapse = ", "))
    }
  } else {
    stop("'plot_id' must be either a string or a number corresponding to the plot.")
  }

  # Define the data sources
  signal_universe_m_df <- x@signal_universe_m_df
  signal_universe_m_df@data <- signal_universe_m_df@data %>% dplyr::filter(theme != "forced")
  final_signal_universe_m_d_ref <- x@final_signal_universe_m_d_ref
  final_signal_universe_m_d_ref@data <- final_signal_universe_m_d_ref@data %>% dplyr::filter(theme != "forced")

  if (x@p_correction_method == "bayesian"){
    #Reconstruct selected_signal_themes_m_d_ref
    selected_signal_themes_m_d_ref <- final_signal_universe_m_d_ref@data %>% dplyr::select(id, tickers, dates, theme)
    #Get brm_model
    brm_model <- x@bayesian_results$brm_model
    #Get theme-level parameters
    theme_level_intercept <- ss_backtest_workflow$theme_level_intercept
    theme_level_slope <- ss_backtest_workflow$theme_level_slope
    model_spec_theme_level <- paste0(theme_level_intercept, "_intercept_", theme_level_slope, "_slope")

    #priors
    if (is.null(x@bayesian_results$elected_priors)){
      elected_priors <- x@bayesian_results$brm_model$prior
    } else {
      elected_priors <- x@bayesian_results$elected_priors
    }
    #Extract tidy posteriores
    ##Check if epred are needed
    if (plot_name == "Waterfall Plot of Return Decomposition by Signal"){
      compute_predictives_full <- TRUE
      n_draws_predictive <- 200
    } else {
      compute_predictives_full <- FALSE
      n_draws_predictive <- NULL
    }

    tidy_posteriors_list <- summarize_posteriors_draws(brm_model = brm_model,
                                                       selected_signal_themes_m_d_ref = selected_signal_themes_m_d_ref,
                                                       model_spec_theme_level = model_spec_theme_level,
                                                       compute_predictives_full = compute_predictives_full,
                                                       n_draws_predictive = n_draws_predictive
    )
  }

  # Plot 1: Time-Series Metrics by Ticker
  if (plot_name == "Time-Series Metrics by Signal") {

    plot_type <- "time_series"
    clustering_variables <- "tickers"
    calc_stat <- "mean"

    plot(signal_universe_m_df, type = plot_type, clustering_variables = clustering_variables, palette = palette)


  } else if (plot_name == "Average Time-Series Metrics by Theme") {
    # Plot 2: Average Time-Series Metrics by Theme

    plot_type <- "time_series"
    clustering_variables <- "theme"
    calc_stat <- "mean"

    plot(signal_universe_m_df, type = plot_type, clustering_variables = clustering_variables, palette = palette)


  } else if (plot_name == "Compare Metrics Side-by-Side by Signals") {
    # Plot 3: Compare Metrics Side-by-Side by Tickers

    plot_type <- "cross_sectional"
    clustering_variables <- "tickers"
    calc_stat <- "mean"

    plot(final_signal_universe_m_d_ref, type = plot_type, clustering_variables = clustering_variables,
         calc_stat = calc_stat, palette = palette)

  } else if (plot_name == "Compare Metrics Side-by-Side by Theme") {
    # Plot 4: Compare Metrics Side-by-Side by Theme

    plot_type <- "cross_sectional"
    clustering_variables <- "theme"
    calc_stat <- "mean"
    plot(final_signal_universe_m_d_ref, type = plot_type, clustering_variables = clustering_variables, calc_stat = calc_stat,
         palette = palette)


  } else if (plot_name == "Box-Plot by Theme") {
    # Plot 5: Box-Plot by Theme

    plot_type <- "boxplot"
    clustering_variables <- "theme"

    plot(final_signal_universe_m_d_ref, type = plot_type, clustering_variables = clustering_variables,
         palette = palette)

  } else if (plot_name == "Box-Plot by Eligibility") {
    # Plot 6: Box-Plot by Eligibility
    final_signal_universe_m_d_ref@data$eligibility <- ifelse(final_signal_universe_m_d_ref@data$is_eligible == 1, "elected", "not_elected")

    plot_type <- "boxplot"
    clustering_variables <- "eligibility"

    plot(final_signal_universe_m_d_ref, type = plot_type, clustering_variables = clustering_variables,
         palette = palette)

  } else if (plot_name == "Waterfall Plot by Signal") {

    # Plot 7: Waterfall Plot by Ticker
    if (ss_backtest_workflow$model_structure == "no_pooled"){
      final_signal_universe_m_d_ref@data <- final_signal_universe_m_d_ref@data %>%
        dplyr::mutate(mean_market_factor_proxy = mean(x@selected_market_factor_proxy_m_xts@data),
                      beta_x_mean_market_factor_proxy = beta * mean_market_factor_proxy,
                      residual = specific_risk)
    } else {
      final_signal_universe_m_d_ref@data <- final_signal_universe_m_d_ref@data %>%
        dplyr::mutate(mean_market_factor_proxy = mean(x@selected_market_factor_proxy_m_xts@data),
                      beta_x_mean_market_factor_proxy = individual_beta * mean_market_factor_proxy,
                      residual = specific_risk) %>%
        dplyr::rename(alpha = individual_alpha)
    }

    plot_type <- "waterfall"
    clustering_variables <- "tickers"
    variables <- c("alpha", "beta_x_mean_market_factor_proxy", "residual")
    calc_stat <- "mean"

    plot(final_signal_universe_m_d_ref, type = plot_type, clustering_variables = clustering_variables,
         variable = variables, calc_stat = calc_stat, palette = palette)


  } else if (plot_name == "Waterfall Plot by Theme") {
    # Plot 8: Waterfall Plot by Ticker
    if (ss_backtest_workflow$model_structure == "no_pooled"){
      final_signal_universe_m_d_ref@data <- final_signal_universe_m_d_ref@data %>%
        dplyr::mutate(mean_market_factor_proxy = mean(x@selected_market_factor_proxy_m_xts@data),
                      beta_x_mean_market_factor_proxy = beta * mean_market_factor_proxy,
                      residual = specific_risk)
    } else {
      final_signal_universe_m_d_ref@data <- final_signal_universe_m_d_ref@data %>%
        dplyr::mutate(mean_market_factor_proxy = mean(x@selected_market_factor_proxy_m_xts@data),
                      beta_x_mean_market_factor_proxy = individual_beta * mean_market_factor_proxy,
                      residual = specific_risk) %>%
        dplyr::rename(alpha = individual_alpha)
    }

    plot_type <- "waterfall"
    clustering_variables <- "theme"
    variables <- c("alpha", "beta_x_mean_market_factor_proxy", "residual")
    calc_stat <- "mean"

    plot(final_signal_universe_m_d_ref, type = plot_type,
         clustering_variables = clustering_variables, variable = variables, calc_stat = calc_stat, palette = palette)


  } else if (plot_name == "Eligibility by Theme") {
    #Plot 9
    signal_universe_m_df@data <- signal_universe_m_df@data %>%
      dplyr::mutate(eligibility = ifelse(is_eligible == 1, "elected", "not_elected"))

    plot_type <- "tile_heatmap"
    clustering_variables <- "tickers"
    variables <- "eligibility"
    calc_stat <- "mean"

    plot(signal_universe_m_df, type = plot_type, clustering_variables = clustering_variables,
         variable = variables, calc_stat = calc_stat, palette = palette)

  }

  ###############
  #Bayesian Plots
  ###############

  else if (plot_name == "Posterior Individual Alphas"){
    #Plot 10
    tidy_posterior_draws_intercept <- tidy_posteriors_list$tidy_posterior_draws_intercept

    available_tickers <- unique(tidy_posterior_draws_intercept$tickers)

    if (is.null(variable)){
      # Prompt the user to select tickers
      # Display available tickers with numbers
      cat("Available tickers:\n")
      for (i in seq_along(available_tickers)) {
        cat(i, ":", available_tickers[i], "\n")
      }

      # Ask user for input
      selected_numbers <- readline(prompt = "Enter the numbers corresponding to the tickers you want to plot, separated by commas: ")

      # Convert input to numeric and validate
      selected_numbers <- as.numeric(strsplit(selected_numbers, ",")[[1]])
      if (any(is.na(selected_numbers)) || !all(selected_numbers %in% seq_along(available_tickers))) {
        stop("Invalid input. Please enter valid numbers corresponding to the tickers.")
      }

      # Match the selected numbers to tickers
      selected_tickers <- available_tickers[selected_numbers]
    } else {
      # Validate the provided variable against available tickers
      if (!all(variable %in% available_tickers)) {
        stop("Invalid 'variable' specified. Available tickers are:\n",
             paste(available_tickers, collapse = ", "))
      }
      selected_tickers <- variable
    }

    # Filter the data based on user selection
    filtered_data <- tidy_posterior_draws_intercept %>%
      dplyr::filter(tickers %in% selected_tickers)

    if (nrow(filtered_data) == 0) {
      stop("No matching tickers found. Please check your input.")
    }

    #Get theme column
    theme_ticker_key <- data.frame(tickers = paste0(selected_signal_themes_m_d_ref$theme, "_", selected_signal_themes_m_d_ref$tickers), theme = selected_signal_themes_m_d_ref$theme)
    filtered_data <- filtered_data %>%
      dplyr::left_join(theme_ticker_key, by = c("tickers" = "tickers"))

    # Extract themes from `elected_priors`
    ##Random Intercept or None
    if(model_spec_theme_level %in% c("random_intercept_fixed_slope", "fixed_intercept_fixed_slope")){
      prior_data <- elected_priors %>%
        dplyr::filter(class == "Intercept") %>%
        dplyr::rowwise() %>%
        dplyr::mutate(
          mean_var = as.numeric(stringr::str_extract(prior, "(?<=\\().+?(?=,)")), # Extract mean
          sd_var = as.numeric(stringr::str_extract(prior, "(?<=, ).+?(?=\\))"))   # Extract sd
        ) %>%
        dplyr::ungroup() %>%
        dplyr::select(mean_var, sd_var)

      prior_data <- data.frame(theme = unique(theme_ticker_key$theme), mean = prior_data$mean_var, sd = prior_data$sd_var)

    }

    ##Fixed intercepts or Fixed Intercepts and Slopes
    if(model_spec_theme_level %in% c("theme_specific_intercept_fixed_slope", "theme_specific_intercept_theme_specific_slope")){
      prior_data <- elected_priors %>%
        dplyr::filter(class == "b" & stringr::str_detect(coef, "^theme")) %>%
        dplyr::mutate(theme = stringr::str_remove(coef, "^theme")) %>%
        dplyr::rowwise() %>%
        dplyr::mutate(
          mean_var = as.numeric(stringr::str_extract(prior, "(?<=\\().+?(?=,)")), # Extract mean
          sd_var = as.numeric(stringr::str_extract(prior, "(?<=, ).+?(?=\\))"))   # Extract sd
        ) %>%
        dplyr::ungroup() %>%
        dplyr::select(theme, mean_var, sd_var)
    }

    # Generate draws for each theme and convert to long format
    long_draws_data <- prior_data %>%
      dplyr::mutate(
        draws = purrr::map2(mean_var, sd_var, ~ stats::rnorm(length(unique(filtered_data$.draw)), mean = .x, sd = .y))
      ) %>%
      tidyr::unnest(draws) %>%                # Expand the list column into long format
      dplyr::group_by(theme) %>%              # Group by theme
      dplyr::mutate(prior_draw = dplyr::row_number()) %>% # Add simulation ID
      dplyr::ungroup()

    # Insert priors in the filtered data
    filtered_data <- filtered_data %>%
      dplyr::left_join(dplyr::select(long_draws_data, theme, draws), by = "theme")

    # Sample the data for performance (adjust the sample size as needed)
    sampled_data <- filtered_data %>%
      dplyr::sample_n(min(10000, nrow(filtered_data)))

    # Transform data to long format with both variables
    long_plot_data <- sampled_data %>%
      tidyr::pivot_longer(
        cols = c(posterior_individual_alpha, draws),
        names_to = "variable",
        values_to = "value"
      )

    # Define custom colors for the variables
    custom_colors <- c(
      "posterior_individual_alpha" = col_primary,  # Neon green
      "draws" = col_secondary                        # Neon orange
    )

    # Create the plot
    p <- long_plot_data %>%
      ggplot2::ggplot(ggplot2::aes(x = value, y = tickers, fill = variable)) +
      ggdist::stat_halfeye(
        adjust = 0.5,
        width = 0.6,
        alpha = 0.7,
        position = ggplot2::position_identity()
      ) +
      ggplot2::geom_vline(xintercept = 0, linetype = "dashed", color = light_gray) + # col_text dashed line
      ggplot2::scale_fill_manual(values = custom_colors,
                                 labels = c("Prior Alpha", "Posterior Alpha")) + # Neon green for posterior, neon orange for draws
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA), # Deep navy background
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.grid.major = ggplot2::element_line(color = light_gray), # Light gray grid lines
        panel.grid.minor = ggplot2::element_blank(), # No minor grid lines
        axis.text = ggplot2::element_text(color = col_text), # col_text axis text
        axis.title = ggplot2::element_text(color = col_text), # col_text axis title
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"), # col_text title
        plot.subtitle = ggplot2::element_text(color = col_text, size = 10, face = "italic"), # col_text subtitle
        legend.position = "bottom", # Legend at the bottom
        legend.text = ggplot2::element_text(color = col_text), # col_text legend text
        legend.title = ggplot2::element_text(color = col_text) # col_text legend title
      ) +
      ggplot2::labs(
        title = "Posterior and Prior Distributions per Ticker",
        subtitle = "Showing posterior and prior distributions of individual alpha",
        x = "Value",
        y = "Tickers",
        fill = "Variable"
      )

    print(p)

  } else if (plot_name == "Posterior Individual Betas"){

    #Plot 11
    tidy_posterior_draws_slope <- tidy_posteriors_list$tidy_posterior_draws_slope
    available_tickers <- unique(tidy_posterior_draws_slope$tickers)

    if (is.null(variable)){
      # Prompt the user to select tickers
      # Display available tickers with numbers
      cat("Available tickers:\n")
      for (i in seq_along(available_tickers)) {
        cat(i, ":", available_tickers[i], "\n")
      }

      # Ask user for input
      selected_numbers <- readline(prompt = "Enter the numbers corresponding to the tickers you want to plot, separated by commas: ")

      # Convert input to numeric and validate
      selected_numbers <- as.numeric(strsplit(selected_numbers, ",")[[1]])
      if (any(is.na(selected_numbers)) || !all(selected_numbers %in% seq_along(available_tickers))) {
        stop("Invalid input. Please enter valid numbers corresponding to the tickers.")
      }

      # Match the selected numbers to tickers
      selected_tickers <- available_tickers[selected_numbers]
    } else {
      # Validate the provided variable against available tickers
      if (!all(variable %in% available_tickers)) {
        stop("Invalid 'variable' specified. Available tickers are:\n",
             paste(available_tickers, collapse = ", "))
      }
      selected_tickers <- variable
    }

    # Filter the data based on user selection
    filtered_data <- tidy_posterior_draws_slope %>%
      dplyr::filter(tickers %in% selected_tickers)

    if (nrow(filtered_data) == 0) {
      stop("No matching tickers found. Please check your input.")
    }

    #Get theme column
    theme_ticker_key <- data.frame(tickers = paste0(selected_signal_themes_m_d_ref$theme, "_", selected_signal_themes_m_d_ref$tickers),
                                   theme = selected_signal_themes_m_d_ref$theme)
    filtered_data <- filtered_data %>% dplyr::left_join(theme_ticker_key, by = c("tickers" = "tickers"))

    # Extract themes from `elected_priors`

    ##Random Intercept, Fixed Intercepts or None
    if(model_spec_theme_level %in% c("random_intercept_fixed_slope", "theme_specific_intercept_fixed_slope", "fixed_intercept_fixed_slope")){
      prior_data <- elected_priors %>%
        dplyr::filter(class == "b" & coef == "market_factor_proxy") %>%
        dplyr::rowwise() %>%
        dplyr::mutate(
          mean_var = as.numeric(stringr::str_extract(prior, "(?<=\\().+?(?=,)")), # Extract mean
          sd_var = as.numeric(stringr::str_extract(prior, "(?<=, ).+?(?=\\))"))   # Extract sd
        ) %>%
        dplyr::ungroup() %>%
        dplyr::select(mean_var, sd_var)

      prior_data <- data.frame(theme = unique(theme_ticker_key$theme), mean = prior_data$mean_var, sd = prior_data$sd_var)

    }

    ##Fixed Intercepts and Slopes
    if(model_spec_theme_level %in% c("theme_specific_intercept_theme_specific_slope")){
      prior_data <- elected_priors %>%
        dplyr::filter(class == "b" & stringr::str_detect(coef, "^theme.*:market_factor_proxy$")) %>%
        dplyr::mutate(theme = stringr::str_extract(coef, "(?<=^theme).*?(?=:)")) %>%
        dplyr::rowwise() %>%
        dplyr::mutate(
          mean_var = as.numeric(stringr::str_extract(prior, "(?<=\\().+?(?=,)")), # Extract mean
          sd_var = as.numeric(stringr::str_extract(prior, "(?<=, ).+?(?=\\))"))   # Extract sd
        ) %>%
        dplyr::ungroup() %>%
        dplyr::select(theme, mean_var, sd_var)
    }

    # Generate draws for each theme and convert to long format
    long_draws_data <- prior_data %>%
      dplyr::mutate(
        draws = purrr::map2(mean_var, sd_var, ~ stats::rnorm(length(unique(filtered_data$.draw)), mean = .x, sd = .y))
      ) %>%
      tidyr::unnest(draws) %>%                # Expand the list column into long format
      dplyr::group_by(theme) %>%              # Group by theme
      dplyr::mutate(prior_draw = dplyr::row_number()) %>% # Add simulation ID
      dplyr::ungroup()

    # Insert priors in the filtered data
    filtered_data <- filtered_data %>%
      dplyr::left_join(dplyr::select(long_draws_data, theme, draws), by = "theme")

    # Sample the data for performance (adjust the sample size as needed)
    sampled_data <- filtered_data %>%
      dplyr::sample_n(min(10000, nrow(filtered_data)))

    # Transform data to long format with both variables
    long_plot_data <- sampled_data %>%
      tidyr::pivot_longer(
        cols = c(posterior_individual_beta, draws),
        names_to = "variable",
        values_to = "value"
      )

    # Define custom colors for the variables
    custom_colors <- c(
      "posterior_individual_beta" = col_primary,  # Neon green
      "draws" = col_secondary                       # Neon orange
    )

    # Create the plot
    p <- long_plot_data %>%
      ggplot2::ggplot(ggplot2::aes(x = value, y = tickers, fill = variable)) +
      ggdist::stat_halfeye(
        adjust = 0.5,
        width = 0.6,
        alpha = 0.7,
        position = ggplot2::position_identity()
      ) +
      ggplot2::geom_vline(xintercept = 0, linetype = "dashed", color = col_text) + # col_text dashed line
      ggplot2::scale_fill_manual(values = custom_colors,
                                 labels = c("Prior Beta", "Posterior Beta")) + # Neon green for posterior, neon orange for draws
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA), # Deep navy background
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.grid.major = ggplot2::element_line(color = light_gray), # Light gray grid lines
        panel.grid.minor = ggplot2::element_blank(), # No minor grid lines
        axis.text = ggplot2::element_text(color = col_text), # col_text axis text
        axis.title = ggplot2::element_text(color = col_text), # col_text axis title
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"), # col_text title
        plot.subtitle = ggplot2::element_text(color = col_text, size = 10, face = "italic"), # col_text subtitle
        legend.position = "bottom", # Legend at the bottom
        legend.text = ggplot2::element_text(color = col_text), # col_text legend text
        legend.title = ggplot2::element_text(color = col_text) # col_text legend title
      ) +
      ggplot2::labs(
        title = "Posterior and Prior Distributions per Ticker",
        subtitle = "Showing posterior and prior distributions of individual beta",
        x = "Value",
        y = "Tickers",
        fill = "Variable"
      )

    print(p)

  } else if (plot_name == "Posterior Random Effects") {
    #Plot 12

    #Get tidy_posterior_draws_sw
    tidy_posterior_draws_sd <-  tidy_posteriors_list$tidy_posterior_draws_sd

    # Transform and plot the data
    p <- tidy_posterior_draws_sd %>%
      # Select relevant columns by excluding unwanted ones
      dplyr::select(-.chain, -.iteration, -.draw, -posterior_cor_r_alpha_beta, -posterior_sigma) %>%
      # Pivot to longer format
      tidyr::pivot_longer(
        cols = dplyr::everything(),
        names_to = "parameter",
        values_to = "sd_value"
      ) %>%
      # Create the plot
        ggplot2::ggplot(ggplot2::aes(y = parameter, x = sd_value)) +
          ggdist::stat_halfeye(
            fill = col_primary,
            show.legend = FALSE,              # Hide legend if not needed
            adjust = 0.5,                     # Adjust the bandwidth of the density estimate
            width = 0.6,                      # Width of the half-eye plot
            alpha = 0.8                       # Transparency for better visibility
          ) +
      ggplot2::geom_vline(
        xintercept = 0,
        linetype = "dashed",
        color = col_text,                # col_text dashed line for consistency
        size = 1
      ) +
      # Customize the theme to match other plots
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),    # Deep navy background
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),   # Deep navy panel
        panel.grid.major = ggplot2::element_line(color = light_gray),             # Light gray major grid lines
        panel.grid.minor = ggplot2::element_blank(),                             # Remove minor grid lines
        axis.text = ggplot2::element_text(color = col_text),                    # col_text axis text
        axis.title = ggplot2::element_text(color = col_text),                   # col_text axis titles
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),       # col_text bold title
        plot.subtitle = ggplot2::element_text(color = col_text, size = 10, face = "italic"),  # col_text italic subtitle
        legend.position = "bottom",                                             # Position legend at the bottom
        legend.text = ggplot2::element_text(color = col_text),                # col_text legend text
        legend.title = ggplot2::element_text(color = col_text)                # col_text legend title
      ) +
      # Add labels
      ggplot2::labs(
        title = "Posterior Distributions of Random Effects",
        subtitle = "Standard Deviations across Parameters",
        x = "Standard Deviation",
        y = "Parameter"
      )

    print(p)
  } else if (plot_name == "Waterfall Plot of Posterior Variance Components") {
    #Plot 13

    #Get tidy_posterior_draws_sw
    tidy_posterior_draws_sd <-  tidy_posteriors_list$tidy_posterior_draws_sd

    #Waterfall plot
    if(model_spec_theme_level == "random_intercept_fixed_slope"){
      #For random_intercept_fixed_slope, include var_theme_intercept
      variance_data <- tidy_posterior_draws_sd %>%
        dplyr::mutate(
          # Variance components
          var_theme_intercept = posterior_r_theme_alpha^2,
          var_tickers_intercept = posterior_r_tickers_alpha^2,
          var_tickers_slope = posterior_r_tickers_beta^2,
          var_sigma = posterior_sigma^2
        ) %>%
        dplyr::mutate(
          cov_tickers_intercept_slope = 2 * posterior_r_tickers_alpha * posterior_r_tickers_beta * posterior_cor_r_alpha_beta
        ) %>%
        dplyr::mutate(
          total_variance = var_theme_intercept +
            var_tickers_intercept +
            var_tickers_slope +
            var_sigma +
            cov_tickers_intercept_slope
        )

      #Get decomposition info
      waterfall_data <- variance_data %>%
        dplyr::select(
          .draw,
          var_theme_intercept,
          var_tickers_intercept,
          var_tickers_slope,
          var_sigma,
          cov_tickers_intercept_slope,
          total_variance
        ) %>%
        # Calculate mean contributions across draws
        dplyr::summarise(
          var_theme_intercept = mean(var_theme_intercept),
          var_tickers_intercept = mean(var_tickers_intercept),
          var_tickers_slope = mean(var_tickers_slope),
          var_sigma = mean(var_sigma),
          cov_tickers_intercept_slope = mean(cov_tickers_intercept_slope),
          total_variance = mean(total_variance)
        ) %>%
        # Reshape data to long format
        tidyr::pivot_longer(
          cols = -total_variance,
          names_to = "Component",
          values_to = "Variance"
        ) %>%
        dplyr::mutate(
          # Order components for plotting
          Component = factor(
            Component,
            levels = c(
              "var_theme_intercept",
              "var_tickers_intercept",
              "var_tickers_slope",
              "cov_tickers_intercept_slope",
              "var_sigma"
            ),
            labels = c(
              "Theme Intercept Variance",
              "Tickers Intercept Variance",
              "Tickers Slope Variance",
              "Tickers Intercept-Slope Covariance",
              "Residual Variance"
            )
          )
        )

      # Calculate cumulative variance contributions
      waterfall_data <- waterfall_data %>%
        dplyr::mutate(
          Cumulative = cumsum(Variance) - Variance[1],
          Start = dplyr::lag(Cumulative, default = 0),
          End = Cumulative,
          Contribution_Type = ifelse(Variance >= 0, "Positive", "Negative")
        )

      # Plot the waterfall
      p <- ggplot2::ggplot(waterfall_data, ggplot2::aes(
        x = Component,
        ymin = Start,
        ymax = End,
        fill = Contribution_Type
      )) +
        ggplot2::geom_rect(
          ggplot2::aes(
            xmin = as.numeric(Component) - 0.4,
            xmax = as.numeric(Component) + 0.4
          ),
          color = black
        ) +
        ggplot2::geom_text(
          ggplot2::aes(
            x = Component,
            y = End,
            label = round(Variance, 4)
          ),
          vjust = ifelse(waterfall_data$Variance >= 0, -0.5, 1.5),
          size = 3,
          color = col_text  # Ensure text is visible against the background
        ) +
        ggplot2::scale_fill_manual(
          values = c("Positive" = pos_color, "Negative" = neg_color)
        ) +
        ggplot2::labs(
          title = "Waterfall Plot of Variance Components",
          x = "Components",
          y = "Cumulative Variance",
          fill = "Contribution"  # Add fill legend title for clarity
        ) +
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.grid.major = ggplot2::element_blank(),
          panel.grid.minor = ggplot2::element_blank(),
          axis.text = ggplot2::element_text(color = col_text, angle = 45, hjust = 1),
          axis.title = ggplot2::element_text(color = col_text),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic"),
          legend.position = "bottom",
          legend.title = ggplot2::element_text(color = col_text),
          legend.text = ggplot2::element_text(color = col_text),
          strip.text = ggplot2::element_text(color = col_text)
        )

      print(p)

    } else {
      ############################
      #Otherwise, include variance for theme
      ##########################
      variance_data <- tidy_posterior_draws_sd %>%
        dplyr::mutate(
          # Variance components
          var_tickers_intercept = posterior_r_tickers_alpha^2,
          var_tickers_slope = posterior_r_tickers_beta^2,
          var_sigma = posterior_sigma^2
        ) %>%
        dplyr::mutate(
          cov_tickers_intercept_slope = 2 * posterior_r_tickers_alpha * posterior_r_tickers_beta * posterior_cor_r_alpha_beta
        ) %>%
        dplyr::mutate(
          total_variance =
            var_tickers_intercept +
            var_tickers_slope +
            var_sigma +
            cov_tickers_intercept_slope
        )

      #Get decomposition info
      waterfall_data <- variance_data %>%
        dplyr::select(
          .draw,
          var_tickers_intercept,
          var_tickers_slope,
          var_sigma,
          cov_tickers_intercept_slope,
          total_variance
        ) %>%
        # Calculate mean contributions across draws
        dplyr::summarise(
          var_tickers_intercept = mean(var_tickers_intercept),
          var_tickers_slope = mean(var_tickers_slope),
          var_sigma = mean(var_sigma),
          cov_tickers_intercept_slope = mean(cov_tickers_intercept_slope),
          total_variance = mean(total_variance)
        ) %>%
        # Reshape data to long format
        tidyr::pivot_longer(
          cols = -total_variance,
          names_to = "Component",
          values_to = "Variance"
        ) %>%
        dplyr::mutate(
          # Order components for plotting
          Component = factor(
            Component,
            levels = c(
              "var_tickers_intercept",
              "var_tickers_slope",
              "cov_tickers_intercept_slope",
              "var_sigma"
            ),
            labels = c(
              "Tickers Intercept Variance",
              "Tickers Slope Variance",
              "Tickers Intercept-Slope Covariance",
              "Residual Variance"
            )
          )
        )

      # Calculate cumulative variance contributions
      waterfall_data <- waterfall_data %>%
        dplyr::mutate(
          Cumulative = cumsum(Variance) - Variance[1],
          Start = dplyr::lag(Cumulative, default = 0),
          End = Cumulative,
          Contribution_Type = ifelse(Variance >= 0, "Positive", "Negative")
        )

      # Plot the waterfall
      p <- ggplot2::ggplot(waterfall_data, ggplot2::aes(
        x = Component,
        ymin = Start,
        ymax = End,
        fill = Contribution_Type
      )) +
        ggplot2::geom_rect(
          ggplot2::aes(
            xmin = as.numeric(Component) - 0.4,
            xmax = as.numeric(Component) + 0.4
          ),
          color = black
        ) +
        ggplot2::geom_text(
          ggplot2::aes(
            x = Component,
            y = End,
            label = round(Variance, 4)
          ),
          vjust = ifelse(waterfall_data$Variance >= 0, -0.5, 1.5),
          size = 3,
          color = col_text  # Ensure text is visible against the background
        ) +
        ggplot2::scale_fill_manual(
          values = c("Positive" = pos_color, "Negative" = neg_color)
        ) +
        ggplot2::labs(
          title = "Waterfall Plot of Variance Components",
          x = "Components",
          y = "Cumulative Variance",
          fill = "Contribution"  # Add fill legend title for clarity
        ) +
        ggplot2::theme_minimal() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.grid.major = ggplot2::element_blank(),
          panel.grid.minor = ggplot2::element_blank(),
          axis.text = ggplot2::element_text(color = col_text, angle = 45, hjust = 1),
          axis.title = ggplot2::element_text(color = col_text),
          plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
          plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic"),
          legend.position = "bottom",
          legend.title = ggplot2::element_text(color = col_text),
          legend.text = ggplot2::element_text(color = col_text),
          strip.text = ggplot2::element_text(color = col_text)
        )

      print(p)
    }

  } else if (plot_name == "Posterior Regression Lines"){

    # Get alpha and beta
    tidy_posterior_draws_intercept <- tidy_posteriors_list$tidy_posterior_draws_intercept
    tidy_posterior_draws_slope <- tidy_posteriors_list$tidy_posterior_draws_slope

    available_tickers <- unique(tidy_posterior_draws_slope$tickers)

    if (is.null(variable)){
      # Prompt the user to select tickers
      # Display available tickers with numbers
      cat("Available tickers:\n")
      for (i in seq_along(available_tickers)) {
        cat(i, ":", available_tickers[i], "\n")
      }

      # Ask user for input
      selected_numbers <- readline(prompt = "Enter the numbers corresponding to the tickers you want to plot, separated by commas: ")

      # Convert input to numeric and validate
      selected_numbers <- as.numeric(strsplit(selected_numbers, ",")[[1]])
      if (any(is.na(selected_numbers)) || !all(selected_numbers %in% seq_along(available_tickers))) {
        stop("Invalid input. Please enter valid numbers corresponding to the tickers.")
      }

      # Match the selected numbers to tickers
      selected_tickers <- available_tickers[selected_numbers]
    } else {
      # Validate the provided variable against available tickers
      if (!all(variable %in% available_tickers)) {
        stop("Invalid 'variable' specified. Available tickers are:\n",
             paste(available_tickers, collapse = ", "))
      }
      selected_tickers <- variable
    }
    num_selected <- length(selected_tickers)

    # Join intercept and slope data, filter for selected tickers, and convert tickers to factor
    tidy_posterior_draws_intercept_and_slope <- dplyr::left_join(
      tidy_posterior_draws_intercept,
      tidy_posterior_draws_slope,
      by = c("tickers", ".draw")
    ) %>%
      dplyr::filter(tickers %in% selected_tickers) %>%
      # **Convert 'tickers' to a factor to ensure distinct colors**
      dplyr::mutate(tickers = as.factor(tickers))

    # Get market_factor_proxy
    x_values <- x@selected_market_factor_proxy_m_xts@data %>% as.vector()
    x_values <- sort(x_values)

    # Sample a subset of posterior draws to avoid overplotting
    set.seed(123)  # For reproducibility
    sampled_draws <- dplyr::group_by(tidy_posterior_draws_intercept_and_slope, tickers) %>%
      dplyr::sample_n(size = 25, replace = FALSE) %>%
      dplyr::ungroup()

    # Create a grid of sampled draws and x_values
    plot_data <- tidyr::crossing(
      sampled_draws %>% dplyr::select(tickers, posterior_individual_alpha, posterior_individual_beta, .draw),
      x = x_values
    ) %>%
      dplyr::mutate(y = posterior_individual_alpha + posterior_individual_beta * x)

    # Generate the plot
    if (num_selected > length(palette_colors)) {
      warning("Number of selected tickers exceeds the number of predefined colors. Colors will be recycled.")
    }

    regression_plot <- ggplot2::ggplot(plot_data, ggplot2::aes(x = x, y = y, group = .draw, color = tickers)) +
      ggplot2::geom_line(alpha = 0.6, size = 1) +  # Increased alpha and line size for better visibility
      ggplot2::scale_color_manual(values = palette_colors[1:num_selected]) +  # Assign neon colors
      ggplot2::labs(
        title = "Posterior Regression Lines by Signal",
        subtitle = "Using Posterior Individual Alpha and Beta",
        x = "Market Factor Proxy",
        y = "Predicted Outcome",
        color = "Ticker"
      ) +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),  # Dark blue background
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.grid.major = ggplot2::element_blank(),
        panel.grid.minor = ggplot2::element_blank(),
        axis.text = ggplot2::element_text(color = col_text, angle = 45, hjust = 1),  # col_text axis text
        axis.title = ggplot2::element_text(color = col_text),  # col_text axis titles
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
        plot.subtitle = ggplot2::element_text(color = col_text, size = 10, face = "italic"),
        legend.position = "bottom",
        legend.title = ggplot2::element_text(color = col_text),
        legend.text = ggplot2::element_text(color = col_text)
      )

    # Display the Plot
    print(regression_plot)

  } else if (plot_name == "Waterfall Plot of Return Decomposition by Signal"){

    # Get alpha and beta
    tidy_posterior_draws_intercept <- tidy_posteriors_list$tidy_posterior_draws_intercept
    tidy_posterior_draws_slope <- tidy_posteriors_list$tidy_posterior_draws_slope

    # Prompt the user to select tickers
    available_tickers <- unique(tidy_posterior_draws_slope$tickers)

    if (is.null(variable)){
      # Prompt the user to select tickers
      # Display available tickers with numbers
      cat("Available tickers:\n")
      for (i in seq_along(available_tickers)) {
        cat(i, ":", available_tickers[i], "\n")
      }

      # Ask user for input
      selected_numbers <- readline(prompt = "Enter the numbers corresponding to the tickers you want to plot, separated by commas: ")

      # Convert input to numeric and validate
      selected_numbers <- as.numeric(strsplit(selected_numbers, ",")[[1]])
      if (any(is.na(selected_numbers)) || !all(selected_numbers %in% seq_along(available_tickers))) {
        stop("Invalid input. Please enter valid numbers corresponding to the tickers.")
      }

      # Match the selected numbers to tickers
      selected_tickers <- available_tickers[selected_numbers]
    } else {
      # Validate the provided variable against available tickers
      if (!all(variable %in% available_tickers)) {
        stop("Invalid 'variable' specified. Available tickers are:\n",
             paste(available_tickers, collapse = ", "))
      }
      selected_tickers <- variable
    }
    num_selected <- length(selected_tickers)

    #Get Expectations
    tidy_posterior_epred_draws <- tidy_posteriors_list$tidy_posterior_epred_draws %>% dplyr::mutate(tickers = `theme:tickers`)

    #Add Alpha and Beta to Expectations
    tidy_posterior_epred_draws_complete <- dplyr::left_join(tidy_posterior_epred_draws,
                                                            #Join with intercept
                                                            tidy_posterior_draws_intercept, by = c("tickers", ".draw")) %>%
      #Join with slopes
      dplyr::left_join(tidy_posterior_draws_slope, by = c("tickers", ".draw")) %>%
      #Filter given tickers
      dplyr::filter(tickers %in% selected_tickers)

    #Waterfall plot
    # Prepare and compute contributions
    if(model_spec_theme_level == "random_intercept_fixed_slope"){
      waterfall_data <- tidy_posterior_epred_draws_complete %>%
        dplyr::mutate(
          # Component contributions
          `Theme Fixed Effect` = posterior_theme_alpha,
          `Theme Random Effect` = r_theme,
          `Ticker Random Intercept` = r_tickers_intercept,
          `Market Factor Fixed Effect` = posterior_theme_beta * market_factor_proxy,
          `Ticker Random Slope` = r_tickers_slope * market_factor_proxy
        ) %>%
        dplyr::select(
          .draw, tickers, return,
          `Theme Fixed Effect`,
          `Theme Random Effect`,
          `Ticker Random Intercept`,
          `Market Factor Fixed Effect`,
          `Ticker Random Slope`
        ) %>%
        tidyr::pivot_longer(
          cols = c(
            `Theme Fixed Effect`,
            `Theme Random Effect`,
            `Ticker Random Intercept`,
            `Market Factor Fixed Effect`,
            `Ticker Random Slope`
          ),
          names_to = "Component",
          values_to = "Contribution"
        ) %>%
        dplyr::group_by(tickers, Component) %>%
        dplyr::summarise(
          Mean_Contribution = mean(Contribution, na.rm = TRUE),
          .groups = 'drop'
        ) %>%
        dplyr::mutate(
          Component = factor(
            Component,
            levels = c(
              "Theme Fixed Effect",
              "Theme Random Effect",
              "Ticker Random Intercept",
              "Market Factor Fixed Effect",
              "Ticker Random Slope"
            )
          )
        ) %>%
        dplyr::arrange(Component) %>%
        dplyr::group_by(tickers) %>%
        dplyr::mutate(
          Start = dplyr::lag(cumsum(Mean_Contribution), default = 0),
          End = cumsum(Mean_Contribution),
          Contribution_Type = ifelse(Mean_Contribution >= 0, "Positive", "Negative")
        ) %>%
        dplyr::ungroup()

    } else { #This is for other model_spec_theme_level
      waterfall_data <- tidy_posterior_epred_draws_complete %>%
        dplyr::mutate(
          # Component contributions
          `Theme Fixed Effect` = posterior_theme_alpha,
          `Ticker Random Intercept` = r_tickers_intercept,
          `Market Factor Fixed Effect` = posterior_theme_beta * market_factor_proxy,
          `Ticker Random Slope` = r_tickers_slope * market_factor_proxy
        ) %>%
        dplyr::select(
          .draw, tickers, return,
          `Theme Fixed Effect`,
          `Ticker Random Intercept`,
          `Market Factor Fixed Effect`,
          `Ticker Random Slope`
        ) %>%
        tidyr::pivot_longer(
          cols = c(
            `Theme Fixed Effect`,
            `Ticker Random Intercept`,
            `Market Factor Fixed Effect`,
            `Ticker Random Slope`
          ),
          names_to = "Component",
          values_to = "Contribution"
        ) %>%
        dplyr::group_by(tickers, Component) %>%
        dplyr::summarise(
          Mean_Contribution = mean(Contribution, na.rm = TRUE),
          .groups = 'drop'
        ) %>%
        dplyr::mutate(
          Component = factor(
            Component,
            levels = c(
              "Theme Fixed Effect",
              "Ticker Random Intercept",
              "Market Factor Fixed Effect",
              "Ticker Random Slope"
            )
          )
        ) %>%
        dplyr::arrange(Component) %>%
        dplyr::group_by(tickers) %>%
        dplyr::mutate(
          Start = dplyr::lag(cumsum(Mean_Contribution), default = 0),
          End = cumsum(Mean_Contribution),
          Contribution_Type = ifelse(Mean_Contribution >= 0, "Positive", "Negative")
        ) %>%
        dplyr::ungroup()
    }

    # Create the waterfall plot per ticker
    p <- ggplot2::ggplot(waterfall_data, ggplot2::aes(
      x = Component,
      ymin = Start,
      ymax = End,
      fill = Contribution_Type
    )) +
      ggplot2::geom_rect(
        ggplot2::aes(
          xmin = as.numeric(Component) - 0.4,
          xmax = as.numeric(Component) + 0.4
        ),
        color = "black"
      ) +
      ggplot2::geom_text(
        ggplot2::aes(
          x = Component,
          y = End,
          label = round(Mean_Contribution, 4)
        ),
        vjust = ifelse(waterfall_data$Mean_Contribution >= 0, -0.5, 1.5),
        size = 3,
        color = col_text
      ) +
      ggplot2::scale_fill_manual(
        values = c("Positive" = pos_color, "Negative" = neg_color)
      ) +
      ggplot2::labs(
        title = "Waterfall Plot of Return Decomposition by Signal",
        x = "Components",
        y = "Cumulative Contribution"
      ) +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        panel.grid.major = ggplot2::element_blank(),
        panel.grid.minor = ggplot2::element_blank(),
        axis.text = ggplot2::element_text(color = col_text, angle = 45, hjust = 1),
        axis.title = ggplot2::element_text(color = col_text),
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
        plot.subtitle = ggplot2::element_text(color = col_text, size = 8, face = "italic"),
        legend.position = "bottom",
        legend.title = ggplot2::element_text(color = col_text),
        legend.text = ggplot2::element_text(color = col_text),
        strip.text = ggplot2::element_text(color = col_text)
      ) +
      ggplot2::facet_wrap(~ tickers, scales = "free_y")


    print(p)

  } else if (plot_name == "Posterior Individual Alpha Distributions by Theme and Signal"){

    # Get alpha and beta
    tidy_posterior_draws_intercept <- tidy_posteriors_list$tidy_posterior_draws_intercept
    tidy_posterior_draws_slope <- tidy_posteriors_list$tidy_posterior_draws_slope

    # Prompt the user to select tickers
    available_tickers <- unique(tidy_posterior_draws_slope$tickers)

    if (is.null(variable)){
      # Prompt the user to select tickers
      # Display available tickers with numbers
      cat("Available tickers:\n")
      for (i in seq_along(available_tickers)) {
        cat(i, ":", available_tickers[i], "\n")
      }

      # Ask user for input
      selected_numbers <- readline(prompt = "Enter the numbers corresponding to the tickers you want to plot, separated by commas: ")

      # Convert input to numeric and validate
      selected_numbers <- as.numeric(strsplit(selected_numbers, ",")[[1]])
      if (any(is.na(selected_numbers)) || !all(selected_numbers %in% seq_along(available_tickers))) {
        stop("Invalid input. Please enter valid numbers corresponding to the tickers.")
      }

      # Match the selected numbers to tickers
      selected_tickers <- available_tickers[selected_numbers]
    } else {
      # Validate the provided variable against available tickers
      if (!all(variable %in% available_tickers)) {
        stop("Invalid 'variable' specified. Available tickers are:\n",
             paste(available_tickers, collapse = ", "))
      }
      selected_tickers <- variable
    }

    # Prepare the data
    theme_ticker_key <- data.frame(tickers = paste0(selected_signal_themes_m_d_ref$theme, "_", selected_signal_themes_m_d_ref$tickers),
                                   theme = selected_signal_themes_m_d_ref$theme)

    plot_data <- tidy_posterior_draws_intercept %>%
      dplyr::ungroup() %>%  # Ensure the data is not grouped
      dplyr::select(tickers, posterior_individual_alpha) %>%
      dplyr::left_join(theme_ticker_key, by = "tickers") %>%
      dplyr::filter(tickers %in% selected_tickers)

    # Automatically generate distinct colors for tickers
    num_tickers <- length(unique(plot_data$tickers))
    ticker_colors <- stats::setNames(palette_colors, unique(plot_data$tickers))

    # Create the boxplot with consistent aesthetics
    p <- ggplot2::ggplot(plot_data, ggplot2::aes(
      x = theme,
      y = posterior_individual_alpha,
      fill = tickers
    )) +
      ggplot2::geom_boxplot(
        position = ggplot2::position_dodge(width = 0.8),
        outlier.shape = NA,
        color = black,  # Border color for boxes
        alpha = 0.8      # Transparency for boxes
      ) +
      ggplot2::scale_fill_manual(
        values = ticker_colors
      ) +
      ggplot2::labs(
        title = "Posterior Individual Alpha Distributions by Theme and Ticker",
        x = "Theme",
        y = "Posterior Individual Alpha",
        fill = "Ticker"
      ) +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        # Set the overall plot background
        plot.background = ggplot2::element_rect(fill = col_background, color = NA),
        # Set the panel background
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        # Remove major and minor grid lines
        panel.grid.major = ggplot2::element_blank(),
        panel.grid.minor = ggplot2::element_blank(),
        # Customize axis text
        axis.text.x = ggplot2::element_text(color = col_text, angle = 45, hjust = 1),
        axis.text.y = ggplot2::element_text(color = col_text),
        # Customize axis titles
        axis.title = ggplot2::element_text(color = col_text, size = 12, face = "bold"),
        # Customize plot title
        plot.title = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
        # Customize legend
        legend.position = "bottom",
        legend.background = ggplot2::element_rect(fill = col_background, color = NA),
        legend.title = ggplot2::element_text(color = col_text, face = "bold"),
        legend.text = ggplot2::element_text(color = col_text),
        # Customize plot subtitle if present
        plot.subtitle = ggplot2::element_text(color = col_text, size = 10, face = "italic")
      )

    print(p)


  }

  invisible(x)
})



#' @title Plot Method for port_backtest_config: Faceted Liquidity Floor Cutoffs (Ordered Within Facets)
#'
#' @description Generates a faceted bar plot displaying liquidity floor cutoff metrics
#' from a \code{port_backtest_config} object. The liquidity floor cutoffs data is expected to
#' contain one grouping column (automatically identified as the first non-numeric column)
#' and one or more numeric columns. The data is pivoted into a long format and, within each metric facet,
#' the grouping variable is reordered (from left to right) based on its numeric value (smallest to largest).
#' All text in the plot (including facet titles) is displayed in white.
#'
#' @param x A \code{port_backtest_config} object containing liquidity floor cutoffs data in the
#'   \code{liquidity_floor_cutoffs} slot.
#' @param palette A character string specifying the color palette to use for the bars. Options include "cyberpunk", "br" and "journal". Default is "cyberpunk".
#' @param ... Additional arguments (currently not used).
#'
#' @return A \code{ggplot} object representing the faceted liquidity floor cutoffs plot.
#' @export

setMethod(
  "plot",
  signature(x = "port_backtest_config", y = "missing"),
  function(x, palette = "cyberpunk", ...) {

    # Check for required packages for plotting
    required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

    missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

    if (length(missing_pkgs) > 0) {
      stop(
        sprintf(
          "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
          paste(missing_pkgs, collapse = ", ")
        ),
        call. = FALSE
      )
    }

    # Check if liquidity_floor_cutoffs data is available
    if (is.null(x@liquidity_floor_cutoffs)) {
      stop("No liquidity floor cutoffs data available in this port_backtest_config object.")
    }

    df <- x@liquidity_floor_cutoffs

    # Identify the grouping column: first column that is not numeric
    non_numeric_cols <- names(df)[!sapply(df, is.numeric)]
    if (length(non_numeric_cols) == 0) {
      stop("Liquidity floor cutoffs data must contain at least one non-numeric column to be used as the grouping variable.")
    }
    group_col <- non_numeric_cols[1]

    # Identify numeric columns (other than the grouping column)
    numeric_cols <- setdiff(names(df), group_col)
    if (length(numeric_cols) == 0) {
      stop("No numeric columns found for plotting.")
    }

    # Pivot the data into long format
    df_long <- tidyr::pivot_longer(
      df,
      cols = numeric_cols,
      names_to = "Metric",
      values_to = "Value"
    )

    # For each Metric facet, reorder the grouping variable by Value.
    # Since each (Metric, group_col) pair is unique, we can arrange by Value and then
    # set new_group factor levels to the order within that group.
    df_long <- df_long %>%
      dplyr::group_by(Metric) %>%
      dplyr::arrange(Value, .by_group = TRUE) %>%
      dplyr::mutate(new_group = factor(.data[[group_col]], levels = unique(.data[[group_col]]))) %>%
      dplyr::ungroup()

    # Define custom colors following the stylistic guidelines
    if (palette == "cyberpunk") {

      light_gray <- "#003641"

      col_background <- "#001f3f"
      col_text       <- "#FFFFFF"
      col_primary    <- "#00FFFF"
      col_secondary <- "#FF69B4"      # Hot Pink
      col_terciary <-  "#FF1493" # Lime Green
      col_quarternary <-  "#FFA500"
      col_quinternary <- "#FF4500"
      col_sextenary <- "#32CD32"
      col_positive   <- "#39FF14"
      col_negative   <- "#FF1493"
      vertical_line_color <- "#FF69B4"
      cyan <- "#00FFFF"

      palette_colors  <- c(
        "#00BFFF", "#FF1493", "#FFFF00",  "#00FFFF", "#8A2BE2",
        "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500"
      )

    }
    if (palette == "br") {

      light_gray <- "#EBEEF1"

      col_background <- "#FFFFFF"
      col_text       <- "#003641"
      col_primary   <- "#00A091"
      col_secondary  <- "#4C7C83"
      col_terciary   <- "#49479D"
      col_quarternary <- "#39FF14"
      col_quinternary <- "#003641"
      col_sextenary  <- "#D6E266"
      col_positive   <- "#7DB61C"
      col_negative   <- "#C2185B"
      vertical_line_color <- "#003641"
      cyan <- "#94E1D6"

      palette_colors  <- c(
        "#94E1D6", "#49479D", "#FF5F1F",
        "#7DB61C", "#98B2B6", "#8A03C9",
        "#00C9B8", "#C9D200", "#C2185B",
        "#00FFFF", "#003641", "#00A091",
        "#4C7C83", "#FF5F1F", "#EBEEA8",
        "#A5CD5C", "#00AE9D",
        "#EBEEA8", "#D6E266", "#00C9B8",
        "#7DB61C", "#A5CD5C", "#003641",
        "#00A091", "#4C7C83"
      )

    }
    if (palette == "journal") {

      jp <- .journal_palette()

      light_gray <- jp$grid

      col_background <- jp$background
      col_text       <- jp$text
      col_primary    <- jp$primary
      col_secondary  <- jp$categorical[3]
      col_terciary   <- jp$categorical[6]
      col_quarternary <- jp$positive
      col_quinternary <- jp$sequential[7]
      col_sextenary  <- jp$categorical[4]
      col_positive   <- jp$positive
      col_negative   <- jp$negative
      vertical_line_color <- jp$text
      cyan <- jp$sequential[3]

      ### Recycle the eight journal hues to match the br palette length
      palette_colors <- rep(jp$categorical, length.out = 25)

    }

    # Create the faceted bar plot: each facet corresponds to a numeric metric.
    # Within each facet, the x-axis uses new_group which is ordered by Value.
    p <- ggplot2::ggplot(df_long, ggplot2::aes(x = new_group, y = Value)) +
      ggplot2::geom_bar(stat = "identity", fill = col_primary, color = col_primary) +
      ggplot2::geom_text(ggplot2::aes(label = scales::scientific(Value, digits = 2)),
                         vjust = -0.5, color = col_text, size = 3.5) +
      ggplot2::facet_wrap(ggplot2::vars(Metric), scales = "free_y") +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        plot.background  = ggplot2::element_rect(fill = col_background, color = NA),
        panel.background = ggplot2::element_rect(fill = col_background, color = NA),
        axis.text        = ggplot2::element_text(color = col_text),
        axis.title       = ggplot2::element_text(color = col_text),
        plot.title       = ggplot2::element_text(color = col_text, size = 16, face = "bold"),
        plot.subtitle    = ggplot2::element_text(color = col_text, size = 10, face = "italic"),
        legend.position  = "bottom",
        legend.title     = ggplot2::element_text(color = col_text),
        legend.text      = ggplot2::element_text(color = col_text),
        strip.text       = ggplot2::element_text(color = col_text)  # Facet titles in white
      ) +
      ggplot2::labs(
        title    = "Liquidity Floor Cutoffs",
        subtitle = paste("Faceted bar plots by metric (grouped by", group_col, ")"),
        x        = group_col,
        y        = "Value"
      )

    print(p)
    invisible(p)
  }
)


#' Plot Method for 'port' Objects
#'
#' This method generates plots for a \code{port} object, depending on the specified \code{type}.
#'
#' The currently supported plot types are:
#' \enumerate{
#'  \item \code{"weights"} - A bar chart of the portfolio weights (or active weights).
#'  \item \code{"exp_ret_score"} - A bar chart of the portfolio's expected return scores.
#'  \item \code{"risk_return"} - A scatterplot of expected return score (y) vs. risk (x).
#'  \item \code{"correlation"} - A heatmap of the asset correlation matrix.
#'  \item \code{"relative_risk_contribution"} - A bar chart comparing weights and risk contributions.
#'  \item \code{"efficient_frontier"} - A scatterplot of random portfolios with Sharpe ratio coloring and the optimal portfolio highlighted.
#'  \item \code{"random_weights_distribution"} - A jitter plot of random portfolio weights with constraints.
#'  \item \code{"group_composition"} - A grouped bar chart comparing portfolio and benchmark weights across classification variables (e.g., sectors).
#'  \item \code{"hierarchical_clustering"} - A dendrogram showing hierarchical clustering of assets.
#' }
#'
#' This method is dispatched on signature \code{plot(x = "port", y = "missing")} and does not use the \code{y} argument.
#'
#' @param x An object of class \code{"port"}.
#' @param type A character string specifying the type of plot to generate. If \code{NULL}, the user will be prompted.
#' @param palette A character string specifying the color palette to use for the plots. Default is "cyberpunk". Supported options include "cyberpunk", "br" and "journal".
#' @param chosen_weights A character vector of asset names to include in the weights plot (if \code{type = "weights"}). If \code{NULL}, all assets are included.
#' @param chosen_risk_metrics A character vector of risk metrics to include in the risk plots (if applicable). If \code{NULL}, all risk metrics are included.
#' @param add_bench A logical indicating whether to add benchmark weights to the weights plot (if \code{type = "weights"}). Default is \code{FALSE}.
#' @param tickers A character vector of asset tickers to include in the plot (if applicable). If \code{NULL}, all tickers are included.
#' @param level A character string specifying the grouping variable for the group composition plot (if type = "group_composition").#' @param by_group A logical indicating whether to facet the group composition plot by the grouping.
#' @param groups A character vector of group names to include in the group composition plot (if \code{type = "group_composition"}). If \code{NULL}, all groups are included.
#' @param micro_port A logical indicating the micro portfolio to plot.
#' @param active_weights A logical indicating whether to plot active weights instead of total weights
#' @param top_n An integer specifying the number of top assets to include in the weights plot (if \code{type = "weights"}). If \code{NULL}, all assets are included.
#' @param by_group A logical indicating whether to facet the group composition plot by the grouping variable (if \code{type = "group_composition"}). Default is \code{FALSE}.
#' @param ... Additional arguments for future extensions (currently unused).
#'
#' @return A \code{ggplot} object (invisibly). The function also prints the plot.
#' @export
setMethod(
  "plot",
  signature(x = "port", y = "missing"),
  function(x, type = NULL, palette = "cyberpunk", chosen_weights = NULL, chosen_risk_metrics = NULL,
           add_bench = NULL, tickers = NULL, level = NULL, by_group = NULL, groups = NULL, micro_port = NULL,
           active_weights = NULL, top_n = NULL,
           ...) {

    ## ---- dependencies ----
    required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")
    missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]
    if (length(missing_pkgs) > 0) {
      stop(
        sprintf("Required plotting packages not installed: %s. Install with install.packages().",
                paste(missing_pkgs, collapse = ", ")),
        call. = FALSE
      )
    }

    ## ---- palette ----
    # Define colors for plotting
    # Palette
    black <- "#000000"
    white <- "#FFFFFF"

    if (palette == "cyberpunk") {

      light_gray <- "#003641"

      col_background <- "#001f3f"
      col_text       <- "#FFFFFF"
      col_primary    <- "#FF1493"
      col_secondary <- "#FF69B4"      # Hot Pink
      col_terciary <-  "#00FFFF" # Lime Green
      col_quarternary <-  "#FFA500"
      col_quinternary <- "#FF4500"
      col_sextenary <- "#32CD32"
      pos_color <- col_positive  <- "#39FF14"
      neg_color <- col_negative <- "#FF1493"
      vertical_line_color <- "#FF69B4"
      cyan <- "#00FFFF"

      palette_colors  <- c(
        "#00BFFF", "#FF1493", "#FFFF00",  "#00FFFF", "#8A2BE2",
        "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500",
        "#FF10F0", "#00FFF7", "#FF4500",  "#FF1493",  "#00CED1",
        "#00FA9A",  "#DC143C", "#FF69B4"
      )


    }
    if (palette == "br") {

      light_gray <- "#EBEEF1"

      col_background <- "#FFFFFF"
      col_text       <- "#003641"
      col_primary   <- "#00A091"
      col_secondary  <- "#4C7C83"
      col_terciary   <- "#49479D"
      col_quarternary <- "#39FF14"
      col_quinternary <- "#003641"
      col_sextenary  <- "#D6E266"
      pos_color  <- col_positive <- "#7DB61C"
      neg_color <- col_negative  <- "#C2185B"
      vertical_line_color <- "#003641"
      cyan <- "#94E1D6"

      palette_colors  <- c(
        "#94E1D6",
        "#49479D",
        "#7DB61C",
        "#003641",
        "#00C9B8",
        "#2F2D6F",
        "#FF5F1F",
        "#39FF14",
        "#C9D200",
        "#00A091",
        "#3FB7C4",
        "#EBEEF1",
        "#98B2B6",
        "#6E8B91",
        "#4C7C83",
        "#A8A600",
        "#3E3C8A",
        "#5A58B5",
        "#6E6CC4",
        "#002C33",
        "#004F57",
        "#8E9400",
        "#EBEEA8",
        "#D6E266",
        "#CEE2A2",
        "#B6B300",
        "#A5CD5C",
        "#0A3D62",
        "#006D77",
        "#1B8A9B",
        "#0F4C81",
        "#1B4F8C",
        "#2E6F95",
        "#3A7CA5",
        "#4A90C2"
      )

    }
    if (palette == "journal") {

      jp <- .journal_palette()

      light_gray <- jp$grid

      col_background <- jp$background
      col_text       <- jp$text
      col_primary    <- jp$primary
      col_secondary  <- jp$categorical[3]
      col_terciary   <- jp$categorical[6]
      col_quarternary <- jp$positive
      col_quinternary <- jp$sequential[7]
      col_sextenary  <- jp$categorical[4]
      pos_color  <- col_positive <- jp$positive
      neg_color <- col_negative  <- jp$negative
      vertical_line_color <- jp$text
      cyan <- jp$sequential[3]

      ### Recycle the eight journal hues to match the br palette length
      palette_colors <- rep(jp$categorical, length.out = 35)

    }


    ## ---- pull slots ----
    U <- if (methods::is(x@universe_m_d_ref, "meta_dataframe")) x@universe_m_d_ref@data else NULL
    asset_names <- x@eligible_assets
    weights <- x@weights
    exp_ret_score <- x@exp_ret_score
    cov_mat <- x@covariance_matrix
    corr_mat <- x@correlation_matrix
    rel_risk_contr <- x@rel_risk_contr
    random_port_wt <- x@random_port_weights
    groups_df <- x@groups
    group_col <- x@group_col
    port_name <- x@port_name
    port_stats <- x@port_stats

    ## ---- helpers ----
    .menu <- function(choices, title = "Choose:") {
      cat(paste0("\n", title, "\n"))
      for (i in seq_along(choices)) cat(sprintf("%d: %s\n", i, choices[i]))
      sel <- readline(prompt = "Enter number: ")
      sel <- suppressWarnings(as.integer(sel))
      if (is.na(sel) || sel < 1L || sel > length(choices)) stop("Invalid selection.")
      choices[sel]
    }

    .select_from_vector <- function(v, title = "Select items (indices '1,3' or names 'A,B' or 'all')") {
      cat("\nItems:\n"); for (i in seq_along(v)) cat(sprintf("%d: %s\n", i, v[i]))
      ans <- readline(prompt = paste0(title, ": "))
      ans <- trimws(ans)
      if (!nzchar(ans) || tolower(ans) == "all") return(v)
      parts <- strsplit(ans, ",")[[1]]; parts <- trimws(parts)
      all_num <- suppressWarnings(!any(is.na(as.numeric(parts))))
      if (all_num) {
        idx <- as.integer(parts)
        if (any(idx < 1L | idx > length(v))) stop("Index out of range.")
        return(v[idx])
      } else {
        if (!all(parts %in% v)) stop("Unknown names in selection.")
        return(parts)
      }
    }

    .gg_dark <- function(base_size = 12) {
      ggplot2::theme_minimal(base_size = base_size) +
        ggplot2::theme(
          plot.background  = ggplot2::element_rect(fill = col_background, color = NA),
          panel.background = ggplot2::element_rect(fill = col_background, color = NA),
          panel.grid       = ggplot2::element_blank(),
          axis.text        = ggplot2::element_text(color = col_text),
          axis.title       = ggplot2::element_text(color = col_text),
          plot.title       = ggplot2::element_text(color = col_text, face = "bold"),
          legend.title     = ggplot2::element_text(color = col_text),
          legend.text      = ggplot2::element_text(color = col_text)
        )
    }


    .bench_cols <- function(U) grep("_bench_weights$", colnames(U), value = TRUE)

    .get_bench_col <- function(U) {
      bc <- .bench_cols(U)
      if (length(bc) == 0) return(NULL)
      if (length(bc) == 1) return(bc[1])
      .menu(bc, "Select benchmark column")
    }

    .safe_cor_from_cov <- function(C) {
      d <- sqrt(diag(C)); outer <- d %*% t(d); C / outer
    }

    .resolve_group_col <- function() {
      if (is.null(groups_df)) stop("groups slot not available.")
      req <- c("id","tickers","dates")
      if (!all(req %in% colnames(groups_df))) stop("groups must have 'id','tickers','dates'.")
      if (is.null(group_col) || !group_col %in% setdiff(colnames(groups_df), req)) {
        stop("group_col must be set and present in groups.")
      }
      group_col
    }

    .ensure_macro_groups_exist <- function(x) {
      if (is.null(x@macro) || is.null(x@macro@universe_m_d_ref)) {
        stop("macro universe not available.")
      }
      if (!methods::is(x@macro@universe_m_d_ref, "meta_dataframe")) {
        stop("macro@universe_m_d_ref must be a 'meta_dataframe'.")
      }
      invisible(TRUE)
    }

    .macro_active_vectors <- function() {
      ## For macro, act_* not stored; compute vs chosen benchmark from macro@universe_m_d_ref
      Um <- if (methods::is(x@macro@universe_m_d_ref, "meta_dataframe")) x@macro@universe_m_d_ref@data else NULL
      if (is.null(Um)) stop("macro universe data not available.")
      bench_col <- .get_bench_col(Um)
      if (is.null(bench_col)) stop("No *_bench_weights column found in macro universe.")
      list(bench_col = bench_col, Um = Um)
    }

    ## ---- prompt type ----
    available_types <- c(
      "Weights",
      "Expected Return Score",
      "Risk-Return Trade-off",
      "Correlation",
      "Relative Risk Contribution",
      "Efficient Frontier",
      "Random Weights Distribution",
      "Groups Allocation",
      "Hierarchical Clustering",
      "Allocation Flow (Groups -> Assets)",
      "Within-Group Composition",
      "Group Risk Decomposition",
      "Portfolio Stats",
      "Universe Data"
    )
    ## Build options
    ## The Micro level is offered on the strength of the slot, not the method name. Every
    ## layered method fills @micro with sub-portfolios, and the dispatch below is already
    ## generic: it lists names(x@micro) and delegates plot() to the chosen entry. Gating
    ## on "mmaf" therefore hid the legs of an slsaf portfolio that was carrying them.
    ## NULL entries are dropped rather than counted, since slsaf leaves the short leg NULL
    ## when every constituent is eligible and the long leg NULL when no budget is
    ## released, and offering one would delegate plot() to NULL.
    micro_list <- if (is.list(x@micro)) Filter(Negate(is.null), x@micro) else list()
    level_opts <- c("Portfolio")
    if (!is.null(x@macro)) level_opts <- c(level_opts, "Macro")
    if (length(micro_list) > 0L) level_opts <- c(level_opts, "Micro")

    ## If there's only Portfolio, skip the menu
    if (length(level_opts) == 1L) {
      pick_label <- "Portfolio"
    } else {
      if (is.null(level)){
      raw_pick <- .menu(level_opts, "Plot level (Portfolio / Macro / Micro)")

        ## Accept both label or index; also guard 0/NA
        if (is.character(raw_pick)) {
          pick_label <- trimws(raw_pick)
          if (!nzchar(pick_label) || !(pick_label %in% level_opts)) stop("Invalid level selection.")
        } else {
          idx <- suppressWarnings(as.integer(raw_pick))
          if (is.na(idx) || idx <= 0L || idx > length(level_opts)) stop("Invalid level selection.")
          pick_label <- level_opts[idx]
        }
      } else {
        if (!level %in% level_opts) stop("Invalid 'level' specified.")
        pick_label <- level
      }
    }

    ## Dispatch by label
    if (identical(pick_label, "Macro")) {
      plot(x@macro, palette = palette, chosen_weights = chosen_weights, add_bench = add_bench,
           tickers = groups, type = type, chosen_risk_metrics = chosen_risk_metrics,
           active_weights = active_weights, top_n = top_n,
           by_group = FALSE, groups = NULL, ...)
      return(invisible())
    }

    if (identical(pick_label, "Micro")) {
      ## micro_list was filtered when the level options were built, so what is selected
      ## here is always a populated sub-portfolio
      if (length(micro_list) < 1L) stop("Micro portfolio list is empty.")
      micro_names <- names(micro_list)
      if (is.null(micro_names)) micro_names <- as.character(seq_along(micro_list))

      if (is.null(micro_port)){
        cat("\nAvailable micro portfolios:\n")
        for (i in seq_along(micro_names)) cat(i, ": ", micro_names[i], "\n", sep = "")

        m_idx <- suppressWarnings(as.integer(readline(prompt = "Select micro index: ")))
      } else {
        if (is.character(micro_port)) {
          m_idx <- which(micro_names == micro_port)
          if (length(m_idx) == 0L) stop("Specified micro_port name not found.")
        } else {
          m_idx <- suppressWarnings(as.integer(micro_port))
          if (is.na(m_idx) || m_idx < 1L || m_idx > length(micro_list)) stop("Invalid micro_port index.")
        }
      }

      if (is.na(m_idx) || m_idx < 1L || m_idx > length(micro_list)) stop("Invalid micro selection.")

      plot(micro_list[[m_idx]], palette = palette, chosen_weights = chosen_weights, add_bench = add_bench,
           tickers = tickers, type = type, chosen_risk_metrics = chosen_risk_metrics,
           by_group = by_group, groups = groups, active_weights = active_weights, top_n = top_n, ...)

      return(invisible())
    }

    ## Portfolio level continues: now ask the plot type
    if (is.null(type)){
      type <- .menu(available_types, "Choose plot type")
    } else {
      if (!type %in% available_types) stop("Invalid plot type specified.")
    }

    ## =========================================================================================
    ## Weights
    ## =========================================================================================
    if (type == "Weights") {
      if (length(weights) == 0L || length(weights) != length(asset_names)) stop("weights/eligible_assets mismatch.")
      if (is.null(U) || !"tickers" %in% colnames(U)) stop("universe_m_d_ref@data must include 'tickers'.")

      has_act <- "act_weights" %in% colnames(U)
      bench_col <- .get_bench_col(U)  # may be NULL

      if (is.null(chosen_weights)){
        metric_choices <- c("weights")
        if (has_act) metric_choices <- c(metric_choices, "act_weights")
        chosen_metrics <- .select_from_vector(metric_choices, "Metrics to include (choose names or 'all')")
      } else {
        chosen_metrics <- chosen_weights
      }
      if (is.null(add_bench)){
        add_bench <- if (!is.null(bench_col)) {
          ans <- tolower(readline(prompt = sprintf("Add benchmark (%s) to plot? (y/n): ", bench_col)))
          ans %in% c("y","yes")
        } else FALSE
      }

      df <- data.frame(tickers = asset_names, weights = weights, stringsAsFactors = FALSE) |>
        dplyr::left_join(U[, c("tickers", intersect(c("act_weights", bench_col), colnames(U))), drop = FALSE], by = "tickers")

      plot_cols <- intersect(c("weights", "act_weights"), chosen_metrics)
      if (add_bench && !is.null(bench_col)) {
        names(df)[names(df) == bench_col] <- "_bench_"
        plot_cols <- c(plot_cols, "_bench_")
      }

      ## subset choice
      if (is.null(tickers)){
        mode <- suppressWarnings(as.integer(readline(prompt = "\n1: Top x by |weights|  2: Pick names/indices\nChoice: ")))
        if (!mode %in% c(1L,2L)) stop("Invalid choice.")
        keep <- asset_names
        if (mode == 1L) {
          n_choice <- suppressWarnings(as.integer(readline(prompt = "How many assets? ")))
          if (is.na(n_choice) || n_choice < 1L) n_choice <- min(length(asset_names), 20L)
          ord <- order(-abs(df$weights))
          keep <- df$tickers[ord][seq_len(min(n_choice, length(ord)))]
        } else {
          keep <- .select_from_vector(asset_names, "Pick assets")
        }
      } else {
        keep <- tickers
      }
      df <- df[df$tickers %in% keep, , drop = FALSE]

      dfl <- tidyr::pivot_longer(df, cols = tidyselect::any_of(plot_cols), names_to = "Metric", values_to = "Value")
      pretty_names <- c(weights = "Weight", act_weights = "Active Weight", `_bench_` = "Benchmark")
      dfl$Metric <- pretty_names[dfl$Metric]

      p <- ggplot2::ggplot(dfl, ggplot2::aes(x = stats::reorder(tickers, -abs(Value)), y = Value, fill = Metric)) +
        ggplot2::geom_bar(stat = "identity", position = "dodge", color = col_text, size = 0.4) +
        ggplot2::scale_fill_manual(values = c("Weight" = col_primary, "Active Weight" = col_secondary, "Benchmark" = col_terciary)) +
        .gg_dark() +
        ggplot2::labs(title = paste("Portfolio Weights:", if (port_name == "") "not_identified" else port_name),
                      x = "Assets", y = "Weight", fill = NULL)
      print(p); return(invisible(p))
    }

    ## =========================================================================================
    ## Expected Return Score
    ## =========================================================================================
    if (type == "Expected Return Score") {
      if (is.null(exp_ret_score) || length(exp_ret_score) != length(asset_names)) stop("exp_ret_score/eligible_assets mismatch.")
      df <- data.frame(Asset = asset_names, ExpRet = exp_ret_score, stringsAsFactors = FALSE)
      if (is.null(tickers)){
        mode <- suppressWarnings(as.integer(readline(prompt = "\n1: Top x by |ExpRet|  2: Pick names/indices\nChoice: ")))
        if (!mode %in% c(1L,2L)) stop("Invalid choice.")
        if (mode == 1L) {
          n_choice <- suppressWarnings(as.integer(readline(prompt = "How many assets? ")))
          n_choice <- if (is.na(n_choice) || n_choice < 1L) min(20L, nrow(df)) else min(n_choice, nrow(df))
          df <- dplyr::arrange(df, dplyr::desc(abs(.data$ExpRet))) |> dplyr::slice_head(n = n_choice)
        } else {
          keep <- .select_from_vector(asset_names, "Pick assets")
          df <- df[df$Asset %in% keep, , drop = FALSE]
        }
      } else {
        df <- df[df$Asset %in% tickers, , drop = FALSE]
      }


      p <- ggplot2::ggplot(df, ggplot2::aes(x = Asset, y = ExpRet, fill = Asset)) +
        ggplot2::geom_bar(stat = "identity", color = col_background, alpha = 0.85) +
        ggplot2::scale_fill_manual(values = rep(palette_colors, length.out = nrow(df))) +
        .gg_dark() +
        ggplot2::theme(legend.position = "none") +
        ggplot2::labs(title = paste("Expected Return Scores:", if (port_name == "") "not_identified" else port_name),
                      x = "Assets", y = "Score")
      print(p); return(invisible(p))
    }

    ## =========================================================================================
    ## Risk-Return Trade-off
    ## =========================================================================================
    if (type == "Risk-Return Trade-off") {
      if (is.null(cov_mat)) stop("covariance_matrix required.")
      if (is.null(U) || !"tickers" %in% colnames(U)) stop("universe data required.")

        x_choices <- c("risk")
        if ("rel_risk_contr" %in% colnames(U)) x_choices <- c(x_choices, "rel_risk_contr")
        if ("act_rel_risk_contr" %in% colnames(U)) x_choices <- c(x_choices, "act_rel_risk_contr")

        if (is.null(chosen_risk_metrics)){
          x_pick <- .menu(x_choices, "X-axis: choose risk or (active) RRC")
        } else {
          x_pick <- chosen_risk_metrics
          if (!any(x_pick %in% x_choices)) stop("Invalid chosen_risk_metrics specified.")
        }


      diag_risk <- sqrt(diag(cov_mat))
      base_df <- data.frame(Asset = asset_names,
                            risk  = diag_risk,
                            ExpRet = exp_ret_score,
                            stringsAsFactors = FALSE)

      join_cols <- setdiff(x_pick, "risk")
      if (length(join_cols) > 0L) {
        base_df <- dplyr::left_join(
          base_df,
          U[, c("tickers", join_cols), drop = FALSE],
          by = c("Asset" = "tickers")
        )
      }

      df <- base_df
      names(df)[names(df) == x_pick] <- "X"

      if (is.null(tickers)){
        mode <- suppressWarnings(as.integer(readline(prompt = "\n1: Top x by |exp_ret_score|  2: Pick names/indices\nChoice: ")))
        if (!mode %in% c(1L,2L)) stop("Invalid choice.")
        if (mode == 1L) {
          n_choice <- suppressWarnings(as.integer(readline(prompt = "How many assets? ")))
          n_choice <- if (is.na(n_choice) || n_choice < 1L) min(20L, nrow(df)) else min(n_choice, nrow(df))
          df <- dplyr::arrange(df, dplyr::desc(abs(.data$ExpRet))) |>
            dplyr::slice_head(n = n_choice)
        } else {
          keep <- .select_from_vector(asset_names, "Pick assets")
          df <- df[df$Asset %in% keep, , drop = FALSE]
        }
      } else {
        df <- df[df$Asset %in% tickers, , drop = FALSE]
      }


      p <- ggplot2::ggplot(df, ggplot2::aes(x = X, y = ExpRet, label = Asset)) +
        ggplot2::geom_point(color = col_primary, size = 3) +
        ggrepel::geom_text_repel(color = col_text, size = 3.5, box.padding = 0.3, segment.color = col_text) +
        .gg_dark() +
        ggplot2::labs(title = sprintf("Risk-Return: X = %s, Y = exp_ret_score", x_pick),
                        x = x_pick, y = "Expected Return Score")
      print(p); return(invisible(p))
    }

    ## =========================================================================================
    ## Correlation  (assets or groups)
    ## =========================================================================================
    if (type == "Correlation") {
      if (is.null(by_group)){
        mode <- .menu(c("Assets", "Groups"), "Correlation heatmap for")
      } else {
        if (isTRUE(by_group)) mode <- "Groups" else mode <- "Assets"
      }

      if (mode == "Assets") {
        C <- if (!is.null(corr_mat)) corr_mat else .safe_cor_from_cov(cov_mat)
        if (is.null(C)) stop("Need correlation or covariance matrix.")
        if (is.null(tickers)){
          keep <- .select_from_vector(asset_names, "Pick assets or 'all'")
        } else {
          keep <- tickers
        }
        sub_mat <- C[keep, keep, drop = FALSE]
      } else {
        if (is.null(x@group_cov_matrix)) stop("group_cov_matrix required for group correlation.")
        G <- x@group_cov_matrix
        Gc <- stats::cov2cor(G)
        if (is.null(groups)){
          keep <- .select_from_vector(colnames(Gc), "Pick groups or 'all'")
        } else {
          group_names <- colnames(Gc)
          if (!all(groups %in% group_names)) stop("groups not all present in group_cov_matrix.")
          keep <- groups
        }
        sub_mat <- Gc[keep, keep, drop = FALSE]
      }

      M <- sub_mat
      M[upper.tri(M, diag = FALSE)] <- NA
      df <- as.data.frame(M); df$Row <- rownames(M)
      dl <- tidyr::pivot_longer(df, cols = -Row, names_to = "Col", values_to = "Correlation")

      p <- ggplot2::ggplot(dl, ggplot2::aes(x = factor(Col, levels = keep),
                                            y = factor(Row, levels = rev(keep)),
                                            fill = Correlation)) +
        ggplot2::geom_tile(color = col_text) +
        ggplot2::geom_text(ggplot2::aes(label = round(Correlation, 2)), color = col_text, na.rm = TRUE, size = 3) +
        ggplot2::scale_fill_gradient2(low = col_negative, mid = light_gray, high = col_positive, midpoint = 0, limits = c(-1,1)) +
        .gg_dark() +
        ggplot2::theme(axis.title = ggplot2::element_blank()) +
        ggplot2::labs(title = "Correlation Heatmap")
      print(p); return(invisible(p))
    }

    ## =========================================================================================
    ## Relative Risk Contribution
    ## =========================================================================================
    if (type == "Relative Risk Contribution") {

      if (is.null(U) || !"tickers" %in% colnames(U)) stop("universe data required.")
      cols <- c("rel_risk_contr", "act_rel_risk_contr")
      cols <- cols[cols %in% colnames(U)]
      if (length(cols) == 0) stop("No rel_risk_contr columns found in universe data.")

      if (is.null(chosen_risk_metrics)){
        pick <- .menu(cols, "Choose RRC measure to plot")
      } else {
        pick <- chosen_risk_metrics
        if (!any(pick %in% cols)) stop("Invalid chosen_risk_metrics specified.")
      }

      ##Only one chosen risk metric allowed
      if (length(chosen_risk_metrics) > 1){
        stop("Please choose only one risk metric for this plot type.")
      }

      is_active_rrc <- identical(pick, "act_rel_risk_contr")

      df <- data.frame(tickers = asset_names, stringsAsFactors = FALSE) |>
        dplyr::left_join(U[, c("tickers", pick), drop = FALSE], by = "tickers")
      names(df)[names(df) == pick] <- "RRC"
      df$Weight <- weights

      if (is.null(tickers)){
        mode <- suppressWarnings(as.integer(readline(prompt = "\n1: Top x by |RRC|  2: Pick names/indices\nChoice: ")))
        if (!mode %in% c(1L,2L)) stop("Invalid choice.")
        if (mode == 1L) {
          n_choice <- suppressWarnings(as.integer(readline(prompt = "How many assets? ")))
          n_choice <- if (is.na(n_choice) || n_choice < 1L) min(20L, nrow(df)) else min(n_choice, nrow(df))
          df <- dplyr::arrange(df, dplyr::desc(abs(.data$RRC))) |> dplyr::slice_head(n = n_choice)
        } else {
          keep <- .select_from_vector(asset_names, "Pick assets")
          df <- df[df$tickers %in% keep, , drop = FALSE]
        }
      } else {
        df <- df[df$tickers %in% tickers, , drop = FALSE]
      }

      dfl <- tidyr::pivot_longer(df, cols = c("Weight","RRC"), names_to = "Metric", values_to = "Value")

      p <- ggplot2::ggplot(dfl, ggplot2::aes(x = tickers, y = Value, fill = Metric)) +
        ggplot2::geom_bar(stat = "identity", position = "dodge", color = col_background, alpha = 0.9) +
        ggplot2::scale_fill_manual(values = c("Weight" = col_secondary, "RRC" = col_terciary)) +
        .gg_dark() +
        ggplot2::labs(
          title = paste0("Relative Risk Contribution",
                         if (is_active_rrc) " (Active)" else "",
                         ": ", if (port_name == "") "not_identified" else port_name),
          x = "Asset", y = "Value", fill = NULL
        )
      print(p); return(invisible(p))
    }

    ## =========================================================================================
    ## Efficient Frontier
    ## =========================================================================================
    if (type == "Efficient Frontier") {
      if (is.null(random_port_wt) || is.null(cov_mat) || is.null(exp_ret_score))
        stop("random_port_weights, covariance_matrix, and exp_ret_score required.")
      if (length(random_port_wt$tickers) != length(asset_names)) stop("random_port_weights columns mismatch.")

      rp_df <- random_port_wt[, -1, drop = FALSE]
      rownames(rp_df) <- asset_names

      rp_ret <- apply(rp_df, 2, function(w) sum(w * exp_ret_score))
      rp_risk <- apply(rp_df, 2, function(w) sqrt(t(w) %*% cov_mat %*% w))
      rp_sh <- rp_ret / rp_risk
      frontier_df <- data.frame(Return = rp_ret, Risk = rp_risk, Sharpe = rp_sh)

      opt_w <- weights
      opt_ret <- sum(opt_w * exp_ret_score)
      opt_risk <- sqrt(t(opt_w) %*% cov_mat %*% opt_w)

      base_risk <- base_return <- target_risk <- target_return <- NA_real_
      if (!is.null(U) && "base_weights" %in% colnames(U)) {
        bw <- dplyr::left_join(data.frame(tickers = asset_names),
                               U[, c("tickers","base_weights")], by = "tickers")$base_weights
        base_return <- sum(bw * exp_ret_score); base_risk <- sqrt(t(bw) %*% cov_mat %*% bw)
      }
      if (!is.null(U) && "target_weights" %in% colnames(U)) {
        tw <- dplyr::left_join(data.frame(tickers = asset_names),
                               U[, c("tickers","target_weights")], by = "tickers")$target_weights
        target_return <- sum(tw * exp_ret_score); target_risk <- sqrt(t(tw) %*% cov_mat %*% tw)
      }

      p <- ggplot2::ggplot(frontier_df, ggplot2::aes(x = Risk, y = Return, color = Sharpe)) +
        ggplot2::geom_point(size = 3, alpha = 0.7) +
        ggplot2::scale_color_gradient(low = col_negative, high = col_positive) +
        ggplot2::annotate("point", x = opt_risk, y = opt_ret, color = "red", size = 4, shape = 17) +
        { if (!is.na(base_risk) && !is.na(base_return)) ggplot2::annotate("point", x = base_risk, y = base_return, color = col_primary, size = 4, shape = 15) } +
        { if (!is.na(target_risk) && !is.na(target_return)) ggplot2::annotate("point", x = target_risk, y = target_return, color = col_secondary, size = 4, shape = 18) } +
        .gg_dark() +
        ggplot2::labs(title = paste("Efficient Frontier:", if (port_name == "") "not_identified" else port_name),
                      x = "Risk (stdev)", y = "Expected Return", color = "Sharpe")
      if (!is.na(base_risk)) cat(sprintf("Blue square: Base Weights (Risk %.4f, Return %.4f)\n", base_risk, base_return))
      if (!is.na(target_risk)) cat(sprintf("Orange diamond: Target Weights (Risk %.4f, Return %.4f)\n", target_risk, target_return))
      cat(sprintf("Red triangle: Optimal Weights (Risk %.4f, Return %.4f)\n", opt_risk, opt_ret))
      print(p); return(invisible(p))
    }

    ## =========================================================================================
    ## Random Weights Distribution
    ## =========================================================================================
    if (type == "Random Weights Distribution") {

      if (is.null(random_port_wt) || is.null(x@ind_max_weights) || is.null(x@ind_min_weights))
        stop("random_port_weights and individual constraints required.")
      W <- as.data.frame(t(random_port_wt[, -1, drop = FALSE])); colnames(W) <- random_port_wt$tickers
      dl <- tidyr::pivot_longer(W, cols = dplyr::everything(), names_to = "assets", values_to = "weights")
      constraints <- data.frame(assets = asset_names,
                                ind_max_weights = x@ind_max_weights,
                                ind_min_weights = x@ind_min_weights,
                                stringsAsFactors = FALSE)
      plot_data <- dplyr::left_join(dl, constraints, by = "assets")

      if (is.null(tickers)){
        mode <- suppressWarnings(as.integer(readline(prompt = "\n1: Top x by avg |random weight|  2: Pick names/indices\nChoice: ")))
        if (!mode %in% c(1L,2L)) stop("Invalid choice.")
        if (mode == 1L) {
          av <- plot_data |> dplyr::group_by(.data$assets) |>
            dplyr::summarize(avg_abs = mean(abs(.data$weights), na.rm = TRUE), .groups = "drop") |>
            dplyr::arrange(dplyr::desc(.data$avg_abs))
          n_choice <- suppressWarnings(as.integer(readline(prompt = "How many assets? ")))
          n_choice <- if (is.na(n_choice) || n_choice < 1L) min(20L, nrow(av)) else min(n_choice, nrow(av))
          keep <- av$assets[seq_len(n_choice)]
          plot_data <- dplyr::filter(plot_data, .data$assets %in% keep)
          constraints <- dplyr::filter(constraints, .data$assets %in% keep)
        } else {
          keep <- .select_from_vector(asset_names, "Pick assets")
          plot_data <- dplyr::filter(plot_data, .data$assets %in% keep)
          constraints <- dplyr::filter(constraints, .data$assets %in% keep)
        }
      } else {
        plot_data <- dplyr::filter(plot_data, .data$assets %in% tickers)
        constraints <- dplyr::filter(constraints, .data$assets %in% tickers)
      }


      p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = assets, y = weights)) +
        ggplot2::geom_jitter(width = 0.2, color = col_primary, alpha = 0.5, size = 2) +
        ggplot2::geom_point(data = constraints, ggplot2::aes(x = assets, y = ind_max_weights), color = col_secondary, size = 3, shape = 17) +
        ggplot2::geom_point(data = constraints, ggplot2::aes(x = assets, y = ind_min_weights), color = col_terciary, size = 3, shape = 17) +
        .gg_dark() +
        ggplot2::labs(title = "Weight Distribution with Constraints", x = "Assets", y = "Weights")
      print(p); return(invisible(p))
    }

    ## =========================================================================================
    ## Groups Allocation  (macro is available for any port with groups)
    ## =========================================================================================
    if (type == "Groups Allocation") {
      ## macro exists for any port that has groups
      .ensure_macro_groups_exist(x)

      Um <- if (methods::is(x@macro@universe_m_d_ref, "meta_dataframe"))
        x@macro@universe_m_d_ref@data else NULL
      if (is.null(Um)) stop("macro universe data not available.")

      ## must have at least weights or rel_risk_contr
      avail <- intersect(c("weights", "rel_risk_contr"), colnames(Um))
      if (length(avail) == 0L) stop("macro universe lacks 'weights'/'rel_risk_contr'.")

      ## prompt once for active version vs bench_weights
      bench_col <- .get_bench_col(Um)  ## auto-detect *_bench_weights
      if (is.null(active_weights)){
        active_ans <- tolower(readline(prompt = "Plot active version (vs bench_weights)? (y/n): "))
        plot_active <- active_ans %in% c("y", "yes")
      } else {
        plot_active <- isTRUE(active_weights)
      }

      ## assemble base df
      keep_cols <- c("tickers", intersect(c("weights","rel_risk_contr", bench_col), colnames(Um)))
      df <- Um[, keep_cols, drop = FALSE]

      if (plot_active) {
        if (is.null(bench_col)) stop("To plot active, a bench_weights column must exist.")
        ## active weights
        w <- df$weights
        b <- df[[bench_col]]
        df$act_weights <- w - b

        ## active RRC using group covariance
        if (is.null(x@group_cov_matrix)) stop("group_cov_matrix required for Active RRC.")
        gC <- x@group_cov_matrix
        grp_names <- df$tickers
        if (!all(grp_names %in% colnames(gC))) stop("group_cov_matrix must include macro groups.")
        gC <- gC[grp_names, grp_names, drop = FALSE]

        wte <- df$act_weights
        port_var <- as.numeric(t(wte) %*% gC %*% wte)
        mrc <- as.numeric(gC %*% wte)
        df$act_rel_risk_contr <- (wte * mrc) / port_var

        plot_cols <- c("act_weights", "act_rel_risk_contr")
        pretty <- c(act_weights = "Active Weight", act_rel_risk_contr = "Active RRC")

      } else {
        ## non-active: weights, RRC, and bench_weights (renamed for legend)
        if (is.null(bench_col)) stop("bench_weights column not found.")
        names(df)[names(df) == bench_col] <- "bench_weights"
        plot_cols <- intersect(c("weights","rel_risk_contr","bench_weights"), colnames(df))
        pretty <- c(weights = "Weight", rel_risk_contr = "RRC", bench_weights = "Bench Weight")
      }

      dfl <- tidyr::pivot_longer(
        df,
        cols = tidyselect::any_of(plot_cols),
        names_to = "Metric", values_to = "Value"
      )
      dfl$Metric <- pretty[dfl$Metric]

      p <- ggplot2::ggplot(dfl, ggplot2::aes(x = tickers, y = Value, fill = Metric)) +
        ggplot2::geom_bar(stat = "identity", position = "dodge", color = col_text) +
        ggplot2::scale_fill_manual(values = palette_colors) +
        .gg_dark() +
        ggplot2::labs(
          title = paste0("Group Allocation (macro)", if (plot_active) " - Active" else ""),
          x = "Group", y = "Value", fill = NULL
        )

      ## these two lines were missing; without them the method falls through
      print(p)
      return(invisible(p))
    }


    ## =========================================================================================
    ## Hierarchical Clustering
    ## =========================================================================================
    if (type == "Hierarchical Clustering") {

      if (is.null(x@clusters) || !inherits(x@clusters, "hclust")) stop("clusters (hclust) required.")
      if (length(asset_names) == 0L || is.null(weights) || length(weights) != length(asset_names))
        stop("eligible_assets/weights required.")
      weights_df <- data.frame(assets = asset_names, weights = weights)

      if (is.null(tickers)){
        mode <- suppressWarnings(as.integer(readline(prompt = "\n1: Top x by |weight|  2: Pick names/indices\nChoice: ")))
        if (!mode %in% c(1L,2L)) stop("Invalid choice.")
        if (mode == 1L) {
          weights_df <- dplyr::arrange(weights_df, dplyr::desc(abs(.data$weights)))
          n_choice <- suppressWarnings(as.integer(readline(prompt = "How many? ")))
          if (is.na(n_choice) || n_choice < 2L) n_choice <- min(12L, nrow(weights_df))
          sel_assets <- weights_df$assets[seq_len(n_choice)]
        } else {
          sel_assets <- .select_from_vector(asset_names, "Pick assets")
          if (length(sel_assets) < 2L) stop("Need at least two assets.")
        }
      } else {
        sel_assets <- tickers
        if (length(sel_assets) < 2L) stop("Need at least two assets.")
      }

      C <- if (!is.null(corr_mat)) corr_mat else if (!is.null(cov_mat)) stats::cov2cor(cov_mat) else stop("Need correlation/covariance.")
      if (!all(sel_assets %in% rownames(C))) stop("Selected assets missing in matrix.")
      rho <- as.matrix(C[sel_assets, sel_assets, drop = FALSE])
      rho[is.na(rho)] <- 0
      d2 <- 0.5 * (1 - rho)
      d2[d2 < 0] <- 0
      diag(d2) <- 0
      hc_method <- if (!is.null(x@clusters$method)) x@clusters$method else "ward.D2"
      hc_sub <- stats::hclust(stats::as.dist(sqrt(d2)), method = hc_method)

      op <- graphics::par(no.readonly = TRUE)
      on.exit(graphics::par(op), add = TRUE)
      graphics::par(bg = col_background, col.axis = col_text, col.lab = col_text, col.main = col_text, col.sub = col_text, fg = col_text)
      graphics::plot(hc_sub, main = paste("Hierarchical Clustering:", if (port_name == "") "not_identified" else port_name),
                     xlab = "", sub = "", hang = -1, labels = hc_sub$labels)
      graphics::box(col = col_primary)
      if (is.null(top_n)){
        k_in <- suppressWarnings(as.integer(readline(prompt = "Highlight k clusters (0=skip): ")))
      } else {
        k_in <- top_n
      }
      if (!is.na(k_in) && k_in > 0L) stats::rect.hclust(hc_sub, k = k_in, border = col_secondary)
      return(invisible(hc_sub))
    }

    ## =========================================================================================
    ## Allocation Flow (Groups -> Assets)
    ## =========================================================================================
    if (type == "Allocation Flow (Groups -> Assets)") {

      gc <- .resolve_group_col()
      if (length(x@eligible_assets) == 0L || length(x@weights) == 0L) stop("eligible_assets/weights required.")
      if (is.null(U)) stop("universe data required.")
      ## use most recent date in universe for group mapping
      last_date <- max(U$dates)
      gmap <- groups_df[groups_df$dates == last_date, c("tickers", gc), drop = FALSE]
      final_df <- data.frame(tickers = x@eligible_assets, w = x@weights, stringsAsFactors = FALSE) |>
        dplyr::left_join(gmap, by = "tickers")
      if (any(is.na(final_df[[gc]]))) stop("Some assets lack group mapping.")

      macro_tbl <- final_df |>
        dplyr::group_by(.data[[gc]]) |>
        dplyr::summarize(group_w_signed = sum(.data$w), group_w_abs = sum(abs(.data$w)), .groups = "drop") |>
        dplyr::arrange(dplyr::desc(.data$group_w_abs))

      if (is.null(groups)){
        g_choice <- suppressWarnings(as.integer(readline(prompt = "Top how many groups (by |weight|)? ")))
        if (is.na(g_choice) || g_choice < 1L) g_choice <- min(nrow(macro_tbl), 10L)
        keep_groups <- macro_tbl[[gc]][seq_len(g_choice)]
      } else {
        group_names <- macro_tbl[[gc]]
        if (!all(groups %in% group_names)) stop("groups not all present in universe data.")
        keep_groups <- groups
      }

      if (is.null(top_n)){
        n_choice <- suppressWarnings(as.integer(readline(prompt = "Top how many assets per group (by |weight|)? ")))
      } else {
        n_choice <- top_n
      }

      if (is.na(n_choice) || n_choice < 1L) n_choice <- 8L

      final_df <- final_df |>
        dplyr::filter(.data[[gc]] %in% keep_groups) |>
        dplyr::group_by(.data[[gc]]) |>
        dplyr::slice_max(order_by = abs(.data$w), n = n_choice, with_ties = FALSE) |>
        dplyr::ungroup()

      macro_filt <- final_df |>
        dplyr::group_by(.data[[gc]]) |>
        dplyr::summarize(group_w_signed = sum(.data$w), group_w_abs = sum(abs(.data$w)), .groups = "drop")

      group_nodes <- data.frame(
        name = paste0("G:", macro_filt[[gc]]),
        label = macro_filt[[gc]],
        type = "group",
        size = macro_filt$group_w_signed,
        size_abs = macro_filt$group_w_abs,
        stringsAsFactors = FALSE
      )
      asset_nodes <- final_df |>
        dplyr::transmute(name = paste0("A:", tickers), label = tickers, type = "asset",
                         size = w, size_abs = abs(w), group = .data[[gc]]) |>
        dplyr::distinct()
      left_pad <- 0.08; right_pad <- 0.04
      group_nodes <- group_nodes[order(-group_nodes$size_abs), , drop = FALSE]
      group_nodes$x <- 0 + left_pad
      group_nodes$y <- cumsum(group_nodes$size_abs) - group_nodes$size_abs/2

      a_tbl <- asset_nodes |>
        dplyr::group_by(.data$group) |>
        dplyr::arrange(dplyr::desc(.data$size_abs), .by_group = TRUE) |>
        dplyr::mutate(
          y = {
            cs <- cumsum(size_abs) - size_abs/2
            g_idx <- match(paste0("G:", group), group_nodes$name)
            g_center <- group_nodes$y[g_idx]; g_half <- group_nodes$size_abs[g_idx]/2
            (g_center - g_half) + cs
          }
        ) |>
        dplyr::ungroup()
      a_tbl$x <- 1 - right_pad

      nodes <- dplyr::bind_rows(
        group_nodes[, c("name","label","type","size","size_abs")],
        a_tbl[, c("name","label","type","size","size_abs","group")]
      )
      nodes <- dplyr::left_join(nodes,
                                rbind(group_nodes[, c("name","x","y")], a_tbl[, c("name","x","y")]),
                                by = "name")
      edges <- data.frame(from = paste0("G:", final_df[[gc]]), to = paste0("A:", final_df$tickers),
                          weight = final_df$w, stringsAsFactors = FALSE)

      g <- igraph::graph_from_data_frame(edges, directed = TRUE, vertices = nodes)
      igraph::V(g)$x <- nodes$x[match(igraph::V(g)$name, nodes$name)]
      igraph::V(g)$y <- nodes$y[match(igraph::V(g)$name, nodes$name)]

      group_nodes_plot <- nodes[nodes$type == "group", , drop = FALSE]
      asset_nodes_plot <- nodes[nodes$type == "asset", , drop = FALSE]

      p <- ggraph::ggraph(g, layout = "manual", x = igraph::V(g)$x, y = igraph::V(g)$y) +
        ggraph::geom_edge_link(ggplot2::aes(edge_width = pmax(abs(weight), 1e-9),
                                            edge_alpha = pmax(abs(weight), 1e-9)),
                               colour = col_primary, lineend = "round") +
        ggraph::scale_edge_width(range = c(0.5, 6), guide = "none") +
        ggraph::scale_edge_alpha(range = c(0.35, 0.9), guide = "none") +
        ggraph::geom_node_point(data = group_nodes_plot, mapping = ggplot2::aes(x = x, y = y, size = pmax(abs(size), 1e-9)),
                                colour = col_positive) +
        ggraph::geom_node_point(data = asset_nodes_plot, mapping = ggplot2::aes(x = x, y = y, size = pmax(abs(size), 1e-9)),
                                colour = col_terciary) +
        ggplot2::scale_size_continuous(range = c(2, 10), guide = "none") +
        ggraph::geom_node_text(data = group_nodes_plot,
                               mapping = ggplot2::aes(x = x, y = y,
                                                      label = paste0(label, " (", scales::percent(size, accuracy = 0.1), ")")),
                               colour = col_text, fontface = 2, hjust = 1, nudge_x = -left_pad * 0.4) +
        ggraph::geom_node_text(data = asset_nodes_plot,
                               mapping = ggplot2::aes(x = x, y = y,
                                                      label = paste0(label, " (", scales::percent(size, accuracy = 0.1), ")")),
                               colour = col_text, size = 3, hjust = 0, nudge_x = right_pad * 0.4) +
        ggplot2::scale_x_continuous(limits = c(0 - left_pad, 1 + right_pad)) +
        ggplot2::coord_cartesian(clip = "off") +
        .gg_dark() +
        ggplot2::theme(axis.text = ggplot2::element_blank(), axis.title = ggplot2::element_blank(),
                       plot.margin = ggplot2::margin(12, 18, 12, 90)) +
        ggplot2::labs(title = paste("Allocation Flow (Groups \u2192 Assets):", if (port_name == "") "not_identified" else port_name))
      print(p); return(invisible(p))
    }

    ## =========================================================================================
    ## Within-Group Composition
    ## =========================================================================================
    if (type == "Within-Group Composition") {
      gc <- .resolve_group_col()

      df <- data.frame(tickers = x@eligible_assets, weight = x@weights, stringsAsFactors = FALSE) |>
        dplyr::left_join(groups_df[, c("tickers", gc)], by = "tickers")
      if (any(is.na(df[[gc]]))) stop("Missing group mapping.")

      if (!is.null(chosen_risk_metrics) && !is.null(chosen_weights)){
        stop ("Cannot specify both chosen_risk_metrics and chosen_weights. Please choose one or the other.")
      }

      if (!is.null(chosen_risk_metrics) || !is.null(chosen_weights)){
        if (!is.null(chosen_risk_metrics)){
          metric_choice <- 2
        } else {
          metric_choice <- 1
        }
      } else {
        metric_choice <- suppressWarnings(as.integer(readline(prompt = "\n1: Weight/Active Weight  2: Relative Risk Contribution\nChoice: ")))
      }
      if (!metric_choice %in% c(1L,2L)) stop("Invalid choice.")

      plot_title_suffix <- ""; y_lab <- "Final Weight"
      if (metric_choice == 1L) {
        if (!is.null(U) && "act_weights" %in% colnames(U)) {
          if (!is.null(chosen_weights)){
            #chosen_weights must be exactly one of weights or act_weights
            if (!chosen_weights %in% c("weights", "act_weights")) stop("Invalid chosen_weights specified.")
            if (grepl("act", chosen_weights)) ans <- "yes" else ans <- "no"
          } else {
            ans <- tolower(readline(prompt = "Use active weights? (y/n): "))
          }
          if (ans %in% c("y","yes")) {
            df <- dplyr::left_join(df, U[, c("tickers","act_weights")], by = "tickers")
            df$plot_value <- df$act_weights; y_lab <- "Active Weight"; plot_title_suffix <- " (Active)"
          } else { df$plot_value <- df$weight }
        } else {
          df$plot_value <- df$weight
        }
      } else {
        if (is.null(U)) stop("universe data required for RRC columns.")
        rrc_cols <- c("rel_risk_contr","act_rel_risk_contr")
        rrc_cols <- rrc_cols[rrc_cols %in% colnames(U)]
        if (!all(c("rel_risk_contr") %in% rrc_cols)) stop("RRC columns missing in universe data.")
        if (!is.null(chosen_risk_metrics)){
          #chosen_risk_metrics must be exactly one of rel_risk_contribution or act_rel_risk_contribution
          if (!chosen_risk_metrics %in% c("rel_risk_contr", "act_rel_risk_contr")) stop("Invalid chosen_risk_metrics specified.")
          if (grepl("act", chosen_risk_metrics)) {
            use_active_rrc <- "act_rel_risk_contr" %in% rrc_cols
            if (!use_active_rrc) stop("Chosen active RRC not found in universe data.")
          } else {
            use_active_rrc <- FALSE
          }
        } else {
          ans_act <- tolower(readline(prompt = "Use active RRC? (y/n): "))
          use_active_rrc <- ans_act %in% c("y","yes") && "act_rel_risk_contr" %in% rrc_cols
        }
        chosen_rrc <- if (use_active_rrc) "act_rel_risk_contr" else "rel_risk_contr"

        df <- dplyr::left_join(df, U[, c("tickers", chosen_rrc)], by = "tickers")
        names(df)[names(df) == chosen_rrc] <- "plot_value"
        y_lab <- if (use_active_rrc) "Active RRC" else "RRC"
        plot_title_suffix <- if (use_active_rrc) " (RRC Active)" else " (RRC)"
      }

      gsum <- df |>
        dplyr::group_by(.data[[gc]]) |>
        dplyr::summarize(group_value = sum(.data$plot_value), .groups = "drop") |>
        dplyr::arrange(dplyr::desc(.data$group_value))
      if (is.null(top_n)){
        g_choice <- suppressWarnings(as.integer(readline(prompt = "Top how many groups (by |value|)? ")))
      } else {
        g_choice <- top_n
      }
      if (is.na(g_choice) || g_choice < 1L || g_choice > nrow(gsum)) g_choice <- min(nrow(gsum), 9L)
      keep_groups <- gsum[[gc]][seq_len(g_choice)]
      if (is.null(top_n)){
        n_choice <- suppressWarnings(as.integer(readline(prompt = "Top how many assets per group (by |value|)? ")))
      } else {
        n_choice <- top_n
      }

      if (is.na(n_choice) || n_choice < 1L) n_choice <- 10L

      dfp <- df |>
        dplyr::filter(.data[[gc]] %in% keep_groups) |>
        dplyr::group_by(.data[[gc]]) |>
        dplyr::slice_max(order_by = abs(.data$plot_value), n = n_choice, with_ties = FALSE) |>
        dplyr::ungroup()

      p <- ggplot2::ggplot(dfp, ggplot2::aes(x = stats::reorder(tickers, -abs(.data$plot_value)),
                                             y = .data$plot_value,
                                             fill = .data$plot_value > 0)) +
        ggplot2::geom_bar(stat = "identity", color = col_text, size = 0.3) +
        ggplot2::scale_fill_manual(values = c("TRUE" = col_positive, "FALSE" = col_negative), guide = "none") +
        ggplot2::facet_wrap(stats::reformulate(gc), scales = "free_y") +
        ggplot2::coord_flip() +
        .gg_dark() +
        ggplot2::theme(strip.text = ggplot2::element_text(color = col_text)) +
        ggplot2::labs(title = paste0("Within-Group Composition", plot_title_suffix, ": ",
                                     if (x@port_name == "") "not_identified" else x@port_name),
                      x = "Asset (ordered by |value|)", y = y_lab)
      print(p); return(invisible(p))
    }

    ## =========================================================================================
    ## Group Risk Decomposition
    ## =========================================================================================
    if (type == "Group Risk Decomposition") {
      gc <- .resolve_group_col()
      if (is.null(U)) stop("universe data required.")
      cols <- c("rel_risk_contr", "act_rel_risk_contr")
      cols <- cols[cols %in% colnames(U)]
      if (length(cols) == 0) stop("No RRC columns in universe data.")
      if (is.null(chosen_risk_metrics)){
        pick <- .menu(cols, "Choose RRC column (portfolio or active)")
      } else {
        if (!chosen_risk_metrics %in% cols) stop("chosen_risk_metrics not found in universe data.")
        pick <- chosen_risk_metrics
      }
      df_rc <- data.frame(tickers = asset_names, stringsAsFactors = FALSE) |>
        dplyr::left_join(U[, c("tickers", pick)], by = "tickers") |>
        dplyr::left_join(groups_df[, c("tickers", gc)], by = "tickers")
      names(df_rc)[names(df_rc) == pick] <- "rrc"
      if (any(is.na(df_rc[[gc]]))) stop("Missing group mapping.")

      g_rc <- df_rc |>
        dplyr::group_by(.data[[gc]]) |>
        dplyr::summarize(group_rrc = sum(.data$rrc, na.rm = TRUE), .groups = "drop") |>
        dplyr::arrange(dplyr::desc(.data$group_rrc))
      if (is.null(top_n)){
        g_choice <- suppressWarnings(as.integer(readline(prompt = "Top how many groups to highlight? ")))
      } else {
        g_choice <- top_n
      }
      if (is.na(g_choice) || g_choice < 1L || g_choice > nrow(g_rc)) g_choice <- min(nrow(g_rc), 8L)
      keep_groups <- g_rc[[gc]][seq_len(g_choice)]

      pA <- ggplot2::ggplot(g_rc, ggplot2::aes(x = stats::reorder(.data[[gc]], .data$group_rrc), y = .data$group_rrc)) +
        ggplot2::geom_bar(stat = "identity", fill = col_primary, color = col_text) +
        ggplot2::coord_flip() +
        .gg_dark() +
        ggplot2::labs(title = "Groups Relative Risk Contribution", x = "Group", y = "RRC")

      df_rc_f <- df_rc |>
        dplyr::filter(.data[[gc]] %in% keep_groups) |>
        dplyr::group_by(.data[[gc]], .data$tickers) |>
        dplyr::summarize(rrc = sum(.data$rrc, na.rm = TRUE), .groups = "drop")

      if (is.null(top_n)){
          k_in <- suppressWarnings(as.integer(readline(prompt = "Top k per group (0 = all): ")))
        } else {
          k_in <- top_n
        }
        for (g in unique(df_rc_f[[gc]])) {
          sub <- df_rc_f[df_rc_f[[gc]] == g, , drop = FALSE]
          sub <- sub[order(-sub$rrc), ]
          if (!is.na(k_in) && k_in > 0L && k_in < nrow(sub)) sub <- sub[seq_len(k_in), ]
          cat("\n== Group:", g, "==\n")
          for (i in seq_len(nrow(sub))) cat(sprintf("%2d. %-15s  RRC: %.6f\n", i, sub$tickers[i], sub$rrc[i]))
        }
        cat("\n")


      pB <- ggplot2::ggplot(df_rc_f, ggplot2::aes(x = .data[[gc]], y = .data$rrc, fill = .data$tickers)) +
        ggplot2::geom_bar(stat = "identity", position = "fill", color = col_text, alpha = 0.6) +
        ggplot2::scale_y_continuous(labels = scales::percent) +
        .gg_dark() + ggplot2::theme(legend.position = "none") +
        ggplot2::labs(title = "Within-Group RRC (stacked to 100%)", x = "Group", y = "Share")

      gridExtra::grid.arrange(pA, pB, ncol = 2)
      return(invisible(list(macro_rrc = pA, micro_rrc = pB)))
    }

    ## =========================================================================================
    ## Port Stats
    ## =========================================================================================
    if (type == "Portfolio Stats") {
      if (is.null(x@port_stats) || !is.data.frame(x@port_stats) || nrow(x@port_stats) < 1L) {
        stop("port_stats not available.")
      }
      ps <- x@port_stats[1, , drop = FALSE]

      # helpers: prefer active; fall back to raw
      .pick_num <- function(df, prefs) {
        cand <- prefs[prefs %in% names(df)]
        if (length(cand) == 0L) return(NA_real_)
        val <- suppressWarnings(as.numeric(df[[cand[1L]]]))
        if (is.na(val)) NA_real_ else val
      }

      # A) basic metrics
      exp_ret    <- .pick_num(ps, c("act_exp_ret", "exp_ret"))
      risk       <- .pick_num(ps, c("act_risk", "risk"))
      ratio_val  <- .pick_num(ps, c("info_ratio", "sharpe", "sharpe_ratio"))
      ratio_lab  <- if ("info_ratio" %in% names(ps)) "Info Ratio" else "Sharpe"

      dfA <- data.frame(
        Metric = c("Expected Return", "Risk", ratio_lab),
        Value  = c(exp_ret, risk, ratio_val),
        stringsAsFactors = FALSE
      )
      pA <- ggplot2::ggplot(dfA, ggplot2::aes(x = Metric, y = Value, fill = Metric)) +
        ggplot2::geom_col(color = black, width = 0.7) +
        ggplot2::scale_fill_manual(values = palette_colors) +
        .gg_dark() +
        ggplot2::theme(legend.position = "none",
                       plot.title = ggplot2::element_text(color = white)) +
        ggplot2::labs(title = "Basic Metrics", x = NULL, y = NULL)

      # B) concentration via weights
      hhi_w   <- .pick_num(ps, c("act_hhi_weights", "hhi_weights"))
      dr_w    <- .pick_num(ps, c("act_diversification_ratio", "diversification_ratio"))
      corr_w  <- .pick_num(ps, c("act_wavg_pairwise_corr", "wavg_pairwise_corr"))
      gini_w  <- .pick_num(ps, c("act_gini_weights", "gini_weights"))
      top5    <- .pick_num(ps, c("act_top_5_concentration", "top_5_concentration"))
      top10   <- .pick_num(ps, c("act_top_10_concentration", "top_10_concentration"))
      top25   <- .pick_num(ps, c("act_top_25_concentration", "top_25_concentration"))

      dfB <- data.frame(
        Metric = c("HHI (weights)", "Diversification Ratio", "Avg Pairwise Corr", "Gini (weights)",
                   "Top 5", "Top 10", "Top 25"),
        Value  = c(hhi_w, dr_w, corr_w, gini_w, top5, top10, top25),
        stringsAsFactors = FALSE
      )
      pB <- ggplot2::ggplot(dfB, ggplot2::aes(x = Metric, y = Value, fill = Metric)) +
        ggplot2::geom_col(color = col_text, width = 0.7) +
        ggplot2::scale_fill_manual(values = palette_colors) +
        .gg_dark() +
        ggplot2::theme(legend.position = "none",
                       plot.title = ggplot2::element_text(color = col_text)) +
        ggplot2::labs(title = "Concentration - Weights", x = NULL, y = NULL)


      # C) concentration via RRC
      hhi_rrc  <- .pick_num(ps, c("act_hhi_rrc", "hhi_rrc"))
      neff_rrc <- .pick_num(ps, c("act_n_eff_rrc", "n_eff_rrc"))
      dist_erc <- .pick_num(ps, c("act_rrc_dist_to_erc", "rrc_dist_to_erc"))

      dfC <- data.frame(
        Metric = c("HHI (RRC)", "N_eff (RRC)", "Dist. to ERC"),
        Value  = c(hhi_rrc, neff_rrc, dist_erc),
        stringsAsFactors = FALSE
      )
      pC <- ggplot2::ggplot(dfC, ggplot2::aes(x = Metric, y = Value, fill = Metric)) +
        ggplot2::geom_col(color = col_text, width = 0.7) +
        ggplot2::scale_fill_manual(values = palette_colors) +
        .gg_dark() +
        ggplot2::theme(legend.position = "none",
                       plot.title = ggplot2::element_text(color = col_text)) +
        ggplot2::labs(title = "Concentration - RRC", x = NULL, y = NULL)

      # D) group-level metrics
      g_exp_ret <- .pick_num(ps, c("act_group_exp_ret", "group_exp_ret"))
      g_risk    <- .pick_num(ps, c("act_group_risk", "group_risk"))
      g_ir      <- .pick_num(ps, c("group_info_ratio", "group_sharpe", "group_sharpe_ratio"))
      g_hhi_w   <- .pick_num(ps, c("act_group_hhi_weights", "group_hhi_weights"))
      g_dr_w    <- .pick_num(ps, c("act_group_diversification_ratio", "group_diversification_ratio"))
      g_corr_w  <- .pick_num(ps, c("act_group_wavg_pairwise_corr", "group_wavg_pairwise_corr"))
      g_gini_w  <- .pick_num(ps, c("act_group_gini_weights", "group_gini_weights"))

      dfD <- data.frame(
        Metric = c("Group ExpRet", "Group Risk",
                   if ("group_info_ratio" %in% names(ps)) "Group IR" else "Group Sharpe",
                   "Group HHI (weights)", "Group Diversification Ratio",
                   "Group Avg Pairwise Corr", "Group Gini (weights)"),
        Value  = c(g_exp_ret, g_risk, g_ir, g_hhi_w, g_dr_w, g_corr_w, g_gini_w),
        stringsAsFactors = FALSE
      )
      pD <- ggplot2::ggplot(dfD, ggplot2::aes(x = Metric, y = Value, fill = Metric)) +
        ggplot2::geom_col(color = black, width = 0.7) +
        ggplot2::scale_fill_manual(values = palette_colors) +
        .gg_dark() +
        ggplot2::theme(legend.position = "none",
                       plot.title = ggplot2::element_text(color = col_text)) +
        ggplot2::labs(title = "Group Metrics", x = NULL, y = NULL)


      # grid: use gridExtra if available; else print sequentially
      if (requireNamespace("gridExtra", quietly = TRUE)) {
        gridExtra::grid.arrange(pA, pB, pC, pD, ncol = 2)
        return(invisible(NULL))
      } else {
        warning("Install 'gridExtra' to show a 2x2 grid. Printing sequentially.")
        print(pA); print(pB); print(pC); print(pD)
        return(invisible(NULL))
      }
    }



    ## =========================================================================================
    ## Universe Data
    ## =========================================================================================
    if (type == "Universe Data") {
      if (!methods::is(x@universe_m_d_ref, "meta_dataframe")) stop("universe_m_d_ref is not meta_dataframe.")
      plot(x@universe_m_d_ref, ..., palette = palette)
      return(invisible(TRUE))
    }

    stop(paste("Plot type", type, "not recognized."))
  }
)



#' @title Plot Method for port_backtest_results Class
#' @description Generates various plots to visualize metrics from the `port_backtest_results` object.
#' Users can select which plot to display by specifying the `plot_id` parameter.
#'
#' @param x An object of class `port_backtest_results`.
#' @param plot_id A character string (plot name) or numeric index specifying which plot to display; if `NULL`, an
#' interactive menu is shown. One of \code{"Time-Series Weights by Tickers"}, \code{"Time-Series Weights by Stock Group"},
#' \code{"Cross-Sectional Weights Statistic by Tickers"}, \code{"Cross-Sectional Weights Statistic by Stock Group"},
#' \code{"Tile Heatmap of Weights by Tickers"}, \code{"Tile Heatmap of Weights by Stock Group"},
#' \code{"Time-Series of Groups Composition"}, \code{"Time-Series of Expected Return Score by Tickers"},
#' \code{"Time-Series of Expected Return Score by Stock Group"}, \code{"Time-Series of Expected Return Score by Eligibility"},
#' \code{"Box-plot of Expected Return Score by Stock Group"}, \code{"Box-plot of Expected Return Score by Eligibility"},
#' \code{"Plot Subjacent Final Port"}, \code{"Time-Series of Port Returns"}, \code{"Cross-Sectional Performance Metric Plot"},
#' \code{"Time-Series of Transaction Costs"}, \code{"Time-Series of Port Metrics"}, or \code{"Port Stats"}.
#' @param vertical_lines Optional. A vector of `Date` objects indicating vertical lines to display in time-series plots (e.g., rebalance dates). If `NULL`, the user will be prompted.
#' @param palette A character string specifying the color palette to use for the plots. Only \code{"cyberpunk"} (default) and \code{"br"} are supported; any other value leaves the plot colors undefined and raises an error.
#' @param group_col Optional. A character string specifying the column name in the backtest results to use for grouping in certain plots. If `NULL`, the user will be prompted to select from available columns.
#' @param facet_by_year Logical. If `TRUE`, time-series plots will be faceted by year. Default is `FALSE`.
#' @return Invisibly returns the input object.
#' @export
setMethod("plot", "port_backtest_results", function(x, plot_id = NULL, vertical_lines = NULL, palette = "cyberpunk", group_col = NULL, facet_by_year = NULL) {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  if (palette == "cyberpunk") {

    light_gray <- "#003641"

    col_background <- "#001f3f"
    col_text       <- "#FFFFFF"
    col_primary    <- "#00FFFF"
    col_secondary <- "#FF69B4"      # Hot Pink
    col_terciary <-  "#FF1493" # Lime Green
    col_quarternary <-  "#FFA500"
    col_quinternary <- "#FF4500"
    col_sextenary <- "#32CD32"
    col_positive   <- "#39FF14"
    col_negative   <- "#FF1493"
    vertical_line_color <- "#FF69B4"
    cyan <- "#00FFFF"

    palette_colors  <- c(
      "#00BFFF", "#FF1493", "#FFFF00",  "#00FFFF", "#8A2BE2",
      "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500"
    )

  }
  if (palette == "br") {

    light_gray <- "#EBEEF1"

    col_background <- "#FFFFFF"
    col_text       <- "#003641"
    col_primary   <- "#00A091"
    col_secondary  <- "#4C7C83"
    col_terciary   <- "#49479D"
    col_quarternary <- "#39FF14"
    col_quinternary <- "#003641"
    col_sextenary  <- "#D6E266"
    col_positive   <- "#7DB61C"
    col_negative   <- "#C2185B"
    vertical_line_color <- "#003641"
    cyan <- "#94E1D6"

    palette_colors  <- c(
      "#94E1D6", "#49479D", "#FF5F1F",
      "#7DB61C", "#98B2B6", "#8A03C9",
      "#00C9B8", "#C9D200", "#C2185B",
      "#00FFFF", "#003641", "#00A091",
      "#4C7C83", "#FF5F1F", "#EBEEA8",
      "#A5CD5C", "#00AE9D",
      "#EBEEA8", "#D6E266", "#00C9B8",
      "#7DB61C", "#A5CD5C", "#003641",
      "#00A091", "#4C7C83"
    )

  }
  if (palette == "journal") {

    jp <- .journal_palette()

    light_gray <- jp$grid

    col_background <- jp$background
    col_text       <- jp$text
    col_primary    <- jp$primary
    col_secondary  <- jp$categorical[3]
    col_terciary   <- jp$categorical[6]
    col_quarternary <- jp$positive
    col_quinternary <- jp$sequential[7]
    col_sextenary  <- jp$categorical[4]
    col_positive   <- jp$positive
    col_negative   <- jp$negative
    vertical_line_color <- jp$text
    cyan <- jp$sequential[3]

    ### Recycle the eight journal hues to match the br palette length
    palette_colors <- rep(jp$categorical, length.out = 25)

  }

  # List of available plots
  available_plots <- c(
    "Time-Series Weights by Tickers",
    "Time-Series Weights by Stock Group",
    "Cross-Sectional Weights Statistic by Tickers",
    "Cross-Sectional Weights Statistic by Stock Group",
    "Tile Heatmap of Weights by Tickers",
    "Tile Heatmap of Weights by Stock Group",
    "Time-Series of Groups Composition",
    "Time-Series of Expected Return Score by Tickers",
    "Time-Series of Expected Return Score by Stock Group",
    "Time-Series of Expected Return Score by Eligibility",
    "Box-plot of Expected Return Score by Stock Group",
    "Box-plot of Expected Return Score by Eligibility",
    "Plot Subjacent Final Port",
    "Time-Series of Port Returns",
    "Cross-Sectional Performance Metric Plot",
    "Time-Series of Transaction Costs",
    "Time-Series of Port Metrics",
    "Port Stats"
  )

  # SLSAF portfolios carry a dimension no other method has, the split of the universe
  # into a long block that may be bought and a short block that may only be
  # underweighted. Almost every question worth asking of such a portfolio is a contrast
  # between those two blocks, so those plots are appended only when the method is in use.
  is_slsaf <- identical(x@port_construction_method, "slsaf")

  if (isTRUE(is_slsaf)) {
    available_plots <- c(
      available_plots,
      "SLSAF Weight Decomposition",
      "SLSAF Benchmark Coverage by Leg",
      "SLSAF Expected Return Score by Leg",
      "SLSAF Expected Return Score Distribution by Leg",
      "SLSAF Tracking Error Contribution by Leg",
      "SLSAF Sector Composition by Leg",
      "SLSAF Capitalization Profile by Leg",
      "SLSAF Underweight Intensity Profile",
      "SLSAF Budget and Grading"
    )
  }


  if (is.null(plot_id)) {
    cat("\nPlease choose a plot to display:\n")
    for (i in seq_along(available_plots)) {
      cat(paste0(i, ": ", available_plots[i], "\n"))
    }
    selection <- readline(prompt = "Enter the number of your choice: ")
    plot_id <- as.numeric(selection)
    if (is.na(plot_id) || plot_id < 1 || plot_id > length(available_plots)) {
      stop("Invalid selection.")
    }
  }

  # Determine plot name from the selection
  if (is.numeric(plot_id)) {
    if (plot_id >= 1 && plot_id <= length(available_plots)) {
      plot_name <- available_plots[plot_id]
    } else {
      stop("Invalid plot number. Please select a valid plot.")
    }
  } else if (is.character(plot_id)) {
    if (plot_id %in% available_plots) {
      plot_name <- plot_id
    } else {
      stop("Invalid 'plot_id' specified. Available options are:\n",
           paste(available_plots, collapse = ", "))
    }
  } else {
    stop("'plot_id' must be either a string or a number corresponding to the plot.")
  }

  # Define the data sources
  port_weights_m_df <- x@port_weights_m_df
  stock_universe_m_df <- x@stock_universe_m_df
  final_stock_universe_m_d_ref <- x@final_stock_universe_m_d_ref
  port_returns_m_xts <- x@port_returns_m_xts
  port_costs_m_xts <- x@port_costs_m_xts
  port_metrics_m_xts <- x@port_metrics_m_xts
  final_stock_port <- x@final_stock_port
  port_stats_m_df <- x@port_stats_m_df

  #Select Group if plot_name contains "Group"
  if (grepl("Group", plot_name)) {

    # Get character columns, excluding the first three columns
    char_cols <- names(which(sapply(stock_universe_m_df@data[,-c(1:3)], is.character)))

    #Stop if char_cols is empty
    if (length(char_cols) == 0) {
      stop("No character columns found in the stock universe data.")
    }

    if (is.null(group_col)){
      # Display available columns with numbers
      cat(crayon::white("\nPlease choose a column to consider as group:\n"))
      for (i in seq_along(char_cols)) {
        cat(crayon::white(paste0(i, ": ", char_cols[i], "\n")))
      }

      # Prompt user input
      selection <- readline(prompt = crayon::white("Enter the column name or number: "))

      # Check if the input is numeric (choosing by index) or a name
      if (nzchar(selection)) {
        if (grepl("^[0-9]+$", selection)) {  # If input is numeric
          selection <- as.numeric(selection)
          if (selection < 1 || selection > length(char_cols)) {
            stop("Invalid selection. Please enter a valid number from the list.")
          }
          group_col <- char_cols[selection]
        } else {  # If input is a column name
          if (!(selection %in% char_cols)) {
            stop("Invalid selection. Please enter a valid column name from the list.")
          }
          group_col <- selection
        }
      } else {
        stop("No input provided. Please enter a valid selection.")
      }
    }


    #Check if the column is in the dataframe
    if (!(group_col %in% names(stock_universe_m_df@data))){
      stop("The column entered is not available in the stock universe.")
    }

  }


  # Plot 1: Time-Series Metrics by Ticker
  if (plot_name == "Time-Series Weights by Tickers") {

    plot_type <- "time_series"
    clustering_variables <- "tickers"
    calc_stat <- "mean"

    plot(port_weights_m_df, type = plot_type, calc_stat = calc_stat, clustering_variables = clustering_variables, palette = palette)


  } else if (plot_name == "Time-Series Weights by Stock Group") {

    plot_type <- "time_series"
    clustering_variables <- group_col
    variable <- "weights"

    plot(stock_universe_m_df, type = plot_type, variable = variable, clustering_variables = clustering_variables, palette = palette)


  } else if (plot_name == "Cross-Sectional Weights Statistic by Tickers"){

    plot_type <- "cross_sectional"
    clustering_variables <- "tickers"

    plot(port_weights_m_df, type = plot_type, clustering_variables = clustering_variables, palette = palette)


  } else if (plot_name == "Cross-Sectional Weights Statistic by Stock Group"){

    plot_type <- "cross_sectional"
    clustering_variables <- group_col
    variable <- "weights"

    plot(stock_universe_m_df, type = plot_type, clustering_variables = clustering_variables, variable = variable, palette = palette)



  } else if (plot_name == "Tile Heatmap of Weights by Tickers"){

    plot_type <- "tile_heatmap"
    clustering_variables <- "tickers"

    plot(port_weights_m_df, type = plot_type, clustering_variables = clustering_variables, palette = palette)

  } else if (plot_name == "Tile Heatmap of Weights by Stock Group"){

    plot_type <- "tile_heatmap"
    clustering_variables <- group_col
    variable <- "weights"

    plot(stock_universe_m_df, type = plot_type, clustering_variables = clustering_variables, variable = variable, palette = palette)

  } else if (plot_name == "Time-Series of Groups Composition"){

    plot_type <- "composition"

    plot(stock_universe_m_df, type = plot_type, variable = group_col, palette = palette)


  } else if (plot_name == "Time-Series of Expected Return Score by Tickers"){

    plot_type <- "time_series"
    clustering_variables <- "tickers"
    variable <- "exp_ret_score"
    calc_stat <- "mean"

    plot(stock_universe_m_df, type = plot_type, clustering_variables = clustering_variables, variable = variable, calc_stat = calc_stat, palette = palette)


  } else if (plot_name == "Time-Series of Expected Return Score by Stock Group"){

    plot_type <- "time_series"
    clustering_variables <- group_col
    variable <- "exp_ret_score"
    calc_stat <- "mean"

    plot(stock_universe_m_df, type = plot_type, clustering_variables = clustering_variables, variable = variable, calc_stat = calc_stat, palette = palette)

  } else if (plot_name == "Time-Series of Expected Return Score by Eligibility"){

    stock_universe_m_df@data$eligibility <- ifelse(stock_universe_m_df@data$is_eligible == 1, "elected", "not_elected")

    plot_type <- "time_series"
    clustering_variables <- "eligibility"
    variable <- "exp_ret_score"
    calc_stat <- "mean"

    plot(stock_universe_m_df, type = plot_type, clustering_variables = clustering_variables, variable = variable, calc_stat = calc_stat, palette = palette)


  } else if (plot_name == "Box-plot of Expected Return Score by Stock Group"){

    plot_type <- "boxplot"
    clustering_variables <- group_col
    variable <- "exp_ret_score"
    calc_stat <- "mean"

    plot(stock_universe_m_df, type = plot_type, clustering_variables = clustering_variables, variable = variable, calc_stat = calc_stat, palette = palette)


  } else if (plot_name == "Box-plot of Expected Return Score by Eligibility"){

    stock_universe_m_df@data$eligibility <- ifelse(stock_universe_m_df@data$is_eligible == 1, "elected", "not_elected")

    plot_type <- "boxplot"
    clustering_variables <- "eligibility"
    variable <- "exp_ret_score"
    calc_stat <- "mean"

    plot(stock_universe_m_df, type = plot_type, clustering_variables = clustering_variables, variable = variable, calc_stat = calc_stat, palette = palette)


  } else if (plot_name == "Plot Subjacent Final Port"){

    plot(final_stock_port, palette = palette)


  } else if (plot_name == "Time-Series of Port Returns"){

    plot_perf_metric = FALSE
    if("selected_bench_return" %in% colnames(port_returns_m_xts@data)){
      bench_returns_m_xts <- port_returns_m_xts
      bench_returns_m_xts@data <- bench_returns_m_xts@data[, "selected_bench_return"]
    } else {
      bench_returns_m_xts <- NULL
    }

    port_returns_m_xts <- port_returns_m_xts
    port_returns_m_xts@data <- port_returns_m_xts@data[, c("raw_return", "net_return", "raw_active_return", "net_active_return")]

    #Add first date
    first_return_date <- zoo::index(port_returns_m_xts@data)[1]
    ##Port Returns
    port_returns_m_xts@data <- rbind(
      xts::xts(data.frame(raw_return = 0, net_return = 0, raw_active_return = 0, net_active_return = 0),
               order.by = lubridate::add_with_rollback(first_return_date, months(-1))), #Add a first row with 0 values
      port_returns_m_xts@data
    )
    ##Bench Returns
    if(!is.null(bench_returns_m_xts)){
      bench_returns_m_xts@data <- rbind(
        xts::xts(data.frame(selected_bench_return = 0),
                 order.by = lubridate::add_with_rollback(first_return_date, months(-1))), #Add a first row with 0 values
        bench_returns_m_xts@data
      )
    }

    #Prompt the user if he wants to plot rebalance dates
    if (is.null(vertical_lines) && plot_name != "Plot Subjacent Final Port"){
      rebalance_dates <- readline(prompt = "Do you want to plot rebalance dates? (yes/no): ")
      if (rebalance_dates %in% c("y", "yes")) {
        vertical_lines <- as.Date(x@port_backtest_workflow[[length(x@port_backtest_workflow)]]$rebalance_dates)
      }
    }

    #Promp the user if he wants to facet by year
    if (is.null(facet_by_year)){
      facet_by_year <- readline(prompt = "Do you want to facet by year? (yes/no): ")
      if (facet_by_year %in% c("y", "yes")) {
        facet_by_year <- TRUE
      } else {
        facet_by_year <- FALSE
      }
    }


    plot(port_returns_m_xts, benchmark_returns_m_xts = bench_returns_m_xts, cumulative = TRUE, plot_perf_metric = plot_perf_metric,
         vertical_lines = vertical_lines, palette = palette, facet_by_year = facet_by_year)

  } else if (plot_name == "Cross-Sectional Performance Metric Plot"){

    plot_perf_metric = TRUE
    if("selected_bench_return" %in% colnames(port_returns_m_xts@data)){
      bench_returns_m_xts <- port_returns_m_xts
      bench_returns_m_xts@data <- bench_returns_m_xts@data[, "selected_bench_return"]
    } else {
      bench_returns_m_xts <- NULL
    }

    port_returns_m_xts <- port_returns_m_xts
    port_returns_m_xts@data <- port_returns_m_xts@data[, c("raw_return", "net_return", "raw_active_return", "net_active_return")]

    #Promp the user if he wants to facet by year
    if (is.null(facet_by_year)){
      facet_by_year <- readline(prompt = "Do you want to facet by year? (yes/no): ")
      if (facet_by_year %in% c("y", "yes")) {
        facet_by_year <- TRUE
      } else {
        facet_by_year <- FALSE
      }
    }

    plot(port_returns_m_xts,  benchmark_returns_m_xts = bench_returns_m_xts, plot_perf_metric = plot_perf_metric, palette = palette, facet_by_year = facet_by_year)

  } else if (plot_name == "Time-Series of Transaction Costs"){

    #Prompt the user if he wants to plot rebalance dates
    if (is.null(vertical_lines) && plot_name != "Plot Subjacent Final Port"){
      rebalance_dates <- readline(prompt = "Do you want to plot rebalance dates? (yes/no): ")
      if (rebalance_dates %in% c("y", "yes")) {
        vertical_lines <- as.Date(x@port_backtest_workflow[[length(x@port_backtest_workflow)]]$rebalance_dates)
      }
    }

    plot(port_costs_m_xts, vertical_lines = vertical_lines, palette = palette)

  } else if (plot_name == "Time-Series of Port Metrics"){

    #Prompt the user if he wants to plot rebalance dates
    if (is.null(vertical_lines) && plot_name != "Plot Subjacent Final Port"){
      rebalance_dates <- readline(prompt = "Do you want to plot rebalance dates? (yes/no): ")
      if (rebalance_dates %in% c("y", "yes")) {
        vertical_lines <- as.Date(x@port_backtest_workflow[[length(x@port_backtest_workflow)]]$rebalance_dates)
      }
    }

    if (!is.null(port_metrics_m_xts)){
      plot(port_metrics_m_xts, vertical_lines = vertical_lines, palette = palette)
    } else {
      stop("No port_metrics available to plot.")
    }

  } else if (plot_name == "Port Stats"){
    if (!is.null(port_stats_m_df)){
      plot(port_stats_m_df, palette = palette)
    } else {
      stop("No port_stats available to plot.")
    }

  } else if (grepl("^SLSAF ", plot_name)){

    # SLSAF leg contrasts------------------------------------------------------

      ## Everything below is rendered by the ordinary meta_dataframe plot methods over
      ## purpose-built frames, so no bespoke plotting logic is introduced. The frames
      ## are keyed by leg, by budget component or by asset, depending on the question.
      slsaf_benchmark <- x@port_backtest_config@selected_benchmark

      if (is.null(slsaf_benchmark)){
        stop("SLSAF plots require the backtest to carry a selected_benchmark.")
      }

      slsaf_plot_objects <- build_slsaf_plot_m_dfs(
        stock_universe_m_df = stock_universe_m_df,
        selected_benchmark = slsaf_benchmark,
        group_col = if (exists("group_col")) group_col else NULL
      )

    if (plot_name == "SLSAF Weight Decomposition"){

      ## Where every unit of portfolio weight comes from. The three components sum to
      ## 1: the index positions the short leg kept, the index positions the long leg
      ## already held, and the active weight the long leg received on top.
      plot(slsaf_plot_objects$budget, type = "time_series", clustering_variables = "tickers",
           variable = "weight", calc_stat = "sum", palette = palette)

    } else if (plot_name == "SLSAF Benchmark Coverage by Leg"){

      ## How much of the index the eligibility cascade is willing to buy, against how
      ## much it will only ever underweight. This is the single number that governs how
      ## much active budget the method can release.
      plot(slsaf_plot_objects$coverage, type = "time_series", clustering_variables = "tickers",
           variable = "bench_mass", calc_stat = "sum", palette = palette)

    } else if (plot_name == "SLSAF Expected Return Score by Leg"){

      ## The sanity check that matters most: the names being sold should score worse
      ## than the names being bought. Weighted by the active exposure actually taken,
      ## so it answers "what am I buying against what am I selling" rather than "what
      ## sits in each block". An eligibility rule other than the score, most often a
      ## strict liquidity floor, can invert this.
      plot(slsaf_plot_objects$leg_score, type = "time_series", clustering_variables = "tickers",
           variable = "wmean_exp_ret_score", calc_stat = "mean", palette = palette)

    } else if (plot_name == "SLSAF Expected Return Score Distribution by Leg"){

      ## The same comparison as a distribution rather than a mean, which shows overlap
      ## between the blocks that a mean would hide
      plot(slsaf_plot_objects$universe_with_leg, type = "boxplot",
           clustering_variables = "leg", variable = "exp_ret_score",
           calc_stat = "mean", palette = palette)

    } else if (plot_name == "SLSAF Tracking Error Contribution by Leg"){

      ## Which leg actually drives active risk. Read against the leg's share of gross
      ## active weight: a leg carrying far more risk than weight is the one to examine.
      if (all(is.na(slsaf_plot_objects$diagnostics$leg_summary$rrc_share))){
        stop(paste0("No active risk contributions available: this backtest ran without a ",
                    "covariance matrix, so tracking error cannot be attributed. Supply ",
                    "daily_stock_returns_m_xts to enable this plot."))
      }

      plot(slsaf_plot_objects$leg_risk, type = "time_series", clustering_variables = "tickers",
           variable = "rrc_share", calc_stat = "sum", palette = palette)

    } else if (plot_name == "SLSAF Sector Composition by Leg"){

      ## Sector composition within each block, so a structural sector bet created by the
      ## eligibility split rather than by conviction becomes visible
      slsaf_group_col <- if (!is.null(group_col)) group_col else "sectors"

      if (!slsaf_group_col %in% names(slsaf_plot_objects$universe_with_leg@data)){
        stop("No sector column available in the stock universe for this plot.")
      }

      plot(slsaf_plot_objects$universe_with_leg, type = "composition",
           variable = slsaf_group_col, custom_filter = "leg",
           filter_values = c("Long leg", "Short leg"), palette = palette)

    } else if (plot_name == "SLSAF Capitalization Profile by Leg"){

      ## Whether underweights are concentrating in small caps, which is the expected
      ## degradation mode: small index positions are the ones the cap sells in full
      if (!"liquidity_classification" %in% names(slsaf_plot_objects$universe_with_leg@data)){
        stop(paste0("No liquidity_classification column available: supply a ",
                    "liquidity_constraint_policy to enable this plot."))
      }

      plot(slsaf_plot_objects$universe_with_leg, type = "composition",
           variable = "liquidity_classification", custom_filter = "leg",
           filter_values = c("Long leg", "Short leg"), palette = palette)

    } else if (plot_name == "SLSAF Underweight Intensity Profile"){

      ## Per constituent, how much of its index position was given up against how bad
      ## the signal said it was. This is where the two exponents and the cap become
      ## directly visible: a flat cloud at 1 means the cap is dominating and the
      ## grading the method exists to produce has collapsed.
      plot(slsaf_plot_objects$underweight, type = "regression",
           variable = "badness", dep_y = "relative_trim", palette = palette)

    } else if (plot_name == "SLSAF Budget and Grading"){

      ## The budget available against the budget actually realized. The gap between the
      ## two lines is the whole point of the plot: it is the capping loss, what the
      ## grading gives up by refusing to sell more of a constituent than the benchmark
      ## actually holds. The count of fully sold names is deliberately not drawn here,
      ## because a count on a weight axis would need a second scale, and the underweight
      ## intensity profile already shows where the cap binds.
      if (is.null(port_stats_m_df)){
        stop("No port_stats available to plot.")
      }

      budget_cols <- c("slsaf_short_budget", "slsaf_active_budget")
      if (!all(budget_cols %in% colnames(port_stats_m_df@data))){
        stop("port_stats does not carry the slsaf budget diagnostics.")
      }

      ### Two series in long form, keyed by the series name, which is how every other
      ### multi-series plot in this file is assembled
      slsaf_stats_m_df <- port_stats_m_df
      slsaf_stats_m_df@data <- port_stats_m_df@data %>%
        dplyr::select(dplyr::all_of(c("dates", budget_cols))) %>%
        tidyr::pivot_longer(cols = dplyr::all_of(budget_cols),
                            names_to = "tickers", values_to = "budget") %>%
        dplyr::mutate(
          tickers = dplyr::recode(tickers,
                                  slsaf_short_budget  = "Budget available",
                                  slsaf_active_budget = "Budget realized"),
          dates   = as.Date(dates),
          id      = paste0(tickers, "-", dates)
        ) %>%
        dplyr::relocate(id, tickers, dates) %>%
        dplyr::arrange(id) %>%
        as.data.frame()

      plot(slsaf_stats_m_df, type = "time_series", clustering_variables = "tickers",
           variable = "budget", calc_stat = "mean", palette = palette)

    }

  } else {
    stop("The plot name provided is not valid. Please choose one of the following: ", paste(available_plots, collapse = ", "))
  }

})


#' @title Plot Method for port_backtest_cohort Class
#' @description Generates various plots to visualize metrics from a \code{port_backtest_cohort} object.
#' Users can select which plot to display by specifying the \code{plot_id} parameter.
#'
#' @param x An object of class \code{port_backtest_cohort}.
#' @param plot_id A character string (plot name) or numeric index specifying which plot to display; if `NULL`, an
#' interactive menu is shown. One of \code{"Time-Series of Raw Returns"}, \code{"Time-Series of Net Returns"},
#' \code{"Time-Series of Raw Active Returns"}, \code{"Time-Series of Net Active Returns"},
#' \code{"Cross-Sectional Raw Performance Metric Plot"}, \code{"Cross-Sectional Net Performance Metric Plot"},
#' \code{"Cross-Sectional Raw Active Performance Metric Plot"}, \code{"Cross-Sectional Net Active Performance Metric Plot"},
#' \code{"Time-Series of Direct Costs"}, \code{"Time-Series of Market Impact Costs"}, \code{"Time-Series of Total Costs"},
#' \code{"Time-Series of Turnover"}, \code{"Time-Series of Port Metrics"}, \code{"Time-Series of Port Stats"},
#' \code{"Weights Correlogram"}, or \code{"Weights Radar"}.
#' @param vertical_lines Optional. A named list or vector specifying vertical lines to add to time-series plots. Used for highlighting events.
#' @param palette A character string specifying the color palette to use for the plots. Only \code{"cyberpunk"} (default) and \code{"br"} are supported; any other value leaves the plot colors undefined and raises an error.
#' @param selected_metric Optional. A character string specifying a particular performance metric to focus on in the plots. If `NULL`, all available metrics will be plotted.
#' @return Invisibly returns the input object.
#' @export
setMethod("plot", "port_backtest_cohort", function(x, plot_id = NULL, vertical_lines = NULL, palette = "cyberpunk", selected_metric = NULL) {

  # Check for required packages for plotting
  required_plot_pkgs <- c("gridExtra", "scales", "ggdist", "ggraph", "ggrepel", "igraph", "RColorBrewer")

  missing_pkgs <- required_plot_pkgs[!vapply(required_plot_pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]

  if (length(missing_pkgs) > 0) {
    stop(
      sprintf(
        "The following packages are required to generate plots but are not installed: %s.\nPlease install them using install.packages().",
        paste(missing_pkgs, collapse = ", ")
      ),
      call. = FALSE
    )
  }

  if (palette == "cyberpunk") {

    light_gray <- "#003641"

    col_background <- "#001f3f"
    col_text       <- "#FFFFFF"
    col_primary    <- "#00FFFF"
    col_secondary <- "#FF69B4"      # Hot Pink
    col_terciary <-  "#FF1493" # Lime Green
    col_quarternary <-  "#FFA500"
    col_quinternary <- "#FF4500"
    col_sextenary <- "#32CD32"
    col_positive   <- "#39FF14"
    col_negative   <- "#FF1493"
    vertical_line_color <- "#FF69B4"
    cyan <- "#00FFFF"

    palette_colors  <- c(
      "#00BFFF", "#FF1493", "#FFFF00",  "#00FFFF", "#8A2BE2",
      "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500"
    )

  }
  if (palette == "br") {

    light_gray <- "#EBEEF1"

    col_background <- "#FFFFFF"
    col_text       <- "#003641"
    col_primary   <- "#00A091"
    col_secondary  <- "#4C7C83"
    col_terciary   <- "#49479D"
    col_quarternary <- "#39FF14"
    col_quinternary <- "#003641"
    col_sextenary  <- "#D6E266"
    col_positive   <- "#7DB61C"
    col_negative   <- "#C2185B"
    vertical_line_color <- "#003641"
    cyan <- "#94E1D6"

    palette_colors  <- c(
      "#94E1D6", "#49479D", "#FF5F1F",
      "#7DB61C", "#98B2B6", "#8A03C9",
      "#00C9B8", "#C9D200", "#C2185B",
      "#00FFFF", "#003641", "#00A091",
      "#4C7C83", "#FF5F1F", "#EBEEA8",
      "#A5CD5C", "#00AE9D",
      "#EBEEA8", "#D6E266", "#00C9B8",
      "#7DB61C", "#A5CD5C", "#003641",
      "#00A091", "#4C7C83"
    )

  }
  if (palette == "journal") {

    jp <- .journal_palette()

    light_gray <- jp$grid

    col_background <- jp$background
    col_text       <- jp$text
    col_primary    <- jp$primary
    col_secondary  <- jp$categorical[3]
    col_terciary   <- jp$categorical[6]
    col_quarternary <- jp$positive
    col_quinternary <- jp$sequential[7]
    col_sextenary  <- jp$categorical[4]
    col_positive   <- jp$positive
    col_negative   <- jp$negative
    vertical_line_color <- jp$text
    cyan <- jp$sequential[3]

    ### Recycle the eight journal hues to match the br palette length
    palette_colors <- rep(jp$categorical, length.out = 25)

  }

  # List of available plots
  available_plots <- c(
    "Time-Series of Raw Returns",
    "Time-Series of Net Returns",
    "Time-Series of Raw Active Returns",
    "Time-Series of Net Active Returns",
    "Cross-Sectional Raw Performance Metric Plot",
    "Cross-Sectional Net Performance Metric Plot",
    "Cross-Sectional Raw Active Performance Metric Plot",
    "Cross-Sectional Net Active Performance Metric Plot",
    "Time-Series of Direct Costs",
    "Time-Series of Market Impact Costs",
    "Time-Series of Total Costs",
    "Time-Series of Turnover",
    "Time-Series of Port Metrics",
    "Time-Series of Port Stats",
    "Weights Correlogram",
    "Weights Radar")

  if (is.null(plot_id)) {
    cat("\nPlease choose a plot to display:\n")
    for (i in seq_along(available_plots)) {
      cat(paste0(i, ": ", available_plots[i], "\n"))
    }
    selection <- readline(prompt = "Enter the number of your choice: ")
    plot_id <- as.numeric(selection)
    if (is.na(plot_id) || plot_id < 1 || plot_id > length(available_plots)) {
      stop("Invalid selection.")
    }
  }

  # Determine plot name from the selection
  if (is.numeric(plot_id)) {
    if (plot_id >= 1 && plot_id <= length(available_plots)) {
      plot_name <- available_plots[plot_id]
    } else {
      stop("Invalid plot number. Please select a valid plot.")
    }
  } else if (is.character(plot_id)) {
    if (plot_id %in% available_plots) {
      plot_name <- plot_id
    } else {
      stop("Invalid 'plot_id' specified. Available options are:\n",
           paste(available_plots, collapse = ", "))
    }
  } else {
    stop("'plot_id' must be either a string or a number corresponding to the plot.")
  }

  # Define the data sources
  port_weights_m_df <- x@port_weights_m_df
  port_costs_m_xts_list <- x@port_costs_m_xts_list
  port_returns_m_xts_list <- x@port_returns_m_xts_list
  port_metrics_m_xts_list <- x@port_metrics_m_xts_list
  port_backtest_results_list <- x@port_backtest_results_list

  #Plot 1
  if (plot_name == "Time-Series of Raw Returns"){

    raw_returns_m_xts <- port_returns_m_xts_list$raw_returns_m_xts

    plot_perf_metric <- FALSE
    if (!is.null(x@backtest_workflow_common$selected_benchmark)){
      bench_returns_m_xts <- raw_returns_m_xts
      bench_returns_m_xts@data <- bench_returns_m_xts@data[, "selected_bench_return"]
      raw_returns_m_xts@data <- raw_returns_m_xts@data[, -which(colnames(raw_returns_m_xts@data) == "selected_bench_return")]
    } else {
      bench_returns_m_xts <- NULL
    }

    #Add first date
    #first_return_date <- zoo::index(raw_returns_m_xts@data)[1]
    ##Port Returns
    #init_df <- as.data.frame(matrix(0, ncol = ncol(raw_returns_m_xts@data), nrow = 1))
    #colnames(init_df) <- colnames(raw_returns_m_xts@data)
    #raw_returns_m_xts@data <- rbind(
    #  xts::xts(init_df, order.by = lubridate::add_with_rollback(first_return_date, months(-1))), #Add a first row with 0 values
    #  raw_returns_m_xts@data
    #)
    ##Bench Returns
    #if(!is.null(bench_returns_m_xts)){
    #  bench_returns_m_xts@data <- rbind(
    #    xts::xts(data.frame(selected_bench_return = 0),
    #             order.by = lubridate::add_with_rollback(first_return_date, months(-1))), #Add a first row with 0 values
    #    bench_returns_m_xts@data
    #  )
    #}

    plot(raw_returns_m_xts, benchmark_returns_m_xts = bench_returns_m_xts, cumulative = TRUE, plot_perf_metric = plot_perf_metric,
         vertical_lines = vertical_lines, palette = palette)

  }

  #Plot 2
  if (plot_name == "Time-Series of Net Returns"){

    net_returns_m_xts <- port_returns_m_xts_list$net_returns_m_xts

    plot_perf_metric <- FALSE
    if (!is.null(x@backtest_workflow_common$selected_benchmark)){
      bench_returns_m_xts <- net_returns_m_xts
      bench_returns_m_xts@data <- bench_returns_m_xts@data[, "selected_bench_return"]
      net_returns_m_xts@data <- net_returns_m_xts@data[, -which(colnames(net_returns_m_xts@data) == "selected_bench_return")]
    } else {
      bench_returns_m_xts <- NULL
    }

    plot(net_returns_m_xts, benchmark_returns_m_xts = bench_returns_m_xts, cumulative = TRUE, plot_perf_metric = plot_perf_metric,
         vertical_lines = vertical_lines, palette = palette)

  }

  #Plot 3
  if (plot_name == "Time-Series of Raw Active Returns"){

    if (is.null(x@backtest_workflow_common$selected_benchmark)){
      stop("This plot is only applicable to cohorts with benchmarks")
    }

    plot_perf_metric <- FALSE
    raw_active_returns_m_xts <- port_returns_m_xts_list$raw_active_returns_m_xts


    plot(raw_active_returns_m_xts, cumulative = TRUE, plot_perf_metric = plot_perf_metric, vertical_lines = vertical_lines, palette = palette)

  }

  #Plot 4
  if (plot_name == "Time-Series of Net Active Returns"){

    if (is.null(x@backtest_workflow_common$selected_benchmark)){
      stop("This plot is only applicable to cohorts with benchmarks")
    }

    plot_perf_metric <- FALSE
    net_active_returns_m_xts <- port_returns_m_xts_list$net_active_returns_m_xts

    #Add first date
    #first_return_date <- zoo::index(net_active_returns_m_xts@data)[1]
    ##Port Returns
    #init_df <- as.data.frame(matrix(0, ncol = ncol(net_active_returns_m_xts@data), nrow = 1))
    #colnames(init_df) <- colnames(net_active_returns_m_xts@data)

    #net_active_returns_m_xts@data <- rbind(
    #  xts::xts(init_df, order.by = lubridate::add_with_rollback(first_return_date, months(-1))), #Add a first row with 0 values
    #
    #  net_active_returns_m_xts@data
    #)


    plot(net_active_returns_m_xts, cumulative = TRUE, plot_perf_metric = plot_perf_metric, vertical_lines = vertical_lines, palette = palette)

  }

  #Plot 5
  if (plot_name == "Cross-Sectional Raw Performance Metric Plot"){

    raw_returns_m_xts <- port_returns_m_xts_list$raw_returns_m_xts

    plot_perf_metric <- TRUE
    if (!is.null(x@backtest_workflow_common$selected_benchmark)){
      bench_returns_m_xts <- raw_returns_m_xts
      bench_returns_m_xts@data <- bench_returns_m_xts@data[, "selected_bench_return"]
      raw_returns_m_xts@data <- raw_returns_m_xts@data[, -which(colnames(raw_returns_m_xts@data) == "selected_bench_return")]
    } else {
      bench_returns_m_xts <- NULL
    }

    plot(raw_returns_m_xts, benchmark_returns_m_xts = bench_returns_m_xts, plot_perf_metric = plot_perf_metric, palette = palette)

  }

  #Plot 6
  if (plot_name == "Cross-Sectional Net Performance Metric Plot"){

    net_returns_m_xts <- port_returns_m_xts_list$net_returns_m_xts

    plot_perf_metric <- TRUE
    if (!is.null(x@backtest_workflow_common$selected_benchmark)){
      bench_returns_m_xts <- net_returns_m_xts
      bench_returns_m_xts@data <- bench_returns_m_xts@data[, "selected_bench_return"]
      net_returns_m_xts@data <- net_returns_m_xts@data[, -which(colnames(net_returns_m_xts@data) == "selected_bench_return")]
    } else {
      bench_returns_m_xts <- NULL
    }

    plot(net_returns_m_xts, benchmark_returns_m_xts = bench_returns_m_xts, plot_perf_metric = plot_perf_metric, palette = palette)

  }

  #Plot 7
  if (plot_name == "Cross-Sectional Raw Active Performance Metric Plot"){

    if (is.null(x@backtest_workflow_common$selected_benchmark)){
      stop("This plot is only applicable to cohorts with benchmarks")
    }

    active_returns <- port_returns_m_xts_list$raw_active_returns_m_xts
    plot_perf_metric <- TRUE

    plot(active_returns, plot_perf_metric = plot_perf_metric, palette = palette)

  }

  #Plot 8
  if (plot_name == "Cross-Sectional Net Active Performance Metric Plot"){

    if (is.null(x@backtest_workflow_common$selected_benchmark)){
      stop("This plot is only applicable to cohorts with benchmarks")
    }

    active_returns <- port_returns_m_xts_list$net_active_returns_m_xts
    plot_perf_metric <- TRUE

    plot(active_returns, plot_perf_metric = plot_perf_metric, palette = palette)

  }

  #Plot 9
  if (plot_name == "Time-Series of Direct Costs"){

    direct_cost_m_xts <- port_costs_m_xts_list$direct_cost_m_xts
    plot(direct_cost_m_xts, vertical_lines = vertical_lines, palette = palette)

  }

  #Plot 10
  if (plot_name == "Time-Series of Market Impact Costs"){

    market_impact_cost_m_xts <- port_costs_m_xts_list$market_impact_cost_m_xts
    plot(market_impact_cost_m_xts,  vertical_lines = vertical_lines, palette = palette)

  }

  #Plot 11
  if (plot_name == "Time-Series of Total Costs"){

    total_cost_m_xts <- port_costs_m_xts_list$total_cost_m_xts
    plot(total_cost_m_xts, vertical_lines = vertical_lines, palette = palette)

  }

  #Plot 12
  if (plot_name == "Time-Series of Turnover"){

    turnover_m_xts <- port_costs_m_xts_list$turnover_m_xts
    plot(turnover_m_xts, vertical_lines = vertical_lines, palette = palette)

  }
  #Plot 13
  if (plot_name == "Time-Series of Port Metrics"){

    #Promp the user regarding the metrics to plot
    available_metrics <- names(port_metrics_m_xts_list) %>% stringr::str_remove("_m_xts")

    if (is.null(selected_metric)){
      selected_metric <- readline(prompt = paste("Please select the metric to plot from the following list: ",
                                                 paste(available_metrics, collapse = ", "), ": "))
    }

    if (!selected_metric %in% available_metrics){
      stop("Invalid metric selected")
    }

    metric_m_xts <- port_metrics_m_xts_list[[paste0(selected_metric, "_m_xts")]]

    plot(metric_m_xts,  vertical_lines = vertical_lines, palette = palette)

  }

  #Plot 14
  if (plot_name == "Time-Series of Port Stats"){

    port_stats_nested <- x@port_stats_m_xts_nested_list

    # Validate presence
    if (is.null(port_stats_nested) || (!length(port_stats_nested$raw_return) && !length(port_stats_nested$net_return))) {
      stop("No port stats available in this cohort.")
    }

    # Detect which families exist
    has_raw <- length(port_stats_nested$raw_return) > 0
    has_net <- length(port_stats_nested$net_return) > 0

    # Ask user to choose raw or net if both exist
    chosen_family <- NULL
    if (has_raw && has_net) {
      cat("\nPort Stats are available for both raw_return and net_return.\n")
      fam_in <- readline(prompt = "Type 'raw' for raw_return or 'net' for net_return: ")
      fam_in <- tolower(trimws(fam_in))
      if (fam_in %in% c("raw", "r")) chosen_family <- "raw_return"
      if (fam_in %in% c("net", "n")) chosen_family <- "net_return"
      if (is.null(chosen_family)) stop("Invalid choice. Please type 'raw' or 'net'.")
    } else if (has_raw) {
      chosen_family <- "raw_return"
      cat("\nOnly raw_return stats are available. Proceeding with raw_return.\n")
    } else { # has_net only
      chosen_family <- "net_return"
      cat("\nOnly net_return stats are available. Proceeding with net_return.\n")
    }

    # Available stats in the chosen family
    family_list <- port_stats_nested[[chosen_family]]
    if (!length(family_list)) stop("Selected family has no stats.")

    # Build vector of stat names without the '_m_xts' suffix
    all_names <- names(family_list)
    available_stats <- sub("_m_xts$", "", all_names)

    # Prompt user to pick the stat
    cat("\nAvailable statistics:\n")
    cat(paste0(" - ", available_stats), sep = "\n")
    selected_stat <- readline(prompt = "Type the statistic name exactly as shown above: ")

    if (!selected_stat %in% available_stats) {
      stop("Invalid statistic selected.")
    }

    # Retrieve the meta_xts and plot
    stat_key  <- paste0(selected_stat, "_m_xts")
    stat_m_xts <- family_list[[stat_key]]

    plot(stat_m_xts, vertical_lines = vertical_lines, palette = palette)
  }

  #Plot 15
  if (plot_name == "Weights Correlogram"){

    plot(port_weights_m_df, type = "correlogram")

  }

  #Plot 16
  if (plot_name == "Weights Radar"){

    port_weights_m_df@data <- port_weights_m_df@data %>% dplyr::select(-dplyr::any_of(c("bench_weights")))
    plot(port_weights_m_df, type = "radar", palette = palette)

  }



})




# Meta backtest plots ------------------------------------------------------
# Two plot methods, one per path, sharing everything that does not depend on how the weights were
# chosen. The palette blocks the older methods repeat inline are factored into a helper here, so
# adding a plot does not mean copying sixty lines of colour definitions.

.meta_plot_palette <- function(palette = "cyberpunk") {

  if (identical(palette, "cyberpunk")) {
    return(list(
      background = "#001f3f", text = "#FFFFFF", grid = "#003641",
      primary = "#00FFFF", secondary = "#FF69B4", tertiary = "#FFA500",
      positive = "#39FF14", negative = "#FF1493", reference = "#FF69B4",
      categorical = c("#00BFFF", "#FF1493", "#FFFF00", "#00FFFF", "#8A2BE2",
                      "#FF4500", "#39FF14", "#FF69B4", "#32CD32", "#FFA500")))
  }

  if (identical(palette, "br")) {
    return(list(
      background = "#FFFFFF", text = "#003641", grid = "#EBEEF1",
      primary = "#00A091", secondary = "#4C7C83", tertiary = "#FF5F1F",
      positive = "#7DB61C", negative = "#C2185B", reference = "#003641",
      categorical = c("#94E1D6", "#49479D", "#FF5F1F", "#7DB61C", "#98B2B6",
                      "#8A03C9", "#00C9B8", "#C9D200", "#C2185B", "#00A091")))
  }

  if (identical(palette, "journal")) {
    journal <- .journal_palette()
    return(list(
      background = journal$background, text = journal$text, grid = journal$text,
      primary = journal$categorical[1], secondary = journal$categorical[2],
      tertiary = journal$categorical[3], positive = journal$categorical[4],
      negative = journal$categorical[5], reference = journal$text,
      categorical = rep(journal$categorical, length.out = 10)))
  }

  stop("Unsupported palette '", palette, "'. Use 'cyberpunk', 'br' or 'journal'.")
}


.meta_plot_theme <- function(colors, base_size = 12) {
  ggplot2::theme_minimal(base_size = base_size) +
    ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = colors$background, color = NA),
      panel.background = ggplot2::element_rect(fill = colors$background, color = NA),
      panel.grid.major = ggplot2::element_line(color = colors$grid, linewidth = 0.3),
      panel.grid.minor = ggplot2::element_blank(),
      text = ggplot2::element_text(color = colors$text),
      axis.text = ggplot2::element_text(color = colors$text),
      plot.title = ggplot2::element_text(color = colors$text, face = "bold"),
      plot.subtitle = ggplot2::element_text(color = colors$text, size = base_size * 0.8),
      legend.background = ggplot2::element_rect(fill = colors$background, color = NA),
      legend.key = ggplot2::element_rect(fill = colors$background, color = NA),
      strip.text = ggplot2::element_text(color = colors$text)
    )
}


## Resolve a plot_id given as a name or an index, or ask when it is NULL. Shared so the two
## methods cannot drift in how they interpret their argument.
.meta_resolve_plot_id <- function(plot_id, available_plots) {

  if (is.null(plot_id)) {
    cat("\nPlease choose a plot to display:\n")
    for (i in seq_along(available_plots)) {
      cat(paste0(i, ": ", available_plots[i], "\n"))
    }
    selection <- readline(prompt = "Enter the number of your choice: ")
    plot_id <- suppressWarnings(as.numeric(selection))
    if (is.na(plot_id) || plot_id < 1 || plot_id > length(available_plots)) {
      stop("Invalid selection.")
    }
  }

  if (is.numeric(plot_id)) {
    if (length(plot_id) != 1 || plot_id < 1 || plot_id > length(available_plots)) {
      stop("Invalid plot number. Please select a number between 1 and ",
           length(available_plots), ".")
    }
    return(available_plots[plot_id])
  }

  if (is.character(plot_id)) {
    if (!plot_id %in% available_plots) {
      stop("Invalid 'plot_id' specified. Available options are:\n",
           paste(available_plots, collapse = ", "))
    }
    return(plot_id)
  }

  stop("'plot_id' must be either a string or a number corresponding to the plot.")
}


.meta_required_plot_packages <- function() {
  required <- c("ggplot2", "scales")
  missing_packages <- required[!vapply(required, requireNamespace,
                                       FUN.VALUE = logical(1), quietly = TRUE)]
  if (length(missing_packages) > 0) {
    stop(sprintf(
      "The following packages are required to generate plots but are not installed: %s.",
      paste(missing_packages, collapse = ", ")), call. = FALSE)
  }
  invisible(NULL)
}


## Backtest identifiers run to fifty characters and crowd a legend out of the panel, so the plots
## key them by number and the mapping is printed to the console, the way the sb plots label their
## backtests.
.meta_sleeve_labels <- function(sleeve_names) {
  sleeve_names <- sort(unique(sleeve_names))
  labels <- seq_along(sleeve_names)
  list(map = stats::setNames(as.character(labels), sleeve_names),
       names = sleeve_names,
       labels = labels)
}


.print_meta_legend <- function(labels) {
  cat("\nLegend:\n")
  for (i in seq_along(labels$labels)) {
    cat(paste(labels$labels[i], ":", labels$names[i], "\n"))
  }
  invisible(NULL)
}


## The plots that do not depend on how the meta weights were chosen. Returns TRUE when it handled
## the request, so each method can fall through to its own plots.
.plot_meta_backtest_common <- function(x, plot_name, colors) {

  meta_weights <- x@meta_port_weights_m_df@data
  stock_results <- x@meta_port_backtest_results

  if (plot_name == "Meta Weights Over Time") {
    ##Stacked, because the sleeves sum to one and the question is how the split moved
    labels <- .meta_sleeve_labels(meta_weights$tickers)
    plot_data <- meta_weights
    plot_data$sleeve <- factor(labels$map[plot_data$tickers], levels = labels$labels)

    figure <- ggplot2::ggplot(
      plot_data, ggplot2::aes(x = .data$dates, y = .data$weights, fill = .data$sleeve)) +
      ggplot2::geom_area(alpha = 0.85) +
      ggplot2::scale_fill_manual(values = colors$categorical) +
      ggplot2::scale_y_continuous(labels = scales::percent) +
      .meta_plot_theme(colors) +
      ggplot2::labs(title = "Meta Weights Over Time", x = NULL, y = "Weight",
                    fill = "Sleeve")

    .print_meta_legend(labels)
    print(figure)
    return(TRUE)
  }

  if (plot_name == "Meta vs Base Cumulative Returns") {
    ##The meta line is the stock-level portfolio, netted across base portfolios holding the same
    ##names, so it is the one that can honestly be compared against the bases. Every series is cut
    ##to the meta portfolio's own first date: it starts later than its bases, and compounding each
    ##from its own start would hand the bases a head start unrelated to the allocation.
    meta_returns <- stock_results@port_returns_m_xts@data
    meta_dates <- zoo::index(meta_returns)
    common_start <- min(meta_dates)

    cumulative_from <- function(dates, values) {
      keep <- dates >= common_start
      data.frame(dates = dates[keep],
                 cumulative = cumprod(1 + values[keep] / 100) - 1,
                 stringsAsFactors = FALSE)
    }

    series <- cbind(cumulative_from(meta_dates, as.numeric(meta_returns[, "net_return"])),
                    series = "meta", stringsAsFactors = FALSE)

    cohort_returns <- x@port_backtest_cohort@port_returns_m_xts_list$net_returns_m_xts
    labels <- NULL
    if (!is.null(cohort_returns)) {
      base_data <- cohort_returns@data
      labels <- .meta_sleeve_labels(setdiff(colnames(base_data), "selected_bench_return"))
      for (base_name in colnames(base_data)) {
        label <- if (base_name %in% names(labels$map)) labels$map[[base_name]] else base_name
        series <- rbind(series, cbind(
          cumulative_from(zoo::index(base_data), as.numeric(base_data[, base_name])),
          series = label, stringsAsFactors = FALSE))
      }
    }

    figure <- ggplot2::ggplot(
      series, ggplot2::aes(x = .data$dates, y = .data$cumulative, color = .data$series)) +
      ggplot2::geom_line(linewidth = 0.8) +
      ggplot2::scale_color_manual(values = colors$categorical) +
      ggplot2::scale_y_continuous(labels = scales::percent) +
      .meta_plot_theme(colors) +
      ggplot2::labs(title = "Meta Portfolio Against Its Base Portfolios",
                    subtitle = paste0("Net returns, compounded from ", format(common_start)),
                    x = NULL, y = "Cumulative return", color = NULL)

    if (!is.null(labels)) .print_meta_legend(labels)
    print(figure)
    return(TRUE)
  }

  if (plot_name == "Meta vs Base Costs and Turnover") {
    ##Costs and turnover on their own say nothing: the question is whether allocating across the
    ##base portfolios traded more or less than the base portfolios themselves did, since trades
    ##that net across bases holding the same names are never charged.
    gather_costs <- function(costs_xts, label) {
      do.call(rbind, lapply(colnames(costs_xts), function(column) {
        data.frame(dates = zoo::index(costs_xts), metric = column,
                   value = as.numeric(costs_xts[, column]), series = label,
                   stringsAsFactors = FALSE)
      }))
    }

    long_costs <- gather_costs(stock_results@port_costs_m_xts@data, "meta")

    base_list <- x@port_backtest_cohort@port_backtest_results_list
    base_names <- vapply(base_list, function(results) results@backtest_identifier, character(1))
    labels <- .meta_sleeve_labels(base_names)
    for (i in seq_along(base_list)) {
      long_costs <- rbind(long_costs, gather_costs(
        base_list[[i]]@port_costs_m_xts@data, labels$map[[base_names[i]]]))
    }

    ##Only the columns both sides carry, so the panels compare like with like
    shared_metrics <- Reduce(intersect, split(long_costs$metric, long_costs$series))
    long_costs <- long_costs[long_costs$metric %in% shared_metrics, , drop = FALSE]

    figure <- ggplot2::ggplot(
      long_costs, ggplot2::aes(x = .data$dates, y = .data$value, color = .data$series)) +
      ggplot2::geom_line(linewidth = 0.8) +
      ggplot2::scale_color_manual(values = colors$categorical) +
      ggplot2::facet_wrap(~ metric, scales = "free_y") +
      .meta_plot_theme(colors) +
      ggplot2::labs(title = "Costs and Turnover Against the Base Portfolios",
                    subtitle = "Priced at stock level",
                    x = NULL, y = NULL, color = NULL)

    .print_meta_legend(labels)
    print(figure)
    return(TRUE)
  }

  if (plot_name == "Meta vs Base Portfolio Stats") {
    ##Stock-level statistics on both sides, which is what makes them comparable. The meta-level
    ##analytics in meta_port_stats_m_df describe an allocation over portfolios and have no
    ##counterpart among the bases, so they are not what belongs in a comparison.
    gather_stats <- function(results, label) {
      stats_data <- results@port_stats_m_df@data
      if (is.null(stats_data)) return(NULL)
      numeric_columns <- names(stats_data)[vapply(stats_data, is.numeric, logical(1))]
      numeric_columns <- setdiff(numeric_columns, c("id", "dates"))
      do.call(rbind, lapply(numeric_columns, function(column) {
        data.frame(dates = stats_data$dates, basis = stats_data$tickers, metric = column,
                   value = stats_data[[column]], series = label, stringsAsFactors = FALSE)
      }))
    }

    long_stats <- gather_stats(stock_results, "meta")
    base_list <- x@port_backtest_cohort@port_backtest_results_list
    base_names <- vapply(base_list, function(results) results@backtest_identifier, character(1))
    labels <- .meta_sleeve_labels(base_names)
    for (i in seq_along(base_list)) {
      long_stats <- rbind(long_stats, gather_stats(base_list[[i]], labels$map[[base_names[i]]]))
    }

    if (is.null(long_stats) || nrow(long_stats) == 0) {
      stop("No portfolio statistics are available to compare.")
    }

    ##port_stats_m_df carries one row per return basis, so the net view is taken rather than
    ##averaging net and raw into a single meaningless number
    if ("net_return" %in% long_stats$basis) {
      long_stats <- long_stats[long_stats$basis == "net_return", , drop = FALSE]
    }

    ##A handful of headline figures, or the facet grid is unreadable
    headline <- c("ann_track_err", "info_ratio", "ann_ret", "act_ann_ret", "ann_vol")
    chosen <- intersect(headline, unique(long_stats$metric))
    if (length(chosen) == 0) chosen <- utils::head(unique(long_stats$metric), 4)
    long_stats <- long_stats[long_stats$metric %in% chosen, , drop = FALSE]

    figure <- ggplot2::ggplot(
      long_stats, ggplot2::aes(x = .data$dates, y = .data$value, color = .data$series)) +
      ggplot2::geom_line(linewidth = 0.8) +
      ggplot2::scale_color_manual(values = colors$categorical) +
      ggplot2::facet_wrap(~ metric, scales = "free_y") +
      .meta_plot_theme(colors) +
      ggplot2::labs(title = "Portfolio Statistics Against the Base Portfolios",
                    subtitle = "Net return basis",
                    x = NULL, y = NULL, color = NULL)

    .print_meta_legend(labels)
    print(figure)
    return(TRUE)
  }

  if (plot_name == "Plot Stock-Level Backtest") {
    plot(stock_results)
    return(TRUE)
  }

  if (plot_name == "Plot Base Portfolio Cohort") {
    plot(x@port_backtest_cohort)
    return(TRUE)
  }

  FALSE
}


#port_metabacktest_results--------------------------------------
#' @title Plot Method for port_metabacktest_results Class
#' @description Plots a multi-portfolio meta backtest: how the allocation across base portfolios
#' moved, how the resulting portfolio compares against those bases, and how the meta score fed
#' through into the weights. Also delegates to the stock-level backtest and to the cohort, which
#' carry their own plots.
#'
#' @param x An object of class `port_metabacktest_results`.
#' @param plot_id A character string naming a plot, or its numeric index. If `NULL`, a menu is
#'   shown. One of \code{"Meta Weights Over Time"},
#'   \code{"Meta vs Base Cumulative Returns"}, \code{"Meta vs Base Costs and Turnover"},
#'   \code{"Meta vs Base Portfolio Stats"}, \code{"Meta Score vs Meta Weight"},
#'   \code{"Plot Stock-Level Backtest"} or \code{"Plot Base Portfolio Cohort"}.
#' @param palette One of `"cyberpunk"`, `"br"` or `"journal"`.
#' @return Invisibly returns the input object.
#' @export
setMethod("plot", "port_metabacktest_results", function(x, plot_id = NULL,
                                                        palette = "cyberpunk") {

  .meta_required_plot_packages()
  colors <- .meta_plot_palette(palette)

  available_plots <- c(
    "Meta Weights Over Time",
    "Meta vs Base Cumulative Returns",
    "Meta vs Base Costs and Turnover",
    "Meta vs Base Portfolio Stats",
    "Meta Score vs Meta Weight",
    "Plot Stock-Level Backtest",
    "Plot Base Portfolio Cohort"
  )

  plot_name <- .meta_resolve_plot_id(plot_id, available_plots)

  if (.plot_meta_backtest_common(x, plot_name, colors)) return(invisible(x))

  if (plot_name == "Meta Score vs Meta Weight") {
    ##The transmission from the score to the allocation. This uses the raw meta score out of
    ##port_universe_m_df rather than the value the optimizer saw, because signal_transform runs
    ##inside the allocation and its output is not retained. The shape of the relationship is
    ##therefore the score as supplied against the weight it earned.
    if (is.null(x@port_universe_m_df)) {
      stop("port_universe_m_df is not available on this object, so the meta score cannot be read.")
    }

    score_name <- names(
      x@port_metabacktest_config@meta_port_backtest_config@chosen_score_metric_and_position)
    universe <- x@port_universe_m_df@data
    if (!score_name %in% names(universe)) {
      stop("The meta score '", score_name, "' is not a column of port_universe_m_df.")
    }

    transmission <- merge(
      x@meta_port_weights_m_df@data[, c("id", "tickers", "dates", "weights")],
      universe[, c("id", score_name)], by = "id")
    names(transmission)[names(transmission) == score_name] <- "meta_score"

    figure <- ggplot2::ggplot(
      transmission, ggplot2::aes(x = .data$meta_score, y = .data$weights,
                                 color = .data$tickers)) +
      ggplot2::geom_point(size = 2.5, alpha = 0.85) +
      ggplot2::scale_color_manual(values = colors$categorical) +
      ggplot2::scale_y_continuous(labels = scales::percent) +
      .meta_plot_theme(colors) +
      ggplot2::labs(
        title = "Meta Score Against Meta Weight",
        subtitle = paste0("Score: ", score_name, ", as supplied"),
        x = score_name, y = "Meta weight", color = "Sleeve")
    print(figure)
    return(invisible(x))
  }

  stop("Plot '", plot_name, "' not recognized.")
})


#risk_target_metabacktest_results-------------------------------
#' @title Plot Method for risk_target_metabacktest_results Class
#' @description Plots a risk-targeted meta backtest: the capital-market-line view of the sleeve
#' blended against its residual, the targeting rule itself, and how the realised risk compares
#' against the level asked for.
#'
#' @param x An object of class `risk_target_metabacktest_results`.
#' @param plot_id A character string naming a plot, or its numeric index. If `NULL`, a menu is
#'   shown. One of \code{"Meta Weights Over Time"},
#'   \code{"Meta vs Base Cumulative Returns"}, \code{"Meta Costs and Turnover"},
#'   \code{"Capital Market Line"}, \code{"Risky Weight vs Sleeve Risk"},
#'   \code{"Realised vs Target Risk"}, \code{"Exposure and Risk Ratio"},
#'   \code{"Plot Stock-Level Backtest"} or \code{"Plot Base Portfolio Cohort"}.
#' @param palette One of `"cyberpunk"`, `"br"` or `"journal"`.
#' @param rolling_window Number of months used for the realised rolling risk. Default 12.
#' @return Invisibly returns the input object.
#' @export
setMethod("plot", "risk_target_metabacktest_results", function(x, plot_id = NULL,
                                                               palette = "cyberpunk",
                                                               rolling_window = 12) {

  .meta_required_plot_packages()
  colors <- .meta_plot_palette(palette)

  available_plots <- c(
    "Meta Weights Over Time",
    "Meta vs Base Cumulative Returns",
    "Meta vs Base Costs and Turnover",
    "Meta vs Base Portfolio Stats",
    "Capital Market Line",
    "Risky Weight vs Sleeve Risk",
    "Realised vs Target Risk",
    "Exposure and Risk Ratio",
    "Plot Stock-Level Backtest",
    "Plot Base Portfolio Cohort"
  )

  plot_name <- .meta_resolve_plot_id(plot_id, available_plots)

  if (.plot_meta_backtest_common(x, plot_name, colors)) return(invisible(x))

  params <- x@risk_target_parameters
  stats_data <- x@meta_port_stats_m_df@data
  is_tracking_error <- !is.null(params) && params@target_metric == "tracking_error"

  ## Which return series the target is stated against. A tracking-error target lives in active
  ## space, where the residual sits at the origin because an index-tracking residual has no
  ## tracking error and no active return. A volatility target lives in total-return space, where
  ## the origin instead assumes a residual that is riskless and returns nothing.
  return_col <- if (is_tracking_error) "net_active_return" else "net_return"
  risk_label <- if (is_tracking_error) "Tracking error" else "Volatility"
  return_label <- if (is_tracking_error) "Active return" else "Return"

  annualise_risk <- function(series) stats::sd(series, na.rm = TRUE) * sqrt(12)
  annualise_return <- function(series) mean(series, na.rm = TRUE) * 12

  if (plot_name == "Capital Market Line") {

    meta_returns <- x@meta_port_backtest_results@port_returns_m_xts@data
    if (!return_col %in% colnames(meta_returns)) {
      stop("The meta portfolio carries no '", return_col, "' column, which a ",
           if (is_tracking_error) "tracking-error" else "volatility", " target is measured on.")
    }
    meta_series <- as.numeric(meta_returns[, return_col])

    ##The sleeve on its own, from the cohort. On this path the cohort holds exactly one portfolio.
    cohort_returns <- if (is_tracking_error) {
      x@port_backtest_cohort@port_returns_m_xts_list$net_active_returns_m_xts
    } else {
      x@port_backtest_cohort@port_returns_m_xts_list$net_returns_m_xts
    }
    if (is.null(cohort_returns)) {
      stop("The cohort carries no returns for the sleeve, so the line cannot be drawn.")
    }
    sleeve_name <- colnames(cohort_returns@data)[1]
    sleeve_series <- as.numeric(cohort_returns@data[, sleeve_name])

    points <- data.frame(
      label = c(x@residual_ticker, sleeve_name, "meta portfolio"),
      risk = c(0, annualise_risk(sleeve_series), annualise_risk(meta_series)),
      ret = c(0, annualise_return(sleeve_series), annualise_return(meta_series)),
      stringsAsFactors = FALSE)

    ##The static line: every fixed blend of residual and sleeve lands on it, because both risk and
    ##return are linear in the weight when the residual sits at the origin. The dynamic rule need
    ##not land on it, and the gap is what timing the blend bought or cost.
    slope <- if (points$risk[2] > 0) points$ret[2] / points$risk[2] else NA_real_

    figure <- ggplot2::ggplot(points, ggplot2::aes(x = .data$risk, y = .data$ret)) +
      {
        if (!is.na(slope)) {
          ggplot2::geom_abline(intercept = 0, slope = slope,
                               color = colors$reference, linetype = "dashed", linewidth = 0.7)
        }
      } +
      ggplot2::geom_point(ggplot2::aes(color = .data$label), size = 4) +
      ggplot2::geom_text(ggplot2::aes(label = .data$label), vjust = -1.2,
                         color = colors$text, size = 3.5) +
      {
        if (!is.null(params)) {
          ggplot2::geom_vline(xintercept = params@target, color = colors$tertiary,
                              linetype = "dotted", linewidth = 0.7)
        }
      } +
      ggplot2::scale_color_manual(values = colors$categorical) +
      ggplot2::expand_limits(x = 0, y = 0) +
      .meta_plot_theme(colors) +
      ggplot2::theme(legend.position = "none") +
      ggplot2::labs(
        title = "Capital Market Line",
        subtitle = "Dashed: static blends. Dotted: the target.",
        x = paste0(risk_label, " (annualised, %)"),
        y = paste0(return_label, " (annualised, %)"))
    print(figure)
    return(invisible(x))
  }

  if (plot_name == "Risky Weight vs Sleeve Risk") {
    ##The rule itself, with the curve it is supposed to trace. Points off the curve are the ones
    ##where a bound bound or where the exposure signal leaned.
    curve <- NULL
    if (!is.null(params)) {
      risk_grid <- seq(max(min(stats_data$sleeve_risk, na.rm = TRUE) * 0.5, 1e-6),
                       max(stats_data$sleeve_risk, na.rm = TRUE) * 1.2, length.out = 200)
      curve <- data.frame(
        sleeve_risk = risk_grid,
        risky_weight = vapply(risk_grid, function(risk) risk_to_weight(risk, params, 1),
                              numeric(1)),
        stringsAsFactors = FALSE)
    }

    ##Each point is one rebalance date, so it is labelled with that date. Without the label the
    ##points read as an unexplained scatter rather than as the sequence the rule actually walked.
    point_data <- stats_data
    point_data$label <- format(point_data$dates)

    figure <- ggplot2::ggplot(
      point_data, ggplot2::aes(x = .data$sleeve_risk, y = .data$risky_weight)) +
      {
        if (!is.null(curve)) {
          ggplot2::geom_line(data = curve,
                             ggplot2::aes(x = .data$sleeve_risk, y = .data$risky_weight),
                             color = colors$reference, linetype = "dashed", linewidth = 0.7)
        }
      } +
      ggplot2::geom_point(ggplot2::aes(color = "one rebalance date"), size = 3) +
      ggplot2::geom_text(ggplot2::aes(label = .data$label), color = colors$text,
                         size = 3, vjust = -1.1) +
      {
        if (!is.null(params)) {
          ggplot2::geom_hline(yintercept = c(params@min_weight, params@max_weight),
                              color = colors$tertiary, linetype = "dotted")
        }
      } +
      ggplot2::scale_color_manual(values = stats::setNames(colors$primary,
                                                           "one rebalance date")) +
      ggplot2::scale_y_continuous(labels = scales::percent) +
      .meta_plot_theme(colors) +
      ggplot2::labs(
        title = "Risky Weight vs Sleeve Risk",
        subtitle = "Dashed: Meta Portfolio. Dotted: Weight bounds.",
        x = paste0("Estimated sleeve ", tolower(risk_label), " (annualised, %)"),
        y = "Weight on the risky sleeve", color = NULL)
    print(figure)
    return(invisible(x))
  }

  if (plot_name == "Realised vs Target Risk") {
    ##Four things are at play and only together do they say whether targeting earned its keep.
    ##target is what was asked for. intended is what the estimate implied, an identity with the
    ##target whenever no bound binds, so on its own it is not evidence. The two realised lines are
    ##the evidence: the sleeve on its own against the blend, so the gap between them is what
    ##holding the residual actually bought.
    rolling_risk <- function(series) {
      out <- rep(NA_real_, length(series))
      if (length(series) >= rolling_window) {
        for (i in seq(rolling_window, length(series))) {
          out[i] <- annualise_risk(series[(i - rolling_window + 1):i])
        }
      }
      out
    }

    meta_returns <- x@meta_port_backtest_results@port_returns_m_xts@data
    meta_dates <- zoo::index(meta_returns)
    realised_meta <- rolling_risk(as.numeric(meta_returns[, return_col]))

    series <- rbind(
      data.frame(dates = stats_data$dates, series = "target",
                 value = stats_data$target, stringsAsFactors = FALSE),
      data.frame(dates = stats_data$dates, series = "intended, from the estimate",
                 value = stats_data$implied_risk, stringsAsFactors = FALSE),
      data.frame(dates = meta_dates,
                 series = paste0("realised, meta portfolio (", rolling_window, "m)"),
                 value = realised_meta, stringsAsFactors = FALSE))

    ##The sleeve on its own, which is the counterfactual the blend is judged against
    base_list <- x@port_backtest_cohort@port_backtest_results_list
    if (length(base_list) >= 1) {
      sleeve_returns <- base_list[[1]]@port_returns_m_xts@data
      if (return_col %in% colnames(sleeve_returns)) {
        series <- rbind(series, data.frame(
          dates = zoo::index(sleeve_returns),
          series = paste0("realised, risky sleeve (", rolling_window, "m)"),
          value = rolling_risk(as.numeric(sleeve_returns[, return_col])),
          stringsAsFactors = FALSE))
      }
    }

    series <- series[!is.na(series$value), , drop = FALSE]
    if (nrow(series) == 0) {
      stop("No risk figures are available to plot. The sample may be shorter than rolling_window.")
    }

    figure <- ggplot2::ggplot(
      series, ggplot2::aes(x = .data$dates, y = .data$value, color = .data$series)) +
      ggplot2::geom_line(linewidth = 0.8) +
      ggplot2::scale_color_manual(values = colors$categorical) +
      .meta_plot_theme(colors) +
      ggplot2::labs(
        title = "Realised Risk Against the Target",
        subtitle = paste0("Rolling ", rolling_window, "m windows"),
        x = NULL, y = paste0(risk_label, " (annualised, %)"), color = NULL)
    print(figure)
    return(invisible(x))
  }

  if (plot_name == "Exposure and Risk Ratio") {
    ##The weight is the product of two things, and a move in it means nothing until they are shown
    ##apart: an exposure signal leaning, or the risk estimate moving.
    if (is.null(params)) stop("risk_target_parameters are not available on this object.")

    decomposition <- rbind(
      data.frame(dates = stats_data$dates, component = "exposure signal",
                 value = stats_data$exposure, stringsAsFactors = FALSE),
      data.frame(dates = stats_data$dates, component = "risk ratio",
                 value = (params@target / stats_data$sleeve_risk)^params@p,
                 stringsAsFactors = FALSE),
      data.frame(dates = stats_data$dates, component = "risky weight",
                 value = stats_data$risky_weight, stringsAsFactors = FALSE))

    figure <- ggplot2::ggplot(
      decomposition, ggplot2::aes(x = .data$dates, y = .data$value, color = .data$component)) +
      ggplot2::geom_line(linewidth = 0.8) +
      ggplot2::geom_point(size = 2) +
      ggplot2::scale_color_manual(values = c(colors$primary, colors$secondary, colors$positive)) +
      .meta_plot_theme(colors) +
      ggplot2::labs(
        title = "Exposure and Risk Ratio Over Time",
        subtitle = "Exposure times the risk ratio, before the bounds",
        x = NULL, y = NULL, color = NULL)
    print(figure)
    return(invisible(x))
  }

  stop("Plot '", plot_name, "' not recognized.")
})
