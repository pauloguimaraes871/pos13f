#' Predict Method for keras_ensemble Class
#'
#' Generates a forecast from an ensemble of independently initialised Keras
#' networks by averaging the forecasts of its members.
#'
#' @param object An instance of the `keras_ensemble` class, as returned in the
#'   `model_nn` element of [fit_keras_model()] when `n_ensembles > 1`.
#' @param x A numeric matrix of features, with one row per observation and columns
#'   in the same order the members were trained on.
#' @param ... Further arguments passed to the members' own `predict` methods.
#'
#' @return A numeric vector with one averaged prediction per row of `x`.
#'
#' @details
#' Forecasts are averaged, not weights: hidden units are permutation symmetric,
#' so the coordinates of independently initialised networks are not comparable
#' and averaging weights would be meaningless.
#'
#' Averaging is done with [Reduce()] rather than by binding member predictions
#' into a matrix, because a single-row `x` (a one-asset cross-section, which does
#' occur at sparse rebalancing dates) would collapse such a matrix to a bare
#' vector and silently average across members instead of across rows.
#'
#' @export
setMethod("predict",
          signature = list(object = "keras_ensemble"),
          function(object, x, ...) {

  if (length(object@members) < 1L) {
    stop("keras_ensemble contains no members; cannot predict.")
  }

  ##Collect each member's forecast for the same feature matrix
  member_predictions <- lapply(object@members, function(member) {
    prediction <- as.numeric(stats::predict(member, x = x, ...))

    ###A member returning the wrong length would otherwise be recycled into the
    ###sum and corrupt the average without any warning.
    if (length(prediction) != nrow(x)) {
      stop("A keras_ensemble member returned ", length(prediction),
           " predictions for ", nrow(x), " rows of new data.")
    }
    return(prediction)
  })

  ##Equal-weighted mean across members
  averaged_prediction <- Reduce(`+`, member_predictions) / length(member_predictions)

  if (any(!is.finite(averaged_prediction))) {
    warning("keras_ensemble produced non-finite predictions.")
  }

  return(averaged_prediction)
})


#' Predict method for signal_port class
#'
#' This method generates predictions using a signal_port obejct
#' based on the provided new feature data. It accommodates different port construction methods.
#' The function handles signal weighting and quantile winsorization.
#'
#' @param object An instance of the `signal_port` class containing the
#' signal portfolio and respective weights.
#' @param new_features_m_df A data frame or an object of class `meta_dataframe`
#'   containing new feature data for which predictions are to be made. The
#'   data frame must be structured correctly and should not include the first
#'   three columns, which are reserved for identifiers.
#' @param upper_quantile_winsorization Numeric value for upper winsorization
#' @param lower_quantile_winsorization Numeric value for lower winsorization
#'
#' @return A numeric vector of blended-signal predictions (weighted sum of the eligible
#'   signals, winsorized by the quantile bounds).
#'
setMethod("predict",
          signature = list(object = "signal_port"),
          function(object, new_features_m_df,
                   upper_quantile_winsorization, lower_quantile_winsorization) {

  #Assign
  new_features_m_df_clean <- new_features_m_df

  #Check if new_features_m_df does not contain identifiers
  if (any(c("id", "tickers", "dates") %in% colnames(new_features_m_df_clean))) {
    stop("new_features_m_df_clean should not contain identifiers (id, tickers, dates).")
  }

  #Check if all signals are present in new_features_m_df_clean
  if(!all(object@eligible_assets %in% colnames(new_features_m_df_clean))){
    stop("Not all eligible assets are present in new_features_m_df_clean")
  }

  #Eliminate signals not in eligible_signals
  selected_signals_corrected_positions_m_df <- new_features_m_df_clean %>% dplyr::select(dplyr::all_of(object@eligible_assets))

  #Get signal weights
  signal_weights <- object@weights

  ##Calculate preds
  ############################
  preds <- selected_signals_corrected_positions_m_df %>% apply(1, function(row){ #To each row
    sum(row * signal_weights) #Multiply by corresponding weights and sum
  }) %>% #Signal transform
    signal_transform(upper_quantile_winsorization = upper_quantile_winsorization, lower_quantile_winsorization = lower_quantile_winsorization)
  ############################

  return(preds)
})


#' Predict Method for sb_model Class and meta_dataframe
#'
#' This method generates predictions using a refitted sb model
#' based on the provided new feature data. It accommodates different machine
#' learning algorithms and applies the appropriate prediction logic.
#'
#' @param object An instance of the `sb_model` class containing the
#'   refitted model and its parameters.
#' @param new_features_m_df A  `meta_dataframe` or a coercible data.frame
#'  containing new feature data for which predictions are to be made.
#' @param upper_quantile_winsorization Numeric value for upper winsorization
#' @param lower_quantile_winsorization Numeric value for lower winsorization

#' @return A numeric vector of predictions for the new feature data.
#'
#' @details The function first validates that `new_features_m_df` is coercible
#' to a `meta_dataframe`. It extracts the relevant data from the input and
#' uses the appropriate prediction method based on the specified signal blending algo
#'
#'
#' @export
setMethod("predict",
          signature = list(object = "sb_model"),
          function(object, new_features_m_df,
                   lower_quantile_winsorization = 0.025, upper_quantile_winsorization = 0.975) {

  ##Validate and prepare inputs
  ##################
  if (!is_coercible_to_meta_dataframe(new_features_m_df)) {
    stop("new_features_m_df must be coercible to meta_dataframe.")
  }

  ##Check if it is a meta_dataframe
  if (methods::is(new_features_m_df, "meta_dataframe")) {
    ##Correct signals and positions
    ###Get eligible signals and positions
    eligible_signals <- object@eligible_signals
    elected_signals_and_positions <- ifelse(stringr::str_detect(eligible_signals, pattern = "low_"), "short", "long")
    names(elected_signals_and_positions) <- stringr::str_remove_all(eligible_signals, pattern = "low_")

    ###Correct
    new_features_m_df <- select_and_correct_signals(
      signals_m_df = new_features_m_df@data, #Extract eligible signals from features_m_df and then correct them (multiply short signal by -1)
      chosen_signals_and_positions = elected_signals_and_positions #Get instruction on what to change features
    )$selected_signals_corrected_positions_m_df
  }

   ##Check if ALL eligible signals are in colnames of new_data
   if (!all(object@eligible_signals %in% colnames(new_features_m_df[,-c(1:3)]))) {
      stop("Not all eligible signals are present in new_features_m_df")
   }

  ##Remove ids and re-order
  new_data <- new_features_m_df[,-c(1:3)] %>%
    dplyr::select(dplyr::all_of(object@eligible_signals)) #Remove ids and keep only eligible signals


  ################

  #Get parameters
  ################
  sb_algorithm <- object@sb_algorithm
  optimal_hyper <- object@best_hyperparameters
  if(sb_algorithm == "glmnet"){
    best_lam = as.numeric(optimal_hyper["best_lam"])
  } else {
    NULL
  }
  sb_model_fit <- object@model
  ################

  #Choose predict method base on sb_algorithm
  ################
  ###Make a general case for signal port
  if(sb_algorithm %in% c("ew", "sw", "mvo", "rp", "hrp", "mmaf", "custom_weights")) sb_algorithm <- "signal_port"

  ###Generate predictions
  predictions <- switch(
    sb_algorithm, #Depending on the algorithm
    ols = as.numeric(predict(sb_model_fit, newdata = as.data.frame(new_data))), #prediction for new data OLS
    glmnet = as.numeric(predict(sb_model_fit, newx = as.matrix(new_data), s = best_lam)), #prediction for new data GLM
    rf = as.numeric(predict(sb_model_fit, data = janitor::clean_names(new_data))$predictions), #prediction for RF
    xgb = as.numeric(predict(sb_model_fit, newdata = as.matrix(new_data))), #predictions for XGB
    nn = as.numeric(predict(sb_model_fit, x = as.matrix(new_data))), #predictions for NN
    signal_port = as.numeric(predict(sb_model_fit, new_features_m_df = new_data,
                                     lower_quantile_winsorization = lower_quantile_winsorization,
                                     upper_quantile_winsorization = upper_quantile_winsorization)) #Predictions for signal ports
  )
  ################

  return(predictions)
})



#' Predict Method for sb_backtest_results Class
#'
#' This method generates predictions using a sb model that has been
#' validated through walk-forward validation. It uses the provided new feature
#' data and applies the appropriate prediction logic based on the underlying
#' model and its hyperparameters.
#'
#' @param object An instance of the `sb_backtest_results` class containing the
#'   validated model, metadata, and best hyperparameters.
#' @param new_features_m_df A data frame or an object of class `meta_dataframe`
#'   containing new feature data for which predictions are to be made. The
#'   data frame must be structured correctly and should not include the first
#'   three columns, which are reserved for identifiers.
#' @param upper_quantile_winsorization Numeric value for upper winsorization
#' @param lower_quantile_winsorization Numeric value for lower winsorization
#' @return A numeric vector of predictions for the new feature data.
#'
#' @details The function validates that `new_features_m_df` is coercible to a
#' `meta_dataframe`. It extracts the relevant data and uses the appropriate
#' prediction method based on the specified machine learning algorithm (e.g., OLS,
#' GLMNET, RF, XGB, NN). The method retrieves the refitted model and the best
#' hyperparameters for making predictions.
#'
#'
#' @export
setMethod("predict",
          signature = list(object = "sb_backtest_results"),
          function(object, new_features_m_df,
                   lower_quantile_winsorization = 0.025, upper_quantile_winsorization = 0.975) {


  #Get objects of sb_backtest_workflow
  sb_model_refit <- object@final_sb_model #Get refitted model

  #Ensure a refitted model exists (final_sb_model can be empty after an update)
  if (is.null(sb_model_refit) || !methods::is(sb_model_refit, "sb_model")) {
    stop("No final_sb_model available in this sb_backtest_results object; cannot predict on new data.")
  }

  #Get predictions
  predictions <- predict(sb_model_refit, new_features_m_df = new_features_m_df,
                         lower_quantile_winsorization = lower_quantile_winsorization, upper_quantile_winsorization = upper_quantile_winsorization)

  return(predictions)

})







