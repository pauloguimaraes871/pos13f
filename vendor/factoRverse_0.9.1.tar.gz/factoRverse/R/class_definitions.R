#External Objects-------------------------------------------------------

# Register 'xts' as an S4 class
setOldClass("xts")
# Register 'recipe' as an S4 class
setOldClass("recipe")


#meta_dataframe------------------------------------------------------

#' meta_dataframe-class
#'
#' An S4 container that wraps a data.frame with backtest workflow metadata and structural validation.
#'
#' @description
#' The \code{meta_dataframe} class encapsulates a \code{data.frame} together with metadata and a
#' recorded workflow of preprocessing and feature-engineering steps used in the factoRverse
#' backtesting pipeline. It enforces a strict table layout and several validation rules to ensure
#' downstream methods (imputation, normalization, portfolio construction, signal blending, etc.)
#' receive a well-formed input.
#'
#' @section Key validation rules:
#' - The underlying \code{data} must be a \code{data.frame}.
#' - The first three columns of \code{data} must be exactly \code{id}, \code{tickers}, \code{dates}
#'   in that order.
#' - \code{tickers} must be a character vector; \code{dates} must be of class \code{Date}; \code{id}
#'   must be character and equal to \code{paste0(tickers, "-", dates)}.
#' - Rows must be ordered by \code{id} (alphabetical order) and \code{dates} must be non-decreasing.
#' - Column names (variable names) must be unique and must not include the prefix \code{"low_"} in any
#'   \code{signals} (this prefix breaks certain backtesting routines).
#' - The validity function also calls \code{is_coercible_to_meta_dataframe()} which prints helpful
#'   messages when coercion checks fail.
#'
#' @slot data A \code{data.frame} containing the actual tabular observations. Required first columns:
#'   \code{id}, \code{tickers}, \code{dates}.
#' @slot workflow A list (typically a sb_backtest_workflow object or plain \code{list}) recording the
#'   sequence of preprocessing / modeling steps applied to the \code{data}. Each element should
#'   describe one operation (name, parameters, timestamp, etc.).
#' @slot signals A \code{character} vector with the names of columns in \code{data} that are
#'   considered signals (features, targets, groupings, etc.).
#' @slot unique_dates Numeric: number of distinct dates present in \code{data}.
#' @slot unique_tickers Numeric: number of distinct tickers present in \code{data}.
#' @slot n_obs Numeric: total number of observations (rows) in \code{data}.
#' @slot current_date A \code{Date} object representing the reference/current date for the object.
#' @slot meta_dataframe_name A short \code{character} identifier for this meta_dataframe instance.
#'
#' @details
#' This class is intended as the canonical input for the package's preprocessing, modeling, and
#' backtesting methods. Storing both the raw table (\code{data}) and a reproducible \code{workflow}
#' history enables reproducible pipelines and safe application of subsequent transforms.
#'
#' Use the package constructor (e.g. \code{create_meta_dataframe()}) when available; it will populate
#' slots and run validation. The low-level S4 constructor \code{new("meta_dataframe", ...)} may be
#' used for testing but must satisfy all validation rules.
#'
#' @examples
#' \dontrun{
#' # Assume create_meta_dataframe() is the user-facing constructor
#' df <- data.frame(
#'   id = c("A-2020-01-01", "B-2020-01-02"),
#'   tickers = c("A", "B"),
#'   dates = as.Date(c("2020-01-01", "2020-01-02")),
#'   signal1 = c(0.1, -0.2),
#'   stringsAsFactors = FALSE
#' )
#'
#' mdf <- create_meta_dataframe(
#'   data = df,
#'   workflow = list(),
#'   signals = c("signal1"),
#'   meta_dataframe_name = "example_mdf"
#' )
#'
#' # low-level creation (not recommended unless you ensure validation)
#' new_mdf <- new(
#'   "meta_dataframe",
#'   data = df,
#'   workflow = list(),
#'   signals = "signal1",
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "example_lowlevel"
#' )
#' }
#'
#' @seealso
#' \code{\link{is_coercible_to_meta_dataframe}}, \code{\link{create_meta_dataframe}},
#' related S4 classes: \code{raw_features_m_df}, \code{signals_m_df}, \code{target_m_df},
#' \code{groups_m_df}, \code{priors_m_df}.
#'
#' @name meta_dataframe-class
#' @rdname meta_dataframe-class
#' @aliases meta_dataframe
#' @exportClass meta_dataframe
#'
setClass("meta_dataframe",
         slots = c(
           data = "data.frame",        # Slot for the data frame
           workflow = "ANY",           # Slot for storing sb_backtest_workflow about the data manipulation workflow
           signals = "character",      # Slot for storing column names
           unique_dates = "numeric",   # Slot for storing count of unique dates
           unique_tickers = "numeric", # Slot for storing count of unique tickers
           n_obs = "numeric",          # Slot for storing total number of observations
           current_date = "Date",      # Slot for storing the current date
           meta_dataframe_name = "character"
         ), validity = function(object){

           #Check coercibility
           is_coercible_to_meta_dataframe(object@data)

           #Check for presence of low
           if(any(grepl("low_", object@signals))){
             stop("Column names should not contain 'low_', as it will bring problems when running backtesting functions")
           }

         })


#' raw_features_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} representing raw feature tables.
#'
#' @description
#' Inherits all slots and behavior from \code{\link{meta_dataframe-class}} but adds no extra validity checks.
#' Use for intermediate/raw outputs (may contain NA) produced by \code{create_meta_dataframe()} or similar constructors.
#'
#' @details
#' All slots are inherited (data, workflow, signals, unique_dates, unique_tickers, n_obs, current_date, meta_dataframe_name).
#'
#' @examples
#' \dontrun{
#' new(
#'   "raw_features_m_df",
#'   data = df,
#'   workflow = list(),
#'   signals = character(),
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "raw_features"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, \code{\link{signals_m_df-class}}
#' @name raw_features_m_df-class
#' @rdname raw_features_m_df-class
#' @aliases raw_features_m_df
#' @exportClass raw_features_m_df
setClass(
  "raw_features_m_df",
  contains = "meta_dataframe"
)

#' signals_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} that represents signal-ready data for modelling.
#'
#' @description
#' \code{signals_m_df} inherits from \code{meta_dataframe} and tightens validation for modelling: the
#' underlying \code{data} must contain no missing values (no NA in any column). This ensures downstream
#' modelling functions (the \code{run_*} family) receive complete data.
#'
#' @details
#' All slots are inherited from \code{\link{meta_dataframe-class}}:
#' \itemize{
#'  \item \code{data} : data.frame (first columns: \code{id}, \code{tickers}, \code{dates})
#'  \item \code{workflow} : list describing preprocessing steps
#'  \item \code{signals} : character vector of signal column names
#'  \item \code{unique_dates}, \code{unique_tickers}, \code{n_obs} : numeric summary slots
#'  \item \code{current_date} : Date
#'  \item \code{meta_dataframe_name} : character
#' }
#'
#' @section Validity:
#' The validity method fails if any value in \code{data} is \code{NA}. Use your package constructor
#' (e.g. \code{create_meta_dataframe()} then a conversion helper if provided) to build valid objects.
#'
#' @examples
#' \dontrun{
#' df <- data.frame(
#'  id = c("A-2020-01-01", "B-2020-01-02"),
#'  tickers = c("A", "B"),
#'  dates = as.Date(c("2020-01-01","2020-01-02")),
#'  s1 = c(0.1, 0.2),
#'  stringsAsFactors = FALSE
#' )
#' new_obj <- new(
#'   "signals_m_df",
#'   data = df,
#'   workflow = list(),
#'   signals = "s1",
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "signals_example"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, \code{\link{is_coercible_to_meta_dataframe}}
#' @name signals_m_df-class
#' @rdname signals_m_df-class
#' @aliases signals_m_df
#' @exportClass signals_m_df
setClass(
  "signals_m_df",
  contains = "meta_dataframe",
  validity = function(object) {
    if (any(object@data %>% apply(2, function(x) any(is.na(x))))){
      stop("Data contains missing values")
    }
  }
)

#' feature_importance_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} that holds feature-importance results produced by
#' the package's signal-blending / interpretability pipeline.
#'
#' @description
#' \code{feature_importance_m_df} inherits all slots and behavior from \code{\link{meta_dataframe-class}}.
#' It is the canonical container for global-surrogate feature importance produced by \code{run_sb_backtest()}
#' (the package's signal-blending backtest). Importance values are obtained from the chosen global surrogate
#' model (e.g. OLS coefficients or tree variable.importance) and then normalized to produce
#' \code{normalized_importance}.
#'
#' @details
#' Valid objects must include at least two columns in \code{data}:
#' \itemize{
#'  \item \code{importance} — numeric importance measure (e.g. OLS coef, tree importance).
#'  \item \code{normalized_importance} — numeric z-scored / standardized importance.
#' }
#' Typical additional columns produced by \code{run_sb_backtest()} and present in examples are
#' \code{tickers}, \code{theme}, \code{is_eligible}, \code{dates}, and \code{id} (where
#' \code{id = paste0(tickers, "-", dates)}). The validity method enforces presence of the two
#' required importance columns; other slot checks come from the parent \code{meta_dataframe} class.
#'
#' @slot data A \code{data.frame} containing importance results (must include \code{importance} and \code{normalized_importance}).
#' @slot workflow Inherited: list describing preprocessing and modeling steps that led to these results.
#' @slot signals Inherited: typically the signal names considered when building the surrogate model.
#' @slot unique_dates, unique_tickers, n_obs, current_date, meta_dataframe_name Inherited summary slots.
#'
#' @examples
#' \dontrun{
#' # Typical object produced by run_sb_backtest()
#' # Here is a minimal manual construction for testing:
#' df <- data.frame(
#'   id = c("A-2026-07-01","B-2026-07-01"),
#'   tickers = c("A","B"),
#'   dates = as.Date(c("2026-07-01","2026-07-01")),
#'   importance = c(0.5, -0.2),
#'   normalized_importance = c(1.0, -1.0),
#'   stringsAsFactors = FALSE
#' )
#' fi <- new(
#'   "feature_importance_m_df",
#'   data = df,
#'   workflow = list(steps = "run_sb_backtest() (mock)"),
#'   signals = c("A","B"),
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "fi_example"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, \code{\link{run_sb_backtest}}
#' @name feature_importance_m_df-class
#' @rdname feature_importance_m_df-class
#' @aliases feature_importance_m_df
#' @exportClass feature_importance_m_df
setClass(
  "feature_importance_m_df",
  contains = "meta_dataframe",
  validity = function(object) {
    if (!all(c("importance", "normalized_importance") %in% colnames(object@data))) {
      stop("Data must contain 'importance' and 'normalized_importance' columns")
    }
  }
)

#' groups_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} for holding grouping/classification variables (e.g., sectors, themes).
#'
#' @description
#' \code{groups_m_df} inherits from \code{\link{meta_dataframe-class}} and is intended for tables where one or
#' more columns represent categorical groupings (for example sector, theme, or factor families).
#' The \code{signals} slot lists the grouping column names to be validated.
#'
#' @section Validity:
#' For every grouping column named in \code{signals}, the validity method counts distinct classifications
#' per \code{tickers}. If a ticker has more than one classification for a given grouping column a
#' user-facing warning is emitted (the object is still created). Parent-class validation (column order,
#' types, uniqueness, id format, etc.) is also enforced by \code{meta_dataframe}.
#'
#' @slot data Inherited: a \code{data.frame} whose first three columns must be \code{id}, \code{tickers}, \code{dates}.
#' @slot workflow Inherited: list describing preprocessing steps that produced the grouping table.
#' @slot signals Inherited: character vector with names of grouping columns in \code{data}.
#' @slot unique_dates, unique_tickers, n_obs, current_date, meta_dataframe_name Inherited summary slots.
#'
#' @examples
#' \dontrun{
#' df <- data.frame(
#'   id = c("A-2026-07-01","B-2026-07-01"),
#'   tickers = c("A","B"),
#'   dates = as.Date(c("2026-07-01","2026-07-01")),
#'   sector = c("Energy", "Financials"),
#'   theme = c("Value", "Value"),
#'   stringsAsFactors = FALSE
#' )
#' gm <- new(
#'   "groups_m_df",
#'   data = df,
#'   workflow = list(step = "assign_groups"),
#'   signals = c("sector","theme"),
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "groups_example"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, \code{\link{create_meta_dataframe}}
#' @name groups_m_df-class
#' @rdname groups_m_df-class
#' @aliases groups_m_df
#' @exportClass groups_m_df
setClass(
  "groups_m_df",
  contains = "meta_dataframe",
  validity = function(object) {
    groups <- object@signals
    for (g in groups) {
      # Count distinct classifications for each ticker
      df_counts <- object@data %>%
        dplyr::group_by(.data[["tickers"]]) %>%
        dplyr::summarise(
          n_class = dplyr::n_distinct(.data[[g]]),
          .groups = "drop"
        )

      # Identify tickers with more than one classification
      multi_idx <- which(df_counts$n_class > 1)
      if (length(multi_idx) > 0) {
        multi_tickers <- df_counts[["tickers"]][multi_idx]
        warning(
          sprintf(
            "Ticker(s) %s have multiple classifications in '%s'.",
            paste(multi_tickers, collapse = ", "),
            g
          ),
          call. = FALSE
        )
      }
    }
  }
)


#' target_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} for target variables used by signal-blending models.
#'
#' @description
#' \code{target_m_df} stores one or more prediction targets used by \code{run_sb_backtest()} and other
#' modeling routines. It inherits all slots from \code{\link{meta_dataframe-class}} and adds a
#' naming convention requirement for target columns.
#'
#' @section Validity:
#' Each name listed in the \code{signals} slot must match the pattern:
#' \code{^[A-Za-z_]+_[0-9]{1,2}m$}. That is, "<target_name>_<horizon>m" where \code{horizon} is 1–99 months.
#' If any target name fails this check object construction is halted with an informative error.
#'
#' @slot data Inherited: a \code{data.frame} whose first three columns must be \code{id}, \code{tickers}, \code{dates}.
#' @slot workflow Inherited: preprocessing / generation history.
#' @slot signals Inherited: character vector naming the target columns (must follow the pattern above).
#' @slot unique_dates, unique_tickers, n_obs, current_date, meta_dataframe_name Inherited summary slots.
#'
#' @details
#' Use \code{create_target_m_df()} to build valid target objects; it populates slots and enforces naming and structural rules.
#'
#' @examples
#' \dontrun{
#' df <- data.frame(
#'   id = "A-2026-07-01",
#'   tickers = "A",
#'   dates = as.Date("2026-07-01"),
#'   return_1m = 0.02,
#'   stringsAsFactors = FALSE
#' )
#' tgt <- new(
#'   "target_m_df",
#'   data = df,
#'   workflow = list(step = "create_target"),
#'   signals = "return_1m",
#'   unique_dates = 1,
#'   unique_tickers = 1,
#'   n_obs = 1,
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "target_example"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, \code{\link{create_target_m_df}}, \code{\link{run_sb_backtest}}
#' @name target_m_df-class
#' @rdname target_m_df-class
#' @aliases target_m_df
#' @exportClass target_m_df
setClass(
  "target_m_df",
  contains = "meta_dataframe",
  validity = function(object) {

    target_fwd_name_right_pattern <- "^[A-Za-z_]+_[0-9]{1,2}m$"

    for(target in object@signals){

      if(!grepl(target_fwd_name_right_pattern, target)){
        stop(cat(paste(target, " is not a valid target variable name. The
            target_m_df colnames should follow the format XXXX_number_m, where ' XXXX is the name of the target variable,
            number is the amount of forward periods and m indicates periods are measured in months.")))
      }
    }
  }
)

#' priors_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} that stores returns and ancillary columns used to derive informative priors.
#'
#' @description
#' \code{priors_m_df} is the canonical container for datasets used to fit frequentist/hierarchical models whose
#' parameter estimates become informative priors for subsequent Bayesian selection (see \code{run_ss_backtest()}).
#' It inherits all slots from \code{\link{meta_dataframe-class}} and enforces structural and content constraints required by
#' the frequentist fitting helpers (e.g. \code{derive_informative_priors_from_data()}, \code{fit_frequentist_hierarchical_model()}).
#'
#' @section Validity:
#' - No missing values are allowed in \code{data} (all NA values cause construction to fail).
#' - The data must contain the columns \code{return}, \code{theme}, and \code{market_factor_proxy} (these names must appear among \code{colnames(data)}).
#' Parent-class validation (first three columns \code{id}, \code{tickers}, \code{dates}; types; unique ids; etc.) also applies.
#'
#' @slot data A \code{data.frame} containing returns and explanatory columns; must include \code{return}, \code{theme}, and \code{market_factor_proxy}.
#' @slot workflow Inherited: list describing preprocessing and modeling steps that produced the priors data.
#' @slot signals Inherited: names of columns considered as signals / grouping variables.
#' @slot unique_dates, unique_tickers, n_obs, current_date, meta_dataframe_name Inherited summary slots.
#'
#' @details
#' Typical workflow: build a \code{priors_m_df} from historical returns (possibly from another geography or period),
#' pass it to \code{derive_informative_priors_from_data()} which fits frequentist/hierarchical models and returns parameter estimates
#' used as priors for Bayesian inference in \code{run_ss_backtest()}. Ensuring no missing values and the presence of the required columns
#' allows stable frequentist estimation and correct prior derivation.
#'
#' @examples
#' \dontrun{
#' df <- data.frame(
#'   id = c("A-2026-01-01","B-2026-01-01"),
#'   tickers = c("A","B"),
#'   dates = as.Date(c("2026-01-01","2026-01-01")),
#'   return = c(0.01, -0.02),
#'   theme = c("Value","Value"),
#'   market_factor_proxy = c(0.003, 0.004),
#'   stringsAsFactors = FALSE
#' )
#' pri <- new(
#'   "priors_m_df",
#'   data = df,
#'   workflow = list(step = "prepare_priors"),
#'   signals = c("theme"),
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "priors_example"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, \code{\link{derive_informative_priors_from_data}}, \code{\link{run_ss_backtest}}
#' @name priors_m_df-class
#' @rdname priors_m_df-class
#' @aliases priors_m_df
#' @exportClass priors_m_df
setClass(
  "priors_m_df",
  contains = "meta_dataframe",
  validity = function(object) {

    if (any(object@data %>% apply(2, function(x) any(is.na(x))))){
      stop("Data contains missing values")
    }

    if (!any(colnames(object@data) %in% c("return", "theme", "market_factor_proxy"))){
      stop("Data does not contain the required columns 'return', 'theme', and 'market_factor_proxy'")
    }
  }
)

#' signal_universe_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} that represents a universe of backtested signals (strategies).
#'
#' @description
#' \code{signal_universe_m_df} stores performance summaries for a set of signals (each row = one signal/strategy).
#' It inverts the usual \code{meta_dataframe} layout: instead of each row being a stock-date observation and
#' columns being signals/features, each row is a signal/strategy and columns are performance metrics or attributes
#' (e.g. IR, alpha, p_value, theme, is_eligible). This object is the canonical input/output for functions that
#' summarize, rank and select signals after backtests (for example \code{summarize_performance()}, selection heuristics,
#' or meta-model training).
#'
#' @details
#' - The parent-class structural rules still apply: \code{data} must be a \code{data.frame} whose first three columns are
#'   \code{id}, \code{tickers}, \code{dates} (here \code{tickers} typically stores the signal identifier or strategy name,
#'   and \code{dates} represents the evaluation date for the performance metrics). The \code{id} column is expected to be
#'   \code{paste0(tickers, "-", dates)} so objects remain compatible with the rest of the package.
#' - Typical performance columns: \code{IR}, \code{alpha}, \code{alpha_se}, \code{p_value}, \code{turnover}, \code{theme},
#'   \code{benchmark_return}, etc.
#' - Eligibility-related columns:
#'   \itemize{
#'     \item \code{pre_eligible_signals} — logical (or integer 0/1) indicating whether the signal passed initial, signal-level filters (data sufficiency, minimum history, etc.).
#'     \item \code{is_eligible} — logical indicating final eligibility for selection in signal-selection pipelines (after rules, thresholds, and cross-signal constraints are applied).
#'     \item \code{eligibility_reason} (optional) — character describing why a signal was excluded (if present).
#'   }
#' - Use \code{summarize_performance()} (or the package helper that builds signal universes) to construct valid objects;
#'   low-level creation must still respect \code{meta_dataframe} validation (id/tickers/dates ordering, types, uniqueness).
#'
#' @slot data A \code{data.frame} where each row is a backtested signal/strategy and columns are performance metrics, attributes and eligibility flags.
#' @slot ss_backtest_workflow \code{ANY}: the signal-selection backtest workflow metadata attached to this universe (may be \code{NULL}).
#' @slot workflow Inherited: history of steps that produced the signal-universe (e.g. backtest parameters, resampling choices).
#' @slot signals Inherited: typically identifies which columns to treat as signal identifiers or the metrics of interest.
#' @slot unique_dates Inherited: number of distinct dates.
#' @slot unique_tickers Inherited: number of distinct signal identifiers.
#' @slot n_obs Inherited: total number of rows (signals).
#' @slot current_date Inherited: reference/current date for the object.
#' @slot meta_dataframe_name Inherited: short identifier for the object.
#'
#' @examples
#' \dontrun{
#' df <- data.frame(
#'   id = c("earnings_yield-2026-07-01", "free_cash_flow_yield-2026-07-01"),
#'   tickers = c("earnings_yield", "free_cash_flow_yield"), # here: signal names
#'   dates = as.Date(c("2026-07-01", "2026-07-01")),
#'   IR = c(1.2, 0.8),
#'   alpha = c(0.015, 0.008),
#'   p_value = c(0.02, 0.10),
#'   theme = c("Value", "Value"),
#'   pre_eligible_signals = c(TRUE, TRUE),
#'   is_eligible = c(TRUE, FALSE),
#'   stringsAsFactors = FALSE
#' )
#'
#' su <- new(
#'   "signal_universe_m_df",
#'   data = df,
#'   workflow = list(step = "summarize_performance()"),
#'   signals = c("earnings_yield","free_cash_flow_yield"),
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "signal_universe_example"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, \code{\link{summarize_performance}}, \code{\link{run_sb_backtest}}
#' @name signal_universe_m_df-class
#' @rdname signal_universe_m_df-class
#' @aliases signal_universe_m_df
#' @exportClass signal_universe_m_df
setClass(
  "signal_universe_m_df",
  slots = c(
    ss_backtest_workflow = "ANY"
  ),
  contains = "meta_dataframe",
  validity = function(object) {

    #Check for valid column names
    valid_performance_metrics_names <- c(
      "arith_mean_ret", "geom_mean_ret", "ann_ret", "std_dev", "ann_std_dev",
      "semi_dev", "down_dev", "dd_dev", "down_freq", "exp_short", "pain", "ulcer", "max_dd", "skew", "kurt",
      "sharpe_ratio", "ann_sharpe_ratio", "sharpe_ratio_semi_dev", "sortino_ratio", "ann_burke_ratio",
      "inv_d_ratio", "sharpe_ratio_exp_short", "ann_pain_ratio", "ann_martin_ratio", "ann_calmar_ratio",
      "ann_adj_sharpe_ratio", "omega", "rachev_ratio", "avg_dd_rec", "avg_dd_length", "hurst", "min_track_record",
      "prob_sharpe_ratio", "modigliani", "ann_modigliani",
      "act_arith_mean_ret", "act_geom_mean_ret", "act_ann_ret", "track_err", "ann_track_err",
      "act_semi_dev", "act_down_dev", "act_dd_dev", "act_down_freq", "act_exp_short", "act_pain", "act_ulcer",
      "act_max_dd", "act_skew", "act_kurt", "info_ratio", "ann_info_ratio", "info_ratio_semi_dev",
      "act_sortino_ratio", "act_ann_burke_ratio", "act_inv_d_ratio", "info_ratio_exp_short", "act_ann_pain_ratio",
      "act_ann_martin_ratio", "act_ann_calmar_ratio", "ann_adj_info_ratio", "act_omega", "act_rachev_ratio",
      "act_avg_dd_rec", "act_avg_dd_length", "act_hurst", "act_min_track_record", "prob_info_ratio",
      "act_modigliani", "act_ann_modigliani",
      "alpha", "theme_alpha", "individual_alpha", "alpha_se", "beta", "theme_beta", "individual_beta", "specific_risk",
      "alpha_t_stat", "treynor_ratio", "appraisal_ratio", "p_value",
      "posterior_theme_alpha", "posterior_individual_alpha", "posterior_alpha_se", "posterior_theme_beta", "posterior_individual_beta",
      "posterior_specific_risk", "posterior_alpha_t_stat", "posterior_treynor_ratio", "posterior_appraisal_ratio", "pd_theme_alpha", "pd_alpha"
    )

    # Check if columns adhere to expectations
    colnames <- colnames(object@data)

    if(any(!colnames %in% c("id", "tickers", "dates", valid_performance_metrics_names, "adjusted_p_value", "pre_eligible_assets", "is_eligible",
                            "theme", "theme_ss_bench_weights", "theme_sb_bench_weights"))){
      message("User-inputed metrics were identified in signal_universe_m_df object")
    }

    if(any(!c("pre_eligible_assets", "is_eligible") %in% colnames)){
      return("signal_universe_m_df object must contain pre_eligible_assets and is_eligible columns.")
    }

    if(any(!c("theme_ss_bench_weights", "theme_sb_bench_weights", "theme") %in% colnames)){
      return("signal_universe_m_df object must contain theme_ss_bench_weights, theme_sb_bench_weights and theme columns.")
    }

    # If all checks pass
    TRUE
  }
)

#' oos_sb_outputs_m_df-class
#'
#' Out-of-sample Signal-Blending backtest outputs container (S4).
#'
#' @description
#' \code{oos_sb_outputs_m_df} extends \code{\link{meta_dataframe-class}} to represent out-of-sample
#' predictions produced by the signal-blending backtest pipeline (\code{run_sb_backtest()}). It stores
#' target values, model predictions and the associated errors together with the usual workflow metadata.
#'
#' @section Validity:
#' Objects must satisfy parent-class checks plus:
#' - \code{data} must include the columns \code{id}, \code{tickers}, \code{dates}, \code{target}, \code{pred}, and \code{error}.
#' - For rows where \code{target} is not \code{NA}, \code{error} must equal \code{target - pred}.
#' - For rows where both \code{target} and \code{pred} are \code{NA}, \code{error} must be \code{NA}.
#'
#' @slot sb_backtest_workflow Any. A record (usually a list) describing the out-of-sample backtest workflow and parameters used to produce the outputs.
#' @slot data A data.frame containing the observations (first three columns: id, tickers, dates).
#' @slot workflow ANY. Record of preprocessing/backtest workflow that produced this object.
#' @slot signals character. Names of columns in data that represent signals/metrics.
#' @slot unique_dates numeric. Number of distinct dates in data.
#' @slot unique_tickers numeric. Number of distinct tickers in data.
#' @slot n_obs numeric. Total number of observations (rows) in data.
#' @slot current_date Date. Reference/current date for the object.
#' @slot meta_dataframe_name character. Short identifier for this meta_dataframe instance.
#'
#' @details
#' This class is the canonical return type for out-of-sample evaluation routines in the signal-blending
#' workflow. Keeping \code{target}, \code{pred}, and \code{error} aligned and validated enables downstream
#' aggregation, performance reporting and diagnostics to rely on consistent semantics.
#'
#' @examples
#' \dontrun{
#' df <- data.frame(
#'   id = c("A-2026-07-01","B-2026-07-01"),
#'   tickers = c("A","B"),
#'   dates = as.Date(c("2026-07-01","2026-07-01")),
#'   target = c(0.02, NA),
#'   pred = c(0.015, NA),
#'   error = c(0.005, NA),
#'   stringsAsFactors = FALSE
#' )
#' oos <- new(
#'   "oos_sb_outputs_m_df",
#'   data = df,
#'   workflow = list(step = "oos_evaluate"),
#'   signals = character(),
#'   sb_backtest_workflow = list(params = "example"),
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "oos_example"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, \code{\link{run_sb_backtest}}, \code{\link{signal_universe_m_df-class}}
#' @name oos_sb_outputs_m_df-class
#' @rdname oos_sb_outputs_m_df-class
#' @aliases oos_sb_outputs_m_df
#' @exportClass oos_sb_outputs_m_df
setClass(
  "oos_sb_outputs_m_df",
  contains = "meta_dataframe",
  slots = c(
    sb_backtest_workflow = "ANY"
  ),
  validity = function(object) {
    #Colnames adherence
    if(!any(colnames(object@data) == c("id", "tickers", "dates", "target", "pred", "error"))){
      stop("Column names do not adhere to expected oos_sb_outputs_m_df object")
    }
    # Check if 1) target not NA, error is target - pred 2) target NA, error is also NA
    valid_indices <- !(is.na(object@data$target))

    # Check for incorrect error values where valid indices exist
    if (any((object@data$target[valid_indices] - object@data$pred[valid_indices]) != object@data$error[valid_indices],
            na.rm = TRUE)) {
      stop("Error values do not match target - pred where target and pred are not both NA.")
    }

    # Check if both target and pred are NA, and error should also be NA
    if (any(is.na(object@data$target) & is.na(object@data$pred) & !is.na(object@data$error))) {
      stop("Error should be NA when both target and pred are NA.")
    }

  }
)


#' stock_universe_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} representing a stock-level universe used for portfolio construction.
#'
#' @description
#' \code{stock_universe_m_df} is the canonical container for per-asset expected-return scores and eligibility flags used by portfolio construction and backtesting helpers (e.g. \code{derive_stock_universe_m_d_ref}, \code{select_universe}, \code{construct_portfolio}). It derives from \code{\link{meta_dataframe-class}} and carries additional metadata about the portfolio/backtest workflow.
#'
#' @slot data A data.frame (first three columns: id, tickers, dates). Must also include pre_eligible_assets, is_eligible, and exp_ret_score.
#' @slot workflow ANY. Record of preprocessing / backtest workflow that produced this object.
#' @slot signals character. Names of columns in data that represent signals / metrics.
#' @slot unique_dates numeric. Number of distinct dates in data.
#' @slot unique_tickers numeric. Number of distinct tickers in data.
#' @slot n_obs numeric. Total number of observations (rows) in data.
#' @slot current_date Date. Reference/current date for the object.
#' @slot meta_dataframe_name character. Short identifier for this meta_dataframe instance.
#' @slot port_backtest_workflow ANY. Metadata describing portfolio/backtest parameters used to build the stock universe.
#'
#' @section Validity:
#' Objects must satisfy parent-class validation and must include the columns \code{pre_eligible_assets}, \code{is_eligible}, and \code{exp_ret_score}. If a scaler is used, \code{exp_ret_score} is the post-scaling score; when only raw signals/predictions are used it equals the raw expected-return score. Typical construction is via \code{derive_stock_universe_m_d_ref()} which enforces additional checks (mutual exclusivity of inputs, scaler/shrinkage semantics, winsorization).
#'
#' @details
#' - \code{pre_eligible_assets} indicates stocks that pass initial asset-level filters before portfolio rules are applied.
#' - \code{is_eligible} is a logical indicating final eligibility for portfolio inclusion.
#' - \code{exp_ret_score} is numeric and used to rank or weight assets; it may be derived from out-of-sample predictions or chosen signal metrics and optionally scaled by a \code{scaler}.
#'
#' @examples
#' \dontrun{
#' df <- data.frame(
#'   id = c("A-2026-07-01","B-2026-07-01"),
#'   tickers = c("A","B"),
#'   dates = as.Date(c("2026-07-01","2026-07-01")),
#'   pre_eligible_assets = c(TRUE, TRUE),
#'   is_eligible = c(TRUE, FALSE),
#'   exp_ret_score = c(0.12, -0.03),
#'   stringsAsFactors = FALSE
#' )
#' su <- new(
#'   "stock_universe_m_df",
#'   data = df,
#'   workflow = list(step = "derive_stock_universe"),
#'   signals = character(),
#'   port_backtest_workflow = list(params = "example"),
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "stock_universe_example"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, \code{\link{signal_universe_m_df-class}}, \code{\link{derive_stock_universe_m_d_ref}}
#' @name stock_universe_m_df-class
#' @rdname stock_universe_m_df-class
#' @aliases stock_universe_m_df
#' @exportClass stock_universe_m_df
setClass(
  "stock_universe_m_df",
  slots = c(
    port_backtest_workflow = "ANY"
  ),
  contains = "meta_dataframe",
  validity = function(object) {

    #Check for exp_ret_score, pre_eligible_assets and is_eligible
    colnames <- colnames(object@data)

    if(any(!c("pre_eligible_assets", "is_eligible", "exp_ret_score") %in% colnames)){
      return("stock_universe_m_df object must contain exp_ret_score, pre_eligible_assets and is_eligible columns.")
    }

    # If all checks pass
    TRUE
  }
)


#' port_universe_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} representing a universe of already-backtested
#' portfolios, used as the input to a meta-portfolio allocation.
#'
#' @description
#' \code{port_universe_m_df} is the meta-level analogue of \code{\link{stock_universe_m_df-class}}:
#' each row is one base portfolio on one date, and each column is a characteristic of that
#' portfolio that could be used to set its meta weight. It is produced by
#' \code{\link{derive_port_universe_m_df}} from a \code{\link{port_backtest_cohort-class}}.
#'
#' @section Column families:
#' \describe{
#'   \item{portfolio statistics}{Carried over unchanged from each base backtest's
#'     \code{port_stats_m_df}, filtered to one return basis. These mix two kinds of number under
#'     similar names: figures such as \code{track_err} and \code{info_ratio} are computed from a
#'     realized return series, while \code{act_risk} and \code{IR} are computed from the
#'     portfolio's positions and a covariance matrix at the formation date. Selecting one where
#'     the other was intended silently changes what a meta allocation optimizes, so
#'     \code{\link{message_meta_score_basis}} announces which kind a chosen score is.}
#'   \item{\code{avg_}}{Running average of a realized cost or turnover figure, over cost
#'     observations strictly preceding the row's date.}
#'   \item{\code{metric_}}{Weight-aggregated custom stock metric at the row's date.}
#' }
#' Base statistics are produced only on base rebalance dates and are carried forward to
#' intervening dates. \code{stats_age_months} reports how stale each row is; a value greater than
#' zero means the statistics were formed at an earlier date, which matters most for risk figures.
#'
#' @section Validity:
#' Objects must satisfy parent-class validation and additionally:
#' \itemize{
#'   \item every column other than \code{id}, \code{tickers} and \code{dates} must be numeric;
#'   \item \code{stats_age_months} must be present;
#'   \item a column named \code{exp_ret_score} must \strong{not} be present. The meta score is
#'     created downstream by \code{\link{derive_stock_universe_m_d_ref}} from the user's chosen
#'     metric, so its presence here would mean a characteristic was silently promoted to the score.
#' }
#' Unlike \code{stock_universe_m_df}, \code{pre_eligible_assets} and \code{is_eligible} are
#' \emph{not} required: this object is built before \code{\link{classify_investment_universe}} runs.
#'
#' @slot port_metabacktest_workflow ANY. Metadata describing how the universe was derived
#'   (source cohort, return basis, cost window, dates covered).
#'
#' @seealso \code{\link{stock_universe_m_df-class}}, \code{\link{port_backtest_cohort-class}},
#'   \code{\link{derive_port_universe_m_df}}
#' @name port_universe_m_df-class
#' @rdname port_universe_m_df-class
#' @aliases port_universe_m_df
#' @exportClass port_universe_m_df
setClass(
  "port_universe_m_df",
  slots = c(
    port_metabacktest_workflow = "ANY"
  ),
  contains = "meta_dataframe",
  validity = function(object) {

    colnames <- colnames(object@data)
    value_cols <- setdiff(colnames, c("id", "tickers", "dates"))

    #The meta score is derived downstream; a column with this name here would mean an ordinary
    #characteristic was silently promoted to the expected-return score
    if ("exp_ret_score" %in% colnames) {
      return(paste0("port_universe_m_df must not contain an 'exp_ret_score' column. ",
                    "The meta score is created downstream from the chosen metric."))
    }

    if (!"stats_age_months" %in% colnames) {
      return("port_universe_m_df object must contain a stats_age_months column.")
    }

    if (length(value_cols) > 0 &&
        !all(vapply(object@data[value_cols], is.numeric, logical(1)))) {
      return("All columns of port_universe_m_df other than id, tickers and dates must be numeric.")
    }

    # If all checks pass
    TRUE
  }
)

#' weights_m_df-class
#'
#' An S4 subclass of \code{meta_dataframe} representing weight matrices used for portfolio construction.
#'
#' @description
#' \code{weights_m_df} stores per-asset weight columns (benchmarks, strategy weights, etc.) aligned with the canonical
#' \code{meta_dataframe} layout (rows = asset-date observations). It enforces numeric weight bounds and performs per-date
#' checks that group sums are approximately 1 (with tolerance).
#'
#' @section Validity:
#' Objects must satisfy parent-class validation and additionally:
#' - All columns except \code{id}, \code{tickers}, and \code{dates} must be numeric and lie between 0 and 1.
#' - For each date and weight-variable the sum of weights is checked; a tolerance of 0.1 is used and violations
#'   emit a warning listing problematic variable-date combinations (failures do not currently abort construction).
#'
#' @slot data A \code{data.frame} (first three columns: \code{id}, \code{tickers}, \code{dates}). Remaining columns are numeric positive weight vectors.
#' @slot workflow ANY. Record of preprocessing / portfolio workflow that produced this object.
#' @slot signals character. Names of columns in \code{data} that represent signals/metrics (may be empty for weights objects).
#' @slot unique_dates numeric. Number of distinct dates in \code{data}.
#' @slot unique_tickers numeric. Number of distinct tickers in \code{data}.
#' @slot n_obs numeric. Total number of observations (rows) in \code{data}.
#' @slot current_date Date. Reference/current date for the object.
#' @slot meta_dataframe_name character. Short identifier for this meta_dataframe instance.
#'
#' @details
#' This class is intended as the canonical container for portfolio weight matrices produced by selection and
#' portfolio-construction helpers. The per-date sum check helps catch data or aggregation errors (bench_weights-only
#' deviations are surfaced as warnings to allow tolerant downstream workflows).
#'
#' @examples
#' \dontrun{
#' df <- data.frame(
#'   id = c("A-2026-07-01","B-2026-07-01"),
#'   tickers = c("A","B"),
#'   dates = as.Date(c("2026-07-01","2026-07-01")),
#'   bench_weights = c(0.6, 0.4),
#'   strategy_weights = c(0.7, 0.3),
#'   stringsAsFactors = FALSE
#' )
#' w <- new(
#'   "weights_m_df",
#'   data = df,
#'   workflow = list(step = "construct_weights"),
#'   signals = character(),
#'   unique_dates = length(unique(df$dates)),
#'   unique_tickers = length(unique(df$tickers)),
#'   n_obs = nrow(df),
#'   current_date = Sys.Date(),
#'   meta_dataframe_name = "weights_example"
#' )
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}, portfolio construction and backtest helpers
#' @name weights_m_df-class
#' @rdname weights_m_df-class
#' @aliases weights_m_df
#' @exportClass weights_m_df
setClass(
  "weights_m_df",
  contains = "meta_dataframe",
  validity = function(object) {


    #Check that all columns except for id, tickers and dates are between 0 and 1
    if(any(apply(object@data %>% dplyr::select(-id, -tickers, -dates), 2, function(x) any(x < 0 | x > 1)))){
      stop("All columns except for id, tickers and dates must be between 0 and 1.")
    }

    #Check if weights sum to 1
    # Pivot the data longer (all columns except id, tickers, dates)
    res_long <- object@data %>%
      tidyr::pivot_longer(
        cols = -c(id, tickers, dates),
        names_to = "variable",
        values_to = "weight"
      ) %>%
      dplyr::group_by(dates, variable) %>%
      dplyr::summarise(sum_w = sum(weight), .groups = "drop") %>%
      dplyr::mutate(check_sum = abs(sum_w - 1) < 0.1)

    # Check if any group does not satisfy the condition
    if(any(!res_long$check_sum)) {
      problematic <- res_long %>% dplyr::filter(!check_sum)

      ##If problematic$variable is only bench_weights, issue a warning instead of stopping
      warning(paste("Weights do not sum to 1 for the following variable-date combinations:",
                    paste0(problematic$variable, " at ", problematic$dates, collapse = "; ")))

    }

    return(TRUE)


  }
)




#tickers_catalog------------------------------------------------------

#' tickers_catalog-class
#'
#' An S4 class to store stock metadata and bookkeeping for ticker lifecycle events
#' (listings, delistings, ticker changes).
#'
#' @slot catalog A \code{data.frame} with one row per ticker and columns at least:
#'   \code{tickers}, \code{tickers_first_quote} (Date), \code{tickers_last_quote} (Date),
#'   and \code{perm_id}.
#' @slot tickers Character vector of tickers.
#' @slot perm_id Character vector of stable unique identifiers (named by \code{tickers}).
#' @slot tickers_first_quote Date vector (first observed trading date per ticker).
#' @slot tickers_last_quote Date vector (last observed trading date per ticker).
#' @slot untraded Character vector of tickers with no trading dates (both dates NA).
#' @slot delisted Character vector of delisted tickers (last quote older than tolerance window).
#' @slot listed Character vector of currently listed tickers.
#' @slot old Character vector of tickers that were renamed/changed.
#' @slot current_date A single \code{Date} representing the catalogue's current reference date.
#' @slot meta_dataframe_name Character: name of the source meta_dataframe (usually the raw features input).
#' @slot n_days_tolerance Numeric: number of days tolerance used to decide delisting vs listed status.
#' @slot ticker_change_history Any: free-form record of ticker-change operations (may be \code{NULL}).
#'
#' @details
#' The class centralizes per-ticker metadata used by universe construction and backtests.
#' \code{perm_id} is intended to be stable across ticker renames (constructed from ticker + first-quote date).
#' The validity method enforces mutual exclusivity of classification vectors (a ticker cannot be simultaneously
#' \code{listed}, \code{delisted}, \code{untraded} or \code{old}), consistent lengths, a single \code{current_date},
#' and that \code{catalog} is ordered by \code{perm_id} with \code{perm_id} names matching \code{tickers}.
#'
#' @section Common validity errors:
#' - "A stock can't be untraded and delisted." — overlapping classifications found.
#' - "Length of listed + delisted + untraded + old does not equal length of tickers." — partitioning mismatch.
#' - "perm_id must be named according to tickers." — naming mismatch between \code{perm_id} and \code{tickers}.
#'
#' @examples
#' \dontrun{
#' df_first <- data.frame(tickers = c("A", "B"),
#'                        date_first_quote = as.Date(c("2020-01-01","2020-06-01")))
#' df_last  <- data.frame(tickers = c("A", "B"),
#'                        date_last_quote  = as.Date(c(NA, "2026-06-30")))
#' tickers_catalog_obj <- create_tickers_catalog(raw_features_m_df = raw_mdf,
#'                                               date_first_quote = df_first,
#'                                               date_last_quote  = df_last,
#'                                               n_days_tolerance = 10)
#' }
#'
#' @seealso \code{\link{meta_dataframe-class}}
#' @name tickers_catalog-class
#' @rdname tickers_catalog-class
#' @aliases tickers_catalog
#' @exportClass tickers_catalog
setClass(
  "tickers_catalog",
  slots = list(
    catalog = "data.frame",
    tickers = "character",
    perm_id = "character",
    tickers_first_quote = "Date",
    tickers_last_quote = "Date",
    untraded = "character",
    delisted = "character",
    listed = "character",
    old = "character",
    current_date = "Date",
    meta_dataframe_name = "character",
    n_days_tolerance = "numeric",
    ticker_change_history = "ANY"
  ),
  validity = function(object){

    #Check that a stock can't be untraded and delisted
    if(length(intersect(object@untraded, object@delisted)) > 0){
      stop("A stock can't be untraded and delisted.")
    }

    #Check that a stock can't be untraded and listed
    if(length(intersect(object@untraded, object@listed)) > 0){
      stop("A stock can't be untraded and listed.")
    }

    #Check that a stock can't be delisted and listed
    if(length(intersect(object@delisted, object@listed)) > 0){
      stop("A stock can't be delisted and listed.")
    }

    #Check that a stock can't be delisted and old
    if(length(intersect(object@delisted, object@old)) > 0){
      stop("A stock can't be delisted and old.")
    }

    #Check that a stock can't be listed and old
    if(length(intersect(object@listed, object@old)) > 0){
      stop("A stock can't be listed and old.")
    }

    #Check that a stock can't be untraded and old
    if(length(intersect(object@untraded, object@old)) > 0){
      stop("A stock can't be untraded and old.")
    }

    #Check that length of tickers equals perm_id
    if(length(object@tickers) != length(object@perm_id)){
      stop("Length of tickers does not equal length of perm_id.")
    }

    #Check that length of listed + delisted + untraded + old equals tickers
    if(length(object@listed) + length(object@delisted) + length(object@untraded) + length(object@old) != length(object@tickers)){
      stop("Length of listed + delisted + untraded + old does not equal length of tickers.")
    }

    #Check current date length
    if(length(object@current_date) != 1){
      stop("current_date must be a single Date value.")
    }

    #Check that catalog is ordered by perm_id
    if(!identical(object@catalog$perm_id, unname(object@perm_id))){
      stop("catalog must be ordered by perm_id.")
    }

    #Check that perm_id is named according to tickers
    if(!identical(names(object@perm_id), object@tickers)){
      stop("perm_id must be named according to tickers.")
    }

  }
)







#meta_xts---------------------------------------------------------------
#' An S4 Class Storing a Time Series Plus Metadata
#'
#' @description
#' Base container class for an \code{xts} time series together with the metadata
#' needed to track its provenance and shape. Not normally instantiated directly;
#' use \code{\link{create_meta_xts}()}, which builds the appropriate subclass
#' (\code{\link{returns_meta_xts-class}} or \code{\link{metrics_meta_xts-class}})
#' for you.
#'
#' @slot data An \code{xts} object containing the time series.
#' @slot meta_xts_name Character. A label or ID for the series.
#' @slot metric_name Character. Name of the metric/return series being stored.
#' @slot workflow ANY. A placeholder for user-defined workflow/pipeline objects
#'   (e.g. a log of the processing steps that produced \code{data}).
#' @slot n_dates Numeric. Number of rows in \code{data}.
#' @slot source Character. Origin of each column, one entry per column of \code{data}.
#' @slot frequency Character. Detected time frequency (e.g. \code{"daily"},
#'   \code{"weekly"}, \code{"monthly"}, \code{"yearly"}).
#' @slot current_date Date. The most recent date in \code{data}.
#'
#' @section Validity:
#' \itemize{
#'   \item Dates in \code{data} must be strictly increasing (no duplicated timestamps).
#'   \item \code{n_dates} must equal \code{nrow(data)}.
#'   \item \code{source} must have one entry per column of \code{data}.
#'   \item Column names in \code{data} must not be duplicated.
#' }
#'
#' @seealso \code{\link{create_meta_xts}}, \code{\link{returns_meta_xts-class}},
#'   \code{\link{metrics_meta_xts-class}}, \code{\link{meta_dataframe-class}}
#'
#' @export
setClass(
  Class = "meta_xts",
  slots = c(
    data          = "xts",
    meta_xts_name = "character",
    metric_name   = "character",
    workflow      = "ANY",
    n_dates       = "numeric",
    source        = "character",
    frequency     = "character",
    current_date  = "Date"
  ),
  validity = function(object) {
    # The underlying data is in object@data
    main_xts <- object@data

    idx <- zoo::index(main_xts)
    if (!all(diff(idx) > 0)) {
      return("Dates must be strictly increasing (oldest to newest).")
    }
    if (object@n_dates != nrow(main_xts)) {
      return("Slot 'n_dates' does not match the number of rows in the xts slot 'data'.")
    }
    current_colnames <- colnames(main_xts)
    ncols <- length(current_colnames)
    if (length(object@source) != ncols) {
      return("Slot 'source' must have the same length as the number of columns in slot 'data'.")
    }

    if (length(unique(idx)) < length(idx)) {
      return("There are duplicated rows (time index) in 'data'.")
    }
    if (anyDuplicated(current_colnames) > 0) {
      return("There are duplicated column names in 'data'.")
    }

    return(TRUE)
  }
)

#' An S4 Subclass of `meta_xts` for Return Series (No Holes Allowed)
#'
#' @description
#' Stores asset (or portfolio) return time series. Extends \code{\link{meta_xts-class}}
#' with asset identity metadata and enforces the invariants that make a return
#' series usable in backtests: consecutive dates and, for portfolios, no missing values.
#'
#' @slot asset_type Character. Type of asset (e.g. \code{"stock"}, \code{"bond"},
#'   \code{"ports"} for portfolios).
#' @slot assets Character. Column names of \code{data} (one per asset).
#' @slot n_assets Numeric. Number of asset columns.
#'
#' @section Return convention:
#' Values are expected on a **percent scale** (e.g. \code{2.0} for 2\%, not
#' \code{0.02}). If the median absolute value in \code{data} is below 1, validity
#' emits a \code{warning()} flagging a probable decimal-scale input, since
#' downstream performance functions assume percent scale.
#'
#' @section Validity:
#' \itemize{
#'   \item Inherits all checks from \code{\link{meta_xts-class}}.
#'   \item Dates should be (approximately) consecutive for the detected
#'     frequency; a large proportion of gaps raises an error.
#'   \item \code{n_assets} must equal \code{ncol(data)}, and \code{assets} must
#'     match \code{colnames(data)}.
#'   \item Missing values trigger a \code{warning()} for individual assets, but
#'     are a hard \code{stop()} when \code{asset_type == "ports"} -- a portfolio
#'     return series is not allowed to have gaps.
#'   \item Emits a \code{message()} reporting the detected frequency, useful
#'     because detection can be unreliable on short or irregular series.
#' }
#'
#' @seealso \code{\link{meta_xts-class}}, \code{\link{metrics_meta_xts-class}}, \code{\link{create_meta_xts}}
#'
#' @export
setClass(
  Class = "returns_meta_xts",
  contains = "meta_xts",
  slots = c(
    asset_type = "character",
    assets   = "character",
    n_assets = "numeric"
  ),
  validity = function(object) {
    main_xts <- object@data
    idx <- zoo::index(main_xts)
    freq_info <- suppressWarnings(xts::periodicity(main_xts))
    discovered_scale <- freq_info$scale

    # Check for consecutive dates
    if (discovered_scale %in% c("daily", "weekly", "monthly", "quarterly", "yearly")) {
      full_seq <- switch(
        discovered_scale,
        "daily"     = seq(idx[1], idx[length(idx)], by = "day"),
        "weekly"    = seq(idx[1], idx[length(idx)], by = "week"),
        "monthly"   = seq(idx[1], idx[length(idx)], by = "month"),
        "quarterly" = seq(idx[1], idx[length(idx)], by = "quarter"),
        "yearly"    = seq(idx[1], idx[length(idx)], by = "year")
      )
      if (length(full_seq)*0.5 > length(idx)) {
        return(paste0("Dates are probably not consecutive for detected frequency: ", discovered_scale, "."))
      }
    }

    all_values <- as.numeric(main_xts)
    if (median(abs(all_values[!is.na(all_values)])) < 1) {
      warning("Data might be in decimal form (e.g. 0.02 for 2%). ",
              "Some functions depend on a percent representation (use 2.0 instead of 0.02), but this check might ",
              "be wrong. Please confirm if data format is right.")
    }

    # Check assets & n_assets
    if (object@n_assets != ncol(main_xts)) {
      return("Slot 'n_assets' does not match the number of columns in the xts slot 'data'.")
    }
    current_colnames <- colnames(main_xts)
    if (!identical(object@assets, current_colnames)) {
      return("Slot 'assets' does not match the colnames of the xts slot 'data'.")
    }

    #Check for NAs
    if (any(is.na(main_xts))) {
      if(object@asset_type == "ports"){
        #NA Values are forbidden for ports
        stop("There are NA values in the time series.")
      } else {
        warning("There are NA values in the time series.")
      }
    }


    freq_info <- object@frequency
    message("Detected frequency is: ", freq_info)

    return(TRUE)
  }
)

#' An S4 Subclass of `meta_xts` for Metric Series (Holes Allowed)
#'
#' @description
#' Stores arbitrary metric time series (e.g. factor exposures, signals) that are
#' not required to be gap-free, unlike \code{\link{returns_meta_xts-class}}.
#'
#' @slot series Character. Column names of \code{data} (one per metric).
#' @slot n_series Numeric. Number of metric columns.
#'
#' @section Validity:
#' \itemize{
#'   \item Inherits all checks from \code{\link{meta_xts-class}}.
#'   \item \code{n_series} must equal \code{ncol(data)}, and \code{series} must
#'     match \code{colnames(data)}.
#'   \item No check on date consecutiveness -- holes (e.g. from illiquid tickers
#'     or metrics undefined on every date) are expected and allowed.
#' }
#'
#' @seealso \code{\link{meta_xts-class}}, \code{\link{returns_meta_xts-class}}, \code{\link{create_meta_xts}}
#'
#' @export
setClass(
  Class = "metrics_meta_xts",
  contains = "meta_xts",
  slots = c(
    series   = "character",
    n_series = "numeric"
  ),
  validity = function(object) {
    main_xts <- object@data
    if (object@n_series != ncol(main_xts)) {
      return("Slot 'n_series' does not match the number of columns in the xts slot 'data'.")
    }
    current_colnames <- colnames(main_xts)
    if (!identical(object@series, current_colnames)) {
      return("Slot 'series' does not match the colnames of the xts slot 'data'.")
    }
    # No check for consecutive dates (holes allowed).
    return(TRUE)
  }
)


#' Define the transactions_log S4 Class
#'
#' This class enforces that the underlying data is adherent to the output of a
#' port_backtest_workflow
#'
#' @export
setClass(
  "transactions_log",
  slots = c(
    data = "list",
    workflow = "ANY"
  ),
  validity = function(object) {
    #Check that all elements of the list are dataframes
    if(!all(sapply(object@data, is.data.frame))){
      stop("All elements of the list must be dataframes.")
    }
    #Check that all have required colnames
    required_colnames <- c("id", "tickers", "dates", "eop_port_weights", "daily_vol", "bop_port_weights", "obs", "delta", "order", "relative_order_size", "alpha",
                           "lambda", "direct_cost", "market_impact_cost", "total_cost")
    if(!all(sapply(object@data, function(x) all(required_colnames %in% colnames(x))))){
      stop("Column names do not adhere to expected transactions_log object")
    }

    # Check if there are NAs
    if(any(sapply(object@data, function(x) any(is.na(x))))){
      stop("NAs are not allowed in transactions_log object.")
    }

    #Check if alpha and lambda are between 0 and 1 for each element
    if(any(purrr::map_lgl(object@data, function(x) any(x$alpha <= 0 | x$alpha > 1)))){
      stop("Alpha must be between 0 and 1.")
    }
    if(any(purrr::map_lgl(object@data, function(x) any(x$lambda <= 0 | x$lambda > 1)))){
      stop("Lambda must be between 0 and 1.")
    }

    #Check if total_cost equals direct_cost + market_impact_cost for each row
    if(any(purrr::map_lgl(object@data, function(x) any(x$total_cost != x$direct_cost + x$market_impact_cost)))){
      stop("Total cost must equal direct cost + market impact cost.")
    }
  }
)



#hyperparams------------------------------------------------------------
#' Define the `hyper_grid_domain` S4 Class
#'
#' @description
#' Holds the set of hyperparameters (and, once populated by
#' \code{\link{add_hyperparameter}()}, their tuning-method-specific values) that
#' \code{\link{hyper_tune}()} -- invoked internally by \code{\link{run_sb_backtest}()}
#' -- will search over. This class only validates that hyperparameter *names* are
#' recognized; it does not check the *shape* of their values (a numeric vector,
#' a distribution spec, or a bounds pair) -- that shape check belongs to
#' \code{\link{tuning_strategy-class}} and depends on the chosen `tuning_method`.
#'
#' @slot hyperparameter_list A named list, one entry per hyperparameter, drawn from:
#' \itemize{
#'   \item \strong{glmnet}: \code{alpha}, \code{lambda.min.ratio}
#'   \item \strong{rf}: \code{mtry}, \code{num.trees}, \code{max.depth}, \code{min.bucket}
#'   \item \strong{xgb}: \code{min_child_weight}, \code{max_depth}, \code{subsample},
#'     \code{colsample_bytree}, \code{eta}, \code{gamma}, \code{nrounds}
#'   \item \strong{nn}: \code{regularizer_l1}, \code{regularizer_l2}, \code{droprate},
#'     \code{lr}, \code{size_of_batch}, \code{number_of_epochs}
#' }
#'
#' @export
setClass(
  "hyper_grid_domain",
  slots = list(
    hyperparameter_list = "list"
  ), validity = function(object){

    #Check for valid choice in hyperparameter
    if(length(object@hyperparameter_list) != 0){
      valid_hyperparameters <- c("alpha", "lambda.min.ratio", "mtry", "num.trees", "max.depth", "min.bucket", "min_child_weight", "max_depth", "subsample", "colsample_bytree",
                                 "eta", "gamma", "nrounds", "regularizer_l1", "regularizer_l2", "droprate", "lr", "size_of_batch", "number_of_epochs")

      if (any(!names(object@hyperparameter_list) %in% valid_hyperparameters) ){
        return("Invalid choice for hyperparameter. Should be one of alpha, lambda.min.ratio (glmnet), mtry, num.trees, max.depth, min.bucket (rf),
             min_child_weight, max_depth, subsample, colsample_bytree, eta, gamma, nrounds (xgb),
             regularizer_l1, regularizer_l2, droprate, lr, size_of_batch, number_of_epochs (nn)")
      }

    }

  })


#tuning_strat-----------------------------------------------------------

#' Base Class for Hyperparameter Tuning Strategies
#'
#' @description
#' Common slots and validity rules shared by the three tuning-strategy
#' subclasses: \code{\link{grid_search_strategy-class}},
#' \code{\link{random_search_strategy-class}}, and
#' \code{\link{bayesian_opt_strategy-class}}. Not normally instantiated
#' directly; use \code{\link{create_tuning_strategy}()}, which builds the
#' subclass matching \code{tuning_method} for you.
#'
#' @slot tuning_method Character. One of \code{"grid_search"},
#'   \code{"random_search"}, or \code{"bayesian_opt"} -- fixed by the
#'   subclass's \code{prototype}, not meant to be set independently.
#' @slot validation_sample_size Numeric. Size of the validation sample. A
#'   value in \verb{(0, 1)} is treated as a proportion of the training sample
#'   size and rescaled by \code{\link{add_tuning_strategy}()}; a value
#'   \code{>= 1} is used as an absolute observation count.
#' @slot chosen_eval_metric Character. The evaluation metric to optimize;
#'   required (despite the name, \code{NULL} is rejected by validity) and
#'   must be one of \code{"rss"}, \code{"rmse"}, \code{"cp"}, \code{"mae"},
#'   \code{"mphe"}, \code{"mpe"}, \code{"mape"}, \code{"hr"}, \code{"mb"}.
#'   \strong{Caveat:} \code{\link{check_inputs_sb_backtest}()}, the gate used
#'   by \code{\link{run_sb_backtest}()}, only accepts 8 of these 9 values --
#'   \code{"mb"} passes this class's validity but is rejected once the
#'   strategy is actually run.
#' @slot hyper_grid_domain A \code{\link{hyper_grid_domain-class}} object
#'   holding the hyperparameter search space. The required shape of its
#'   \code{hyperparameter_list} slot depends on \code{tuning_method}; see the
#'   relevant subclass.
#' @slot early_stop Numeric or \code{NULL}. Epochs with no improvement before
#'   stopping early; only meaningful for \code{xgb}/\code{nn} algorithms.
#'
#' @section Validity:
#' \itemize{
#'   \item \code{tuning_method} must be one of the three supported methods.
#'   \item \code{chosen_eval_metric} must be non-\code{NULL} and one of the
#'     nine values listed above.
#'   \item \code{hyper_grid_domain@hyperparameter_list} must match the shape
#'     required by \code{tuning_method} (see subclasses).
#' }
#'
#' @export
setClass(
  "tuning_strategy",
  slots = list(
    tuning_method = "character",
    validation_sample_size = "numeric",
    chosen_eval_metric = "character",
    hyper_grid_domain = "hyper_grid_domain",
    early_stop = "ANY"
  ),
  validity = function(object) {
    if (!(object@tuning_method %in% c("grid_search", "random_search", "bayesian_opt"))) {
      return("Invalid tuning_method.")
    }
    if(is.null(object@chosen_eval_metric)){
      stop("chosen_eval_metric can't be missing.")
    }
    valid_eval_metrics <- c("rss", "rmse", "cp", "mae", "mphe", "mpe", "mape", "hr", "mb")
    if (!is.null(object@chosen_eval_metric) && !(object@chosen_eval_metric %in% valid_eval_metrics)) {
      return("Invalid chosen_eval_metric. Choose from 'rss', 'rmse', 'cp', 'mae', 'mphe', 'mpe', 'mape', 'hr', 'mb'.")
    }

    # Validate hyperparameters based on tuning_method

    ##Grid search
    if (object@tuning_method == "grid_search") {
      if (!all(sapply(object@hyper_grid_domain@hyperparameter_list, function(x) is.numeric(x) && is.vector(x)))) {
        stop("For 'grid_search', hyperparameters must be a list of numeric vectors.")
      }

      ##Random search
    }

    else if (object@tuning_method == "random_search") {
      for (name in names(object@hyper_grid_domain@hyperparameter_list)) {
        if (!is.list(object@hyper_grid_domain@hyperparameter_list[[name]]) || !all(c("distribution_choice") %in% names(object@hyper_grid_domain@hyperparameter_list[[name]]))) {
          stop("For 'random_search', each hyperparameters must be a list with 'distribution_choice'.")
        }

        distribution_choice <- object@hyper_grid_domain@hyperparameter_list[[name]]$distribution_choice

        if (is.null(distribution_choice) || !(distribution_choice %in% c("normal", "uniform", "lognormal", "constant"))) {
          stop("distribution_choice must be one of 'normal', 'uniform', 'lognormal', or 'constant'.")
        }

        if (distribution_choice == "constant") {
          if (is.null(object@hyper_grid_domain@hyperparameter_list[[name]]$value) || !is.numeric(object@hyper_grid_domain@hyperparameter_list[[name]]$value)) {
            stop("For 'constant', the second argument must be a numeric vector named 'value'.")
          }
        } else {
          if (!is.null(object@hyper_grid_domain@hyperparameter_list[[name]]$value)) {
            stop("For distributions other than 'constant', do not specify 'value'.")
          }
          pars <- object@hyper_grid_domain@hyperparameter_list[[name]]$pars
          if (is.null(pars) || !is.numeric(pars) || !is.vector(pars)) {
            stop("For distributions, the second argument must be a numeric vector named 'pars'.")
          }

          # Additional checks based on distribution_choice
          if (distribution_choice == "normal") {
            if (!all(names(pars) %in% c("mean", "sd"))) {
              stop("For 'normal', 'pars' must have names 'mean' and 'sd'.")
            }
          } else if (distribution_choice == "uniform") {
            if (!all(names(pars) %in% c("min", "max"))) {
              stop("For 'uniform', 'pars' must have names 'min' and 'max'.");
            }
          } else if (distribution_choice == "lognormal") {
            if (!all(names(pars) %in% c("meanlog", "sdlog"))) {
              stop("For 'lognormal', 'pars' must have names 'meanlog' and 'sdlog'.");
            }
          }
        }
      }
    }

    #Bayesian Optimization
    else if (object@tuning_method == "bayesian_opt") {
      ###Entries are either searched ranges or hyperparameters pinned to a
      ###constant. A constant is declared exactly as under 'random_search' and
      ###is removed from the surrogate's input space at tuning time; it must not
      ###be expressed as a zero-width range, which silently produces an all-NaN
      ###input and still costs a full dimension of search.
      hyperparameter_list <- object@hyper_grid_domain@hyperparameter_list

      is_constant_entry <- sapply(hyperparameter_list,
                                  function(x) is.list(x) && identical(x$distribution_choice, "constant"))

      if (length(hyperparameter_list) != 0) {
        for (name in names(hyperparameter_list)) {
          entry <- hyperparameter_list[[name]]

          if (isTRUE(is_constant_entry[[name]])) {
            ###Finiteness is part of the constraint, not a downstream concern:
            ###NA, NaN and Inf are all numeric of length 1, and letting them
            ###through here defers the failure to the domain checks, where a
            ###comparison against a missing value reports an unrelated error.
            if (is.null(entry$value) || !is.numeric(entry$value) ||
                length(entry$value) != 1 || !is.finite(entry$value)) {
              stop("For 'bayesian_opt', a 'constant' hyperparameter must have a single finite numeric 'value'.")
            }
          } else {
            ###A zero-width range c(x, x) is still accepted here: configurations
            ###written before constants existed use it to pin a hyperparameter.
            ###hyper_tune() leaves such a range in the search space, exactly as
            ###before, and warns that it should be declared as a constant; it is
            ###deliberately not reinterpreted, since that would change the
            ###searched dimension and hence those configurations' results.
            if (!is.numeric(entry) || length(entry) != 2) {
              stop("For 'bayesian_opt', each hyperparameters must be a numeric vector of length 2 representing the bounds, or a constant declared with distribution_choice = 'constant'.")
            }
          }
        }

        if (all(is_constant_entry)) {
          stop("For 'bayesian_opt', at least one hyperparameter must have a range to search over.")
        }
      }
    }

    else {
      stop("Invalid tuning_method. Only 'grid_search', 'random_search', and 'bayesian_opt' are supported.")
    }

    return(TRUE)
  }
)


#' Grid Search Tuning Strategy
#'
#' @description
#' Subclass of \code{\link{tuning_strategy-class}} for grid search: every
#' combination of user-supplied hyperparameter values is evaluated
#' exhaustively (see \code{\link{hyper_tune}()}).
#'
#' @section `hyper_grid_domain` shape:
#' \code{hyper_grid_domain@hyperparameter_list} must be a list of named
#' numeric vectors, one per hyperparameter, each holding the exact values to
#' try (e.g. \code{list(alpha = c(0, 0.5, 1))}).
#'
#' @seealso \code{\link{tuning_strategy-class}} for the inherited slots
#'   (\code{validation_sample_size}, \code{chosen_eval_metric},
#'   \code{hyper_grid_domain}, \code{early_stop}).
#'
#' @export
setClass(
  "grid_search_strategy",
  contains = "tuning_strategy",
  slots = list(),
  prototype = list(tuning_method = "grid_search")
)

#' Random Search Tuning Strategy
#'
#' @description
#' Subclass of \code{\link{tuning_strategy-class}} for random search:
#' hyperparameter values are drawn from user-specified distributions instead
#' of being enumerated exhaustively.
#'
#' @slot n_iter Numeric. Number of random draws generated per hyperparameter
#'   that has a distribution assigned (hyperparameters with a
#'   \code{"constant"} \code{distribution_choice} are exempt). Draws across
#'   different hyperparameters are then combined exhaustively, so for
#'   \code{n_iter = 5} and 2 non-constant hyperparameters the model is
#'   generally evaluated \eqn{5^2 = 25} times.
#'
#' @section `hyper_grid_domain` shape:
#' \code{hyper_grid_domain@hyperparameter_list} must be a list of named
#' lists, one per hyperparameter, each with:
#' \itemize{
#'   \item \code{distribution_choice}: one of \code{"normal"}, \code{"uniform"},
#'     \code{"lognormal"}, or \code{"constant"}.
#'   \item \code{pars}: named numeric vector of distribution parameters
#'     (\code{c(mean, sd)}, \code{c(min, max)}, or \code{c(meanlog, sdlog)}
#'     as appropriate) -- omitted when \code{distribution_choice = "constant"}.
#'   \item \code{value}: a single numeric value, present only when
#'     \code{distribution_choice = "constant"}.
#' }
#'
#' @seealso \code{\link{tuning_strategy-class}} for the inherited slots.
#'
#' @export
setClass(
  "random_search_strategy",
  contains = "tuning_strategy",
  slots = list(
    n_iter = "numeric"
  ),
  prototype = list(tuning_method = "random_search")
)

#' Bayesian Optimization Tuning Strategy
#'
#' @description
#' Subclass of \code{\link{tuning_strategy-class}} for Bayesian optimization
#' via \code{ParBayesianOptimization::bayesOpt()}.
#'
#' @slot n_iter Numeric. Number of evaluations after the initialization phase.
#' @slot acq Character. Acquisition function: \code{"ucb"} (default),
#'   \code{"ei"}, or \code{"poi"}.
#' @slot init_points Numeric. Number of initial random points; must exceed
#'   the number of hyperparameters being tuned.
#' @slot k_iter Numeric. Number of times to sample the scoring function per
#'   epoch. Must be \code{<= n_iter}, and, when running in parallel, is best
#'   set to a multiple of the number of cores (and preferably of \code{n_iter}).
#'
#' @section `hyper_grid_domain` shape:
#' \code{hyper_grid_domain@hyperparameter_list} must be a list of named
#' numeric vectors of length 2, one per hyperparameter, giving its
#' \code{c(lower, upper)} bounds.
#'
#' @section Validity:
#' In addition to the checks inherited from \code{\link{tuning_strategy-class}},
#' \code{acq} must be one of \code{"ucb"}, \code{"ei"}, or \code{"poi"}.
#'
#' @seealso \code{\link{tuning_strategy-class}} for the inherited slots.
#'
#' @export
setClass(
  "bayesian_opt_strategy",
  contains = "tuning_strategy",
  slots = list(
    n_iter = "numeric",
    acq = "character",
    init_points = "numeric",
    k_iter = "numeric"
  ),
  prototype = list(
    tuning_method = "bayesian_opt",
    acq = "ucb"),
  validity = function(object){
    if (!object@acq %in% c("ucb", "ei", "poi")) {
      stop("acq must be one of 'ucb', 'ei', or 'poi'.")
    }
    return(TRUE)
  }
)


#keras------------------------------------------------------------------
#' @title Keras Architecture Parameters
#' @description Class to encapsulate parameters for constructing a Keras neural network architecture.
#'
#' @slot units A numeric vector specifying the number of units (neurons) for each layer.
#' @slot n_layers A numeric value representing the total number of layers in the model.
#' @slot activation A character vector containing the activation functions for each layer.
#' @slot nn_optimizer A character string indicating the optimization algorithm used (length = 1).
#' @slot batch_norm_option A character vector specifying whether to apply batch normalization for each layer.
#' @slot n_ensembles A single integer (>= 1) giving how many independently initialised
#'   networks are trained at refit time and averaged into one forecast. Defaults to 1,
#'   which trains a single network and reproduces the behaviour of earlier versions
#'   exactly. Values above 1 follow the practice of averaging over random
#'   initialisations to remove initialisation variance from the forecast: Gu, Kelly and
#'   Xiu (2020) average 10 networks per topology, Rubesam (2021) averages 50. Applies to
#'   the refit only; hyperparameter tuning always fits a single network.
#'
#' @export
setClass(
  "keras_architecture_parameters",
  slots = list(
    units = "numeric",            # Vector of numeric units per layer
    n_layers = "numeric",         # Total number of layers
    activation = "character",     # Vector of activation functions
    nn_optimizer = "character",    # Optimization algorithm
    batch_norm_option = "logical", # Vector of batch normalization options
    n_ensembles = "numeric"       # Number of independently initialised networks to average
  ),
  ### The prototype keeps objects built by callers that never mention
  ### n_ensembles at the historical single-network behaviour. It does NOT repair
  ### objects deserialised from artifacts written before the slot existed: a
  ### prototype applies at new(), not at load. Reads go through as.list(), which
  ### guards for the missing slot.
  prototype = list(n_ensembles = 1),
  validity = function(object) {
    if (!is.numeric(object@n_ensembles) || length(object@n_ensembles) != 1L ||
        is.na(object@n_ensembles) || !is.finite(object@n_ensembles) ||
        object@n_ensembles < 1 || object@n_ensembles != round(object@n_ensembles)) {
      return("n_ensembles must be a single finite integer >= 1.")
    }
    return(TRUE)
  }
)


#keras_ensemble---------------------------------------------------------
#' @title Ensemble of Independently Initialised Keras Networks
#' @description
#' Holds several trained Keras networks that share an architecture and
#' hyperparameters but differ in their random weight initialisation, and behaves
#' as a single model through its \code{predict} method.
#'
#' @details
#' A single network fit is one draw from a distribution over networks induced by
#' the random initialisation, so its forecast carries initialisation variance
#' that nothing else in the walk-forward scheme removes. Averaging the forecasts
#' of \code{k} independently initialised members reduces that variance component
#' by roughly a factor of \code{k}.
#'
#' Forecasts are averaged, never weights. Hidden units are permutation
#' symmetric, so the weights of independently initialised networks are not
#' comparable coordinate by coordinate and averaging them is meaningless.
#'
#' @slot members A list of trained Keras models, each fitted on the same data with
#'   the same hyperparameters and its own random initialisation.
#'
#' @seealso \code{\link{fit_keras_model}}
#'
#' @export
setClass(
  "keras_ensemble",
  slots = list(
    members = "list"
  ),
  validity = function(object) {
    if (length(object@members) < 1L) {
      return("A keras_ensemble must contain at least one member.")
    }
    if (any(vapply(object@members, is.null, logical(1)))) {
      return("keras_ensemble members must all be fitted models, but some are NULL.")
    }
    return(TRUE)
  }
)



#cov_est_method---------------------------------------------------------
#' Define the `cov_est_method` S4 Class
#'
#' S4 class to represent a set of configurations for estimating the covariance matrix.
#'
#' @slot cov_estimation_method A character string representing the covariance estimation method. Must be one of 'sample', 'ewma', 'cc', 'pca1', 'pca2', 'shrink_id' or 'shrink_cc'.
#' @slot cov_matrix_sample_size Number of periods to subset return sample when estimating the covariance matrix. A high number will provide
#' higher degrees of freedom, but old returns might not reflect current risk due to parameter shift. A low number will tend to expose estimation
#' to dimensionality curse.
#' @slot active_returns logical. If TRUE, the covariance matrix will be estimated using active returns.
#'  If FALSE, the covariance matrix will be estimated using raw returns.
#' @slot cov_matrix_benchmark  A character string representing the benchmark from benchmark_returns_xts to be used when estimating the covariance matrix.
#' Only needed when active_returns is TRUE.
#'
#' @return An S4 object of class `cov_est_method`.
#'
#' @export
setClass("cov_est_method",
         slots = list(
           cov_estimation_method = "character",
           cov_matrix_sample_size = "numeric",
           active_returns = "logical",
           cov_matrix_benchmark = "ANY"
         ),
         prototype = list(
           cov_estimation_method = "sample",
           cov_matrix_sample_size = 36,
           active_returns = TRUE
         ),
         validity = function(object){
           if(!object@cov_estimation_method %in% c("sample", "ewma", "cc", "pca1", "pca2", "shrink_id", "shrink_cc")){
             stop("Invalid cov_estimation_method. Must be one of 'sample', 'ewma', 'cc', 'pca1', 'pca2', 'shrink_id' or 'shrink_cc'.")
           }
           if(object@active_returns && is.null(object@cov_matrix_benchmark)){
             stop("cov_matrix_benchmark must be provided when active_returns is TRUE.")
           }
         }
)


#mvo_parameters---------------------------------------------------------

#' Define the `mvo_parameters` S4 Class
#'
#' S4 class to represent a set of configurations for mean-variance optimization.
#'
#' @slot opt_method A character indicating the optimization method. The only current available method is 'random'. In this case, n_random_portfolios are
#' generated under the constraints defined in the mvo_parameters object and the one that optimizes the opt_objective will be selected.
#' @slot random_ports_method A character string representing the method that will be passed to PortfolioAnalytics::random_portfolios to generate random portfolios. Options are
#' 'sample', 'simplex or 'grid'.
#' @slot n_random_ports Number of random portfolios to generate. Only needed when opt_method is 'random'.
#' @slot opt_objective A character indicating the optimization objective. Possible options are 'return', 'risk' or 'sharpe'.
#' @slot ridge_pen A numeric value representing the ridge penalty to be applied to weights. If NULL, no ridge penalty is applied.
#' @slot n_resamples Number of resamples to perform when estimating the optimal portfolio. If 0, no resampling is performed.
#' @slot exp_ret_score_jitter A numeric value representing the standard deviation of the Gaussian
#' noise to be added to the expected returns scores when estimating the optimal portfolio.
#' This is used to introduce randomness in the optimization process and avoid overfitting to the expected returns.
#' @slot cov_eigval_jitter A numeric value representing the standard deviation of the Gaussian
#' noise to be added to the covariance matrix eigenvalues when estimating the optimal portfolio.
#' This is used to introduce randomness in the optimization process and avoid overfitting to the covariance matrix.
#'
#'
#' @return An S4 object of class `port_backtest_config`.
#'
#' @export
setClass("mvo_parameters",
         slots = list(
           opt_method = "character",
           random_ports_method = "character",
           n_random_ports = "numeric",
           opt_objective = "character",
           ridge_pen = "ANY",
           n_resamples = "numeric",
           exp_ret_score_jitter = "numeric",
           cov_eigval_jitter = "numeric"
         ),
         prototype = list(
           opt_method = "random",
           random_ports_method = "sample",
           n_random_ports = 1000,
           opt_objective = "sharpe",
           ridge_pen = NULL,
           n_resamples = 0,
           exp_ret_score_jitter = 0,
           cov_eigval_jitter = 0
         ),
         validity = function(object){
           if (!object@opt_method %in% c("random")) {
             stop("Currently, 'opt_method' must be 'random'.")
           }
           if (!object@random_ports_method %in% c("sample", "simplex", "grid")) {
             stop("random_ports_method must be one of 'sample', 'simplex', 'grid'.")
           }
           if (object@n_random_ports < 1) {
             stop("n_random_ports must be at least 1.")
           }
           if (!object@opt_objective %in% c("return", "risk", "sharpe")) {
             stop("opt_objective must be one of 'return', 'risk', 'sharpe'.")
           }
           if(!is.null(object@ridge_pen)){
             if(!is.numeric(object@ridge_pen) || length(object@ridge_pen) != 1 || object@ridge_pen < 0){
               stop("ridge_pen must be a single non-negative numeric value.")
             }
           }
           if(object@n_resamples < 0 || length(object@n_resamples) != 1 ||
              object@n_resamples != round(object@n_resamples)){
             stop("n_resamples must be a non-negative integer.")
           }
           if(object@exp_ret_score_jitter < 0 || length(object@exp_ret_score_jitter) != 1){
             stop("exp_ret_score_jitter must be a non-negative numeric value.")
           }
           if(object@cov_eigval_jitter < 0 || length(object@cov_eigval_jitter) != 1){
             stop("cov_eigval_jitter must be a non-negative numeric value.")
           }
           ## If n_resamples > 0, then exp_ret_score_jitter and cov_eigval_jitter must be > 0
           if(object@n_resamples > 0){

             if(object@exp_ret_score_jitter == 0){
               stop("If n_resamples > 0, then exp_ret_score_jitter must be > 0.")
             }
             if(object@cov_eigval_jitter == 0){
               stop("If n_resamples > 0, then cov_eigval_jitter must be > 0.")
             }
           }
           TRUE
         }
)


#rp_parameters----------------------------------------------------------
#' Define the `rp_parameters` S4 Class
#'
#' S4 class to represent a set of configurations for risk-parity portfolios.
#'
#' @slot rp_method A character indicating the method to compute the risk-parity vanilla solution. It is passed to riskParityPortfolio::riskParityPortfolio function as method_init.
#' Default is "cyclical-spinu"
#' @slot exp_ret_score_tilt A character indicating when to apply the expected return score tilt. Possible options are 'none', 'inner' or 'final'.
#' 'none' means no tilt is applied, 'inner' means the tilt is applied within the risk parity algorithm and 'final' means the tilt is applied after the risk parity solution is computed.
#' @slot exp_ret_score_tilt_eta A numeric value representing the intensity of the expected return score tilt. Must be a positive value. Only needed when exp_ret_score_tilt is 'inner' or 'final'.
#'
#' @return An S4 object of class `rp_parameters`.
#'
#' @export
setClass("rp_parameters",
         slots = list(
           rp_method = "character",
           exp_ret_score_tilt = "character",
           exp_ret_score_tilt_eta = "ANY"

         ),
         prototype = list(
           rp_method = "cyclical-spinu",
           exp_ret_score_tilt = "none",
           exp_ret_score_tilt_eta = NULL
         ),
         validity = function(object){

            ##Validate exp_ret_score pars
            validate_exp_ret_score_tilt(
              object@exp_ret_score_tilt, object@exp_ret_score_tilt_eta
            )

           ## Validate rp_method
           if(!object@rp_method %in% c("cyclical-spinu", "cyclical-roncalli", "newton")){
             stop("Invalid rp_method. Must be one of 'cyclical-spinu', 'cyclical-roncalli' or 'newton'.")
           }
         }
)



#hrp_parameters---------------------------------------------------------
#' Define the `hrp_parameters` S4 Class
#'
#' S4 class to represent a set of configurations for hierarchical risk-parity portfolios.
#'
#' @slot linkage A character indicating the linkage method to be used in the hierarchical clustering algorithm.
#' Must be one of 'single', 'complete', 'average', 'ward.D', 'ward.D2', 'mcquitty', 'median' or 'centroid'.
#' @slot exp_ret_score_tilt A character indicating when to apply the expected return score tilt. Possible options are 'none', 'inner' or 'final'.
#' 'none' means no tilt is applied, 'inner' means the tilt is applied within the risk parity algorithm and 'final' means the tilt is applied after the risk parity solution is computed.
#' @slot exp_ret_score_tilt_eta A numeric value representing the intensity of the expected return score tilt. Must be a positive value. Only needed when exp_ret_score_tilt is 'inner' or 'final'.
#'
#' @return An S4 object of class `rp_parameters`.
#'
#' @export
setClass("hrp_parameters",
         slots = list(
           linkage = "character",
           exp_ret_score_tilt = "character",
           exp_ret_score_tilt_eta = "ANY"

         ),
         prototype = list(
           linkage = "single",
           exp_ret_score_tilt = "none",
           exp_ret_score_tilt_eta = NULL
         ),
         validity = function(object){

           ##Validate exp_ret_score pars
           validate_exp_ret_score_tilt(
             object@exp_ret_score_tilt, object@exp_ret_score_tilt_eta
           )

           ## Validate linkage
           if(!object@linkage %in% c("single", "complete", "average", "ward.D", "ward.D2", "mcquitty", "median", "centroid")){
             stop("Invalid linkage. Must be one of 'single', 'complete', 'average', 'ward.D', 'ward.D2', 'mcquitty', 'median' or 'centroid'.")
           }
         }
)

#risk_target_parameters---------------------------------------------------------
#' Define the `risk_target_parameters` S4 Class
#'
#' Parameters for the `risk_targeted` meta-portfolio path: scaling a single risky sleeve against a
#' residual sleeve so that the combination targets a stated level of risk. The weight on the risky
#' sleeve is
#' \deqn{w_t = \min\left(\max\left(\left(\frac{target}{risk_t}\right)^{p},\ min\_weight\right),\ max\_weight\right)}
#' and the residual sleeve takes whatever is left. At \eqn{p = 1} this is ordinary risk targeting;
#' at \eqn{p = 2} it is the inverse-variance response of a volatility-managed portfolio.
#'
#' @section The residual must match the target metric:
#' This is the easiest thing to get wrong here, and it is silent when wrong.
#' \itemize{
#'   \item A residual that \strong{tracks the benchmark}, such as an index ETF, makes tracking
#'     error scale linearly in the weight: halving the risky sleeve halves the tracking error, and
#'     a fully residual portfolio has none. \code{target_metric = "tracking_error"} is then valid.
#'   \item A residual that is \strong{riskless}, such as a cash line, makes total volatility scale
#'     linearly instead. \code{target_metric = "volatility"} is then valid.
#'   \item Crossing them does not error, it just stops working. Blending toward cash while
#'     targeting tracking error \emph{raises} tracking error past a point, since a fully cash
#'     portfolio is maximally far from the index, so the rule chases a level it can never reach.
#' }
#' Validation cannot read a ticker's mind, so it checks the residual's own realised tracking error
#' against the benchmark and warns when a tracking-error target is paired with a residual that does
#' not track.
#'
#' @section Estimating current risk:
#' \code{vol_source} chooses where \eqn{risk_t} comes from.
#' \describe{
#'   \item{\code{"ex_ante"}}{Re-estimates a covariance matrix from daily stock returns over a short
#'     window and applies the sleeve's current weights. This is the default because it describes
#'     the portfolio held now: a rolling window of past monthly portfolio returns describes a chain
#'     of past compositions instead, and inheriting the risk figure from the base backtest's
#'     \code{port_stats} would use a long window that is also stale between rebalances. Requires
#'     \code{daily_stock_returns_m_xts}.}
#'   \item{\code{"realized_rolling"}}{Standard deviation of the sleeve's own past monthly returns
#'     over \code{vol_window} months. Fewer observations and a slower response.}
#'   \item{\code{"supplied"}}{A series the caller computes, passed to the backtest as data.}
#' }
#' For a tracking-error target the covariance is applied to \emph{active} weights, portfolio minus
#' benchmark, which is how \code{calculate_port_stats} derives \code{act_risk}. The estimator itself
#' therefore works on raw returns, so \code{active_returns} in \code{vol_cov_est_method} should stay
#' \code{FALSE} to avoid subtracting the benchmark twice.
#'
#' @slot residual_ticker Character naming the residual sleeve, which must be a row of the data
#'   objects the backtest runs on.
#' @slot target Numeric, in the target metric's own units, typically annualised percentage points.
#' @slot target_metric Either `"tracking_error"` or `"volatility"`.
#' @slot p Numeric exponent. 1 for risk targeting, 2 for the inverse-variance response.
#' @slot vol_source One of `"ex_ante"`, `"realized_rolling"` or `"supplied"`.
#' @slot vol_cov_est_method A `cov_est_method` used when `vol_source` is `"ex_ante"`.
#' @slot vol_window Numeric months, used when `vol_source` is `"realized_rolling"`.
#' @slot exposure_method How the exposure multiplier \eqn{s} is derived from a metric on
#'   the sleeve: `"none"`, `"trend"`, `"ts_adjusted"` or `"as_is"`.
#' @slot exposure_window Numeric months of history for `"ts_adjusted"`, `NULL` otherwise.
#' @slot exposure_center Numeric, the multiplier when the metric says nothing either way.
#' @slot exposure_sensitivity Numeric, how far the multiplier moves from the centre. Its sign
#'   sets the direction. Required by `"trend"` and `"ts_adjusted"`.
#' @slot exposure_bounds Numeric of length two, the box the multiplier is clipped to before the
#'   risk ratio scales it.
#' @slot min_weight,max_weight Numeric bounds on the risky sleeve, so the residual is capped at
#'   `1 - min_weight`.
#'
#' @seealso [create_risk_target_parameters()], [add_risk_target_parameters()],
#'   \code{\link{port_metabacktest_config-class}}
#' @export
setClass("risk_target_parameters",
         slots = list(
           residual_ticker = "character",
           target = "numeric",
           target_metric = "character",
           p = "numeric",
           vol_source = "character",
           vol_cov_est_method = "ANY",
           vol_window = "numeric",
           exposure_method = "character",
           exposure_window = "ANY",
           exposure_center = "numeric",
           exposure_sensitivity = "ANY",
           exposure_bounds = "numeric",
           min_weight = "numeric",
           max_weight = "numeric"
         ),
         prototype = list(
           target_metric = "tracking_error",
           p = 1,
           vol_source = "ex_ante",
           vol_cov_est_method = NULL,
           vol_window = 6,
           exposure_method = "none",
           exposure_window = NULL,
           exposure_center = 1,
           exposure_sensitivity = NULL,
           exposure_bounds = c(0, 1),
           min_weight = 0,
           max_weight = 1
         ),
         validity = function(object) {

           ##Residual sleeve
           if (length(object@residual_ticker) != 1 || is.na(object@residual_ticker) ||
               !nzchar(object@residual_ticker)) {
             stop("residual_ticker must be a single non-empty character value.")
           }

           ##Target
           if (length(object@target) != 1 || !is.finite(object@target) || object@target <= 0) {
             stop("target must be a single positive finite number, in the target metric's units.")
           }
           if (length(object@target_metric) != 1 ||
               !object@target_metric %in% c("tracking_error", "volatility")) {
             stop("target_metric must be either 'tracking_error' or 'volatility'.")
           }

           ##Response
           if (length(object@p) != 1 || !is.finite(object@p) || object@p <= 0) {
             stop("p must be a single positive finite number. Use 1 for risk targeting and 2 for ",
                  "the inverse-variance response.")
           }

           ##Risk estimate
           if (length(object@vol_source) != 1 ||
               !object@vol_source %in% c("ex_ante", "realized_rolling", "supplied")) {
             stop("vol_source must be one of 'ex_ante', 'realized_rolling' or 'supplied'.")
           }
           if (object@vol_source == "ex_ante") {
             if (is.null(object@vol_cov_est_method) ||
                 !inherits(object@vol_cov_est_method, "cov_est_method")) {
               stop("vol_cov_est_method must be a 'cov_est_method' object when vol_source is 'ex_ante'.")
             }
             ###The benchmark is expressed through active weights, not by subtracting it from the
             ###returns, so subtracting it here too would count it twice
             if (isTRUE(object@vol_cov_est_method@active_returns)) {
               stop("vol_cov_est_method must have active_returns = FALSE. A tracking-error target ",
                    "is expressed by applying active weights to a raw covariance matrix, so ",
                    "estimating the covariance on active returns as well would subtract the ",
                    "benchmark twice.")
             }
           }
           if (object@vol_source == "realized_rolling") {
             if (length(object@vol_window) != 1 || is.na(object@vol_window) ||
                 object@vol_window < 2 || object@vol_window %% 1 != 0) {
               stop("vol_window must be a single whole number of at least 2 months when ",
                    "vol_source is 'realized_rolling'.")
             }
           }

           ##Exposure signal
           if (length(object@exposure_method) != 1 ||
               !object@exposure_method %in% c("none", "trend", "ts_adjusted", "as_is")) {
             stop("exposure_method must be one of 'none', 'trend', 'ts_adjusted' or 'as_is'. ",
                  "There is deliberately no inverse-of-risk mapping: that is what the ",
                  "(target / risk)^p term does, and having it in both places would let the ",
                  "volatility scaling be applied twice.")
           }
           if (object@exposure_method %in% c("trend", "ts_adjusted")) {
             if (is.null(object@exposure_sensitivity) ||
                 !is.numeric(object@exposure_sensitivity) ||
                 length(object@exposure_sensitivity) != 1 ||
                 !is.finite(object@exposure_sensitivity)) {
               stop("exposure_sensitivity must be a single finite number for exposure_method '",
                    object@exposure_method, "'. Its sign sets the direction of the rule, so it ",
                    "has no default.")
             }
           }
           if (object@exposure_method == "ts_adjusted") {
             if (is.null(object@exposure_window) || !is.numeric(object@exposure_window) ||
                 length(object@exposure_window) != 1 || is.na(object@exposure_window) ||
                 object@exposure_window < 2 || object@exposure_window %% 1 != 0) {
               stop("exposure_window must be a single whole number of at least 2 for ",
                    "exposure_method 'ts_adjusted'.")
             }
           }
           if (length(object@exposure_bounds) != 2 || any(!is.finite(object@exposure_bounds)) ||
               object@exposure_bounds[1] < 0 ||
               object@exposure_bounds[1] > object@exposure_bounds[2]) {
             stop("exposure_bounds must be two finite numbers, non-negative and non-decreasing.")
           }

           ##Bounds on the risky sleeve
           if (length(object@min_weight) != 1 || length(object@max_weight) != 1 ||
               !is.finite(object@min_weight) || !is.finite(object@max_weight)) {
             stop("min_weight and max_weight must each be a single finite number.")
           }
           if (object@min_weight < 0 || object@max_weight > 1) {
             stop("min_weight and max_weight must lie within [0, 1]: these are long-only weights ",
                  "on the risky sleeve, with the residual taking the remainder.")
           }
           if (object@min_weight > object@max_weight) {
             stop("min_weight must not exceed max_weight.")
           }

           TRUE
         }
)


#mmaf_parameters--------------------------------------------------------
#' Define the `mmaf_parameters` S4 Class
#'
#' S4 class to represent a set of configurations for the MMAF portfolio construction method.
#'
#' @slot mmaf_method A character indicating the MMAF method to be used. Must be one of 'top_down' or 'bottom_up'.
#' @slot top_down_proxy_port_method A character indicating the method to be used for constructing the top-down proxy portfolio.
#' Must be one of 'ew', 'rp', 'hrp', 'cs' or 'sw' if mmaf_method is 'top_down' and NULL if mmaf_method is 'bottom_up'.
#' @slot mmaf_group_col A character string representing the MMAF group to which the assets belong. This is used to group assets when constructing micro and macro portfolios.
#' It must be a length 1 character.
#' @slot micro_port_config An object of class `mmaf_sub_port_config` representing the configuration for constructing micro portfolios.
#' @slot macro_port_config An object of class `mmaf_sub_port_config` representing the configuration for constructing macro portfolios.
#'
#' @export
#'
setClass(
  "mmaf_parameters",
  slots = c(
    mmaf_method = "character",
    top_down_proxy_port_method = "ANY",
    mmaf_group_col = "ANY",
    micro_port_config = "ANY",
    macro_port_config = "ANY"
  ),
  validity = function(object){

    ## MMAF method must be one of top_down or bottom_up
    if(!object@mmaf_method %in% c("top_down", "bottom_up")){
      stop("Invalid mmaf_method. Must be one of 'top_down' or 'bottom_up'.")
    }

    ## Top down_proxy port method must be one of "ew", "rp", "hrp", "cs", "sw" if
    ## mmaf_method is top_down and NULL if it is bottom_up
    if(object@mmaf_method == "top_down"){
      if(is.null(object@top_down_proxy_port_method) ||
         !object@top_down_proxy_port_method %in% c("ew", "rp", "hrp", "cs", "sw")){
        stop("Invalid top_down_proxy_port_method. Must be one of 'ew', 'rp', 'hrp', 'cs', 'sw' when mmaf_method is 'top_down'.")
      }
    } else {
      if(!is.null(object@top_down_proxy_port_method)){
        stop("top_down_proxy_port_method must be NULL when mmaf_method is 'bottom_up'.")
      }
    }

    ## If not NULL, micro and macro port config must be of class mmaf_sub_port_config
    if(!is.null(object@micro_port_config) &&
       !methods::is(object@micro_port_config, "mmaf_sub_port_config")){
      stop("micro_port_config must be of class 'mmaf_sub_port_config'.")
    }
    if(!is.null(object@macro_port_config) &&
       !methods::is(object@macro_port_config, "mmaf_sub_port_config")){
      stop("macro_port_config must be of class 'mmaf_sub_port_config'.")
    }

    ## If micro_port_config or macro_port_config is NULL, display a message
    if(is.null(object@micro_port_config)){
      message("A micro_port_config is necessary for mmaf portfolios.")
    }
    if(is.null(object@macro_port_config)){
      message("A macro_port_config is necessary for mmaf portfolios.")
    }

    ##mmaf group must be length 1 character
    if(!is.null(object@mmaf_group_col) &&
       (length(object@mmaf_group_col) != 1 || !is.character(object@mmaf_group_col))){
      stop("mmaf_group_col must be a length 1 character.")
    }


    return(TRUE)
  }


)


#sub_port_config-----------------------------------------------------------
#' @title Sub Portfolio Configuration
#' @description An S4 class to represent the configuration of a sub-portfolio built by a
#' layered portfolio construction method (the `*af` family). A layered method calls
#' `set_portfolio_weights()` recursively on a block of the universe, and one
#' `sub_port_config` fully specifies how that inner call must be made: which construction
#' method to use, and the parameters of that method.
#'
#' @details
#' This is the shared configuration type for every layered method. `mmaf_sub_port_config`
#' extends it without adding structure and is kept as the name used by
#' `mmaf_parameters`.
#'
#' Only the parameter object matching `port_construction_method` is used. The remaining
#' parameter slots are ignored, so a configuration carrying, say, `rp_parameters` while
#' `port_construction_method` is `"ew"` is valid but inert.
#'
#' @slot port_construction_method A character string indicating the method used for constructing the sub-portfolio.
#' Must be one of 'ew', 'sw', 'cw', 'cs', 'rp', 'hrp' or 'mvo'.
#' @slot mvo_parameters An object of class `mvo_parameters` representing the parameters for mean-variance optimization. This is only relevant for 'mvo'.
#' @slot rp_parameters An object of class `rp_parameters` representing the parameters for risk parity. This is only relevant for 'rp'.
#' @slot hrp_parameters An object of class `hrp_parameters` representing the parameters for hierarchical risk parity. This is only relevant for 'hrp'.
#'
#' @export
#'
setClass(
  "sub_port_config",
  slots = c(
    port_construction_method = "character",
    mvo_parameters = "ANY",
    rp_parameters = "ANY",
    hrp_parameters = "ANY"
  ),
  prototype = list(
    mvo_parameters = NULL,
    rp_parameters = NULL,
    hrp_parameters = NULL
  ),
  validity = function(object){

    validate_sub_port_config(object)

  }
)


#mmaf_sub_port_config------------------------------------------------------
#' @title MMAF Sub Portfolio Configuration
#' @description An S4 class to represent the configuration of micro or macro portfolios
#' in the MMAF portfolio construction method.
#'
#' @details
#' Extends [sub_port_config-class] without adding slots or validity rules. It exists so
#' that MMAF configurations keep a distinct, self-documenting class name while sharing a
#' single configuration contract with every other layered (`*af`) method.
#'
#' @slot port_construction_method A character string indicating the method used for constructing micro portfolios.
#' @slot mvo_parameters An object of class `mvo_parameters` representing the parameters for mean-variance optimization. This is only relevant for 'mvo'.
#' @slot rp_parameters An object of class `rp_parameters` representing the parameters for risk parity. This is only relevant for 'rp'.
#' @slot hrp_parameters An object of class `hrp_parameters` representing the parameters for hierarchical risk parity. This is only relevant for 'hrp'.
#'
#' @export
#'
setClass(
  "mmaf_sub_port_config",
  contains = "sub_port_config"
)


#slsaf_parameters-------------------------------------------------------
#' Define the `slsaf_parameters` S4 Class
#'
#' S4 class holding the configuration of the Simulated Long-Short Allocation Framework,
#' a long-only benchmark-relative method that expresses conviction as an active overlay:
#' benchmark constituents outside the eligible set are underweighted according to
#' conviction, capped by the position actually held, and the budget released is spent on
#' the eligible names.
#'
#' @details
#' The short leg is fully specified by the class and has no method of its own to choose:
#' it is always signal weighted on the score built by
#' \code{\link{compute_short_leg_scores}}, since a risk-based method would grant the
#' largest underweight to the name contributing least to active risk. Only the long leg
#' is configurable.
#'
#' The two exponents divide as follows. `bench_weight_tilt_eta` sets the basis: at 1 the
#' benchmark term is exactly proportional to benchmark weight, which is the point where
#' the whole available budget converts into realized underweight, and which is also the
#' ungraded case where every ineligible constituent is sold in full. `badness_tilt_eta`
#' then walks the budget-versus-grading frontier away from that anchor, concentrating
#' underweight on the worst names and monotonically giving up budget in exchange.
#' Maximum budget and graded underweights are mutually exclusive by construction.
#'
#' @slot long_port_config An object of class `sub_port_config` describing how the long
#' leg is built. Any non-layered method is allowed.
#' @slot bench_weight_tilt_eta A numeric exponent applied to the benchmark weight in the
#' short-leg score. Defaults to 1.
#' @slot badness_tilt_eta A numeric exponent applied to the badness score in the short
#' leg. Must be non-negative; defaults to 1.
#' @slot max_short_budget An optional numeric in (0, 1] capping the realized active
#' budget, or NULL to leave it endogenous.
#'
#' @return An S4 object of class `slsaf_parameters`.
#'
#' @export
setClass(
  "slsaf_parameters",
  slots = c(
    long_port_config      = "ANY",
    bench_weight_tilt_eta = "numeric",
    badness_tilt_eta      = "numeric",
    max_short_budget      = "ANY"
  ),
  prototype = list(
    long_port_config      = NULL,
    bench_weight_tilt_eta = 1,
    badness_tilt_eta      = 1,
    max_short_budget      = NULL
  ),
  validity = function(object){

    validate_slsaf_parameters(object)

  }
)




#concentration_constraint_policy----------------------------------------
#' @title Concentration Constraint Policy
#' @description An S4 class to represent a concentration constraint policy
#' in portfolio construction.
#'
#' @slot benchmark A character vector indicating which benchmark(s) to use.
#' For stocks, must be a column in benchmarks_m_df.
#' For signals, must be theme_ss or theme_sb
#' @slot max_abs_active_individual_weight A numeric value indicating the
#'   maximum absolute active weight for individual assets.
#' @slot max_abs_active_group_weight A **named** numeric vector indicating
#'   maximum absolute group weights in relation to the benchmark.
#'   Names should match columns in a groups_m_df.
#'
#' @export
setClass(
  "concentration_constraint_policy",
  slots = c(
    benchmark = "character",
    max_abs_active_individual_weight = "ANY",
    max_abs_active_group_weight = "ANY"
  ),
  validity = function(object){
    validate_concentration_constraint_policy(as.list(object))
  }
)



#liquidity_constraint_policy--------------------------------------------
#' @title Liquidity Constraint Policy
#' @description An S4 class to represent a liquidity constraint policy in portfolio construction.
#'
#' @slot liquidity_floor_rule A character indicating the minimum liquidity classification
#' for an asset to be considered eligible. Should be one of 'micro_caps', 'small_caps', 'mid_caps', 'large_caps' or 'mega_caps'.
#' This constraint will work even if port_construction_method is not 'mvo'.
#' It can be added via add_liquidity_floor_rule function.
#' @slot liquidity_cap_rules A named vector in which each element is a value indicating the maximum (active) weight that can be assigned to assets
#' with the classification specified by its name. The names should be one of 'micro_caps', 'small_caps', 'mid_caps', 'large_caps' or 'mega_caps'.
#' A liquidity_constraint_policy can contain as many liquidity_cap_rules as needed, but names can't be repeated and a less liquid asset can't have a higher cap than a more liquid one.
#' New cap rules can be added through the add_liquidity_cap_rule function.
#' @export
setClass(
  "liquidity_constraint_policy",
  slots = c(
    liquidity_floor_rule = "ANY",
    liquidity_cap_rules = "ANY"
  ),
  validity = function(object) {

    validate_liquidity_constraint_policy(as.list(object))

  }
)


#turnover_constraint_policy--------------------------------------------
#' @title Turnover Constraint Policy
#' @description An S4 class to represent a turnover constraint policy in portfolio construction.
#'
#' @slot quantile_range_buffer A numeric indicating the increase in the quantile_range for an asset to be considered eligible to the buffer zone.
#' Stocks in this quantile that were present in bop_port_weights will be included in the buffer zone, if they meet buffer_zones_rules.
#' @slot turnover_cap_rules A named vector in which each element is a value indicating the maximum absolute weight deviation in relation to the bop_port_weights
#' that can be assigned to assets, with the classification specified by its name. The names should be one of 'micro_caps', 'small_caps', 'mid_caps', 'large_caps' or 'mega_caps'.
#' A turnover_constraint_policy can contain as many buffer_zone_rules as needed, but names can't be repeated and a less liquid asset can't have a higher cap than a more liquid one.
#' New cap rules can be added through the add_turnover_cap_rule function.
#' @export
setClass(
  "turnover_constraint_policy",
  slots = c(
    quantile_range_buffer = "numeric",
    turnover_cap_rules = "numeric"
  ),
  validity = function(object) {

    validate_turnover_constraint_policy(as.list(object))

  }
)


#transaction_costs_parameters-----------------------------------------------------
#' Transaction Cost Parameters S4 Class
#'
#' This S4 class stores transaction cost parameters based on the BARRA model.
#'
#' @slot direct_transaction_cost A numeric value representing the direct transaction cost (ie, brokerage fees). Should be in percentage (0.07 = 0.07%) .
#' @slot strategy_aum A numeric value representing the strategy's assets under management (AUM). Should be in same units as main_liquidity_metrics
#' @slot alpha A numeric value representing the alpha parameter.
#' @slot lambda A numeric value or the string "dynamic" representing the lambda parameter.
#'
#' @export
methods::setClass(
  Class = "transaction_costs_parameters",
  slots = c(
    direct_transaction_cost = "numeric",
    strategy_aum = "numeric",
    alpha = "numeric",
    lambda = "ANY"  # Accepts numeric or "dynamic"
  ),
  validity = function(object) {

    validate_transaction_costs_parameters(as.list(object))

  }
)




#signal_port_parameters------------------------------------------------
#' @title Signal Portfolio Parameters
#' @description Class to encapsulate parameters for constructing signal portfolios (portfolio-blending). Only needed when
#' sb_algorithm is 'rp' or 'mvo'.
#'
#' @slot cov_est_method An object of class `cov_est_method` representing the covariance estimation method and relevant parameters. Current methods are: 'sample', 'ewma', 'cc' (constant correlation),
#' 'pca1', 'pca2', 'shrink_id' (shrinkage to identity matrix), 'shrink_cc' (shrinkage to constant correlation). This is only relevant for 'rp' and 'mvo'.
#' @slot mvo_parameters An object of class `mvo_parameters` representing the parameters for mean-variance optimization. This is only relevant for 'mvo'.
#' @slot rp_parameters An object of class `rp_parameters` representing the parameters for risk parity. This is only relevant for 'rp'.
#' @slot hrp_parameters An object of class `hrp_parameters` representing the parameters for hierarchical risk parity. This is only relevant for 'hrp'.
#' @slot mmaf_parameters An object of class `mmaf_parameters` representing the parameters for the MMAF portfolio construction method. This is only relevant for 'mmaf'.
#' @slot concentration_constraint_policy The policy to handle concentration constraints.
#'  It contains up to to three elements:
#' - `benchmark`: A character vector describing the benchmark to be used to apply constraint.
#' For signal portfolios, possible options are theme_ss or theme_sb.
#' For stock portfolios, there must be a correspondence in `benchmark_weights_m_df`
#' - `max_abs_active_individual_weight`: The maximum absolute individual active weights.
#' - `max_abs_active_group_weight`: The maximum absolute theme active weight used for creating group constraints.
#'
#' @export
setClass(
  "signal_port_parameters",
  slots = list(
    cov_est_method = "cov_est_method",
    mvo_parameters = "ANY",
    rp_parameters = "ANY",
    hrp_parameters = "ANY",
    mmaf_parameters = "ANY",
    concentration_constraint_policy = "ANY"
  ),
  validity = function(object){
    if (!is.null(object@mvo_parameters)) {
      if (!inherits(object@mvo_parameters, "mvo_parameters")) {
        stop("mvo_parameters must be of class 'mvo_parameters'")
      }
    }
    if (!is.null(object@rp_parameters)) {
      if (!inherits(object@rp_parameters, "rp_parameters")) {
        stop("rp_parameters must be of class 'rp_parameters'")
      }
    }
    if (!is.null(object@hrp_parameters)) {
      if (!inherits(object@hrp_parameters, "hrp_parameters")) {
        stop("hrp_parameters must be of class 'hrp_parameters'")
      }
    }
    if (!is.null(object@mmaf_parameters)) {
      if (!inherits(object@mmaf_parameters, "mmaf_parameters")) {
        stop("mmaf_parameters must be of class 'mmaf_parameters'")
      }
    }

    if (!is.null(object@concentration_constraint_policy)) {
      if (!inherits(object@concentration_constraint_policy, "concentration_constraint_policy")) {
        stop("concentration_constraint_policy must be of class 'concentration_constraint_policy'")
      }
      if(!object@concentration_constraint_policy@benchmark %in% c("theme_ss", "theme_sb")){
        stop("Only allowed benchmarks for concentration_constraint_policy in 'signal_port_parameters' are 'theme_ss' and 'theme_sb'")
      }

    }
  }
)




#alpha_test------------------------------------------------------------
#' @title alpha_test_strategy Class
#' @description The alpha_test_strategy class is designed to specify parameters of hypothesis testing regarding
#' CAPM alpha under a multiple testing framework, with frequentist and bayesian approaches.
#' In the latter, the user can change the hierarchical model specification and how priors are going to be set.
#' @slot model_structure A character describing the model structure.
#' @slot signal_significance_threshold A decimal indicating the hypothesis testing negative-alpha null-hypothesis rejection criteria. If one wants to select all chosen_signals,
#' provide 1. In any case, a signal being selected demands a significant CAPM alpha.
#' @slot p_correction_method The method for p-value correction. Possible options are:
#'\itemize{
#'  \item{"none"}: No correction.
#'  \item{"bayesian"}: When bayesian is set, a hierarchical mixed-effects bayesian linear model is fitted to the data, using the `brms` package,
#'  which is an interface to the `Stan` probabilistic programming language.
#'  The user can also choose one of the following frequentist methods, which will control Family-Wise Error Rate (FWER) or the False Discovery Rate (FDR).
#'  FDR is less stringent than FWER.
#'  For FWER, possible options are:
#'  \item{"bonferroni"}: Bonferroni correction, which is dominated by Holm's method.
#'  \item{"holm"}: Holm's (1979) method.
#'  \item{"hochberg"}: Hochberg's (1988) method, valid when hypothesis tests are independent or non-negatively associated. Less powerful than Hommel's (1988) method, but
#'  faster to compute.
#'  \item{"hommel"}: Hommel's (1988) method, also valid when hypothesis tests are independent or non-negatively associated, but is more powerful than Hochberg (1988).
#'  For FDR, possible options are:
#'  \item{"BH" or "fdr"}: Benjamini-Hochberg (1995) procedure.
#'  \item{"BY"}: Benjamini-Yekutieli (2001) procedure.
#'  }
#' @slot market_factor_proxy A character string indicating the market factor proxy to be used in the CAPM model.
#' Should correspond to one of the columns in `benchmark_returns_df`.
#' @slot bayesian_model_parameters An object of class `bayesian_model_parameters`, containing the
#' parameters needed to build the hierarhicical bayesian model and specify its priors.
#' @slot enable_theme_representativeness A logical indicating whether, if a given theme in `signal_themes_m_df` does not have any eligible signal, the signal
#' with highest alpha t-stat should be elected.

setClass("alpha_test_strategy",
         slots = list(
           model_structure = "character",
           theme_level_intercept = "ANY",
           theme_level_slope = "ANY",
           lmer_control = "ANY",
           signal_significance_threshold = "numeric",
           p_correction_method = "character",
           enable_theme_representativeness = "logical",
           market_factor_proxy = "character"
         ),
         validity = function(object) {

           if (!(object@p_correction_method %in% c(
             "none", "bonferroni", "holm", "hochberg", "hommel", "BH", "fdr", "BY", "bayesian"
           ))) {
             stop("Invalid p_correction_method.")
           }
           if(object@p_correction_method == "bayesian" && object@model_structure != "partial_pooled"){
             stop("Currently, bayesian p_correction method is only available for partial_pooled model_structure")
           }
           if (object@signal_significance_threshold < 0 || object@signal_significance_threshold > 1) {
             stop("signal_significance_threshold must be between 0 and 1.")
           }
           if(!object@model_structure %in% c("partial_pooled", "no_pooled")){
             stop("Currently, model_structure must be one of partial_pooled or no_pooled")
           }

           if(object@model_structure == "partial_pooled"){
             if (!object@theme_level_intercept %in% c("fixed", "random", "theme_specific")){
               stop("theme_level_intercept must be 'fixed', 'random' or 'theme_specific'")
             }
             if (!object@theme_level_slope %in% c("fixed", "theme_specific")){
               stop("Currently, theme_level_slope can only be 'fixed' or 'theme_specific'")
             }
             avaiable_combinations <- c(c("random_intercept_fixed_slope"), #old random_intercept
                                        c("theme_specific_intercept_fixed_slope"), #old fixed_intercepts
                                        c("theme_specific_intercept_theme_specific_slope"), #old fixed_intercepts_fixed_slopes
                                        c("fixed_intercept_fixed_slope")) #one none
             chosen_combination <- paste0(object@theme_level_intercept, "_intercept_", object@theme_level_slope, "_slope")

             if(!chosen_combination %in% avaiable_combinations){
               stop("Chosen combination of theme_level_intercept and theme_level_slope is currently not supported.")
             }

             if (!is.null(object@lmer_control)) {
               if (!is.list(object@lmer_control) || any(!names(object@lmer_control) %in% c("lmer_optimizer", "lmer_optimization_objective", "hierarchical_p_value_method"))) {
                 return("lmer_control must be a list with 'lmer_optimizer', 'lmer_optimization_objective' and/or 'hierarchical_p_value_method'.")
               }
               if (!is.null(object@lmer_control$lmer_optimizer)){
                 if (!is.character(object@lmer_control$lmer_optimizer) || !object@lmer_control$lmer_optimizer %in% c("nloptwrap", "bobyqa", "Nelder_Mead", "nlminbwrap")) {
                   stop("lmer_optimizer must be one of 'nloptwrap', 'bobyqa', 'Nelder_Mead', or 'nlminbwrap'.")
                 }
               }
               if( !is.null(object@lmer_control$lmer_optimization_objective)){
                 if(!is.character(object@lmer_control$lmer_optimization_objective) || !object@lmer_control$lmer_optimization_objective %in% c("likelihood", "REML")){
                   stop("lmer_optimization_objective should be one of 'likelihood' or 'REML'.")
                 }
               }
             }
           }
           else {
             if(any(!is.null(object@theme_level_intercept), !is.null(object@theme_level_slope))){
               stop("Theme-level parameters are only avaiable for partial pooled models.")
             }
             if(!is.null(object@lmer_control)){
               stop("lmer_control is only avaiable for partial pooled models.")
             }
           }
           TRUE
         },
         prototype = list(
           signal_significance_threshold = 0.05,
           p_correction_method = "none",
           enable_theme_representativeness = TRUE,
           model_structure = "no_pooled",
           theme_level_intercept = NULL,
           theme_level_slope = NULL
         )
)

#' @title frequentist_alpha_test_strategy Class
#' @description A subclass of alpha_test_strategy for frequentist methods.
setClass("frequentist_alpha_test_strategy",
         contains = "alpha_test_strategy",
         validity = function(object) {
           if (object@p_correction_method == "bayesian") {
             stop("p_correction_method cannot be 'bayesian' for frequentist_alpha_test_strategy.")
           }
           TRUE
         }
)


#bayesian_model_params-------------------------------------------------
#' @title bayesian_model_parameters Class
#' @description A class encapsulating parameters necessary to specify the hierarchical Bayesian model and its priors.
#'
#' @slot user_priors An object of class `brmsprior` with user-defined priors for the hierarchical Bayesian model.
#' Should be structured according to the `model_spec_theme_level`.
#' @slot prior_derivation_control A list of additional parameters for deriving priors when `priors_type` is `"informative_exogenous_dataset"`.
#' Should include:
#'   - `half_t_df`: Degrees of freedom for the half-t distribution applied to sd priors.
#'   - `lmer_optimizer`: Optimizer to be used in `lme4::lmer` for deriving priors.
#'     Options include: `"nloptwrap"`, `"bobyqa"`, `"Nelder_Mead"`, `"nlminbwrap"`.
#'   - `lmer_optimization_objective`: Criteria to be optimized in `lme4::lmer` for deriving priors.
#'     Options include: `likelihood`, `REML`.
#' @slot brms_control A list of additional parameters to be passed to `brms::brm` for MCMC sampling, including:
#'   - `chains`: Number of Markov chains to run (default is 4).
#'   - `iter`: Total number of iterations per chain (default is 2000).
#'   - `warmup`: Number of warmup iterations per chain (default is `floor(iter / 2)`).
#'   - `thin`: Thinning interval for MCMC sampling (default is 1).
#'   - `seed`: Seed for reproducibility (default is `NA` for random seeding).
#'   - `adapt_delta`: Target acceptance probability for the Hamiltonian Monte Carlo sampler (default is 0.99).
#'
#' @export
setClass(
  "bayesian_model_parameters",
  slots = list(
    user_priors = "ANY", # To accommodate brmsprior objects or NULL
    prior_derivation_control = "ANY",
    brms_control = "ANY"
  ),
  prototype = list(
    user_priors = NULL,
    brms_control = list(
      chains = 4,
      iter = 2000,
      warmup = 1000,
      thin = 1,
      seed = NA,
      adapt_delta = 0.80
    )
  ),
  validity = function(object) {

    # Validate user_priors if not NULL
    if (!is.null(object@user_priors)) {
      if (!inherits(object@user_priors, "brmsprior")) {
        return("user_priors must be a 'brmsprior' object.")
      }
    }
    # Validate prior_derivation_control
    if (!is.null(object@prior_derivation_control)) {
      if (!is.list(object@prior_derivation_control) || any(!names(object@prior_derivation_control) %in% c("half_t_df"))) {
        return("prior_derivation_control must be a list with 'half_t_df'.")
      }
      if (!is.null(object@prior_derivation_control$half_t_df)){
        if (!is.numeric(object@prior_derivation_control$half_t_df) || object@prior_derivation_control$half_t_df <= 0) {
          stop("half_t_df must be a positive numeric value.")
        }
      }
    }
    #Validate brms_control
    if(!is.null(object@brms_control)){
      if(any(!names(object@brms_control) %in% c("chains", "iter", "warmup", "thin", "seed", "adapt_delta"))){
        stop("brms_control must be a list containing 'chains', 'iter', 'warmup', 'thin', 'seed' and/or 'adapt_delta'.")
      }

      #chains
      if(!is.null(object@brms_control$chains)){
        if(!is.numeric(object@brms_control$chains) || object@brms_control$chains <= 0){
          stop("chains must be a positive number.")
        }
      }

      #iter
      if(!is.null(object@brms_control$iter)){
        if(!is.numeric(object@brms_control$iter) || object@brms_control$iter <= 0){
          stop("iter must be a positive number.")
        }
      }

      #warmup
      if(!is.null(object@brms_control$warmup)){
        if(!is.numeric(object@brms_control$warmup) || object@brms_control$warmup <= 0){
          stop("warmup must be a positive number.")
        }
      }

      #thin
      if(!is.null(object@brms_control$thin)){
        if(!is.numeric(object@brms_control$thin) || object@brms_control$thin <= 0){
          stop("thin must be a positive number.")
        }
      }

      #seed
      if(!is.null(object@brms_control$seed)){
        if(!is.numeric(object@brms_control$seed) || object@brms_control$seed <= 0){
          stop("seed must be a positive number.")
        }
      }

      #adapt_delta
      if(!is.null(object@brms_control$adapt_delta)){
        if(!is.numeric(object@brms_control$adapt_delta) || object@brms_control$adapt_delta <= 0 || object@brms_control$adapt_delta > 1){
          stop("adapt_delta should be between 0 and 1.")
        }
      }

      #warmup and iter
      if(!is.null(object@brms_control$warmup) && !is.null(object@brms_control$iter) && object@brms_control$warmup >= object@brms_control$iter){
        stop("warmup must be less than iter.")
      }
    }

    TRUE
  }
)

#' @title bayesian_alpha_test_strategy Class
#' @description A subclass of alpha_test_strategy for Bayesian methods.
#' @slot bayesian_model_parameters Parameters for the hierarchical Bayesian model.
setClass("bayesian_alpha_test_strategy",
         contains = "alpha_test_strategy",
         slots = list(
           bayesian_model_parameters = "bayesian_model_parameters"
         ),
         validity = function(object) {
           if (object@p_correction_method != "bayesian") {
             stop("p_correction_method must be 'bayesian' for bayesian_alpha_test_strategy.")
           }

           # Warnings for missing typical priors based on theme_level parameters
           theme_level_intercept <- object@theme_level_intercept
           theme_level_slope <- object@theme_level_slope

           if(!is.null(object@bayesian_model_parameters@user_priors)){
             #Get user priors
             priors_df <- as.data.frame(object@bayesian_model_parameters@user_priors)

             if (theme_level_intercept == "random" && theme_level_slope == "fixed") {
               # Check for prior with class 'sd', coef 'Intercept', group 'theme'
               required_row <- subset(priors_df, class == "sd" & coef == "Intercept" & group == "theme")
               if (nrow(required_row) == 0) {
                 warning("For this model specification, remember to add a prior with effect = 'random', type = 'intercept', and level = 'theme'.")
               }
             } else if (theme_level_intercept == "theme_specific" && theme_level_slope == "fixed") {
               # Check for priors with class 'b' and coef matching 'theme...'
               required_rows <- subset(priors_df, class == "b" & grepl("^theme", coef))
               if (nrow(required_rows) == 0) {
                 warning("For this model specification, it is recommended to include priors for type = 'intercept' and effect = 'fixed' for each desired theme.")
               }
             } else if (theme_level_intercept == "theme_specific" && theme_level_slope == "theme_specific") {

               # Check for priors with class 'b' and coef matching 'theme...' and 'theme...:market_factor_proxy'
               required_rows_intercepts <- subset(priors_df, class == "b" & grepl("^theme[^:]*$", coef))
               required_rows_slopes <- subset(priors_df, class == "b" & grepl("^theme[^:]*:market_factor_proxy$", coef))
               if (nrow(required_rows_intercepts) == 0) {
                 warning("For this model specification, it is recommended to include priors for type = 'intercept' and effect = 'fixed' for each desired theme.")
               }
               if (nrow(required_rows_slopes) == 0) {
                 warning("For this model specification, it is recommended to include priors for type = 'slope' and effect = 'fixed' for each desired theme.")
               }
             }
           }

           TRUE
         }
)


#ss_backtest_config-----------------------------------------------------
#' @title ss_backtest_config Class
#' @description The ss_backtest_config class is designed to define an end-to-end signal selection experiment based on
#' backtest returns of associated strategies. The class includes parameters for manipulating the backtest returns object and
#' conducting hypothesis tests regarding CAPM alpha under a multiple testing framework, with frequentist and bayesian approaches. In the
#' latter, a hierarhical model is fit, with informative priors set according to an exogeneous dataset or by the user, or
#' default uninformative priors.
#' @slot chosen_signals_and_positions A character indicating to which signals ss_backtest should be applied and their positions (long and short).
#' For example, chosen_signals_and_positions = c(book_yield = "long", vol_36m = "short").
#' @slot initial_sample_size A numeric indicating the minimum number of observations required to begin the backtest.
#' @slot rebalancing_months A numeric indicating the number of months between rebalancing periods.
#' @slot active_returns A logical indicating whether to use active returns (TRUE) or total returns (FALSE) for the backtest.
#' @slot split_method The method used for splitting the data, either "expanding" or "rolling" (default is "expanding").
#' @slot alpha_test_strategy An `alpha_test_strategy` object with the configuration for the alpha test.
#' @slot config_name A character string representing the name of the configuration.
#' @export
setClass("ss_backtest_config",
         slots = list(
           chosen_signals_and_positions = "character",
           initial_sample_size = "numeric",
           rebalancing_months = "numeric",
           active_returns = "logical",
           split_method = "character",
           alpha_test_strategy = "ANY",
           config_name = "character"
         ), prototype = list(
           split_method = "expanding"
         ),
         validity = function(object) {

           if(length(object@chosen_signals_and_positions) == 1){
             if(!object@chosen_signals_and_positions == "all"){
               stop("chosen_signals_and_positions should be 'all' or a named vector with signals and positions")
             }
           } else {
             if(any(!object@chosen_signals_and_positions %in% c("long", "short", "force"))){
               stop("chosen_signals_and_positions should be either 'long', 'short' or 'force'.")
             }
           }
           if(object@initial_sample_size < 0){
             stop("initial_sample_size can't be negative")
           }

           if (!is.null(object@alpha_test_strategy)){
             if (!inherits(object@alpha_test_strategy, "alpha_test_strategy")) {
               stop("alpha_test_strategy must be an object of class alpha_test_strategy")
             }
           }
         }
)



#ss_backtest_results---------------------------------------------------
#' S4 Class for Signal Selection Backtest Results
#'
#' This S4 class encapsulates the results and parameters from performing a signal selection backtest.
#' It includes information about eligible signals, signal universes, Bayesian fits, and the backtest workflow.
#'
#' @slot ss_backtest_config An object of class `ss_backtest_config` containing the configuration for the backtest.
#' @slot signal_universe_m_df A meta dataframe containing the signal universes at each rebalancing period.
#' @slot final_signal_universe_m_d_ref A meta dataframe containing the last signal universe.
#' @slot selected_market_factor_proxy_m_xts A meta_xts object containing the selected market factor proxy.
#' @slot frequentist_results A list of frequentist model fit results
#' @slot bayesian_results A list of Bayesian model fit results
#' @slot p_correction_method A character string indicating the p-value correction method used.
#' @slot ss_backtest_workflow A list describing the signal selection backtest workflow, including parameters and metadata.
#' @slot backtest_identifier A character string representing the backtest identifier.
#' @slot update A logical indicating whether the backtest results should be updated.
#'
#' @return An S4 object of class `ss_backtest_results`.
#'
#' @export
setClass(
  "ss_backtest_results",
  slots = list(
    ss_backtest_config = "ANY",
    signal_universe_m_df = "ANY",
    final_signal_universe_m_d_ref = "ANY",
    selected_market_factor_proxy_m_xts = "meta_xts",
    frequentist_results = "ANY",
    bayesian_results = "ANY",
    p_correction_method = "character",
    ss_backtest_workflow = "list",
    backtest_identifier = "character",
    update = "logical"
  ),
  validity = function(object){

    if (!is.null(object@signal_universe_m_df)){
      if (!inherits(object@signal_universe_m_df, "signal_universe_m_df")){
        stop("signal_universe_m_df must be an object of class signal_universe_m_df")
      }
    }
    if (!is.null(object@final_signal_universe_m_d_ref)){
      if (!inherits(object@final_signal_universe_m_d_ref, "signal_universe_m_df")){
        stop("final_signal_universe_m_d_ref must be an object of class signal_universe_m_df")
      }
    }


  }
)


#sb_backtest_config-----------------------------------------------------
#' @title sb_backtest_config Class
#' @description The sb_backtest_config class is designed to define an end-to-end signal-blending (heuristic or machine learning)
#' experiment, including the hyperparameter tuning strategy, algorithm parameters, and other experiment-specific configurations.
#' @slot sb_algorithm Character string specifying the signal-blending algorithm. One of
#' ew (Equal Weight), sw (Signal Weighting), rp (Risk Parity), hrp (Hierarchical Risk Parity),
#' mvo (Mean-Variance Optimization), mmaf (Micro-Macro Allocation Framework), custom_weights,
#' ols (Ordinary Least Squares), glmnet (Elastic Net), rf (Random Forest), xgb (eXtreme Gradient Boosting), or nn (Keras Neural Network).
#' @slot target_fwd_name Name of the target variable in `target_m_df`.
#' @slot tuning_strategy An object of class `tuning_strategy`, specifying the strategy for tuning hyperparameters.
#' @slot chosen_signals_and_positions A character vector indicating which signals to include in the backtest and their positions (long and short).
#' @slot split_method Character string indicating the data splitting method ('expanding' or 'rolling').
#' @slot training_sample_size Number of observations to include in each training sample.
#' @slot rebalancing_months Months (numeric) when model should be rebalanced (refit).
#' @slot custom_objective Character string specifying the objective. For ML algorithms: one of
#' 'squared_error', 'pseudo_huber_error', 'absolute_error' (a twice-differentiable loss; non-'squared_error'
#' choices only apply to 'xgb'/'nn'). For heuristic portfolio algorithms ('sw', 'rp', 'hrp', 'mvo', 'mmaf'):
#' a 'max_'/'min_' prefix + a heuristic performance metric present in `signal_universe_m_df`
#' (see `display_valid_custom_objectives()`). May be NULL.
#' @slot keras_architecture_parameters An object of class `keras_architecture_parameters` or NULL, providing parameters specific to keras-based neural networks.
#' It includes:
#' \itemize{
#'   \item \strong{units}: A numeric vector specifying the number of neurons in each layer.
#'   \item \strong{n_layers}: An integer indicating the total number of layers in the neural network.
#'   \item \strong{activation}: A character vector listing the activation functions for each layer (e.g., "relu", "sigmoid", "tanh").
#'   \item \strong{nn_optimizer}: A character string specifying the optimizer used for training the model (options: "Adam" or "RMSProp").
#'   \item \strong{batch_norm_option}: A logical vector indicating whether batch normalization should be applied after each respective layer (TRUE or FALSE).
#' }
#' @slot signal_port_parameters An object of class `signal_port_parameters`, specifying the parameters for constructing signal portfolios (portfolio-blending).
#' @slot quantile_tau A single numeric value indicating the tau parameter used for quantile regression, between 0 and 1.
#' @slot huber_delta A single positive numeric value indicating the boundary that separates where the loss function turns from quadratic to linear.
#' @slot config_name A character string to identify the configuration.
#'
#' @section Validity:
#' \itemize{
#'   \item \code{sb_algorithm} must be one of the 12 supported algorithms.
#'   \item \code{chosen_signals_and_positions} must be \code{"all"} or a named vector of \code{"long"}/\code{"short"}.
#'   \item \code{tuning_strategy} is required for ML algorithms and forbidden for \code{ols}/heuristic algorithms; hyperparameter names must match the algorithm.
#'   \item \code{early_stop} only for \code{xgb}/\code{nn}; \code{keras_architecture_parameters} only for \code{nn}; \code{signal_port_parameters} only for \code{rp}/\code{hrp}/\code{mvo}/\code{mmaf}.
#'   \item \code{split_method} must be \code{"expanding"}; \code{rebalancing_months} in 1--12; \code{quantile_tau} in (0,1); \code{huber_delta} > 0.
#' }
#' @export
setClass(
  "sb_backtest_config",
  slots = list(
    sb_algorithm = "character",
    target_fwd_name = "character",
    tuning_strategy = "ANY",
    chosen_signals_and_positions = "character",
    split_method = "character",
    training_sample_size = "numeric",
    rebalancing_months = "numeric",
    custom_objective = "character",
    keras_architecture_parameters = "ANY",
    signal_port_parameters = "ANY",
    quantile_tau = "numeric",
    huber_delta = "numeric",
    config_name = "character"
  ),
  prototype = list(
    sb_algorithm = "ols",
    split_method = "expanding",
    custom_objective = "squared_error",
    quantile_tau = 0.5,
    huber_delta = 1
  ),
  validity = function(object) {

    ##Chosen Signals and Positions
    if (!is.null(object@chosen_signals_and_positions)){
      if (length(object@chosen_signals_and_positions) == 1 && !object@chosen_signals_and_positions == "all"){
        stop("chosen_signals_and_positions should be 'all' or a named vector with signals and positions")
      }
      if (length(object@chosen_signals_and_positions) > 1 && any(!object@chosen_signals_and_positions %in% c("long", "short"))){
        stop("chosen_signals_and_positions should be either 'long' or 'short'.")
      }
    }

    #Check for valid sb_algorithm
    valid_sb_algorithms <- c("ols", "glmnet", "rf", "xgb", "nn", "ew", "sw", "rp", "hrp", "mvo", "mmaf", "custom_weights")
    if (!(object@sb_algorithm %in% valid_sb_algorithms)) {
      return("Invalid sb_algorithm. Choose from 'ew', 'sw', 'rp', 'hrp', 'mvo', 'mmaf', 'ols', 'glmnet', 'rf', 'xgb', 'nn' or 'custom_weights'.")
    }

    #Check for custom objective
    if ((object@sb_algorithm %in% c("sw", "mvo", "mmaf")) ||
        (object@sb_algorithm %in% c("rp", "hrp") && !is.null(object@custom_objective))){
      if (!grepl("^max_|^min_", object@custom_objective)){
        stop("Invalid custom_objective. Should be 'max_' or 'min_' + one of valid heuristic performance metrics.
             To see complete list of valid heuristic performance metrics, use 'display_valid_custom_objectives()'")
      }
      ###Valid Metrics
      valid_heuristic_sb_metrics <- c(
        "arith_mean_ret", "geom_mean_ret", "ann_ret", "std_dev", "ann_std_dev",
        "semi_dev", "down_dev", "dd_dev", "down_freq", "exp_short", "pain", "ulcer", "max_dd", "skew", "kurt",
        "sharpe_ratio", "ann_sharpe_ratio", "sharpe_ratio_semi_dev", "sortino_ratio", "ann_burke_ratio",
        "inv_d_ratio", "sharpe_ratio_exp_short", "ann_pain_ratio", "ann_martin_ratio", "ann_calmar_ratio",
        "ann_adj_sharpe_ratio", "omega", "rachev_ratio", "avg_dd_rec", "avg_dd_length", "hurst", "min_track_record",
        "prob_sharpe_ratio", "modigliani", "ann_modigliani",
        "act_arith_mean_ret", "act_geom_mean_ret", "act_ann_ret", "track_err", "ann_track_err",
        "act_semi_dev", "act_down_dev", "act_dd_dev", "act_down_freq", "act_exp_short", "act_pain", "act_ulcer",
        "act_max_dd", "act_skew", "act_kurt", "info_ratio", "ann_info_ratio", "info_ratio_semi_dev",
        "act_sortino_ratio", "act_ann_burke_ratio", "act_inv_d_ratio", "info_ratio_exp_short", "act_ann_pain_ratio",
        "act_ann_martin_ratio", "act_ann_calmar_ratio", "ann_adj_info_ratio", "act_omega", "act_rachev_ratio",
        "act_avg_dd_rec", "act_avg_dd_length", "act_hurst", "act_min_track_record", "prob_info_ratio",
        "act_modigliani", "act_ann_modigliani",
        "alpha", "theme_alpha", "individual_alpha", "alpha_se", "theme_beta", "individual_beta", "specific_risk",
        "alpha_t_stat", "treynor_ratio", "appraisal_ratio", "p_value",
        "posterior_theme_alpha", "posterior_individual_alpha", "posterior_alpha_se", "posterior_theme_beta", "posterior_individual_beta",
        "posterior_specific_risk", "posterior_alpha_t_stat", "posterior_treynor_ratio", "posterior_appraisal_ratio", "pd_theme_alpha", "pd_alpha"
      )
      valid_oos_eval_metrics <- c("rss", "cp", "rmse", "mae", "mphe", "mpe", "mape", "hr", "mb")
      if (!substr(object@custom_objective, 5, nchar(object@custom_objective)) %in% c(valid_heuristic_sb_metrics, valid_oos_eval_metrics)){
        warning("custom_objective is not one of typical valid heuristic performance. Please be sure that the metric is present in signal_universe_m_df")
      }

      if (substr(object@custom_objective, 5, nchar(object@custom_objective)) %in% valid_oos_eval_metrics){
        message("This custom_objective is valid only for meta sb backtests. Please be sure that the current configuration is for such a backtest.")
      }

      typical_max_objective <- c(
        "arith_mean_ret", "geom_mean_ret", "ann_ret",
        "sharpe_ratio", "ann_sharpe_ratio", "sharpe_ratio_semi_dev", "sortino_ratio", "ann_burke_ratio",
        "inv_d_ratio", "sharpe_ratio_exp_short", "ann_pain_ratio", "ann_martin_ratio", "ann_calmar_ratio",
        "ann_adj_sharpe_ratio", "omega", "rachev_ratio", "avg_dd_rec", "hurst",
        "prob_sharpe_ratio", "modigliani", "ann_modigliani",
        "act_arith_mean_ret", "act_geom_mean_ret", "act_ann_ret",
        "info_ratio", "ann_info_ratio", "info_ratio_semi_dev",
        "act_sortino_ratio", "act_ann_burke_ratio", "act_inv_d_ratio", "info_ratio_exp_short", "act_ann_pain_ratio",
        "act_ann_martin_ratio", "act_ann_calmar_ratio", "ann_adj_info_ratio", "act_omega", "act_rachev_ratio",
        "act_avg_dd_rec", "act_avg_dd_length", "act_hurst", "prob_info_ratio",
        "act_modigliani", "act_ann_modigliani",
        "alpha", "theme_alpha", "individual_alpha", "alpha_se",
        "alpha_t_stat", "treynor_ratio", "appraisal_ratio",
        "posterior_theme_alpha", "posterior_individual_alpha", "posterior_theme_beta", "posterior_individual_beta",
        "posterior_alpha_t_stat", "posterior_treynor_ratio", "posterior_appraisal_ratio", "pd_theme_alpha", "pd_alpha",
        "rss", "cp", "hr", "mb"
      )

      if (any(stringr::str_remove(object@custom_objective, "min_") %in% typical_max_objective %in% typical_max_objective)){
        warning("Custom_objective is min, but chosen metric is typically maximized.")
      }

      typical_min_objective <- setdiff(valid_heuristic_sb_metrics, typical_max_objective)

      if (any(stringr::str_remove(object@custom_objective, "max_") %in% typical_min_objective)){
        warning("Custom_objective is max, but chosen metric is typically minimized.")
      }

    } else {
      if (!is.null(object@custom_objective) && !(object@custom_objective %in% c("squared_error", "pseudo_huber_error", "absolute_error"))) {
        return("Invalid custom_objective. Choose from 'squared_error', 'pseudo_huber_error', or 'absolute_error'.")
      }
    }
    if (!(object@sb_algorithm %in% c("xgb", "nn", "sw", "mvo", "rp", "hrp", "mmaf")) && !is.null(object@custom_objective) && object@custom_objective != "squared_error") {
      return("Invalid custom_objective. Custom objectives are only allowed for 'sw', 'rp', 'hrp', 'mvo', 'mmaf', 'xgb' or 'nn' algorithms.")
    }
    if (!(object@sb_algorithm %in% c("xgb", "nn")) && !is.null(object@tuning_strategy) && !is.null(object@tuning_strategy@early_stop)) {
      return("Invalid early_stop. Early stop is only allowed for 'xgb' or 'nn' algorithms.")
    }
    #Check for tuning strategy
    if(!object@sb_algorithm %in% c("ew", "sw", "rp", "hrp", "mvo", "mmaf", "ols", "custom_weights") && is.null(object@tuning_strategy)){
      message("when sb_algorithm is not 'ew', 'sw', 'rp', 'hrp', 'mvo', 'mmaf' or 'ols', a tuning_strategy must be set")
    }
    #ETC
    if((object@training_sample_size < 0)){
      stop("training_sample_size should be positive.")
    }
    if (object@split_method != "expanding") {
      return("split_method should be expanding.")
    }
    if (any(object@rebalancing_months < 0 | object@rebalancing_months > 12)){
      stop("rebalancing_months should be between 1 and 12.")
    }
    ##Keras
    if(!is.null(object@keras_architecture_parameters)){
      if(!is_keras_architecture_parameters(object@keras_architecture_parameters)){
        return("Invalid keras_architecture_parameters. Should be of class keras_architecture_parameters")
      }
      if(object@sb_algorithm != "nn"){
        return("keras_architecture_parameters is only needed when sb_algorithm is nn")
      }
    }
    ##Heuristic Portfolio
    if(!is.null(object@signal_port_parameters)){
      if(!inherits(object@signal_port_parameters, "signal_port_parameters")){
        return("Invalid signal_port_parameters Should be of class signal_port_parameters")
      }
      if(!object@sb_algorithm %in% c("rp", "hrp", "mvo", "mmaf")){
        return("signal_port_parameters is only needed when sb_algorithm is rp, hrp, mvo or mmaf")
      }
    }
    ##Quantile tau and huber delta
    if (!is.null(object@quantile_tau) && (object@quantile_tau <= 0 || object@quantile_tau >= 1)) {
      return("quantile_tau must be between 0 and 1.")
    }
    if (!is.null(object@huber_delta) && object@huber_delta <= 0) {
      return("huber_delta must be greater than 0.")
    }
    #Check if hypers are correctly set
    if(!is.null(object@tuning_strategy)){
      if(!is_tuning_strategy(object@tuning_strategy)){
        return("Invalid tuning_strategy. Should be of class tuning_strategy")
      }
      if(object@sb_algorithm %in% c("ew", "sw", "rp", "hrp", "mvo", "mmaf", "ols", "custom_weights")){
        return("ew, sw, rp, hrp, mvo, mmaf, ols and custom_weights do not support hyperparameter tuning")
      }

      # Check hyperparameters validity based on sb_algorithm
      hyperparameters_names <- names(object@tuning_strategy@hyper_grid_domain@hyperparameter_list)

      # GLMNET
      expected_hyperparameters_glmnet <- c("alpha", "lambda.min.ratio")
      if (object@sb_algorithm == "glmnet" && any(!hyperparameters_names %in% expected_hyperparameters_glmnet)) {
        stop("hyperparameters do not match sb_algorithm choice for 'glmnet'")
      }
      hyperparameters_missing <- expected_hyperparameters_glmnet[which(!expected_hyperparameters_glmnet %in% hyperparameters_names)]
      if(length(hyperparameters_missing) != 0 && object@sb_algorithm == "glmnet"){
        cat("\n")
        message(paste("The following hyperparameter(s) must still be configured for the",
                      object@sb_algorithm, "algorithm:",
                      paste(hyperparameters_missing, collapse = ", ")))
        cat("\n")
      }


      # RF
      expected_hyperparameters_rf <- c("mtry", "num.trees", "max.depth", "min.bucket")
      if (object@sb_algorithm == "rf" && any(!hyperparameters_names %in% expected_hyperparameters_rf)) {
        stop("hyperparameters do not match sb_algorithm choice for 'rf'")
      }
      hyperparameters_missing <- expected_hyperparameters_rf[which(!expected_hyperparameters_rf %in% hyperparameters_names)]
      if(length(hyperparameters_missing) != 0 && object@sb_algorithm == "rf"){
        cat("\n")
        message(paste("The following hyperparameter(s) must still be configured for the",
                      object@sb_algorithm, "algorithm:",
                      paste(hyperparameters_missing, collapse = ", ")))
        cat("\n")
      }


      # XGB
      expected_hyperparameters_xgb <- c("min_child_weight", "max_depth", "subsample", "colsample_bytree", "eta", "alpha", "gamma", "nrounds")
      if (object@sb_algorithm == "xgb" && any(!hyperparameters_names %in% expected_hyperparameters_xgb)) {
        stop("hyperparameters do not match sb_algorithm choice for 'xgb'")
      }
      hyperparameters_missing <- expected_hyperparameters_xgb[which(!expected_hyperparameters_xgb %in% hyperparameters_names)]
      if(length(hyperparameters_missing) != 0 && object@sb_algorithm == "xgb"){
        cat("\n")
        message(paste("The following hyperparameter(s) must still be configured for the",
                      object@sb_algorithm, "algorithm:",
                      paste(hyperparameters_missing, collapse = ", ")))
        cat("\n")
      }


      # NN
      expected_hyperparameters_nn <- c("regularizer_l1", "regularizer_l2", "droprate", "lr", "size_of_batch", "number_of_epochs")
      if (object@sb_algorithm == "nn" && any(!hyperparameters_names %in% expected_hyperparameters_nn)) {
        stop("hyperparameters do not match sb_algorithm choice for 'nn'")
      }
      hyperparameters_missing <- expected_hyperparameters_nn[which(!expected_hyperparameters_nn %in% hyperparameters_names)]
      if(length(hyperparameters_missing) != 0 && object@sb_algorithm == "nn"){
        cat("\n")
        message(paste("The following hyperparameter(s) must still be configured for the",
                      object@sb_algorithm, "algorithm:",
                      paste(hyperparameters_missing, collapse = ", ")))
        cat("\n")
      }

    }


    # Validate hyperparameters based on sb_algorithm
    if(!is.null(object@tuning_strategy) && !is.null(object@tuning_strategy@hyper_grid_domain@hyperparameter_list)){

      #Hyperparameters
      hyperparameter_list <- object@tuning_strategy@hyper_grid_domain@hyperparameter_list
      tuning_method <- object@tuning_strategy@tuning_method

      #Normalize bayesian_opt constants before the per-hyperparameter domain checks
      ###Mirrors the normalization in check_inputs_sb_backtest(): a constant entry
      ###is a degenerate domain, and the checks below expect a plain numeric value,
      ###not the list shape a constant is declared with. is_constant_hyperparameter
      ###is also needed below so init_points is compared against the searched
      ###hyperparameters only, not the declared total.
      is_constant_hyperparameter <- rep(FALSE, length(hyperparameter_list))
      if(tuning_method == "bayesian_opt" && is.list(hyperparameter_list)){
        is_constant_hyperparameter <- sapply(
          hyperparameter_list,
          function(entry) is.list(entry) && identical(entry$distribution_choice, "constant")
        )
        hyperparameter_list <- lapply(hyperparameter_list, function(entry){
          if(is.list(entry) && identical(entry$distribution_choice, "constant")){
            return(entry$value)
          }
          return(entry)
        })
      }

      if (length(hyperparameter_list) > 0) {
        for (hyperparameter in names(hyperparameter_list)) {
          #Extract value for grid_searcho or bayesian_opt
          value <- hyperparameter_list[[hyperparameter]]

          #Extract distribution and parameters for random_search
          if(tuning_method == "random_search"){
            distribution_choice <- object@tuning_strategy@hyper_grid_domain@hyperparameter_list[[hyperparameter]]$distribution_choice  #Distribution Choice
            pars <- object@tuning_strategy@hyper_grid_domain@hyperparameter_list[[hyperparameter]]$pars  #Pars
          }

          #GLMET Logic
          if (object@sb_algorithm == "glmnet") {
            if(tuning_method != "random_search"){
              if (hyperparameter == "alpha" && (any(value < 0) || any(value > 1))) {
                stop("alpha should be set in interval [0, 1]")
              }
              if (hyperparameter == "lambda.min.ratio" && (any(value < 0) || any(value >= 1))) {
                stop("lambda.min.ratio should be set in interval [0, 1)")
              }
            } else {
              if (hyperparameter == "alpha"){
                if(distribution_choice == "uniform" && pars["max"] > 1) warning("max above upper range for alpha")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for alpha")
                if(distribution_choice == "normal" && (pars["mean"] + pars["sd"]/2 > 1)) warning("mean + sd/2 above upper range for alpha")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for alpha")
                if(distribution_choice == "lognormal" && (pars["meanlog"] + pars["sdlog"]/2 > 1)) warning("meanlog + sdlog/2 above upper range for alpha")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for alpha")
                if(distribution_choice == "constant" && (any(value$value < 0) || any(value$value > 1))) stop("alpha should be set in interval [0, 1]")
              }
              if (hyperparameter == "lambda.min.ratio"){
                if(distribution_choice == "uniform" && pars["max"] >= 1) warning("max above upper range for lambda.min.ratio")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for lambda.min.ratio")
                if(distribution_choice == "normal" && (pars["mean"] + pars["sd"]/2 >= 1)) warning("mean + sd/2 above upper range for lambda.min.ratio")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for lambda.min.ratio")
                if(distribution_choice == "lognormal" && (pars["meanlog"] + pars["sdlog"]/2 >= 1)) warning("meanlog + sdlog/2 above upper range for lambda.min.ratio")
                if(distribution_choice == "lognormal" && (pars["meanlog"] + pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for lambda.min.ratio")
                if(distribution_choice == "constant" && (any(value$value < 0) || any(value$value >= 1)))stop("lambda.min.ratio should be set in interval [0, 1)")
              }
            }
          }

          #RF Logic
          if (object@sb_algorithm == "rf") {
            if(tuning_method != "random_search"){
              if (hyperparameter == "num.trees" && tuning_method == "bayesian_opt" && (any(value <= 0) || any(!is.integer(value)))) {
                stop("num.trees should be a positive integer without decimals")
              }
              if (hyperparameter == "num.trees" && tuning_method == "grid_search" && (any(value <= 0) || any(!(value == floor(value))))) {
                stop("num.trees should be a positive integer without decimals")
              }
              if (hyperparameter == "mtry" && (any(value < 0) || any(value > 1))) {
                stop("mtry should be set in interval [0, 1]")
              }
              if (hyperparameter == "max.depth" && tuning_method == "bayesian_opt" && (any(value <= 0) || any(!is.integer(value)))) {
                stop("max.depth should be a positive integer without decimals")
              }
              if (hyperparameter == "max.depth" && tuning_method == "grid_search" && (any(value <= 0) || any(!(value == floor(value))))) {
                stop("max.depth should be a positive integer without decimals")
              }

            } else {
              if (hyperparameter == "num.trees"){
                if(distribution_choice != "constant" && any(!is.integer(pars))) stop("pars should be set as integers for num.trees")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for num.trees")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for num.trees")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for num.trees")
                if(distribution_choice == "constant" && (any(value$value < 0))) stop("num.trees should be positive")
              }
              if (hyperparameter == "mtry"){
                if(distribution_choice == "uniform" && pars["max"] > 1) warning("max above upper range for mtry")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for mtry")
                if(distribution_choice == "normal" && (pars["mean"] + pars["sd"]/2 > 1)) warning("mean + sd/2 above upper range for mtry")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for mtry")
                if(distribution_choice == "lognormal" && (pars["meanlog"] + pars["sdlog"]/2 > 1)) warning("meanlog + sdlog/2 above upper range for mtry")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for mtry")
                if(distribution_choice == "constant" && (any(value$value < 0) || any(value$value > 1))) stop("mtry should be set in interval [0, 1]")
              }
              if (hyperparameter == "max.depth"){
                if(distribution_choice != "constant" && any(!is.integer(pars))) stop("pars should be set as integers for max.depth")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for max.depth")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for max.depth")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for max.depth")
                if(distribution_choice == "constant" && (any(value$value < 0))) stop("max.depth should be positive")
              }
            }
          }

          #XGB Logic
          if (object@sb_algorithm == "xgb") {
            if(tuning_method != "random_search"){
              if (hyperparameter == "eta" && (any(value < 0) || any(value >= 1))) {
                stop("eta should be set in interval [0, 1)")
              }
              if (hyperparameter == "colsample_bytree" && (any(value < 0) || any(value > 1))) {
                stop("colsample_bytree should be set in interval [0, 1]")
              }
              if (hyperparameter == "subsample" && (any(value < 0) || any(value > 1))) {
                stop("subsample should be set in interval [0, 1]")
              }
              if (hyperparameter == "max_depth" && tuning_method == "grid_search" && (any(value <= 0) || any(!(value == floor(value))))) {
                stop("max_depth should be a positive integer without decimals")
              }
              if (hyperparameter == "max_depth" && tuning_method == "bayesian_opt" && (any(value <= 0) || any(!is.integer(value)))) {
                stop("max_depth should be a positive integer without decimals")
              }

            } else {
              if (hyperparameter == "eta"){
                if(distribution_choice == "uniform" && pars["max"] > 1) warning("max above upper range for eta")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for eta")
                if(distribution_choice == "normal" && (pars["mean"] + pars["sd"]/2 > 1)) warning("mean + sd/2 above upper range for eta")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for eta")
                if(distribution_choice == "lognormal" && (pars["meanlog"] + pars["sdlog"]/2 > 1)) warning("meanlog + sdlog/2 above upper range for eta")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for eta")
                if(distribution_choice == "constant" && (any(value$value < 0) || any(value$value > 1))) stop("eta should be set in interval [0, 1]")
              }
              if (hyperparameter == "colsample_bytree"){
                if(distribution_choice == "uniform" && pars["max"] > 1) warning("max above upper range for colsample_bytree")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for colsample_bytree")
                if(distribution_choice == "normal" && (pars["mean"] + pars["sd"]/2 > 1)) warning("mean + sd/2 above upper range for colsample_bytree")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for colsample_bytree")
                if(distribution_choice == "lognormal" && (pars["meanlog"] + pars["sdlog"]/2 > 1)) warning("meanlog + sdlog/2 above upper range for colsample_bytree")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for colsample_bytree")
                if(distribution_choice == "constant" && (any(value$value < 0) || any(value$value > 1))) stop("colsample_bytree should be set in interval [0, 1]")
              }
              if (hyperparameter == "subsample"){
                if(distribution_choice == "uniform" && pars["max"] > 1) warning("max above upper range for subsample")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for subsample")
                if(distribution_choice == "normal" && (pars["mean"] + pars["sd"]/2 > 1)) warning("mean + sd/2 above upper range for subsample")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for subsample")
                if(distribution_choice == "lognormal" && (pars["meanlog"] + pars["sdlog"]/2 > 1)) warning("meanlog + sdlog/2 above upper range for subsample")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for subsample")
                if(distribution_choice == "constant" && (any(value$value < 0) || any(value$value > 1))) stop("subsample should be set in interval [0, 1]")
              }
              if (hyperparameter == "max_depth"){
                if(distribution_choice != "constant" && any(!is.integer(pars))) warning("pars should be set as integers for max_depth")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for max_depth")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for max_depth")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for max_depth")
                if(distribution_choice == "constant" && (any(value$value < 0))) stop("max_depth should be positive")
              }
            }
          }


          #NN Logic
          if (object@sb_algorithm == "nn") {
            if(tuning_method != "random_search"){
              if (hyperparameter == "droprate" && (any(value < 0) || any(value >= 1))) {
                stop("droprate should be set in interval [0, 1)")
              }
              if (hyperparameter == "number_of_epochs" && tuning_method == "grid_search" && (any(value <= 0) || any(!(value == floor(value))))) {
                stop("number_of_epochs should be a positive integer without decimals")
              }
              if (hyperparameter == "number_of_epochs" && tuning_method == "bayesian_opt" && (any(value <= 0) || any(!is.integer(value)))) {
                stop("number_of_epochs should be a positive integer without decimals")
              }
              if (hyperparameter == "size_of_batch" && tuning_method == "grid_search" && (any(value <= 0) || any(!(value == floor(value))))) {
                stop("size_of_batch should be a positive integer without decimals")
              }
              if (hyperparameter == "size_of_batch" && tuning_method == "bayesian_opt" && (any(value <= 0) || any(!is.integer(value)))) {
                stop("size_of_batch should be a positive integer without decimals")
              }
            } else {
              if (hyperparameter == "droprate"){
                if(distribution_choice == "uniform" && pars["max"] > 1) warning("max above upper range for droprate")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for droprate")
                if(distribution_choice == "normal" && (pars["mean"] + pars["sd"]/2 > 1)) warning("mean + sd/2 above upper range for droprate")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for droprate")
                if(distribution_choice == "lognormal" && (pars["meanlog"] + pars["sdlog"]/2 > 1)) warning("meanlog + sdlog/2 above upper range for droprate")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for droprate")
                if(distribution_choice == "constant" && (any(value$value < 0) || any(value$value > 1))) stop("droprate should be set in interval [0, 1]")
              }
              if (hyperparameter == "number_of_epochs"){
                if(distribution_choice != "constant" && any(!is.integer(pars))) stop("pars should be set as integers for number_of_epochs")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for number_of_epochs")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for number_of_epochs")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for number_of_epochs")
                if(distribution_choice == "constant" && (any(value$value < 0))) stop("number_of_epochs should be positive")
              }
              if (hyperparameter == "size_of_batch"){
                if(distribution_choice != "constant" && any(!is.integer(pars))) stop("pars should be set as integers for size_of_batch")
                if(distribution_choice == "uniform" && pars["min"] < 0) warning("min below lower range for size_of_batch")
                if(distribution_choice == "normal" && (pars["mean"] - pars["sd"]/2 < 0)) warning("mean - sd/2 below lower range for size_of_batch")
                if(distribution_choice == "lognormal" && (pars["meanlog"] - pars["sdlog"]/2 < 0)) warning("meanlog - sdlog/2 below lower range for size_of_batch")
                if(distribution_choice == "constant" && (any(value$value < 0))) stop("size_of_batch should be positive")
              }
            }
          }
        }
        #Check if init_points > number of hypers
        ###Counted against the searched hyperparameters only, matching
        ###check_inputs_sb_backtest(): constants are removed from the surrogate's
        ###input space, so they must not inflate this count.
        if(tuning_method == "bayesian_opt" && sum(!is_constant_hyperparameter) >= object@tuning_strategy@init_points){
          stop("init_points should be greater than the number of hyperparameters")
        }

      }
    }
    return(TRUE)
  }
)

#sb_metabacktest_config-----------------------------------------------------
#' @title sb_metabacktest_config Class
#' @description The sb_metabacktest_config class configures a meta-learning (stacking) backtest:
#' it wraps a single meta-learner `sb_backtest_config` together with the rules for building the
#' meta feature set from base learners' out-of-sample predictions (feature passthrough,
#' normalization, winsorization).
#' @slot meta_sb_backtest_config A `sb_backtest_config` with the configuration for the meta learner
#' @slot features_passthrough A character vector indicating which features from \code{features_m_df} are to be passed through to the meta learner.
#'   Alternatively, if \code{'all'}, all features are passed through. If \code{'none'}, no features are passed through. Default is \code{'none'}.
#' @slot normalize_base_predictions Logical; if \code{TRUE}, normalizes the base learners' predictions before passing them to the meta learner. Default is \code{TRUE}.
#' @slot winsorize_base_predictions Logical; if \code{TRUE}, winsorizes the base learners' predictions before passing them to the meta learner. Default is \code{FALSE}.
#' @slot allow_heterogeneous_base_features Logical; if \code{TRUE}, permits base learners fitted on
#'   different feature sets, and on different \code{features_m_df} objects, to be stacked together.
#'   Requires \code{features_passthrough = "none"}, which the validity function enforces, since only
#'   then does the meta learner ignore \code{features_m_df} and build its design matrix purely from
#'   the base learners' predictions joined on \code{id}. All base learners must still score an
#'   identical \code{id} set. Default is \code{FALSE}, which reproduces historical behaviour exactly.
#' @slot config_name A character string with the name of the configuration
#'
#' @section Validity:
#' \itemize{
#'   \item The meta learner's \code{sb_algorithm} may not be \code{rp}/\code{hrp}/\code{mvo}/\code{mmaf}.
#'   \item The meta learner requires a \code{tuning_strategy} unless it is \code{ols} or heuristic.
#'   \item \code{chosen_signals_and_positions} must be \code{"all"} (positions are corrected via \code{features_passthrough}).
#'   \item \code{features_passthrough} may not contain \code{"long"}, \code{"short"} or \code{"force"}.
#' }
#' @export
setClass(
  "sb_metabacktest_config",
  slots = list(
    meta_sb_backtest_config = "sb_backtest_config",
    features_passthrough = "character",
    normalize_base_predictions = "logical",
    winsorize_base_predictions = "logical",
    allow_heterogeneous_base_features = "logical",
    config_name = "character"
  ),
  prototype = methods::prototype(allow_heterogeneous_base_features = FALSE),
  validity = function(object) {

    #Check for tuning strat
    if (!object@meta_sb_backtest_config@sb_algorithm %in% c("ols", "ew", "sw", "rp", "hrp", "mvo", "mmaf", "custom_weights") &&
        is.null(object@meta_sb_backtest_config@tuning_strategy)){
      stop("tuning_strategy in meta_sb_backtest_config can't be NULL (except for ols and heuristic sb algorithms).")
    }

    #Check for rp or mvo at meta-level
    if (object@meta_sb_backtest_config@sb_algorithm %in% c("rp", "hrp", "mvo", "mmaf")){
      stop("rp, hrp, mvo and mmaf are not supported at meta-level at this time.")
    }

    #Check for ss_backtest_results at meta-level
    if (object@meta_sb_backtest_config@chosen_signals_and_positions != "all"){
      stop("chosen_signals_and_positions should always be 'all' at meta-level.",
           "This is because features positions are already corrected through features_passthrough, which will replicate base chosen_signal_and_positions.")
    }

    #Check for features_passthrough
    if (any(object@features_passthrough %in% c("long", "short", "force"))){
      stop ("features_passthrough should just declare which signals from features_m_df should be added to meta learner features.
            Postions will be corrected based on base-level chosen_signals_and_positions.")
    }

    #Check for allow_heterogeneous_base_features
    ##The relaxation is only well-defined when nothing is passed through. With
    ##features_passthrough != "none" the meta learner selects pass-through columns from
    ##the single supplied features_m_df, so a pool whose learners saw different feature
    ##sets makes "which learner's features?" ill-posed rather than merely unchecked.
    ##Enforced here rather than at run time so the combination cannot be constructed at
    ##all: the pairing is a property of the configuration, and a config that cannot exist
    ##cannot be stored, reloaded a year later, and only then discovered to be invalid.
    if (length(object@allow_heterogeneous_base_features) != 1 ||
        is.na(object@allow_heterogeneous_base_features)){
      stop("allow_heterogeneous_base_features must be a single non-missing logical.")
    }
    if (object@allow_heterogeneous_base_features &&
        !(length(object@features_passthrough) == 1 && object@features_passthrough == "none")){
      stop("allow_heterogeneous_base_features = TRUE requires features_passthrough = 'none'. ",
           "Only then does the meta learner ignore features_m_df entirely and build its ",
           "design matrix purely from the base learners' predictions joined on id.")
    }

    return(TRUE)
  }
)


#sb_model--------------------------------------------------------------
#' Define the `sb_model` S4 Class
#'
#' This class represents a (re)fitted sb model. It encapsulates the algorithm used, hyperparameters, custom objective,
#' feature data, target variable, and the fitted model object.
#'
#' @slot sb_algorithm A character string specifying the algorithm used ("ols", "glmnet", "rf", "xgb", "nn", "ew", "sw", "rp", "hrp", "mvo", "mmaf" or "custom_weights").
#' @slot best_hyperparameters The chosen hyperparameters relevant to the specified machine learning algorithm. Applicable only for machine-learning algorithms.
#' @slot model The fitted model object, which varies based on the algorithm used.
#' @slot model_class A character string specifying the class of the model object.
#' @slot eligible_signals A vector of eligible signals used to fit the model.
#' @slot custom_objective A custom objective function used to fit the model.
#' @slot huber_delta A numeric value specifying the delta parameter for the Huber loss function. Applicable only for machine-learning algorithms.
#' @slot keras_architecture_parameters A list of parameters used to define the architecture of a neural network model. Applicable only for the "nn" algorithm.
#'
#' @section Methods:
#' \describe{
#'   \item{\code{predict(new_features_m_df)}}{Generates predictions using the fitted model on new feature data.}
#' }
#'
#' @export
setClass(
  "sb_model",
  slots = list(
    model = "ANY",
    eligible_signals = "character",
    model_class = "character",
    sb_algorithm = "character",
    best_hyperparameters = "ANY",
    custom_objective = "ANY",
    huber_delta = "numeric",
    keras_architecture_parameters = "ANY"
  )
)



#sb_backtest_results---------------------------------------------------
#' S4 Class for Time Series Walk-Forward Validation Results of Signal-Blending Models
#'
#' This S4 class encapsulates the results and parameters from performing walk-forward
#' validation on time series data using signal-blending algorithms. It includes
#' information about the model, data, tuning process, and performance metrics.
#'
#' @slot oos_sb_outputs_m_df A meta dataframe containing out-of-sample predictions, target and errors, all indexed by testing dates.
#' @slot sb_backtest_config An object of class `sb_backtest_config` containing the configuration parameters for the backtest.
#' @slot oos_testing_eval_metrics_m_xts A meta_xts of evaluation metrics for the out-of-sample testing samples.
#' @slot consolidated_eval_metrics A data frame containing the consolidated evaluation metrics for the out-of-sample testing samples.
#' @slot final_sb_model The final (re)fitted signal blending model with best hyperparameters found after tuning. Possibly a object of sb_model S4 class.
#' @slot final_gsm The final (re)fitted global surrogate model.
#' @slot chosen_eval_metric_validation A list of data.frames with the chosen evaluation metric calculated for the hyperparameter grid.
#' @slot best_hyperparameters_m_xts A meta_xts containing the best hyperparameters selected during tuning for each rebalancing period.
#' @slot validation_eval_metrics_hyper_choice_m_xts A meta_xts with all evaluation metrics calculated for the set of best hyperparameters.
#' @slot feature_importance_m_df A meta_dataframe containing the feature importance scores for each feature.
#' @slot final_feature_importance_m_d_ref A meta_dataframe containing the final feature importance scores for the chosen model.
#' @slot sb_backtest_workflow A list containing sb_backtest_workflow about the walk-forward validation process.
#' @slot backtest_identifier A character string that identifies the backtest.
#'
#' @section Validity:
#' When non-\code{NULL}: \code{sb_backtest_config} must be a \code{sb_backtest_config};
#' \code{final_sb_model} a \code{sb_model}; \code{final_gsm} an \code{lm} or \code{rpart};
#' \code{feature_importance_m_df}/\code{final_feature_importance_m_d_ref} a \code{meta_dataframe};
#' the \code{*_m_xts} slots \code{meta_xts} objects. (Model/importance slots may be empty in an update.)
#'
#' @return An S4 object of class `sb_backtest_results` containing all the specified results and sb_backtest_workflow.
#'
#'
#'@export
setClass(
  "sb_backtest_results",
  slots = list(
    oos_sb_outputs_m_df = "meta_dataframe",
    sb_backtest_config = "ANY",
    oos_testing_eval_metrics_m_xts = "ANY",
    consolidated_eval_metrics = "data.frame",
    final_sb_model = "ANY", #In an update, this can be empty
    final_gsm = "ANY",
    chosen_eval_metric_validation = "ANY",
    best_hyperparameters_m_xts = "ANY",
    validation_eval_metrics_hyper_choice_m_xts = "ANY",
    feature_importance_m_df = "ANY", #In an update, this can be empty
    final_feature_importance_m_d_ref = "ANY", #In an update, this can be empty
    sb_backtest_workflow = "list",
    backtest_identifier = "character"
  ), validity = function(object){

    #Sb backtest config
    if (!is.null(object@sb_backtest_config)) {
      if (!inherits(object@sb_backtest_config, "sb_backtest_config")) {
        return("sb_backtest_config must be a 'sb_backtest_config' object")
      }
    }

    if (!is.null(object@final_gsm) && !class(object@final_gsm) %in% c("lm", "rpart")){
      stop("final_gsm must be a 'lm' or 'rpart' object")
    }

    if (!is.null(object@validation_eval_metrics_hyper_choice_m_xts) && !inherits(object@validation_eval_metrics_hyper_choice_m_xts, "meta_xts")){
      stop("validation_eval_metrics_hyper_choice_xts must be an 'meta_xts' object")
    }

    if (!is.null(object@best_hyperparameters_m_xts) && !inherits(object@best_hyperparameters_m_xts, "meta_xts")){
      stop("best_hyperparameters_xts must be an 'meta_xts' object")
    }

    if (!is.null(object@oos_testing_eval_metrics_m_xts) && !inherits(object@oos_testing_eval_metrics_m_xts, "meta_xts")){
      stop("oos_testing_eval_metrics_m_xts must be an 'meta_xts' object")
    }

    if (!is.null(object@final_sb_model) && !inherits(object@final_sb_model, "sb_model")) {
      return("final_sb_model must be a 'sb_model' object")
    }

    if (!is.null(object@feature_importance_m_df) && !inherits(object@feature_importance_m_df, "meta_dataframe")) {
      return("feature_importance_m_df must be a 'meta_dataframe' object")
    }

    if (!is.null(object@final_feature_importance_m_d_ref) && !inherits(object@final_feature_importance_m_d_ref, "meta_dataframe")) {
      return("final_feature_importance_m_d_ref must be a 'meta_dataframe' object")
    }

  }
)

#' @title sb_metabacktest_results Class
#' @description An S4 class designed to store and manage a collection of `sb_backtest_results` objects,
#' along with consolidated and time series evaluation metrics for machine learning models.
#'
#' @slot sb_metabacktest_config An object of class `sb_metabacktest_config` containing the configuration for the meta backtest.
#' @slot meta_sb_backtest_results An object of class `sb_backtest_results` containing the results of the meta-learner.
#' @slot base_sb_backtest_results_list A list of `sb_backtest_results` objects for each base algorithm.
#' @slot base_learners_oos_predictions_m_df A meta dataframe containing out-of-sample predictions, target and errors for each base algorithm.
#' @slot combined_oos_testing_metrics A list containing data frames with consolidated out-of-sample testing evaluation metrics for each algorithm.
#' @slot mean_validation_metrics A data frame containing the mean validation metrics for each algorithm.
#' @slot time_series_oos_testing_metrics A list of data frames for each evaluation metric over time (out-of-sample testing).
#' @slot time_series_validation_metrics A list of data frames for each evaluation metric over time (validation).
#' @slot backtest_identifier A character string used to identify the backtest.
#'
#' @section Validity:
#' When non-\code{NULL}, \code{sb_metabacktest_config} must be a \code{sb_metabacktest_config}
#' and \code{mean_validation_metrics} a \code{data.frame}; every element of
#' \code{base_sb_backtest_results_list} must be a \code{sb_backtest_results} and every element
#' of \code{combined_oos_testing_metrics} a \code{data.frame}.
#'
#' @export
setClass(
  "sb_metabacktest_results",
  slots = list(
    sb_metabacktest_config = "ANY",
    meta_sb_backtest_results = "sb_backtest_results",
    base_sb_backtest_results_list = "list",
    base_learners_oos_predictions_m_df = "meta_dataframe",
    combined_oos_testing_metrics = "list",
    mean_validation_metrics = "ANY",
    time_series_oos_testing_metrics = "list",
    time_series_validation_metrics = "list",
    backtest_identifier = "character"
  ),
  validity = function(object) {

    if (!is.null(object@sb_metabacktest_config)){
      if (!inherits(object@sb_metabacktest_config, "sb_metabacktest_config")) {
        return("sb_metabacktest_config must be a 'sb_metabacktest_config' object")
      }
    }

    if (!all(sapply(object@base_sb_backtest_results_list, function(x) methods::is(x, "sb_backtest_results")))) {
      return("All elements in 'base_sb_backtest_results_list' must be of class 'sb_backtest_results'.")
    }

    if (!all(sapply(object@combined_oos_testing_metrics, function(x) methods::is(x, "data.frame")))){
      return("All elements in 'combined_oos_testing_metrics' must be of class 'data.frame'.")
    }

    if (!is.null(object@mean_validation_metrics)){
      if (!methods::is(object@mean_validation_metrics, "data.frame")){
        return("mean_validation_metrics must be a 'data.frame' object")
      }
    }

    TRUE
  }
)


#port_backtest_config---------------------------------------------------
#' Class for Port Backtest Config
#'
#' An S4 class specifying parameters for backtesting stock-level portfolios.
#'
#' @slot chosen_score_metric_and_position A character string representing the chosen score metric and position.
#' @slot eligibility_quantile_range A numeric vector of length 2 representing the quantile range for stock selection.
#' @slot min_eligible_assets_fallback A numeric value representing the minimum number of eligible assets.
#' @slot chosen_scaler A character string representing the chosen scaler method.
#' @slot scaler_shrinkage A numeric value representing the scaler shrinkage parameter.
#' @slot use_raw_for_eligibility Logical; if TRUE, uses raw scores for eligibility instead of scaled scores.
#' @slot enable_group_representativeness Logical; if TRUE, ensures at least one asset in all groups in groups_m_d_ref
#' @slot selected_benchmark A character string representing the selected benchmark.
#' @slot initial_buffer_period A numeric value representing the initial buffer period.
#' @slot rebalancing_months A numeric value representing the number of months for rebalancing.
#' @slot cov_est_method An object of class `cov_est_method` representing the covariance estimation method and relevant parameters. Current methods are: 'sample', 'ewma', 'cc' (constant correlation),
#' 'pca1', 'pca2', 'shrink_id' (shrinkage to identity matrix), 'shrink_cc' (shrinkage to constant correlation). This is only relevant for the covariance-based methods 'rp', 'hrp', 'mvo' and 'mmaf'.
#' @slot port_construction_method A character string representing the type of portfolio. Must be one of 'ew', 'sw', 'cw', 'cs', 'rp', 'hrp', 'mvo', 'mmaf', 'slsaf' or 'custom_weights'. For signal portfolios,
#' 'cw' and 'cs' are not applicable. For signal portfolios, this is inferred based on sb_algorithm.
#' @slot mvo_parameters An object of class `mvo_parameters` representing the parameters for mean-variance optimization. This is only relevant for 'mvo'.
#' @slot rp_parameters An object of class `rp_parameters` representing the parameters for risk parity. This is only relevant for 'rp'.
#' @slot hrp_parameters An object of class `hrp_parameters` representing the parameters for hierarchical risk parity. This is only relevant for 'hrp'.
#' @slot mmaf_parameters An object of class `mmaf_parameters` representing the parameters for the MMAF method. This is only relevant for 'mmaf'.
#' @slot slsaf_parameters An object of class `slsaf_parameters` representing the parameters for the SLSAF method. This is only relevant for 'slsaf'.
#' @slot main_liquidity_metric A character string indicating which of the variables in `liquidity_m_df` should be ultimately used.
#' @slot liquidity_floor_cutoffs Mandatory if `turnover_constraint_policy` and/or `liquidity_constraint_policy` are provided.
#' A data.frame containing a liquidity_classification column and liquidity metrics that define cutoff values to classify stocks according to liquidity.
#' Each liquidity_classification must be named according to the 5 following liquidity classifications: ("micro_caps", "small_caps", "mid_caps", "large_caps" and "mega_caps)
#' and numeric column indicate the minimum acceptable values (adjusted for inflation) for stocks to have that classification.
#' Classification should be in ascending order (from least liquid to most liquid) for all metrics.
#' If set in decimals, values will be interpreted as quantiles and classification will be set accordingly.
#' Stocks with liquidity lower than micro_caps will receive nano_caps classification.
#' @slot liquidity_constraint_policy The policy to handle liquidity constraints. It is only relevant for stocks. Possible elements are:
#' - `liquidity_floor_rule`: A character indicating the liquidity classification (e.g., micro_caps, small_caps) used to filter stocks. Stocks with less liquidity than specified in `liquidity_floor_rule` will be considered ineligible.
#'   In the case of the `generate_box_constraints` function, `liquidity_constraint_policy` can also contain:
#' - `liquidity_cap_rules`: A named vector with one or many elements used to create upper bounds for weights based on a liquidity classification.
#'   Each element's name and corresponding value represents, respectively:
#'   - `liquidity_classification`: The character classification for the cap.
#'   - `liquidity_cap`: A numeric value indicating the cap (upper bound) for stocks with that liquidity classification.
#'   Many liquidity caps might be created.
#' @slot turnover_constraint_policy The policy to handle turnover constraints. It is only relevant for stocks. Its elements are used to build buffer zones and apply turnover constraints.
#' - It should contain:
#'  - `quantile_range_buffer`: A numeric value indicating the increase of quantile eligibility (both sides) range to be used for the buffer zones.
#'  - `turnover_cap_rules`: A named vector with one or many elements used to create maximum absolute bounds for weights in relation to the old portfolio, based on a liquidity classification.
#'   Each element's name and corresponding value represents, respectively:
#'   - `liquidity_classification`: The character classification for the cap.
#'   - `turnover_cap`: A numeric value indicating the cap (lower and upper bounds) for stocks with that liquidity classification.
#'   Many turnover caps might be created.
#'   Stocks that are less liquid than specified for a buffer zone and have a signal higher than the respective buffer quantile will be considered eligible, even if they do not meet the `liquidity_floor_rule`.
#' @slot concentration_constraint_policy The policy to handle concentration constraints. This is the only constraint that is applicable to either signal or stock portfolios.
#'  It contains up to to four elements:
#' - `benchmark`: A character vector describing the benchmark to be used to apply constraint.
#' For signal portfolios, possible options are theme_ss or theme_sb.
#' For stock portfolios, there must be a correspondence in `benchmark_weights_m_df`
#' - `max_abs_active_individual_weight`: The maximum absolute individual active weights.
#' - `max_abs_active_group_weight`: The maximum absolute sector/theme active weight used for creating group constraints in `generate_sector_constraints`.
#' If a given sector has no eligible stock, the one with the greatest signal will be automatically promoted. In case of signal portfolios, during ss_backtest, signals with highest alpha_t_values are promoted if
#' enable_theme_representativeness is TRUE.
#' Note that, in the context of stocks, a `benchmark_weights_m_d_ref` data frame must also be supplied.
#' @slot transaction_costs_parameters An object of class `transaction_costs_parameters` containing the parameters for calculating direct and indirect costs.
#' @slot config_name A character string representing the name of the configuration.
#'
#' @export
setClass(
  "port_backtest_config",
  slots = list(
    chosen_score_metric_and_position = "ANY",
    eligibility_quantile_range = "numeric",
    min_eligible_assets_fallback = "ANY",
    chosen_scaler = "ANY",
    scaler_shrinkage = "ANY",
    use_raw_for_eligibility = "ANY",
    enable_group_representativeness = "ANY",
    selected_benchmark = "ANY",
    initial_buffer_period = "numeric",
    rebalancing_months = "numeric",
    cov_est_method = "cov_est_method",
    port_construction_method = "character",
    mvo_parameters = "ANY",
    rp_parameters = "ANY",
    hrp_parameters = "ANY",
    mmaf_parameters = "ANY",
    slsaf_parameters = "ANY",
    main_liquidity_metric = "character",
    liquidity_floor_cutoffs = "ANY",
    liquidity_constraint_policy = "ANY",
    turnover_constraint_policy = "ANY",
    concentration_constraint_policy = "ANY",
    transaction_costs_parameters = "ANY",
    config_name = "character"
  ),
  validity = function(object){
    #Check if selected benchmark is character if not NULL
    if (!is.null(object@selected_benchmark)){
      if (!is.character(object@selected_benchmark)){
        stop("selected_benchmark must be a character.")
      }
    }

    #Port method
    #The custom_weights method supplies its weights rather than deriving them, so there is no
    #score to rank on and no cross-sectional rule to apply. The engine reaches it through the
    #weights-based route in classify_investment_universe() and through set_portfolio_weights(),
    #which takes the positively-weighted assets as the eligible set.
    if (object@port_construction_method == "custom_weights" && !is.null(object@chosen_score_metric_and_position)){
      stop("chosen_score_metric_and_position must be NULL when port_construction_method is custom_weights")
    }

    #Supplied weights reach the engine through a route that returns before the policy cascade,
    #so a policy attached alongside them is never applied. Refusing it is the difference between
    #a constraint that does not bind and one that was silently discarded.
    if (object@port_construction_method == "custom_weights") {
      inert_policies <- c(
        liquidity_constraint_policy = !is.null(object@liquidity_constraint_policy),
        turnover_constraint_policy = !is.null(object@turnover_constraint_policy),
        concentration_constraint_policy = !is.null(object@concentration_constraint_policy))
      if (any(inert_policies)) {
        stop(paste(names(inert_policies)[inert_policies], collapse = " and "),
             " cannot be combined with port_construction_method 'custom_weights': the weights ",
             "are supplied rather than derived, so the eligibility cascade these policies act on ",
             "never runs and they would be silently ignored.")
      }
    }

    if (!object@port_construction_method %in% c("ew", "sw", "cw", "cs", "rp", "mvo", "hrp", "mmaf", "slsaf", "custom_weights")){
      stop("port_construction_method must be one of 'ew', 'sw', 'cw', 'cs', 'rp', 'mvo', 'hrp', 'mmaf', 'slsaf' or 'custom_weights'.")
    }

    #Check if eligibility_quantile_range has length of 2 between 0 and 1
    if (length(object@eligibility_quantile_range) != 2 | any(object@eligibility_quantile_range < 0) | any(object@eligibility_quantile_range > 1)){
      stop("eligibility_quantile_range must be a numeric vector of length 2 between 0 and 1.")
    }

    #Check if min_eligible_assets_fallback is a integer single numeric value if not null
    if (!is.null(object@min_eligible_assets_fallback)){
      if (!is.numeric(object@min_eligible_assets_fallback) | length(object@min_eligible_assets_fallback) != 1 | !is.numeric(object@min_eligible_assets_fallback) |
          !(object@min_eligible_assets_fallback %% 1 == 0)){
        stop("min_eligible_assets_fallback must be a single integer numeric value.")
      }
    }

    #Check if enable_group_representativeness is logical if not NULL
    if (!is.null(object@enable_group_representativeness)){
      if (!is.logical(object@enable_group_representativeness) | length(object@enable_group_representativeness) != 1){
        stop("enable_group_representativeness must be a single logical value (TRUE or FALSE).")
      }
    }

    #chosen_scaler checks
    if (is.null(object@chosen_scaler)){
      if (!is.null(object@use_raw_for_eligibility)){
        stop("chosen_scaler must be provided if use_raw_for_eligibility is not NULL")
      }

      if (!is.null(object@scaler_shrinkage)){
        stop("chosen_scaler must be provided if scaler_shrinkage is not NULL")
      }
    } else {

      if (is.null(object@use_raw_for_eligibility)){
        stop("use_raw_for_eligibility must be provided if chosen_scaler is not NULL")
      }

      if (is.null(object@scaler_shrinkage)){
        stop("scaler_shrinkage must be provided if chosen_scaler is not NULL")
      }

      if (!is.null(object@use_raw_for_eligibility) && !is.logical(object@use_raw_for_eligibility)){
        stop("use_raw_for_eligibility must be a logical value (TRUE or FALSE).")
      }

      # Check that scaler_shrinkage is between 0 and 1
      if (!is.null(object@scaler_shrinkage) && (
        !is.numeric(object@scaler_shrinkage) || is.na(object@scaler_shrinkage) ||
        length(object@scaler_shrinkage) != 1 ||
        object@scaler_shrinkage < 0 || object@scaler_shrinkage > 1
      )) {
        stop("scaler_shrinkage must be a single number between 0 and 1")
      }

      #Check that use_raw_for_eligibility is FALSE if scaler_shrinkage is 0
      # or if scaler_shrinkage is NULL
      if (!is.null(object@scaler_shrinkage) && object@scaler_shrinkage == 0 &&
          !is.null(object@use_raw_for_eligibility) && isTRUE(object@use_raw_for_eligibility)){
        stop("use_raw_for_eligibility must be FALSE if scaler_shrinkage is 0")
      }
      if (is.null(object@scaler_shrinkage) &&
          !is.null(object@use_raw_for_eligibility) && isTRUE(object@use_raw_for_eligibility)){
        stop("use_raw_for_eligibility must be FALSE if scaler_shrinkage is NULL")
      }
    }

    ###Check classes
    ####MVO
    if (!is.null(object@mvo_parameters)){
      if(!inherits(object@mvo_parameters, "mvo_parameters")){
        stop("mvo_parameters must be an object of class mvo_parameters.")
      }
    }
    ####RP Pars
    if (!is.null(object@rp_parameters)){
      if(!inherits(object@rp_parameters, "rp_parameters")){
        stop("rp_parameters must be an object of class rp_parameters.")
      }
    }
    ####HRP Pars
    if (!is.null(object@hrp_parameters)){
      if(!inherits(object@hrp_parameters, "hrp_parameters")){
        stop("hrp_parameters must be an object of class hrp_parameters.")
      }
    }
    ####MMAF Pars
    if (!is.null(object@mmaf_parameters)){
      if(!inherits(object@mmaf_parameters, "mmaf_parameters")){
        stop("mmaf_parameters must be an object of class mmaf_parameters.")
      }
    }
    ####SLSAF Pars
    if (!is.null(object@slsaf_parameters)){
      if(!inherits(object@slsaf_parameters, "slsaf_parameters")){
        stop("slsaf_parameters must be an object of class slsaf_parameters.")
      }
    }

    ###SLSAF is benchmark-relative by construction: it expresses conviction as an
    ###overlay on benchmark positions, so it cannot be built without one
    if (object@port_construction_method == "slsaf"){
      if (is.null(object@slsaf_parameters)){
        stop("slsaf_parameters must be provided when port_construction_method is 'slsaf'.")
      }
      if (is.null(object@selected_benchmark)){
        stop("selected_benchmark must be provided when port_construction_method is 'slsaf'.")
      }
      ####The overlay already determines every active weight, so a concentration policy
      ####would either duplicate it or silently fight it
      if (!is.null(object@concentration_constraint_policy)){
        stop("concentration_constraint_policy is not supported for 'slsaf': the active weights are already set by the long/short overlay.")
      }
      ####See the note in classify_investment_universe(): the buffer rule gates on
      ####bop_port_weights > 0, which under this construction is true for every
      ####constituent not fully sold, so the whole short block would drain into the
      ####long block
      if (!is.null(object@turnover_constraint_policy)){
        stop("turnover_constraint_policy is not supported for 'slsaf'.")
      }
    }



    ##Check chosen_score_metric_and_position
    if(!is.null(object@chosen_score_metric_and_position) &&
       (length(object@chosen_score_metric_and_position) != 1 || !object@chosen_score_metric_and_position %in% c("long", "short"))){
      stop("chosen_score_metric_and_position must a single named vector with either 'long' or 'short' values")
    }

    ###Check benchmark of cov_est_method
    if(!is.null(object@selected_benchmark)){
      if (object@cov_est_method@cov_matrix_benchmark != object@selected_benchmark){
        stop("cov_est_method benchmark must be the same as selected_benchmark")
      }
    }

    ###Check liquidity_floor_cutoffs
    if (!is.null(object@liquidity_floor_cutoffs)){

      validate_liquidity_floor_cutoffs(object@liquidity_floor_cutoffs, object@main_liquidity_metric)

      ###Check if liquidity_floor_rule is contemplated
      if (!is.null(object@liquidity_constraint_policy@liquidity_floor_rule) &&
          !object@liquidity_constraint_policy@liquidity_floor_rule %in% dplyr::pull(object@liquidity_floor_cutoffs, liquidity_classification)){
        stop("liquidity_floor_rule must be contemplated in liquidity_floor_cutoffs")
      }

    } else {
      if (!is.null(object@liquidity_constraint_policy)){
        stop("liquidity_floor_cutoffs must be provided if liquidity_constraint_policy is provided")
      }
      if (!is.null(object@turnover_constraint_policy)){
        stop("liquidity_floor_cutoffs must be provided if turnover_constraint_policy is provided")
      }
    }

    #Liquidity constraint policy
    if (!is.null(object@liquidity_constraint_policy)){
      #S4 Class
      if(!inherits(object@liquidity_constraint_policy, "liquidity_constraint_policy")){
        stop("liquidity_constraint_policy must be an object of class liquidity_constraint_policy.")
      }

      #Check if liquidity_cap_rules match liquidity_floor_cutoffs
      if (!all(names(object@liquidity_constraint_policy@liquidity_cap_rules) %in% dplyr::pull(object@liquidity_floor_cutoffs, liquidity_classification))){
        stop("liquidity_cap_rules must match liquidity_floor_cutoffs")
      }
    }

    #Concentration constraint policy
    if (!is.null(object@concentration_constraint_policy)){
      #S4 Class
      if(!inherits(object@concentration_constraint_policy, "concentration_constraint_policy")){
        stop("concentration_constraint_policy must be an object of class concentration_constraint_policy.")
      }
      #Check benchmark
      if(object@concentration_constraint_policy@benchmark != object@selected_benchmark){
        stop("concentration_constraint_policy benchmark must be the same as selected_benchmark")
      }
    }

    TRUE
  }
)


#port_metabacktest_config-----------------------------------------------
#' Class for Port Meta Backtest Config
#'
#' An S4 class specifying how meta weights are attributed across a set of already-backtested
#' portfolios. It wraps a single \code{port_backtest_config} describing the meta allocation,
#' together with the rules for reading the base portfolios' characteristics out of a
#' \code{\link{port_backtest_cohort-class}}. The base portfolios themselves are supplied later,
#' as a cohort, to \code{\link{run_port_backtest}}.
#'
#' @section Which slots act at which level:
#' The wrapped \code{port_backtest_config} serves two levels at once, and it is worth being
#' explicit about which of its slots does what:
#' \describe{
#'   \item{meta level, allocating across base portfolios}{\code{port_construction_method},
#'     \code{chosen_score_metric_and_position} (the meta score, a column of
#'     \code{\link{port_universe_m_df-class}}), \code{eligibility_quantile_range},
#'     \code{min_eligible_assets_fallback}, the scaler slots, \code{cov_est_method} and the
#'     \code{mvo_parameters} / \code{rp_parameters} / \code{hrp_parameters} blocks.}
#'   \item{stock level, running the resulting weights as a portfolio}{
#'     \code{main_liquidity_metric} and \code{transaction_costs_parameters}, which price the
#'     trades the meta allocation implies once it is pushed through to individual stocks.}
#'   \item{both levels}{\code{rebalancing_months} and \code{initial_buffer_period}, which set the
#'     single schedule on which meta weights are formed, and \code{selected_benchmark}.}
#' }
#'
#' @section Covariance sample size is in months:
#' At meta level the assets are portfolios and their return series are monthly, so
#' \code{cov_est_method@@cov_matrix_sample_size} counts months rather than trading days. The
#' default carried by \code{\link{create_port_backtest_config}} is 252, which is a daily figure;
#' left unchanged it would ask for 21 years of monthly history. Validity warns when a
#' covariance-based method is combined with an implausibly long sample.
#'
#' @slot meta_port_backtest_config A \code{port_backtest_config} describing the meta allocation.
#' @slot type A character selecting the allocation path, either \code{"multi_port"} or
#'   \code{"risk_targeted"}. Under \code{"multi_port"} the base portfolios form a cross-section
#'   scored on a column of \code{\link{port_universe_m_df-class}}; under \code{"risk_targeted"}
#'   there is no cross-section to rank and one risky sleeve is scaled against a residual sleeve.
#'   Defaults to \code{"multi_port"}.
#' @slot risk_target_parameters A \code{\link{risk_target_parameters-class}} object on the
#'   \code{"risk_targeted"} path, holding the target level, the response exponent, the weight
#'   bounds and the residual sleeve. \code{NULL} on the \code{"multi_port"} path, where there is
#'   no sleeve to scale. Defaults to \code{NULL}.
#' @slot return_basis A character, \code{"net"} or \code{"raw"}, selecting which return basis of the
#'   base portfolios' statistics feeds the meta universe.
#' @slot cost_lookback \code{NULL} for an expanding cost average, or a single positive whole number
#'   of trailing cost observations.
#' @slot stock_cov_matrix_sample_size Numeric, in \strong{trading days}. The covariance
#'   window used by the stock-level run for its analytics. It is separate from the meta-level
#'   window in \code{meta_port_backtest_config@cov_est_method}, which counts
#'   \strong{months} because the meta level allocates over portfolios whose returns are
#'   monthly. Reusing one number for both would mean 36 months at one level and 36 days at the
#'   other. Defaults to 252.
#' @slot config_name A character string naming the configuration.
#'
#' @seealso \code{\link{create_port_metabacktest_config}}, \code{\link{port_universe_m_df-class}},
#'   \code{\link{port_backtest_cohort-class}}
#' @export
setClass(
  "port_metabacktest_config",
  slots = list(
    meta_port_backtest_config = "port_backtest_config",
    type = "character",
    return_basis = "character",
    cost_lookback = "ANY",
    stock_cov_matrix_sample_size = "numeric",
    risk_target_parameters = "ANY",
    config_name = "character"
  ),
  prototype = list(
    type = "multi_port",
    risk_target_parameters = NULL,
    ##A daily default, because this window is applied to daily stock returns
    stock_cov_matrix_sample_size = 252
  ),
  validity = function(object) {

    inner_config <- object@meta_port_backtest_config
    port_construction_method <- inner_config@port_construction_method

    ##Type
    if (length(object@type) != 1 || !object@type %in% c("multi_port", "risk_targeted")) {
      stop("type must be either 'multi_port' or 'risk_targeted'.")
    }

    #Checks common to both paths, run before the type branch so neither can skip them
    ####################
    ##Constraint policies that would be silently inert
    ###At meta level these describe stock properties portfolios do not have; at stock level the
    ###meta weights are applied as custom weights, which bypass them. That holds on both paths.
    if (!is.null(inner_config@liquidity_constraint_policy)) {
      stop("liquidity_constraint_policy is not supported at meta-level: portfolios have no liquidity ",
           "classification, and the stock-level run applies the meta weights directly.")
    }
    if (!is.null(inner_config@turnover_constraint_policy)) {
      stop("turnover_constraint_policy is not supported at meta-level: the stock-level run applies ",
           "the meta weights directly, so a buffer rule would have nothing to act on.")
    }
    if (!is.null(inner_config@concentration_constraint_policy)) {
      stop("concentration_constraint_policy is not supported at meta-level: it requires benchmark ",
           "weights over the allocated assets, which do not exist for a set of portfolios.")
    }

    ##Return basis
    if (length(object@return_basis) != 1 || !object@return_basis %in% c("net", "raw")) {
      stop("return_basis must be a single character value, either 'net' or 'raw'.")
    }

    ##Cost lookback
    if (!is.null(object@cost_lookback)) {
      if (!is.numeric(object@cost_lookback) || length(object@cost_lookback) != 1 ||
          is.na(object@cost_lookback) || object@cost_lookback < 1 ||
          object@cost_lookback %% 1 != 0) {
        stop("cost_lookback must be NULL or a single positive whole number of months.")
      }
    }

    ##Config name
    if (length(object@config_name) != 1) {
      stop("config_name must be a single character string.")
    }

    ##Covariance sample size is counted in months at meta level, so a daily-sized window is
    ##almost certainly the create_port_backtest_config default left unchanged
    if (port_construction_method %in% c("rp", "hrp", "mvo")) {
      cov_matrix_sample_size <- inner_config@cov_est_method@cov_matrix_sample_size
      if (cov_matrix_sample_size > 120) {
        warning("cov_matrix_sample_size is ", cov_matrix_sample_size, ", but at meta-level it counts ",
                "months of portfolio returns rather than trading days. This asks for ",
                round(cov_matrix_sample_size / 12, 1), " years of history. The default carried by ",
                "create_port_backtest_config() is the daily 252; consider setting it explicitly.")
      }
    }

    ##The stock-level analytics window, in trading days
    if (length(object@stock_cov_matrix_sample_size) != 1 ||
        !is.finite(object@stock_cov_matrix_sample_size) ||
        object@stock_cov_matrix_sample_size < 2 ||
        object@stock_cov_matrix_sample_size %% 1 != 0) {
      stop("stock_cov_matrix_sample_size must be a single whole number of at least 2 trading days.")
    }
    ####################

    ##The two paths carry different parameters, and neither should silently ignore the other's
    if (object@type == "risk_targeted") {
      ###Left NULL, the configuration is incomplete rather than invalid, so it can be built first
      ###and completed with add_risk_target_parameters(). residual_ticker and target have no sensible
      ###defaults, so unlike the other parameter blocks this one cannot be defaulted into place.
      ###check_inputs_meta_port_backtest() refuses to run without it, the same way a backtest
      ###refuses to run without transaction_costs_parameters.
      if (!is.null(object@risk_target_parameters) &&
          !inherits(object@risk_target_parameters, "risk_target_parameters")) {
        stop("risk_target_parameters must be a 'risk_target_parameters' object when type is 'risk_targeted'.")
      }
      ###The weight on the risky sleeve comes from the targeting rule, so nothing here ranks a
      ###cross-section. 'custom_weights' is the value that says so, and requiring it keeps the
      ###wrapped config honest about itself: its own show method reports a NULL score as coming
      ###from SB predictions for every other method, which would be untrue on this path. It also
      ###matches what the stock-level run actually does, since that is invoked with
      ### 'custom_weights' on the projected weights. The wrapped config refuses a score alongside
      ### 'custom_weights', so requiring it here also settles that the meta score must be NULL.
      if (port_construction_method != "custom_weights") {
        stop("port_construction_method must be 'custom_weights' when type is 'risk_targeted': ",
             "the weight on the risky sleeve comes from the risk-targeting rule rather than from ",
             "ranking a cross-section, and 'custom_weights' is the value that says so. Got '",
             port_construction_method, "'.")
      }
      ###Scaling against a residual is defined relative to a benchmark for a tracking-error target,
      ###and the benchmark also anchors the stock-level run
      if (!is.null(object@risk_target_parameters) &&
          object@risk_target_parameters@target_metric == "tracking_error" &&
          is.null(inner_config@selected_benchmark)) {
        stop("A 'tracking_error' target needs a selected_benchmark in meta_port_backtest_config.")
      }
      return(TRUE)
    }

    ##type == "multi_port" from here on
    if (!is.null(object@risk_target_parameters)) {
      stop("risk_target_parameters is only used when type is 'risk_targeted'.")
    }

    ##Methods that do not carry over to a set of portfolios
    ###slsaf and mmaf are overlays on a stock cross-section: the first expresses conviction
    ###relative to benchmark constituents, the second allocates within and across stock groups.
    ###Neither has a counterpart over a handful of portfolios.
    if (port_construction_method %in% c("slsaf", "mmaf")) {
      stop("port_construction_method '", port_construction_method, "' is not supported at meta-level. ",
           "It is defined as an overlay on a stock cross-section (benchmark constituents for 'slsaf', ",
           "stock groups for 'mmaf') and has no counterpart over a set of portfolios.")
    }
    ###cw and cs weight by a liquidity metric, which portfolios do not have
    if (port_construction_method %in% c("cw", "cs")) {
      stop("port_construction_method '", port_construction_method, "' is not supported at meta-level. ",
           "It weights by a liquidity metric, which a portfolio does not have.")
    }
    if (!port_construction_method %in% c("ew", "sw", "rp", "hrp", "mvo")) {
      stop("port_construction_method at meta-level must be one of 'ew', 'sw', 'rp', 'hrp' or 'mvo'.")
    }

    ##A derived meta score is needed for every method that ranks the cross-section, because the
    ##universe must carry an exp_ret_score before classify_investment_universe can select from it
    if (is.null(inner_config@chosen_score_metric_and_position)) {
      stop("chosen_score_metric_and_position must be provided in meta_port_backtest_config. ",
           "It names the column of port_universe_m_df used as the meta score.")
    }


    TRUE
  }
)


#port-------------------------------------------------------------------
#' Portfolio classes for backtesting portfolios
#'
#' These classes encapsulate various parameters and constraints used in backtesting portfolios.
#'
#' @section port-class:
#' The \code{port} class is a base S4 class specifying general parameters for portfolio construction.
#'
#' @slot universe_m_d_ref A \code{meta_dataframe} containing the universe of assets, with weights and per-asset metrics attached.
#' @slot port_construction_method A \code{character} string specifying the method used to construct the portfolio. Must be one of \code{c("ew", "sw", "cw", "cs", "rp", "hrp", "mvo", "mmaf", "custom_weights")}.
#' @slot eligible_assets A \code{character} vector of eligible assets for the portfolio.
#' @slot exp_ret_score The eligible assets expected return scores. Required when \code{port_construction_method} is \code{"sw"}, \code{"cs"} or \code{"mvo"}, and also for \code{"rp"}, \code{"hrp"} or \code{"mmaf"} when an \code{exp_ret_score} column is present in \code{universe_m_d_ref} (e.g. a risk-parity tilt).
#' @slot covariance_matrix The eligible assets covariance matrix of returns. Must have rownames identical to colnames and be symmetric.
#' @slot correlation_matrix An object storing the correlation matrix of returns (optional if covariance is provided).
#' @slot weights A \code{numeric} vector of portfolio weights for eligible assets.
#' @slot rel_risk_contr An object representing relative risk contributions (must be provided if \code{covariance_matrix} is not \code{NULL}).
#' @slot clusters An object for storing clusters of assets (used in HRP).
#' @slot mvo_port_spec An object of class \code{portfolio.spec} (from the \pkg{PortfolioAnalytics} or similar package) used for Markowitz optimization.
#' @slot ind_max_weights A numeric vector specifying maximum weight constraints per asset.
#' @slot ind_min_weights A numeric vector specifying minimum weight constraints per asset.
#' @slot random_port_weights An object for storing random portfolio weights (used in MVO).
#' @slot groups An object for grouping assets (e.g., sectors).
#' @slot group_col A \code{character} naming the group column of \code{groups} used for macro/group aggregation (used in MMAF and group-level analytics).
#' @slot mmaf_method An object for storing the MMAF method (used in MMAF).
#' @slot group_cov_matrix An object for storing the group covariance matrix (used in MMAF).
#' @slot micro A named list of sub-portfolios, filled by any layered method: the
#'   per-group portfolios under MMAF, and the `long` and `short` legs under SLSAF. A leg
#'   with nothing to build is `NULL`.
#' @slot macro An object for storing the macro-level portfolio (used in MMAF).
#' @slot selected_benchmark_port An object for storing the selected benchmark portfolio.
#' @slot port_stats A one-row \code{data.frame} of portfolio (and, when applicable, group and active/benchmark-relative) analytics for this portfolio.
#' @slot port_name A \code{character} giving a unique name or label for the portfolio.
#'
#' @section signal_port-class:
#' Inherits from \code{port}. Restricts \code{port_construction_method} to one of
#' \code{c("ew","sw","rp","mvo")}. Additionally, it introduces:
#' \describe{
#'   \item{\code{heuristic_sb_metric}}{\code{ANY} object that must be non-\code{NULL}
#'         when \code{port_construction_method} is \code{"sw"} or \code{"mvo"}.}
#' }
#'
#' @section stock_port-class:
#' Inherits from \code{port} and introduces:
#' \describe{
#'   \item{\code{type}}{\code{character} specifying the portfolio subtype. Must be one of
#'   "signal_blend", "single_signal" or "custom_weights".}
#'   \item{\code{main_liquidity_metric}}{\code{ANY} object specifying a liquidity metric;
#'         must be non-\code{NULL} when \code{port_construction_method} is \code{"cw"} or \code{"cs"}.}
#' }
#'
#' @section sb_stock_port-class:
#' Inherits from \code{stock_port}. Intended for scenarios where \code{sb_algorithm}
#' can be one of \code{"cw"} or \code{"cs"}, with additional liquidity constraints required.
#'
#' @section single_signal_stock_port-class:
#' Inherits from \code{stock_port}. Specialized stock-level portfolio class with
#' \code{sb_algorithm} possibly being \code{"cw"} or \code{"cs"}, requiring the same
#' liquidity-related parameters as \code{sb_stock_port}.
#'
#' @name port-class
#'
NULL

# Base class: port
#' @rdname port-class
#' @export
setClass(
  "port",
  slots = list(
    universe_m_d_ref = "meta_dataframe",
    port_construction_method = "character",
    eligible_assets = "character",
    exp_ret_score = "ANY",
    covariance_matrix = "ANY",
    correlation_matrix = "ANY",
    weights = "numeric",
    rel_risk_contr = "ANY",
    clusters = "ANY",
    mvo_port_spec = "ANY",
    ind_max_weights = "ANY",
    ind_min_weights = "ANY",
    random_port_weights = "ANY",
    groups = "ANY",
    group_col = "ANY",
    mmaf_method = "ANY",
    group_cov_matrix = "ANY",
    micro = "ANY",
    macro = "ANY",
    selected_benchmark_port = "ANY",
    port_stats = "data.frame",
    port_name = "character"
  ),
  validity = function(object) {

   # port_construction_method must be one of the allowed
    if (!object@port_construction_method %in% c("ew","sw","cw","cs","rp","mvo","custom_weights", "hrp", "mmaf", "slsaf")) {
      stop("port_construction_method must be one of 'ew', 'sw', 'cw', 'cs', 'rp', 'mvo', 'custom_weights', 'hrp', 'mmaf' or 'slsaf'.")
    }

    #weights and eligible_assets
    if(length(object@weights) != length(object@eligible_assets)){
      stop("weights must have the same length as eligible_assets")
    }
    #Check for weights summing to 1
    if (object@port_construction_method != "custom_weights"){
      if(sum(object@weights) - 1 > 0.01){
        stop("weights must sum to 1.")
      }
    } else {
      if((sum(object@weights) - 1 )> 0.01 && (sum(object@weights) - 1) <= 0.05){
        warning("weights do not sum to 1, but are between 0.95 and 1.05. Consider adjusting weights or check for errors.")
      }
      if(sum(object@weights) - 1 > 0.05){
        stop("weights must sum to less than 0.95 or more than 1.05 for port_construction_method 'custom_weights'.")
      }
    }

    #exp_ret_score
    if (
      (object@port_construction_method %in% c("sw", "cs", "mvo")) ||
      (object@port_construction_method %in% c("rp", "hrp", "mmaf") &&  #For rp, hrp w tilts or mmaf
       ("exp_ret_score" %in% names(object@universe_m_d_ref)))
    ) {
      if (is.null(object@exp_ret_score)){
        stop("exp_ret_score must be provided for port_construction_method 'sw', 'cs', 'mvo' and for ",
             "'rp', 'hrp' or 'mmaf', depending on arguments.")
      }
      if(!is.numeric(object@exp_ret_score)){
        stop("exp_ret_score must be numeric.")
      }
      if(length(object@eligible_assets) != length(object@exp_ret_score)){
        stop("exp_ret_score must have the same length as eligible_assets")
      }
    }

    # Check covariance_matrix rownames vs. colnames and symmetry
    if(object@port_construction_method %in% c("mvo", "rp", "hrp", "mmaf") & is.null(object@covariance_matrix)){
      stop("covariance_matrix must be provided for port_construction_method 'mvo', 'rp', 'hrp' or 'mmaf'.")
    }
    if (!is.null(object@covariance_matrix)) {
      if (!identical(rownames(object@covariance_matrix), colnames(object@covariance_matrix))) {
        stop("covariance_matrix must have rownames identical to colnames.")
      }
      if (!isSymmetric(object@covariance_matrix)) {
        stop("covariance_matrix must be symmetric.")
      }
      if (!is.numeric(object@covariance_matrix)){
        stop("covariance_matrix must be numeric.")
      }
      if (is.null(object@rel_risk_contr)){
        stop("rel_risk_contr must be provided when covariance_matrix is not NULL.")
      }
      if(length(object@eligible_assets) != ncol(object@covariance_matrix)){
        stop("covariance_matrix must have the same number of cols as eligible_assets")
      }
      if(!any(colnames(object@covariance_matrix) == object@eligible_assets)){
        stop("covariance_matrix must have the same colnames as eligible_assets")
      }
      if(length(object@eligible_assets) != length(object@rel_risk_contr)){
        stop("rel_risk_contr must have the same length as eligible_assets")
      }
    }

    # Do the same for group_covariance_matrix
    if(object@port_construction_method == "mmaf" & is.null(object@group_cov_matrix)){
      stop("group_cov_matrix must be provided for port_construction_method 'mmaf'.")
    }
    if (!is.null(object@group_cov_matrix)) {
      if (!identical(rownames(object@group_cov_matrix), colnames(object@group_cov_matrix))) {
        stop("group_cov_matrix must have rownames identical to colnames.")
      }
      if (!isSymmetric(object@group_cov_matrix)) {
        stop("group_cov_matrix must be symmetric.")
      }
      if (!is.numeric(object@group_cov_matrix)){
        stop("group_cov_matrix must be numeric.")
      }
      eligible_groups <- object@groups %>%
        dplyr::filter(tickers %in% object@eligible_assets) %>%
        dplyr::pull(!!rlang::sym(object@group_col)) %>%
        unique()
      if (length(eligible_groups) != ncol(object@group_cov_matrix)){
        stop("group_cov_matrix must have the same number of cols as eligible groups")
      }
      if (any(!colnames(object@group_cov_matrix) %in% c(eligible_groups, "forced"))){ ### For signals, there might be forced signals
        stop("group_cov_matrix must have the same colnames as eligible groups")
      }
      ### colnames must be ordered according to sort
      if (!identical(colnames(object@group_cov_matrix), sort(colnames(object@group_cov_matrix)))){
        stop("group_cov_matrix colnames must be ordered alphabetically")
      }
    }
    if (!is.null(object@group_cov_matrix) &&
        !is.null(object@covariance_matrix) &&
        is.null(object@groups)){
      stop("groups must be provided when group_cov_matrix is not NULL.")
    }

    # Check for mvo
    if(object@port_construction_method == "mvo"){
      if(length(object@eligible_assets) > 1 &&
        is.null(object@random_port_weights)){
        stop("random_port_weights must not be NULL for port_construction_method 'mvo' when, ",
             "there is more than one eligible asset.")
      }
      if(!is.null(object@random_port_weights) &&
         !any(object@random_port_weights$tickers %in% object@eligible_assets)){
        stop("random_port_weights must have the same colnames as eligible_assets")
      }
      if(!is.null(object@ind_max_weights)){
        if(length(object@ind_max_weights) != length(object@eligible_assets)){
          stop("ind_max_weights must have the same length as eligible_assets")
        }
      }
      if(!is.null(object@ind_min_weights)){
        if(length(object@ind_min_weights) != length(object@eligible_assets)){
          stop("ind_min_weights must have the same length as assets")
        }
      }
    }

    # Check for mmaf
    if (object@port_construction_method == "mmaf") {
      # Require macro/micro and some minimal structure
      if (is.null(object@macro)) {
        stop("macro slot must be provided for 'mmaf'.")
      }
      if (is.null(object@micro)) {
        stop("micro slot must be provided for 'mmaf'.")
      }
      if (is.null(object@groups)){
        stop("groups slot must be provided for 'mmaf'.")
      }
      ## MMAF method must be top or bottom
      if (is.null(object@mmaf_method) ||
          !object@mmaf_method %in% c("top_down", "bottom_up")) {
        stop("mmaf_method must be either 'top_down' or 'bottom_up'.")
      }
      ## Micro must be a list of port objects
      ## If mmaf_method is 'bottom_up', micro should be a list of a single 'port'
      ## Otherwise, it should be a list of 'port's with groups as names
      if (object@mmaf_method == "top_down"){
        if (!is.list(object@micro) ||
            !all(purrr::imap_lgl(object@micro, function(x, y){
              if (!is.null(x) &&
                  object@macro@universe_m_d_ref@data %>%
                  dplyr::filter(tickers == y) %>%
                  dplyr::pull(weights) >= 1e-8){
                inherits(x, "port")
              } else {
                TRUE
              }
            }))){
          stop("micro must be a list of 'port' objects.")
        }
      } else {
        if (!inherits(object@micro$bottom_up, "port")){
          stop("micro must be a list with one element named 'bottom_up' of class 'port'.")
        }
      }
      ## If mmaf_method is 'top_down', micro must be a list with groups as names,
      ## matchings colnames of group_cov_matrix
      if (!is.null(object@groups) &&
          object@mmaf_method == "top_down" &&
          !identical(
            names(object@micro),
            sort(unique(object@groups[[object@group_col]]))
          )) {
        stop("Names of micro list must match groups.")
      }
      ## If mmaf_method is 'bottom_up', micro must be list with only one element
      ## named 'bottom_up'
      if (object@mmaf_method == "bottom_up" &&
          (!identical(names(object@micro), "bottom_up") ||
           length(object@micro) != 1)) {
        stop("For 'bottom_up' mmaf_method, micro must be a list with one element named 'bottom_up'.")
      }
    }

    # Check for slsaf
    if (object@port_construction_method == "slsaf") {
      ## Both legs are reported, and either may legitimately be absent: there is no short
      ## leg when every constituent is eligible, and no long leg when no budget was released
      if (!is.list(object@micro) ||
          !identical(sort(names(object@micro)), c("long", "short"))) {
        stop("For 'slsaf', micro must be a list with elements named 'long' and 'short'.")
      }
      if (!all(purrr::map_lgl(object@micro, function(x) is.null(x) || inherits(x, "port")))) {
        stop("For 'slsaf', each element of micro must be a 'port' object or NULL.")
      }
      ## A benchmark is what the whole construction is relative to
      if (is.null(object@selected_benchmark_port)) {
        stop("selected_benchmark_port must be provided for 'slsaf'.")
      }
    }

    if (!is.null(object@macro)){
      ## Macro should be of S4 class port
      if (!inherits(object@macro, "port")) {
        stop("macro must be a 'port' object.")
      }
      ## If port_construction_method is not mmaf, macro port construction method must be "custom_weights"
      if (object@port_construction_method != "mmaf" &&
          object@macro@port_construction_method != "custom_weights") {
        stop("If port_construction_method is not 'mmaf', macro port_construction_method must be 'custom_weights'.")
      }
      ## Macro universe_m_d_ref tickers order must match group_covariance
      if (!is.null(object@group_cov_matrix) &&
          !identical(object@macro@universe_m_d_ref@data$tickers,
                     sort(colnames(object@group_cov_matrix)))) {
        stop("Tickers in macro universe_m_d_ref must match group_cov_matrix colnames and be ordered alphabetically.")
      }
      if (is.null(object@groups)){
        stop("groups slot must be provided for 'macro'.")
      }
      ## Check if names of tickers in macro port match groups
      all_groups <- object@groups %>%
        dplyr::pull(!!rlang::sym(object@group_col)) %>%
        unique()
      missing_groups <- setdiff(all_groups, object@macro@eligible_assets)
      if (length(missing_groups) > 0) {
        message(paste0("The following groups are missing in macro eligible_assets: ",
                        paste(missing_groups, collapse = ", ")))
      }
    }

    #Check for clusters
    if (!is.null(object@covariance_matrix)){
      # hclust type check if provided
      if (!is.null(object@clusters) && !inherits(object@clusters, "hclust")) {
        stop("clusters must be an 'hclust' object.")
      }
    }

    #Check for selected_benchmark_port
    if (!is.null(object@selected_benchmark_port)){

      ## Should be of class 'port'
      if (!inherits(object@selected_benchmark_port, "port")) {
        stop("selected_benchmark_port must be a 'port' object.")
      }

      ## PCM should be custom_weights
      if (object@selected_benchmark_port@port_construction_method != "custom_weights") {
        stop("selected_benchmark_port must have port_construction_method 'custom_weights'.")
      }

      ## universe_m_d_ref should contain act_weights and act_rel_risk_contr columns
      req_cols <- ifelse(!is.null(object@covariance_matrix), c("act_weights", "act_rel_risk_contr"), "act_weights")
      if (!all(req_cols %in% names(object@universe_m_d_ref@data))) {
        stop("When a benchmark is provided, active columns must exist in universe_m_d_ref.")
      }

      ## tickers between univers_m_d_ref from port and benchmark must match
      if (!identical(object@universe_m_d_ref@data$tickers, object@selected_benchmark_port@universe_m_d_ref@data$tickers)) {
        stop("Tickers in universe_m_d_ref must match those in selected_benchmark_port universe_m_d_ref.")
      }

      ## exp_ret_score must match between port and benchmark
      if (!identical(object@universe_m_d_ref@data$exp_ret_score, object@selected_benchmark_port@universe_m_d_ref@data$exp_ret_score)) {
        stop("exp_ret_score must match between port and selected_benchmark_port.")
      }

    }

    #Port stats
      ## If covariance matrix is not NULL, port_stats must have rrc columns as not NA
      ## and as NA otherwise
      if (!is.null(object@covariance_matrix)){
        rrc_cols <- object@port_stats[, setdiff(names(object@port_stats %>% dplyr::select(dplyr::contains("rrc"))), "group_hhi_rrc")]
        if ((!is.null(object@selected_benchmark_port) && "act_weights" %in% names(object@universe_m_d_ref@data) && any(object@universe_m_d_ref@data$act_weights > 0)) &&
             any(sapply(rrc_cols, function(x) all(is.na(x))))){
          stop("When covariance_matrix is not NULL, port_stats must have relative risk contribution (rrc) columns as not NA.")
        }
      } else {
        rrc_cols <- object@port_stats[, setdiff(names(object@port_stats %>% dplyr::select(dplyr::contains("rrc"))), "group_hhi_rrc")]
        if (any(sapply(rrc_cols, function(x) !all(is.na(x))))){
          stop("When covariance_matrix is NULL, port_stats must have relative risk contribution (rrc) columns as NA.")
        }
      }
      ## The same goes for object having groups as not NULL and group_columns existing
      ## Those cols should exist only if groups is not NULL
      if (!is.null(object@macro)){
        group_cols <- object@port_stats %>% dplyr::select(dplyr::contains("group"))
        if (ncol(group_cols) == 0){
          stop("When groups is not NULL, port_stats must have group-related columns.")
        }
      } else {
        group_cols <- object@port_stats %>% dplyr::select(dplyr::contains("group"))
        if (ncol(group_cols) > 0){
          stop("When groups is NULL, port_stats must not have group-related columns.")
        }
      }
    TRUE
  }
)

#signal_port
#' @rdname port-class
#' @export
setClass(
  "signal_port",
  contains = "port",
  slots = list(
    heuristic_sb_metric = "ANY"
  ),
  validity = function(object) {

    # Restrict port_construction_method
    if (!object@port_construction_method %in% c("ew","sw","rp","hrp","mvo","mmaf","custom_weights")) {
      stop("For signal_port, port_construction_method must be one of 'ew','sw','rp','hrp','mvo','mmaf' or 'custom_weights'.")
    }

    # If sw or mvo => heuristic_sb_metric should not be NULL
    if (object@port_construction_method %in% c("sw","mvo","mmaf")) {
      if (is.null(object@heuristic_sb_metric)) {
        stop("heuristic_sb_metric cannot be NULL when port_construction_method is 'sw', 'mvo' or 'mmaf'.")
      }
    }

    TRUE
  }
)

# Subclass: stock_port class
#' @rdname port-class
#' @export
setClass(
  "stock_port",
  contains = "port",
  slots = list(
    type = "character",
    main_liquidity_metric = "ANY"
  ),
  validity = function(object) {

    # If port_construction_method is 'cw' or 'cs', we enforce
    # liquidity-related constraints must not be NULL
    if (object@port_construction_method %in% c("cw","cs")) {
      if (is.null(object@main_liquidity_metric)) {
        stop("main_liquidity_metric cannot be NULL when port_construction_method is 'cw' or 'cs'.")
      }
    }
    if(!object@type %in% c("signal_blend", "single_signal", "custom_weights")){
      stop("type must be one of 'signal_blend', 'single_signal' or 'custom_weights'")
    }

    TRUE
  }
)


#port_backtest_results------------------------------------------------
#' S4 Class for Portfolio Backtest Results
#'
#' This S4 class encapsulates the results and parameters from running a portfolio backtest based on
#' signals derived from simple stock characteristics or expected returns from machine learning model predictions.
#'
#' @slot port_backtest_config An object of class `port_backtest_config` containing the configuration parameters for the backtest.
#' @slot port_weights_m_df A meta dataframe containing the portfolio weights across different dates.
#' @slot transactions_log An object of class `transactions_log` containing the transaction for the portfolio.
#' @slot port_costs_m_xts A meta xts object containing portfolio costs (e.g., direct cost, market impact cost, total cost, turnover) indexed by dates.
#' @slot port_metrics_m_xts A meta xts object containing portfolio performance metrics (if provided) indexed by dates.
#' @slot port_returns_m_xts A meta xts object containing portfolio returns (raw and net returns) indexed by dates.
#' @slot final_stock_port An object of class `stock_port` representing the final stock portfolio.
#' @slot port_construction_method A character string indicating the portfolio construction method used (e.g., "ew", "sw", "rp", "mvo", "custom_weights").
#' @slot stock_universe_m_df A meta dataframe containing the stock universe derived from the backtest.
#' @slot final_stock_universe_m_d_ref A meta dataframe containing the last stock universe.
#' @slot port_stats_m_df A meta dataframe containing portfolio statistics across different dates.
#' @slot final_port_stats_m_d_ref A meta dataframe containing the final portfolio statistics.
#' @slot port_backtest_workflow A list detailing the portfolio backtest workflow, including parameters, rebalancing dates, and other metadata.
#' @slot backtest_identifier A character string representing the backtest identifier.
#' @slot update A logical indicating whether the backtest results are an update or an original backtest.
#'
#' @export
setClass(
  "port_backtest_results",
  slots = list(
    port_backtest_config = "ANY",
    port_weights_m_df = "meta_dataframe",
    transactions_log = "transactions_log",
    port_costs_m_xts = "meta_xts",
    port_metrics_m_xts = "ANY",
    port_returns_m_xts = "meta_xts",
    final_stock_port = "ANY",
    port_construction_method = "character",
    stock_universe_m_df = "ANY", #In an update, this might be empty
    final_stock_universe_m_d_ref = "ANY", #In an update, this might be empty
    port_stats_m_df = "ANY",
    final_port_stats_m_d_ref = "ANY",
    port_backtest_workflow = "list",
    backtest_identifier = "character",
    update = "logical"
  ),
  validity = function(object) {

    #Updated objects are temporarily allowed to have empty stock_universe_m_df and final_stock_universe_m_d_ref
    if (!object@update){
      #Check classes of final-stock_port, stock_universe_m_df, final_stock_universe_m_d_ref, port_stats_m_df and final_port_stats_m_d_ref
      if (!inherits(object@final_stock_port, "stock_port")) {
        return("final_stock_port must be a 'stock_port' object")
      }
      if (!inherits(object@stock_universe_m_df, "stock_universe_m_df")) {
        return("stock_universe_m_df must be a 'stock_universe_m_df' object")
      }
      if (!inherits(object@final_stock_universe_m_d_ref, "stock_universe_m_df")) {
        return("final_stock_universe_m_d_ref must be a 'stock_universe_m_df' object")
      }
      if (!inherits(object@port_stats_m_df, "meta_dataframe")) {
        return("port_stats_m_df must be a 'meta_dataframe' object")
      }
      if (!inherits(object@final_port_stats_m_d_ref, "meta_dataframe")) {
        return("final_port_stats_m_d_ref must be a 'meta_dataframe' object")
      }

    }

    if (!is.null(object@port_backtest_config) && !inherits(object@port_backtest_config, "port_backtest_config")) {
      return("port_backtest_config must be a 'port_backtest_config' object or NULL")
    }

    if (!is.null(object@port_metrics_m_xts) && !inherits(object@port_metrics_m_xts, "meta_xts")) {
      return("port_metrics_m_xts must be a 'meta_xts' object or NULL")
    }

    if (length(object@backtest_identifier) != 1) {
      return("backtest_identifier must be a single character string")
    }
    TRUE
  }
)




#port_backtest_cohort------------------------------------------------
#' S4 Class for Portfolio Backtest Cohort
#'
#' This S4 class encapsulates the merged results of multiple portfolio backtests.
#' It contains the merged portfolio weights (as a meta_dataframe), portfolio costs,
#' portfolio returns, and portfolio metrics (each as lists of meta_xts objects), as well as
#' the common backtest workflow parameters.
#'
#' @slot cohort_name A character string representing the cohort name.
#' @slot port_backtest_results_list A list of `port_backtest_results` objects, each representing a portfolio backtest.
#' @slot port_weights_m_df A meta_dataframe containing merged portfolio weights.
#' @slot port_costs_m_xts_list A list of meta_xts objects for portfolio costs (direct_cost, market_impact_cost, total_cost, turnover).
#' @slot port_returns_m_xts_list A list of meta_xts objects for portfolio returns (raw_return, net_return, raw_active_return, net_active_return).
#' @slot port_metrics_m_xts_list A list of meta_xts objects for portfolio metrics.
#' @slot port_stats_m_xts_nested_list A nested list of meta_xts objects for portfolio statistics.
#' @slot backtest_workflow_common A list containing the common backtest workflow parameters (used for compatibility).
#'
#' @export
setClass("port_backtest_cohort",
         slots = list(
           cohort_name = "character",
           port_backtest_results_list = "list",
           port_weights_m_df = "meta_dataframe",
           port_costs_m_xts_list = "list",
           port_returns_m_xts_list = "list",
           port_metrics_m_xts_list = "list",
           port_stats_m_xts_nested_list = "list",
           backtest_workflow_common = "list"
         ),
         validity = function(object) {
           if (length(object@cohort_name) != 1)
             return("cohort_name must be a single character string")
           TRUE
         }
)


#port_metabacktest_results--------------------------------------------
#' S4 Class for Portfolio Meta Backtest Results
#'
#' Holds the results of allocating across a cohort of already-backtested portfolios: the meta
#' allocation itself, the stock-level backtest it implies, and the objects that connect the two.
#'
#' @section The two levels:
#' A meta backtest happens at two levels and this object keeps both, because neither answers the
#' other's questions:
#' \describe{
#'   \item{meta level}{\code{meta_port_weights_m_df} and \code{meta_port_stats_m_df} record how
#'     much of the portfolio each base portfolio was given and what the allocation looked like as
#'     an allocation, including its expected-return score, risk and relative risk contributions
#'     across base portfolios. \code{final_meta_port} is the \code{port} object from the last meta
#'     rebalance.}
#'   \item{stock level}{\code{meta_port_backtest_results} is an ordinary
#'     \code{port_backtest_results} for the portfolio those meta weights imply once pushed through
#'     to individual stocks. Its returns, costs and turnover are the real ones, netted across base
#'     portfolios that hold the same names, and it is what should be compared against a benchmark
#'     or against the base portfolios themselves.}
#' }
#' Note that the stock-level object reports no expected-return statistics: its weights are supplied
#' rather than derived, so \code{exp_ret} and its ratios are missing by construction. The
#' expected-return view lives at the meta level, in \code{meta_port_stats_m_df}.
#'
#' @section Reading meta_port_stats_m_df:
#' Two of its columns are easy to misread.
#' \itemize{
#'   \item \code{exp_ret} is the weighted average of the meta score after
#'     \code{\link{signal_transform}}, so it is a dimensionless cross-sectional quantity and not a
#'     return in percent. \code{sharpe} inherits that, being \code{exp_ret / risk}.
#'   \item \code{risk}, and everything else derived from the covariance matrix, is measured on the
#'     base portfolios' own returns, not on active returns, and so is an absolute figure. This
#'     holds regardless of \code{cov_est_method@@active_returns}, which
#'     \code{\link{create_port_backtest_config}} turns on automatically whenever a benchmark is
#'     set: that setting reaches only the covariance used to \emph{construct} weights under
#'     \code{rp}, \code{hrp} and \code{mvo}, because \code{calculate_port_stats()} re-estimates its
#'     own covariance with active returns switched off to avoid counting the benchmark twice.
#' }
#' The stock-level object in \code{meta_port_backtest_results} is benchmark-relative in the
#' ordinary way and needs no such caveat.
#'
#' @slot port_metabacktest_config The \code{port_metabacktest_config} used.
#' @slot meta_port_backtest_results A \code{port_backtest_results} for the stock-level portfolio.
#' @slot port_backtest_cohort The \code{port_backtest_cohort} allocated across.
#' @slot port_universe_m_df The \code{port_universe_m_df} the meta weights were chosen from.
#' @slot meta_port_weights_m_df A \code{weights_m_df} of meta weights per base portfolio per
#'   rebalance date.
#' @slot projected_stock_weights_m_df A \code{weights_m_df} of the stock-level weights those meta
#'   weights imply, as handed to the stock-level backtest.
#' @slot meta_port_stats_m_df A \code{meta_dataframe} of meta-level portfolio analytics per
#'   rebalance date.
#' @slot final_meta_port The \code{port} object for the last meta rebalance date.
#' @slot backtest_identifier A character identifying the backtest.
#'
#' @seealso \code{\link{port_metabacktest_config-class}}, \code{\link{port_universe_m_df-class}},
#'   \code{\link{port_backtest_results-class}}
#' @export
setClass(
  "port_metabacktest_results",
  slots = list(
    port_metabacktest_config = "ANY",
    meta_port_backtest_results = "port_backtest_results",
    port_backtest_cohort = "ANY",
    port_universe_m_df = "ANY",
    meta_port_weights_m_df = "ANY",
    projected_stock_weights_m_df = "ANY",
    meta_port_stats_m_df = "ANY",
    final_meta_port = "ANY",
    backtest_identifier = "character"
  ),
  validity = function(object) {

    if (!is.null(object@port_metabacktest_config) &&
        !inherits(object@port_metabacktest_config, "port_metabacktest_config")) {
      return("port_metabacktest_config must be a 'port_metabacktest_config' object")
    }
    if (!is.null(object@port_backtest_cohort) &&
        !inherits(object@port_backtest_cohort, "port_backtest_cohort")) {
      return("port_backtest_cohort must be a 'port_backtest_cohort' object")
    }
    if (!is.null(object@port_universe_m_df) &&
        !inherits(object@port_universe_m_df, "port_universe_m_df")) {
      return("port_universe_m_df must be a 'port_universe_m_df' object")
    }
    if (!is.null(object@meta_port_weights_m_df) &&
        !inherits(object@meta_port_weights_m_df, "meta_dataframe")) {
      return("meta_port_weights_m_df must be a 'meta_dataframe' object")
    }
    if (!is.null(object@projected_stock_weights_m_df) &&
        !inherits(object@projected_stock_weights_m_df, "meta_dataframe")) {
      return("projected_stock_weights_m_df must be a 'meta_dataframe' object")
    }
    if (!is.null(object@meta_port_stats_m_df) &&
        !inherits(object@meta_port_stats_m_df, "meta_dataframe")) {
      return("meta_port_stats_m_df must be a 'meta_dataframe' object")
    }
    if (!is.null(object@final_meta_port) && !inherits(object@final_meta_port, "port")) {
      return("final_meta_port must be a 'port' object")
    }
    if (length(object@backtest_identifier) != 1) {
      return("backtest_identifier must be a single character string")
    }

    TRUE
  }
)

#risk_target_metabacktest_results---------------------------------------------
#' S4 Class for Risk-Targeted Meta Backtest Results
#'
#' The result of the `risk_targeted` path: a single risky sleeve scaled against a residual sleeve
#' so the combination targets a stated level of risk. Extends
#' \code{\link{port_metabacktest_results-class}} with the diagnostics that only make sense for a
#' targeting rule, and carries its own plot method for the capital-market-line view.
#'
#' @section Reading meta_port_stats_m_df on this path:
#' Where the multi-portfolio path reports cross-sectional portfolio analytics, this one reports the
#' targeting rule at work: \code{sleeve_risk} is the risky sleeve's estimated risk at each
#' rebalance date, \code{risky_weight} the weight the rule set from it, \code{target} the level
#' asked for, and \code{implied_risk} the product \eqn{sleeve\_risk \times risky\_weight}.
#'
#' \code{implied_risk} equals \code{target} exactly whenever the weight is unclipped, so a
#' departure from it says a bound was binding, not that the targeting failed. Whether the rule
#' actually worked is a question about realised returns, which exist only after the stock-level run:
#' compare the realised tracking error of
#' \code{meta_port_backtest_results@@port_returns_m_xts} against \code{target}. A realised figure
#' persistently above the target means the risk estimator is too slow to catch risk as it rises.
#'
#' @slot residual_ticker Character naming the residual sleeve.
#' @slot risk_target_parameters The `risk_target_parameters` used.
#'
#' @seealso \code{\link{port_metabacktest_results-class}}, \code{\link{risk_target_parameters-class}}
#' @export
setClass(
  "risk_target_metabacktest_results",
  contains = "port_metabacktest_results",
  slots = list(
    residual_ticker = "character",
    risk_target_parameters = "ANY"
  ),
  validity = function(object) {
    if (length(object@residual_ticker) != 1) {
      return("residual_ticker must be a single character string")
    }
    if (!is.null(object@risk_target_parameters) &&
        !inherits(object@risk_target_parameters, "risk_target_parameters")) {
      return("risk_target_parameters must be a 'risk_target_parameters' object")
    }
    TRUE
  }
)






#####################################
#########Accesor Methods############
#####################################

# meta_dataframe acessors -------------------------------------------------

#' Accessor for Data Slot
#'
#' Retrieves the `data` slot from a `meta_dataframe` or `meta_xts` object.
#'
#' @param object An object of class `meta_dataframe` or `meta_xts`.
#'
#' @return A `data.frame` (for `meta_dataframe`) or `xts` object (for `meta_xts`) containing the data.
#' @rdname get_data
#' @export
setGeneric("get_data", function(object) standardGeneric("get_data"))

#' @rdname get_data
#' @export
setMethod("get_data", "meta_dataframe", function(object) {
  return(object@data)
})

#' @rdname get_data
#' @export
setMethod("get_data", "meta_xts", function(object) {
  return(object@data)
})

#' Accessor for Workflow Slot
#'
#' Retrieves the `workflow` slot from a `meta_dataframe` or `meta_xts` object.
#'
#' @param object An object of class `meta_dataframe` or `meta_xts`.
#'
#' @return A named list representing the workflow steps applied to the object.
#' @rdname get_workflow
#' @export
setGeneric("get_workflow", function(object) standardGeneric("get_workflow"))

#' @rdname get_workflow
#' @export
setMethod("get_workflow", "meta_dataframe", function(object) {
  return(object@workflow)
})

#' @rdname get_workflow
#' @export
setMethod("get_workflow", "meta_xts", function(object) {
  return(object@workflow)
})


#' Accessor for Tickers
#'
#' Retrieves the unique tickers from a `meta_dataframe` or `meta_xts` object.
#'
#' @param object An object of class `meta_dataframe` or `meta_xts`.
#'
#' @return A character vector of unique tickers (column names in the case of `meta_xts`).
#' @rdname get_tickers
#' @export
setGeneric("get_tickers", function(object) standardGeneric("get_tickers"))

#' @rdname get_tickers
#' @export
setMethod("get_tickers", "meta_dataframe", function(object) {
  tickers <- unique(object@data$tickers)
  return(tickers)
})

#' @rdname get_tickers
#' @export
setMethod("get_tickers", "meta_xts", function(object) {
  stocks <- colnames(object@data)
  tickers(tickers)
})

#' Accessor for Dates
#'
#' Retrieves the unique dates from a `meta_dataframe` or `meta_xts` object.
#'
#' @param object An object of class `meta_dataframe` or `meta_xts`.
#' @return A sorted vector of dates.
#' @param ... Additional arguments (not used).
#' @rdname get_dates
#' @export
setGeneric("get_dates", function(object, ...) standardGeneric("get_dates"))

#' @rdname get_dates
#' @export
setMethod("get_dates", "meta_dataframe", function(object) {
  dates <- unique(object@data$dates)[order(unique(object@data$dates))]
  return(dates)
})

#' @rdname get_dates
#' @export
setMethod("get_dates", "meta_xts", function(object) {
  dates <- sort(unique(zoo::index(object@data)))
  return(dates)
})


#' Coerce a meta_dataframe Object to Data Frame
#'
#' This method extracts the `data` slot from a `meta_dataframe` object and returns it as a standard `data.frame`.
#'
#' @param x An object of class `meta_dataframe`.
#'
#' @return A `data.frame` containing the contents of the `data` slot.
#' @method as.data.frame meta_dataframe
#' @export
setMethod(
  "as.data.frame", "meta_dataframe", function(x) {
    as.data.frame(x@data)
  }
)

#' Coerce a meta_xts Object to Data Frame
#'
#' This method extracts the `data` slot from a `meta_xts` object and returns it as a standard `data.frame`.
#'
#' @param x An object of class `meta_xts`.
#'
#' @return A `data.frame` containing the contents of the `data` slot.
#' @method as.data.frame meta_xts
#' @export
setMethod(
  "as.data.frame", "meta_xts", function(x) {
    as.data.frame(x@data)
  }
)


# tickers_catalog accessors -------------------------------------------------
#' Lookup method for tickers_catalog
#'
#' Filters the catalog by provided tickers.
#' @param tickers_catalog A tickers_catalog object.
#' @param tickers_to_lookup A character vector of tickers to filter.
#' @param perm_id_to_lookup A character vector of perm_ids to filter.
#' @return A filtered data.frame.
#' @export
setGeneric(
  "lookup_catalog",
  function(tickers_catalog, tickers_to_lookup = NULL, perm_id_to_lookup = NULL) {
    standardGeneric("lookup_catalog")
  }
)

#' @rdname lookup_catalog
setMethod("lookup_catalog", signature(tickers_catalog = "tickers_catalog"),
          function(tickers_catalog, tickers_to_lookup = NULL, perm_id_to_lookup = NULL) {

            if(!"tickers" %in% colnames(tickers_catalog@catalog)){
              stop("The catalog slot must contain a 'tickers' column.")
            }
            if(!"perm_id" %in% colnames(tickers_catalog@catalog)){
              stop("The catalog slot must contain a 'perm_id' column.")
            }
            #Check that tickers_to_lookup or perm_id_to_lookup is not NULL
            if(is.null(tickers_to_lookup) && is.null(perm_id_to_lookup)){
              stop("Either tickers_to_lookup or perm_id_to_lookup must be provided.")
            }
            #Check that both are not provided simultaneously
            if(!is.null(tickers_to_lookup) && !is.null(perm_id_to_lookup)){
              stop("Only one of tickers_to_lookup or perm_id_to_lookup can be provided.")
            }

            #Check tickers_to_lookup
            if(!is.null(tickers_to_lookup)){
              #Get the data
              query <- tickers_catalog@catalog %>%
                dplyr::filter(tickers %in% tickers_to_lookup) %>%
                dplyr::select(tickers, perm_id)

              ##Check if any tickers were not found
              if(nrow(query) == 0){
                stop("Provided tickers were not found in the catalog.")
              }

              ##Check if all tickers were found and complain about. Tell the user which were not found.
              not_found <- setdiff(tickers_to_lookup, unique(query$tickers))
              if (length(not_found) > 0) {
                stop(paste("The following tickers were not found in the catalog: ",
                           paste(not_found, collapse = ", ")))
              }
              ##If checks pass:
              result <- setNames(query$perm_id, query$tickers)
              return(result[tickers_to_lookup])

            }


            #Check perm_id_to_lookup
            if(!is.null(perm_id_to_lookup)){
              #Get the data
              query <- tickers_catalog@catalog %>%
                dplyr::filter(perm_id %in% perm_id_to_lookup) %>%
                dplyr::arrange(dplyr::desc(tickers_last_quote)) %>%   # most recent first
                dplyr::group_by(perm_id) %>%
                dplyr::slice_head(n = 1) %>%
                dplyr::ungroup() %>%
                dplyr::select(perm_id, tickers)

              ##Check if any perm_ids were not found
              if(nrow(query) == 0){
                stop("Provided perm_ids were not found in the catalog.")
              }

              ##Check if all perm_ids were found and complain about. Tell the user which were not found.
              not_found <- setdiff(perm_id_to_lookup, unique(query$perm_id))

              if (length(not_found) > 0) {
                stop(paste("The following perm_ids were not found in the catalog: ",
                           paste(not_found, collapse = ", ")))
              }

              ##If checks pass
              result <- setNames(query$tickers, query$perm_id)
              return(result[perm_id_to_lookup])
            }

          })



# sb_model acessors -------------------------------------------------


#' Accessor Methods for sb_model
#'
#' These methods retrieve slots from an object of class `sb_model`, including its algorithm,
#' fitted model, and hyperparameters.
#'
#' @param object An object of class `sb_model`.
#'
#' @return The respective slot from the `sb_model` object:
#' \describe{
#'   \item{\code{get_sb_algorithm}}{Returns the algorithm used (character).}
#'   \item{\code{get_best_hyperparameters}}{Returns the list of best hyperparameters, or \code{NULL} if not applicable.}
#'   \item{\code{get_model}}{Returns the fitted model object.}
#' }
#'
#' @rdname sb_model_accessors
#' @name sb_model_accessors
#' @aliases get_sb_algorithm get_best_hyperparameters get_model
#' @export
setGeneric("get_sb_algorithm", function(object) standardGeneric("get_sb_algorithm"))

#' @rdname sb_model_accessors
#' @export
setMethod("get_sb_algorithm", "sb_model", function(object) {
  return(object@sb_algorithm)
})

#' @rdname sb_model_accessors
#' @export
setGeneric("get_best_hyperparameters", function(object) standardGeneric("get_best_hyperparameters"))

#' @rdname sb_model_accessors
#' @export
setMethod("get_best_hyperparameters", "sb_model", function(object) {
  return(object@best_hyperparameters)
})

#' @rdname sb_model_accessors
#' @export
setGeneric("get_model", function(object) standardGeneric("get_model"))

#' @rdname sb_model_accessors
#' @export
setMethod("get_model", "sb_model", function(object) {
  return(object@model)
})





# get tuning strategy -----------------------------------------------------

#' @title Get Hyperparameter Tuning Strategy
#' @description Accessor function to retrieve the hyperparameter tuning strategy from an sb_backtest_config object.
#'
#' @param object An sb_backtest_config object.
#'
#' @return The `tuning_strategy` slot of the `sb_backtest_config` object.
#' @export
setGeneric("get_tuning_strategy", function(object) {
  standardGeneric("get_tuning_strategy")
})

#' @rdname get_tuning_strategy
#' @export
setMethod("get_tuning_strategy", "sb_backtest_config", function(object) {
  return(object@tuning_strategy)
})


#' @rdname get_tuning_strategy
#' @export
setMethod("get_tuning_strategy", "sb_metabacktest_config", function(object) {
  return(lapply(object@sb_backtest_configs, function(config) get_tuning_strategy(config)))
})

#' @rdname get_tuning_strategy
#' @export
setMethod("get_tuning_strategy", "sb_backtest_results", function(object){

  #WF
  sb_backtest_workflow <- object@sb_backtest_workflow

  if(sb_backtest_workflow$sb_algorithm %in% c("ols", "ew", "sw", "rp", "mvo")) return(NULL)

  #Hyper Grid Domain
  hyper_grid_domain <- get_hyper_grid_domain(object)

  if(!sb_backtest_workflow$sb_algorithm %in% c("ols", "ew", "sw", "rp", "mvo")){
    tuning_strategy <- create_tuning_strategy(tuning_method = sb_backtest_workflow$tuning_method,
                                              validation_sample_size = sb_backtest_workflow$validation_sample_size,
                                              chosen_eval_metric = sb_backtest_workflow$chosen_eval_metric,
                                              hyper_grid_domain = hyper_grid_domain,
                                              early_stop = sb_backtest_workflow$early_stop,
                                              n_iter =  if(sb_backtest_workflow$tuning_method != "grid_search") sb_backtest_workflow$n_iter else NULL,
                                              acq = if(sb_backtest_workflow$tuning_method == "bayesian_opt") sb_backtest_workflow$acq else NULL,
                                              init_points = if(sb_backtest_workflow$tuning_method == "bayesian_opt") sb_backtest_workflow$init_points else NULL,
                                              k_iter = if(sb_backtest_workflow$tuning_method == "bayesian_opt") sb_backtest_workflow$k_iter else NULL
    )
  }

  return(tuning_strategy)

})


# get hyper grid domain -----------------------------------------------------

#' @title Get Hyperparameter Grid Domain
#' @description Accessor function to retrieve the hyperparameter grid domain.
#'
#' @param object An sb_backtest_config or tuning_strategy object
#'
#' @return The `hyper_grid_domain` object stored in the `tuning_strategy`.
setGeneric("get_hyper_grid_domain", function(object) {
  standardGeneric("get_hyper_grid_domain")
})

#' @rdname get_hyper_grid_domain
setMethod("get_hyper_grid_domain", "sb_backtest_config", function(object) {
  if(is.null(object@tuning_strategy)){
    stop("tuning_strategy not avaiable.")
  } else {
    return(object@tuning_strategy@hyper_grid_domain)
  }
})

#' @rdname get_hyper_grid_domain
setMethod("get_hyper_grid_domain", "tuning_strategy", function(object) {
  return(object@hyper_grid_domain)
})

#' @rdname get_hyper_grid_domain
#' @export
setMethod("get_hyper_grid_domain", "sb_metabacktest_config", function(object) {
  return(lapply(object@sb_backtest_configs, function(config) {
    if(is.null(config@tuning_strategy)) {
      stop("tuning_strategy not available for one of the sb_backtest_config objects.")
    } else {
      return(config@tuning_strategy@hyper_grid_domain@hyperparameter_list)
    }
  }))
})

#' @rdname get_hyper_grid_domain
#' @export
setMethod("get_hyper_grid_domain", "sb_backtest_results", function(object){

  hyper_grid_domain <- methods::new("hyper_grid_domain", hyperparameter_list = object@sb_backtest_workflow$hyper_grid_domain_list)
  return(hyper_grid_domain)
})




# get keras architecture -----------------------------------------------------

#' @title Get Keras Architecture Parameters
#' @description Accessor function to retrieve the keras architecture parameters.
#'
#' @param object A sb_backtest_config, a sb_metabacktest_config or a sb_backtest_results object.
#'
#' @return A `keras_architecture_parameters` S4 class.
setGeneric("get_keras_architecture_parameters", function(object) standardGeneric("get_keras_architecture_parameters"))

#' @rdname get_keras_architecture_parameters
setMethod("get_keras_architecture_parameters", "sb_backtest_config", function(object) {

  if(object@sb_algorithm != "nn"){
    stop("keras_architecture_parameters not available for non-neural network algorithms.")
  }

  if(is.null(object@keras_architecture_parameters)){
    stop("keras_architecture_parameters not available.")
  } else {
    return(object@keras_architecture_parameters)
  }
})

#' @rdname get_keras_architecture_parameters
setMethod("get_keras_architecture_parameters", "sb_metabacktest_config", function(object) {
  return(lapply(object@sb_metabacktest_configs[sapply(object@sb_metabacktest_configs, function(config) config@sb_algorithm == "nn")],
                function(nn_config) get_keras_architecture_parameters(nn_config)
  ))
})

#' @rdname get_keras_architecture_parameters
setMethod("get_keras_architecture_parameters", "sb_backtest_results", function(object) {

  if(object@sb_backtest_workflow$sb_algorithm != "nn"){
    stop("keras_architecture_parameters not available for non-neural network algorithms.")
  } else {

    ### Workflows recorded before n_ensembles existed have no such element, and
    ### `$` returns NULL for it; create_keras_architecture() reads that as the
    ### single-network setting those runs were produced under.
    keras_architecture_parameters <- create_keras_architecture(
      nn_optimizer = object@sb_backtest_workflow$keras_architecture_parameters$nn_optimizer,
      units = object@sb_backtest_workflow$keras_architecture_parameters$units,
      activation = object@sb_backtest_workflow$keras_architecture_parameters$activation,
      batch_norm_option = object@sb_backtest_workflow$keras_architecture_parameters$batch_norm_option,
      n_ensembles = object@sb_backtest_workflow$keras_architecture_parameters$n_ensembles
    )

  }

  return(keras_architecture_parameters)

})

#' @rdname get_keras_architecture_parameters
setMethod("get_keras_architecture_parameters", "sb_model", function(object) {

  if(object@sb_algorithm != "nn"){
    stop("keras_architecture_parameters not available for non-neural network algorithms.")
  } else {
    ### As above: a model fitted before n_ensembles existed reports a single
    ### network rather than silently adopting a different default.
    keras_architecture_parameters <- create_keras_architecture(
      nn_optimizer = object@keras_architecture_parameters$nn_optimizer,
      units = object@keras_architecture_parameters$units,
      activation = object@keras_architecture_parameters$activation,
      batch_norm_option = object@keras_architecture_parameters$batch_norm_option,
      n_ensembles = object@keras_architecture_parameters$n_ensembles
    )
  }

  return(keras_architecture_parameters)

})


#' @title Convert Keras Architecture Parameters to List
#' @description Converts a `keras_architecture_parameters` object to a list.
#'
#' This method extracts the relevant attributes from a `keras_architecture_parameters`
#' object and returns them as a list, making it easier to work with the parameters
#' in a more general R context.
#'
#' @param x A `keras_architecture_parameters` object that contains the architecture parameters
#'          for a Keras model.
#'
#' @return A list containing the following elements:
#' \item{units}{The number of units in the layer.}
#' \item{n_layers}{The number of layers in the architecture.}
#' \item{activation}{The activation function used in the architecture.}
#' \item{nn_optimizer}{The optimizer used for training the neural network.}
#' \item{batch_norm_option}{Indicates if batch normalization is applied.}
#' \item{n_ensembles}{The number of independently initialised networks averaged at refit.}
#'
#' @details
#' Objects deserialised from artifacts written before \code{n_ensembles} was
#' introduced have no such slot, and an S4 prototype does not retrofit one on
#' load. Those objects are read as a single network, which is the behaviour they
#' were produced under.
#'
#' @export
setMethod("as.list", "keras_architecture_parameters", function(x) {
  list(
    units = x@units,
    n_layers = x@n_layers,
    activation = x@activation,
    nn_optimizer = x@nn_optimizer,
    batch_norm_option = x@batch_norm_option,
    n_ensembles = if (methods::.hasSlot(x, "n_ensembles")) x@n_ensembles else 1
  )
})


# get alpha_test_strategy -----------------------------------------------------

#' @title Get Alpha Test Strategy
#' @description Accessor function to retrieve the alpha test strategy from `ss_backtest_config`, `ss_backtest_results`   object.
#'
#' @param object An ss_backtest_config object.
#'
#' @return The `alpha_test_strategy` slot of the `ss_backtest_config` object.
#' @export
setGeneric("get_alpha_test_strategy", function(object) {
  standardGeneric("get_alpha_test_strategy")
})

#' @rdname get_alpha_test_strategy
#' @export
setMethod("get_alpha_test_strategy", "ss_backtest_config", function(object){
  alpha_test_strategy <- object@alpha_test_strategy

  if(!is.null(alpha_test_strategy)){
    return(alpha_test_strategy)
  } else {
    stop("alpha_test_strategy not available.")
  }

})

#' @rdname get_alpha_test_strategy
#' @export
setMethod("get_alpha_test_strategy", "ss_backtest_results", function(object){

  #WF
  ss_backtest_workflow <- object@ss_backtest_workflow

  #Fabricate bayesian results
  if(ss_backtest_workflow$p_correction_method == "bayesian"){
    bayesian_model_parameters <- methods::new("bayesian_model_parameters",
                                     user_priors = ss_backtest_workflow$user_priors,
                                     prior_derivation_control = ss_backtest_workflow$prior_derivation_control,
                                     brms_control = ss_backtest_workflow$brms_control
    )
  } else {
    bayesian_model_parameters <- NULL
  }

  alpha_test_strategy <- create_alpha_test_strategy(
    model_structure = ss_backtest_workflow$model_structure,
    theme_level_intercept = ss_backtest_workflow$theme_level_intercept,
    theme_level_slope = ss_backtest_workflow$theme_level_slope,
    signal_significance_threshold = ss_backtest_workflow$signal_significance_threshold,
    p_correction_method = ss_backtest_workflow$p_correction_method,
    market_factor_proxy = ss_backtest_workflow$market_factor_proxy,
    bayesian_model_parameters = bayesian_model_parameters,
    enable_theme_representativeness = ss_backtest_workflow$enable_theme_representativeness,
    lmer_control = ss_backtest_workflow$lmer_control
  )


  return(alpha_test_strategy)

})

#' @rdname get_alpha_test_strategy
#' @export
setMethod("get_alpha_test_strategy", "sb_backtest_config", function(object) {

  ss_object <- if(!is.null(object@ss_backtest_config)) object@ss_backtest_config else object@ss_backtest_results
  alpha_test_strategy <- get_alpha_test_strategy(ss_object)

  return(alpha_test_strategy)
})




# get priors -----------------------------------------------------
#' @title Get brms priors
#' @description Accessor function to retrieve brms priors.
#'
#' @param object A `ss_backtest_config` or a `ss_backtest_results` object.
#'
#' @return A `brmsprior` S4 class.
setGeneric("get_brms_prior", function(object){
  standardGeneric("get_brms_prior")
})

#' @rdname get_brms_prior
#' @export
setMethod("get_brms_prior", "ss_backtest_results", function(object){
  if(!object@p_correction_method == "bayesian"){
    stop("brms prior not available for non-bayesian models.")
  }
  return(object@bayesian_results$elected_priors)

})

#' @rdname get_brms_prior
#' @export
setMethod("get_brms_prior", "ss_backtest_config", function(object){

  alpha_test_strategy <- object@alpha_test_strategy

  if(!is.null(alpha_test_strategy) && !is.null(alpha_test_strategy@bayesian_model_parameters) && !is.null(alpha_test_strategy@bayesian_model_parameters@user_priors)){
    return(alpha_test_strategy@bayesian_model_parameters@user_priors)
  } else {
    stop("brms prior not available.")
  }

})

# get bayesian_model_params -----------------------------------------------------
#' @title Get Bayesian Model Parameters
#' @description Extracts the \code{bayesian_model_parameters} from an object (e.g. a
#'   \code{bayesian_alpha_test_strategy} or an \code{ss_backtest_config} holding a Bayesian strategy).
#'
#' @param object An S4 object, typically \code{bayesian_alpha_test_strategy} or \code{ss_backtest_config}.
#'
#' @return An object of class \code{bayesian_model_parameters}.
#' @export
setGeneric("get_bayesian_model_parameters", function(object) {
  standardGeneric("get_bayesian_model_parameters")
})

#' @describeIn get_bayesian_model_parameters
#'   Extract parameters from a \code{bayesian_alpha_test_strategy}.
#' @export
setMethod("get_bayesian_model_parameters", "bayesian_alpha_test_strategy",
          function(object) {
            return(object@bayesian_model_parameters)
          }
)

#' @describeIn get_bayesian_model_parameters
#'   Extract parameters from an \code{ss_backtest_config}, if it has a Bayesian alpha test strategy.
#' @export
setMethod("get_bayesian_model_parameters", "ss_backtest_config",
          function(object) {
            alpha_strat <- object@alpha_test_strategy

            # Check if we actually have a bayesian_alpha_test_strategy
            if (!methods::is(alpha_strat, "bayesian_alpha_test_strategy")) {
              # Option 1: Return NULL
              # return(NULL)

              # Option 2: Throw an error
              stop("This ss_backtest_config does not hold a bayesian_alpha_test_strategy.")
            }

            return(alpha_strat@bayesian_model_parameters)
          }
)






# concentration_constraint policy  -----------------------------------------------------
#' @title Get the Concentration Constraint Policy
#' @description Accessor method to extract the `concentration_constraint_policy` from an object.
#'
#' @param object An object of class \code{port_backtest_config} or \code{sb_backtest_config}.
#'
#' @return An S4 object of class \code{concentration_constraint_policy}.
#' @export
setGeneric("get_concentration_constraint_policy", function(object) {
  standardGeneric("get_concentration_constraint_policy")
})

#' @describeIn get_concentration_constraint_policy
#'   Extract the concentration policy from \code{port_backtest_config}.
#' @export
setMethod("get_concentration_constraint_policy",
          signature(object = "port_backtest_config"),
          function(object) {
            return(object@concentration_constraint_policy)
          }
)

#' @describeIn get_concentration_constraint_policy
#'   Extract the concentration policy from \code{sb_backtest_config},
#'   which stores it inside \code{object@signal_port_parameters}.
#' @export
setMethod("get_concentration_constraint_policy",
          signature(object = "sb_backtest_config"),
          function(object) {
            return(object@signal_port_parameters@concentration_constraint_policy)
          }
)

#' Turn a concentration_constraint_policy into a list
#'
#' @param x An S4 object of class \code{concentration_constraint_policy}.
#'
#' @return A named list containing:
#'   \itemize{
#'     \item \code{benchmark}
#'     \item \code{max_abs_active_individual_weight}
#'     \item \code{max_abs_active_group_weight}
#'   }
#'
#' @export
setMethod("as.list", "concentration_constraint_policy", function(x) {
  list(
    benchmark = x@benchmark,
    max_abs_active_individual_weight = x@max_abs_active_individual_weight,
    max_abs_active_group_weight = x@max_abs_active_group_weight
  )
})


# liquidity_constraint_policy -----------------------------------------------------
#' @title Accessor for Liquidity Constraint Policy
#' @description Retrieves the liquidity constraint policy from a `port_backtest_config` object.
#' @param port_backtest_config_obj A `port_backtest_config` object.
#' @return The liquidity constraint policy list.
#' @export
setGeneric("get_liquidity_constraint_policy", function(port_backtest_config_obj) {
  standardGeneric("get_liquidity_constraint_policy")
})

#' @rdname get_liquidity_constraint_policy
#' @export
setMethod("get_liquidity_constraint_policy", "port_backtest_config", function(port_backtest_config_obj) {
  return(port_backtest_config_obj@liquidity_constraint_policy)
})

#' as.list Method for liquidity_constraint_policy S4 Class
#'
#' Converts a liquidity_constraint_policy S4 object to a list with elements
#' \code{liquidity_floor_rule} and \code{liquidity_cap_rules}.
#'
#' @param x A liquidity_constraint_policy S4 object.
#' @param ... Additional arguments (unused).
#'
#' @return A list with elements \code{liquidity_floor_rule} and \code{liquidity_cap_rules}.
#'
#' @export
setMethod(
  f = "as.list",
  signature = "liquidity_constraint_policy",
  definition = function(x, ...) {
    list(
      liquidity_floor_rule = x@liquidity_floor_rule,
      liquidity_cap_rules = x@liquidity_cap_rules
    )
  }
)




# turnover_constraint_policy -----------------------------------------------------
#' @title Accessor for Turnover Constraint Policy
#' @description Retrieves the turnover constraint policy from a `port_backtest_config` object.
#' @param port_backtest_config_obj A `port_backtest_config` object.
#' @return The turnover constraint policy list.
#' @export
setGeneric("get_turnover_constraint_policy", function(port_backtest_config_obj) {
  standardGeneric("get_turnover_constraint_policy")
})

#' @rdname get_turnover_constraint_policy
#' @export
setMethod("get_turnover_constraint_policy", "port_backtest_config", function(port_backtest_config_obj) {
  return(port_backtest_config_obj@turnover_constraint_policy)
})

#' as.list Method for turnover_constraint_policy S4 Class
#'
#' Converts a turnover_constraint_policy S4 object to a list with elements
#' \code{quantile_range_buffer} and \code{turnover_cap_rules}.
#'
#' @param x A turnover_constraint_policy S4 object.
#' @param ... Additional arguments (unused).
#'
#' @return A list with elements \code{quantile_range_buffer} and \code{turnover_cap_rules}.
#'
#' @export
setMethod("as.list", "turnover_constraint_policy", function(x, ...) {
  list(
    quantile_range_buffer = x@quantile_range_buffer,
    turnover_cap_rules = x@turnover_cap_rules
  )
})



# transaction_costs_parameters -----------------------------------------------------
#' @title Accessor for Transaction Cost Parameters
#' @description Retrieves the transaction_costs_parameters from a `port_backtest_config` object.
#' @param port_backtest_config_obj A `port_backtest_config` object.
#' @return The turnover constraint policy list.
#' @export
setGeneric("get_transaction_costs_parameters", function(port_backtest_config_obj) {
  standardGeneric("get_transaction_costs_parameters")
})

#' @rdname get_transaction_costs_parameters
#' @export
setMethod("get_transaction_costs_parameters", "port_backtest_config", function(port_backtest_config_obj) {
  return(port_backtest_config_obj@transaction_costs_parameters)
})

#' as.list Method for transaction_costs_parameters S4 Class
#'
#' Converts a transaction_costs_parameters S4 object to a list with elements
#' \code{direct_transaction_cost}, \code{alpha}, \code{lambda} and \code{strategy_aum}.
#'
#' @param x A transaction_costs_parameters S4 object.
#' @param ... Additional arguments (unused).
#'
#' @return A list with elements \code{quantile_range_buffer} and \code{turnover_cap_rules}.
#'
#' @export
setMethod("as.list", "transaction_costs_parameters", function(x, ...) {
  list(
    direct_transaction_cost = x@direct_transaction_cost,
    strategy_aum = x@strategy_aum,
    alpha = x@alpha,
    lambda = x@lambda
  )
})




# liquidity_floor_cutoffs -----------------------------------------------------
#' @title Accessor for Liquidity Floor Cutoffs
#' @description Retrieves the liquidity floor cutoffs from a `port_backtest_config` object.
#' @param port_backtest_config_obj A `port_backtest_config` object.
#' @return The liquidity floor cutoffs list.
#' @export
setGeneric("get_liquidity_floor_cutoffs", function(port_backtest_config_obj) {
  standardGeneric("get_liquidity_floor_cutoffs")
})

#' @rdname get_liquidity_floor_cutoffs
#' @export
setMethod("get_liquidity_floor_cutoffs", "port_backtest_config", function(port_backtest_config_obj) {
  return(port_backtest_config_obj@liquidity_floor_cutoffs)
})
















