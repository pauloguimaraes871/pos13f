#' @title Compute Formula-Based Signal Calculation
#'
#' @description
#' Applies a user-defined arithmetic formula to variables in a `meta_dataframe` object.
#' The function computes the formula for each row (ticker-date pair), without any rolling
#' or seasonal windowing (unlike `compute_window`).
#'
#' @param features_m_df A `meta_dataframe` object.
#' @param formula A `formula` specifying the transformation to apply. The formula should use
#'   column names from `features_m_df` and may include arithmetic operations such as
#'   \code{+}, \code{-}, \code{*}, \code{/}, and common functions like \code{log()}, \code{exp()}, \code{sqrt()}.
#'   The left-hand side of the formula defines the new feature name.
#'   For example: \code{log_mktcap ~ log(market_cap)}, \code{pe_ratio ~ price / earnings}.
#' @param ignore_NA A `character` vector specifying which variables (among those in the formula) should be imputed
#'   in case of missing values. If the formula uses \code{+} or \code{-}, NAs are replaced with 0.
#'   If the formula uses \code{*} or \code{/}, NAs are replaced with 1.
#'
#' @return A modified `meta_dataframe` object with a new column computed based on the formula.
#'
#' @details
#' If `ignore_NA` is specified, the computation avoids propagation of missing values by replacing
#' them according to the arithmetic structure. Mixing addition/subtraction with multiplication/division
#' in the same formula is not allowed when `ignore_NA` is used. The function appends the result to
#' the `meta_dataframe`, preserving its workflow log.
#'
#' @examples
#' \dontrun{
#' # Book yield from two columns, then a log transform
#' features_m_df <- compute_formula(features_m_df, book_yield ~ book_value / market_cap)
#' features_m_df <- compute_formula(features_m_df, log_mktcap ~ log(market_cap))
#' # NA-safe additive combination: treat a missing Beta as 0
#' features_m_df <- compute_formula(features_m_df, combo ~ Alpha + Beta, ignore_NA = "Beta")
#' }
#'
#' @export
setGeneric("compute_formula", function(features_m_df, formula, ignore_NA = NULL) {
  standardGeneric("compute_formula")
})

#' @rdname compute_formula
#' @export
setMethod("compute_formula",
          signature(features_m_df = "meta_dataframe", formula = "formula"),
          function(features_m_df, formula, ignore_NA = NULL) {

            #Extract data
            #################
              ##Extract necessary data
              meta_dataframe_workflow <- features_m_df@workflow
              meta_dataframe_name <- features_m_df@meta_dataframe_name
              pre_silver_features_m_df <- features_m_df@data


              ##Extract left-hand side (feature name) and right-hand side (formula expression)
              feature_name <- as.character(formula[[2]]) #LHS
              formula_expr <- formula[[3]]  # RHS expression
              formula_vars <- all.vars(formula_expr)
              formula_tokens <- all.names(formula_expr)

              ##Identify operations in the formula
              contains_add_subtract <- any(formula_tokens %in% c("+", "-"))
              contains_mult_div <- any(formula_tokens %in% c("*", "/"))
              contains_other_functions <- any(formula_tokens %in% c("log", "exp", "sqrt", "^"))

            #################

            #Check errors
            #################

              ##Check if all referenced columns exist
              missing_vars <- setdiff(formula_vars, names(pre_silver_features_m_df))
              if (length(missing_vars) > 0) {
                stop("The following columns are missing in the data: ", paste(missing_vars, collapse = ", "))
              }
              ##Check if all ignore_NA columns exist
              if (!is.null(ignore_NA)) {
                missing_ignore_NA_vars <- setdiff(ignore_NA, names(pre_silver_features_m_df))
                if (length(missing_ignore_NA_vars) > 0) {
                  stop("The following columns are missing in the data: ", paste(missing_ignore_NA_vars, collapse = ", "))
                }
              }
              ##Check that ignore_NA and formula_vars are not exactly the same (order may differ)
              if (!is.null(ignore_NA)) {
                if (identical(sort(ignore_NA), sort(formula_vars))) {
                  stop("The ignore_NA columns and formula columns are the same.")
                }
                if ((contains_add_subtract && contains_mult_div) || contains_other_functions) {
                  stop("When ignore_NA is specified, only basic arithmethic operations that do not mix addition/subtraction with multiplication/division are allowed.")
                }
              }

            #################

            #Apply formula
            ################

              ##Handle NA values dynamically using dplyr
              modified_data <- pre_silver_features_m_df

              if (is.character(ignore_NA) && !(length(ignore_NA) == 1 && is.null(ignore_NA))) {
                cols_to_replace <- intersect(ignore_NA, formula_vars)
                if (contains_add_subtract) {
                  modified_data <- modified_data %>%
                    dplyr::mutate(dplyr::across(dplyr::all_of(cols_to_replace), ~ifelse(is.na(.), 0, .)))
                } else if (contains_mult_div) {
                  modified_data <- modified_data %>%
                    dplyr::mutate(dplyr::across(dplyr::all_of(cols_to_replace), ~ifelse(is.na(.), 1, .)))
                }
              }

              ##Evaluate the formula dynamically with error handling
              computed_values <- tryCatch({
                modified_data %>%
                  dplyr::mutate(result = eval(formula_expr, .))
              }, error = function(e) {
                stop("Formula evaluation failed: ", e$message)
              }, warning = function(w) {
                warning("Formula evaluation produced a warning: ", w$message)
                # Only replace problematic rows with NA
                modified_data %>%
                  dplyr::mutate(
                    result = dplyr::if_else(is.na(eval(formula_expr, .)), NA_real_, eval(formula_expr, .))
                  )
              })

            #################

            #Finalize
            #################

              ##Add computed values to meta_dataframe
              pre_silver_features_m_df <- pre_silver_features_m_df %>%
                dplyr::mutate(!!rlang::sym(feature_name) := computed_values$result)

              ##Update workflow
              new_workflow <- list(
                list(
                  timestamp = Sys.time(),
                  formula = deparse(formula),
                  ignore_NA = ignore_NA,
                  feature_name = feature_name,
                  call = match.call()
                )
              )

              ##Recreate meta_dataframe
              pre_silver_features_m_df <- create_meta_dataframe(
                pre_silver_features_m_df,
                meta_dataframe_name = meta_dataframe_name,
                workflow = c(meta_dataframe_workflow, new_workflow),
                type = "generic"
              )

              # Rename workflow entry
              names(pre_silver_features_m_df@workflow)[length(pre_silver_features_m_df@workflow)] <-
                paste0("compute_", feature_name, "_", features_m_df@current_date)

            return(pre_silver_features_m_df)
          })
