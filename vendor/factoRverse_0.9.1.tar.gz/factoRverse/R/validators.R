#' Check if an object is coercible to meta_dataframe
#'
#' This function checks if an object can be converted to a \code{meta_dataframe} class
#' by verifying the required columns, data types, and other constraints. It provides
#' detailed messages explaining why the object is not coercible.
#'
#' @param obj An R object to be checked for coercibility.
#' @return A logical value indicating whether the object can be coerced to \code{meta_dataframe}.
#' @export
is_coercible_to_meta_dataframe <- function(obj) {

  #If the object is already meta_dataframe, return TRUE
  if(is_meta_dataframe(obj)){
    return(TRUE)
  } else {
  #Otherwise...
    if (!is.data.frame(obj)){
      message("The object is not a data frame.")
      return(FALSE)
    }

    required_columns <- c("id", "tickers", "dates")

    if (!all(required_columns == names(obj)[1:3])) {
      message("The data frame must contain the following columns: 'id', 'tickers', 'dates', exactly in this order.")
      return(FALSE)
    }

    if(any(!is.character(obj$tickers))){
      stop("Tickers must be of class character")
    }

    if (any(is.na(obj[required_columns]))) {
      message("Columns 'id', 'tickers', or 'dates' contain NA values.")
      return(FALSE)
    }

    if (!inherits(obj$dates, "Date")) {
      message("The 'dates' column must be of class 'Date'.")
      return(FALSE)
    }

    if (!is.character(obj$id)) {
      message("The 'id' column must be character.")
      return(FALSE)
    }

    ordered_id <- dplyr::arrange(obj, id)$id

    if (!isTRUE(all.equal(obj$id, ordered_id, check.attributes = FALSE))) {
      message("Object must be ordered alphabetically according to id.")
      return(FALSE)
    }

    expected_id <- paste0(obj$tickers, "-", obj$dates)
    if (!all(obj$id == expected_id)) {
      message("The 'id' column does not match the expected format 'tickers-dates'.")
      return(FALSE)
    }


    if (!all(diff(unique(obj$dates)[order(unique(obj$dates))]) >= 0)) {
      message("Dates must be in ascending chronological order")
      return(FALSE)
    }

    if (any(duplicated(obj$id))) {
      message("The 'id' column contains duplicated values.")
      return(FALSE)
    }



    # Check for NA values in remaining columns
    remaining_columns <- setdiff(names(obj), required_columns)
    na_remaining <- sapply(obj[, remaining_columns, drop = FALSE], function(col) any(is.na(col)))
    if (any(na_remaining)) {
      message("The following columns contain NA values: ",
              paste(remaining_columns[na_remaining], collapse = ", "))
    }

    if (any(duplicated(remaining_columns))) {
      stop("Column names for variables must be unique")
    }



    # All checks passed
    return(TRUE)

  }


}



# Define the is_meta_dataframe function
#' Check if an object is a meta_dataframe
#'
#' @param x The object to check.
#' @return TRUE if x is of class "meta_dataframe", FALSE otherwise.
#' @export
is_meta_dataframe <- function(x) {
  inherits(x, "meta_dataframe")
}


#' Check if an object is of class hyper_grid_domain
#'
#' This function checks whether a given object is of class 'hyper_grid_domain'.
#'
#' @param x The object to check.
#'
#' @return Logical value: TRUE if the object is of class 'hyper_grid_domain', FALSE otherwise.
#'
#' @export
is_hyper_grid_domain <- function(x) {
  inherits(x, "hyper_grid_domain")
}

#' Define the is_hyperparameter_tuning_strategy function
#' @description Function to check if an object is of class `hyperparameter_tuning_strategy`.
#'
#' @param x An object to check.
#'
#' @return A logical value indicating whether the object is of class `hyperparameter_tuning_strategy`.
#'
#' @export
is_tuning_strategy <- function(x) {
  methods::is(x, "tuning_strategy")
}

#' Define the is keras_architecture_parameters function
#' @description Function to check if an object is of class `keras_architecture_parameters`.
#'
#' @param x An object to check.
#'
#' @return A logical value indicating whether the object is of class `keras_architecture_parameters`.
#'
#' @export
is_keras_architecture_parameters <- function(x) {
  methods::is(x, "keras_architecture_parameters")
}


#' Define the is portfolio_policies function
#' @description Function to check if an object is of class `portfolio_policies`.
#'
#' @param x An object to check.
#'
#' @return A logical value indicating whether the object is of class `portfolio_policies`.
#'
#' @export
is_portfolio_policies <- function(x) {
  methods::is(x, "portfolio_policies")
}

#' Get Expected Hyperparameters for a Machine Learning Algorithm or Configuration
#'
#' The `hyperparameters` function returns a character vector of expected hyperparameters for a given machine learning algorithm or configuration.
#'
#' @param object An `sb_algorithm` character string or an `sb_backtest_config` object.
#' @return A character vector containing the names of the expected hyperparameters for the specified algorithm.
#' @export
setGeneric("hyperparameters", function(object) standardGeneric("hyperparameters"))


#' @describeIn hyperparameters Get expected hyperparameters for a given machine learning algorithm.
#'
#' @param object A character string specifying the machine learning algorithm.
#' Valid options are "glmnet", "rf", "xgb", "nn", or "ols".
#'
#' @return A character vector of expected hyperparameters.
#' If the algorithm is "ols" or not recognized, it returns an empty character vector.
#'
#'
#' @export
setMethod("hyperparameters", signature(object = "character"),
          function(object) {
            sb_algorithm <- object
            expected_hyperparameters <- switch(
              sb_algorithm,
              "glmnet" = c("alpha", "lambda.min.ratio"),
              "rf" = c("mtry", "num.trees", "max.depth", "min.bucket"),
              "xgb" = c("min_child_weight", "max_depth", "subsample", "colsample_bytree",
                        "eta", "alpha", "gamma", "nrounds"),
              "nn" = c("regularizer_l1", "regularizer_l2", "droprate", "lr",
                       "size_of_batch", "number_of_epochs"),
              character(0) # default for unrecognized algorithms or 'ols'
            )
            return(expected_hyperparameters)
          })

#' @describeIn hyperparameters Get expected hyperparameters from an `sb_backtest_config` object.
#'
#' @param object An `sb_backtest_config` object.
#'
#' @return A character vector of expected hyperparameters for the algorithm specified in the configuration.
#' If the algorithm is "ols" or not recognized, it returns an empty character vector.
#'
#'
#' @export
setMethod("hyperparameters", signature(object = "sb_backtest_config"),
          function(object) {
            sb_algorithm <- object@sb_algorithm
            expected_hyperparameters <- hyperparameters(sb_algorithm)
            return(expected_hyperparameters)
          })



#' Validate Concentration Constraint Policy
#'
#' Internal function to validate the structure and values of the concentration constraint policy.
#'
#' @param concentration_constraint_policy A list with the following possible elements:
#'   \describe{
#'     \item{benchmark}{Benchmark weights (not validated by this function).}
#'     \item{max_abs_active_individual_weight}{A numeric value in (0, 1] representing the maximum absolute active weight for an individual asset.}
#'     \item{max_abs_active_group_weight}{A named numeric vector in (0, 1] representing the maximum absolute active weight for groups of assets. Names must be unique.}
#'   }
#'  @param macro If true, indicates concentration_constraint_policy is for a macro portfolio.
#'
#' @return Invisibly returns TRUE if the policy is valid.
#' @keywords internal
validate_concentration_constraint_policy <- function(concentration_constraint_policy, macro = FALSE){

  warning_str <- if (macro) "Error in macro_concentration_constraint_policy:" else "Error in concentration_constraint_policy:"

  ## Check if the input is a list
  if (!is.list(concentration_constraint_policy)) {
    stop(paste0(warning_str, " must be a list"))
  }

  ##Check if names in concentration_constraint_policy match possible options
  if (macro){
    if(any(!names(concentration_constraint_policy) %in%
           c("benchmark", "max_abs_active_individual_weight"))){
      stop(paste0(warning_str,
                  " elements of concentration_constraint_policy should be one of benchmark or max_abs_active_individual_weight."))
    }
  } else {
    if(any(!names(concentration_constraint_policy) %in%
           c("benchmark", "max_abs_active_individual_weight", "max_abs_active_group_weight"))){
      stop(paste0(warning_str,
                  " elements of concentration_constraint_policy should be one of benchmark, max_abs_active_individual_weight or max_abs_active_group_weight."))
    }
  }


  ##Check if benchmark is always set
  if(is.null(concentration_constraint_policy$benchmark)){
    stop(paste0(warning_str, " benchmark must be set"))
  }

  ##Check if one of max_abs_active_individual_weight or max_abs_active_group_weight is set
  if(is.null(concentration_constraint_policy$max_abs_active_individual_weight) &
     is.null(concentration_constraint_policy$max_abs_active_group_weight)){
    stop(paste0(warning_str, " either max_abs_active_individual_weight or max_abs_active_group_weight must be set"))
  }

  ##Check if max_abs_active_individual_weight is numeric
  if(!is.null(concentration_constraint_policy$max_abs_active_individual_weight) &
     !is.numeric(concentration_constraint_policy$max_abs_active_individual_weight)){
    stop(paste0(warning_str, " max_abs_active_individual_weight must be numeric"))
  }

  ##Check if max_abs_active_group_weight is numeric
  if(!is.null(concentration_constraint_policy$max_abs_active_group_weight) &
     !is.numeric(concentration_constraint_policy$max_abs_active_group_weight)){
    stop(paste0(warning_str, " max_abs_active_group_weight must be numeric"))
  }

  ##Constraints are bounded in (0,1]
  if (!is.null(concentration_constraint_policy$max_abs_active_individual_weight) &&
      (concentration_constraint_policy$max_abs_active_individual_weight <= 0 || concentration_constraint_policy$max_abs_active_individual_weight > 1)){
    stop(paste0(warning_str, " max_abs_active_individual_weight must be in (0,1]"))
  }

  ##Constraints are bounded in (0,1]
  if (!is.null(concentration_constraint_policy$max_abs_active_group_weight) &&
      (any(concentration_constraint_policy$max_abs_active_group_weight <= 0) ||
       any(concentration_constraint_policy$max_abs_active_group_weight > 1))){
    stop(paste0(warning_str, " max_abs_active_group_weight must be in (0,1]"))
  }

  ## Check if max_abs_active_group_weight contains duplicated names
  if (!is.null(concentration_constraint_policy$max_abs_active_group_weight)) {
    grp_names <- names(concentration_constraint_policy$max_abs_active_group_weight)
    if (!is.null(grp_names) && any(duplicated(grp_names))) {
      stop(paste0(warning_str, " max_abs_active_group_weight can't contain duplicated names"))
    }
  }


}



#' Validate Liquidity Constraint Policy
#'
#' Internal function to validate the liquidity constraint policy.
#'
#' The policy is provided as a list that may contain two elements:
#' \describe{
#'   \item{liquidity_floor_rule}{(Optional) A character string indicating the liquidity floor.
#'      Must be one of "micro_caps", "small_caps", "mid_caps", "large_caps", or "mega_caps".}
#'   \item{liquidity_cap_rules}{(Optional) A named numeric vector containing liquidity caps.
#'      The names must be valid liquidity categories (see above), there must be no duplicated names,
#'      and the numeric values must lie in the interval (0, 1]. If liquidity_floor_rule is provided,
#'      no liquidity cap can be set for a category that is less liquid than the floor.
#'      Moreover, monotonicity is enforced: for any two categories, if one category is less liquid than
#'      another, its cap must not exceed that of the more liquid category.}
#' }
#'
#' @param liquidity_constraint_policy A list with the elements described above.
#'
#' @return Invisibly returns TRUE if the policy is valid.
#'
#' @keywords internal
validate_liquidity_constraint_policy <- function(liquidity_constraint_policy) {
  ## Check that input is a list
  if (!is.list(liquidity_constraint_policy)) {
    stop("Error in liquidity_constraint_policy: must be a list")
  }

  ##Either liquidity_floor_rule or liquidity_cap_rules must be set
  if (is.null(liquidity_constraint_policy$liquidity_floor_rule) &&
      is.null(liquidity_constraint_policy$liquidity_cap_rules)) {
    stop("Error in liquidity_constraint_policy: either liquidity_floor_rule or liquidity_cap_rules must be set")
  }

  allowed_elements <- c("liquidity_floor_rule", "liquidity_cap_rules")
  if (!is.null(names(liquidity_constraint_policy)) &&
      !all(names(liquidity_constraint_policy) %in% allowed_elements)) {
    stop("Error in liquidity_constraint_policy: elements of liquidity_constraint_policy should be one of liquidity_floor_rule or liquidity_cap_rules")
  }

  ## Define allowed liquidity categories (from less liquid to more liquid)
  allowed_categories <- c("micro_caps", "small_caps", "mid_caps", "large_caps", "mega_caps")

  ## Validate liquidity_floor_rule if provided
  if (!is.null(liquidity_constraint_policy$liquidity_floor_rule)) {
    if (!is.character(liquidity_constraint_policy$liquidity_floor_rule) ||
        length(liquidity_constraint_policy$liquidity_floor_rule) != 1) {
      stop("Error in liquidity_constraint_policy: liquidity_floor_rule must be a character string")
    }
    if (!liquidity_constraint_policy$liquidity_floor_rule %in% allowed_categories) {
      stop("Error in liquidity_constraint_policy: liquidity_floor_rule must be one of 'micro_caps', 'small_caps', 'mid_caps', 'large_caps' or 'mega_caps'")
    }
  }

  ## Validate liquidity_cap_rules if provided
  if (!is.null(liquidity_constraint_policy$liquidity_cap_rules)) {
    cap_rules <- liquidity_constraint_policy$liquidity_cap_rules

    ## Must be numeric
    if (!is.numeric(cap_rules)) {
      stop("Error in liquidity_constraint_policy: liquidity_cap_rules must be numeric")
    }
    ## Must have names
    if (is.null(names(cap_rules))) {
      stop("Error in liquidity_constraint_policy: liquidity_cap_rules must have names")
    }
    ## All names must be valid liquidity categories
    if (!all(names(cap_rules) %in% allowed_categories)) {
      stop("Error in liquidity_constraint_policy: liquidity_cap_rules names must be one of 'micro_caps', 'small_caps', 'mid_caps', 'large_caps' or 'mega_caps'")
    }
    ## Check for duplicated names
    if (any(duplicated(names(cap_rules)))) {
      stop("Error in liquidity_constraint_policy: liquidity_cap_rules can't have duplicated names")
    }
    ## Check that liquidity_cap_rules are bounded in (0,1]
    if (any(cap_rules <= 0 | cap_rules > 1)) {
      stop("Error in liquidity_constraint_policy: liquidity_cap_rules must be in (0,1]")
    }

    ## If liquidity_floor_rule is provided, ensure that no liquidity cap rule is defined
    ## for a category that is less liquid than the floor.
    if (!is.null(liquidity_constraint_policy$liquidity_floor_rule)) {
      floor_rule <- liquidity_constraint_policy$liquidity_floor_rule
      floor_index <- match(floor_rule, allowed_categories)
      for (cat in names(cap_rules)) {
        cat_index <- match(cat, allowed_categories)
        if (cat_index < floor_index) {
          stop(
            paste0("Error in liquidity_constraint_policy: Liquidity cap rule for '", cat,
                   "' is less liquid than the liquidity_floor_rule '", floor_rule, "'")
          )
        }
      }
    }

    ## Enforce monotonicity in liquidity_cap_rules.
    ## For any two categories in liquidity_cap_rules, if one category is less liquid than another then its
    ## cap must not exceed that of the more liquid category.
    for (i in seq_along(cap_rules)) {
      for (j in seq_along(cap_rules)) {
        if (match(names(cap_rules)[i], allowed_categories) <
            match(names(cap_rules)[j], allowed_categories)) {
          if (cap_rules[i] > cap_rules[j]) {
            stop(
              paste0("Error in liquidity_constraint_policy: Cap for '", names(cap_rules)[i],
                     "' of ", cap_rules[i],
                     " cannot be greater than cap for '", names(cap_rules)[j],
                     "' of ", cap_rules[j])
            )
          }
        }
      }
    }
  }

  invisible(TRUE)
}


#' Validate Turnover Constraint Policy
#'
#' Internal function to validate the turnover constraint policy.
#'
#' The policy is provided as a list that must contain the following elements:
#' \describe{
#'   \item{quantile_range_buffer}{A numeric value between 0 and 1 that defines the buffer for turnover quantiles.}
#'   \item{turnover_cap_rules}{A named numeric vector whose names correspond to valid liquidity categories
#'      ("micro_caps", "small_caps", "mid_caps", "large_caps", "mega_caps"). Each value must be between 0 and 1.
#'      Additionally, for any two categories, if one category is less liquid than another then its cap must not exceed
#'      that of the more liquid category.}
#' }
#'
#' @param turnover_constraint_policy A list with the elements described above.
#'
#' @return Invisibly returns TRUE if the policy is valid.
#'
#' @keywords internal
validate_turnover_constraint_policy <- function(turnover_constraint_policy) {
  # Check that the input is a list
  if (!is.list(turnover_constraint_policy)) {
    stop("Error in turnover_constraint_policy: must be a list")
  }

  allowed_elements <- c("quantile_range_buffer", "turnover_cap_rules")
  if (!is.null(names(turnover_constraint_policy)) &&
      !all(names(turnover_constraint_policy) %in% allowed_elements)) {
    stop("Error in turnover_constraint_policy: elements of turnover_constraint_policy should be one of quantile_range_buffer or turnover_cap_rules")
  }

  # Validate quantile_range_buffer
  if (is.null(turnover_constraint_policy$quantile_range_buffer)) {
    stop("Error in turnover_constraint_policy: quantile_range_buffer can't be missing")
  }
  if (!is.numeric(turnover_constraint_policy$quantile_range_buffer) ||
      length(turnover_constraint_policy$quantile_range_buffer) != 1) {
    stop("Error in turnover_constraint_policy: quantile_range_buffer must be a number")
  }
  if (turnover_constraint_policy$quantile_range_buffer < 0 ||
      turnover_constraint_policy$quantile_range_buffer > 1) {
    stop("Error in turnover_constraint_policy: quantile_range_buffer must be a number between 0 and 1")
  }

  # Validate turnover_cap_rules
  if (is.null(turnover_constraint_policy$turnover_cap_rules)) {
    stop("Error in turnover_constraint_policy: turnover_cap_rules can't be missing")
  }
  cap_rules <- turnover_constraint_policy$turnover_cap_rules
  if (!is.numeric(cap_rules)) {
    stop("Error in turnover_constraint_policy: turnover_cap_rules must be numeric")
  }
  if (is.null(names(cap_rules))) {
    stop("Error in turnover_constraint_policy: turnover_cap_rules must have names")
  }

  allowed_categories <- c("micro_caps", "small_caps", "mid_caps", "large_caps", "mega_caps")
  if (!all(names(cap_rules) %in% allowed_categories)) {
    stop("Error in turnover_constraint_policy: names of turnover_cap_rules must be in accordance to micro_caps, small_caps, mid_caps, large_caps, mega_caps")
  }
  if (any(duplicated(names(cap_rules)))) {
    stop("Error in turnover_constraint_policy: names of turnover_cap_rules must not be duplicated")
  }
  if (!all(cap_rules >= 0 & cap_rules <= 1)) {
    stop("Error in turnover_constraint_policy: turnover_cap_rules must be bounded between 0 and 1")
  }

  # Enforce monotonicity in turnover_cap_rules.
  # For any two categories, if one category is less liquid than another then its cap must not exceed that of the more liquid category.
  for (i in seq_along(cap_rules)) {
    for (j in seq_along(cap_rules)) {
      if (match(names(cap_rules)[i], allowed_categories) < match(names(cap_rules)[j], allowed_categories)) {
        if (cap_rules[i] > cap_rules[j]) {
          stop(paste0("Error in turnover_constraint_policy: Cap for '", names(cap_rules)[i],
                      "' of", cap_rules[i],
                      " cannot be greater than cap for '", names(cap_rules)[j],
                      "' of ", cap_rules[j]))
        }
      }
    }
  }

  invisible(TRUE)
}


#' Validate Transaction Cost Parameters
#'
#' This function validates a list of transaction cost parameters based on the BARRA model.
#' It checks that the list contains the names: "direct_transaction_cost", "strategy_aum",
#' "alpha", and "lambda". Additionally, it ensures that:
#' \itemize{
#'   \item \code{direct_transaction_cost} is a single numeric value and positive.
#'   \item \code{strategy_aum} is a single numeric value and positive.
#'   \item \code{alpha} is a single numeric value and positive.
#'   \item \code{lambda} is a single value that is either numeric or exactly the string "dynamic".
#' }
#'
#' @param transaction_costs_parameters A list containing transaction cost parameters.
#'
#' @return TRUE if all validations pass; otherwise, the function stops with an error.
#'
#'
#' @export
validate_transaction_costs_parameters <- function(transaction_costs_parameters) {
  # Check if all required names are present
  required_names <- c("direct_transaction_cost", "strategy_aum", "alpha", "lambda")
  if (!all(required_names %in% names(transaction_costs_parameters))) {
    stop("transaction_costs_parameters should have names 'direct_transaction_cost', 'strategy_aum', 'alpha' and 'lambda'")
  }

  # Check if direct_transaction_cost is numeric of length 1
  if (!is.numeric(transaction_costs_parameters$direct_transaction_cost) ||
      length(transaction_costs_parameters$direct_transaction_cost) != 1 ||
      (transaction_costs_parameters$direct_transaction_cost <= 0.0001 || transaction_costs_parameters$direct_transaction_cost >= 0.1)){
    stop("direct_transaction_cost should be a single numeric between 0.0001 and 0.1")
  }

  # Check if strategy_aum is numeric of length 1
  if (!is.numeric(transaction_costs_parameters$strategy_aum) ||
      length(transaction_costs_parameters$strategy_aum) != 1 ||
      transaction_costs_parameters$strategy_aum <= 0){
    stop("strategy_aum should be a single positive numeric")
  }

  # Check if alpha is numeric of length 1
  if (!is.numeric(transaction_costs_parameters$alpha) ||
      length(transaction_costs_parameters$alpha) != 1 ||
      (transaction_costs_parameters$alpha <= 0 || transaction_costs_parameters$alpha > 1)
  ) {
    stop("alpha should be a single numeric between 0 and 1")
  }

  # Check if lambda is of length 1
  if (length(transaction_costs_parameters$lambda) != 1 ||
      (!is.numeric(transaction_costs_parameters$lambda) && transaction_costs_parameters$lambda != "dynamic")){
    stop("lambda should be a single numeric value or 'dynamic'")
  }

  if(is.numeric(transaction_costs_parameters$lambda) && (transaction_costs_parameters$lambda <= 0 || transaction_costs_parameters$lambda > 1)){
    stop("lambda should be a single numeric value between 0 and 1")
  }



  TRUE
}


#' Valida exp_ret_score_tilt
#'
#' Internal function to validate the exp_ret_score_tilt and exp_ret_score_tilt_eta parameters
#' that belong to rp and hrp port constructions methods.
#'
#' @param exp_ret_score_tilt A character indicating when to apply the expected return score tilt. Possible options are 'none', 'inner' or 'final'.
#' 'none' means no tilt is applied, 'inner' means the tilt is applied within the risk parity algorithm and 'final' means the tilt is applied after the risk parity solution is computed.
#' @param exp_ret_score_tilt_eta A numeric value representing the intensity of the expected return score tilt. Must be a positive value. Only needed when exp_ret_score_tilt is 'inner' or 'final'.
#'
#' @return Invisibly returns TRUE if the parameters are valid.
#'
#' @export
#'
validate_exp_ret_score_tilt <- function(exp_ret_score_tilt, exp_ret_score_tilt_eta){

  #Check that exp_ret_score_tilt is a length 1 character equal to 'none', 'inner' or 'final'
  if(!exp_ret_score_tilt %in% c("none", "inner", "final")){
    stop("exp_ret_score_tilt must be one of 'none', 'inner' or 'final'.")
  }


  #Check that exp_ret_score_tilt_eta is NULL or a single positive numeric value
  if(!is.null(exp_ret_score_tilt_eta)){
    if(!is.numeric(exp_ret_score_tilt_eta) || length(exp_ret_score_tilt_eta) != 1 || exp_ret_score_tilt_eta <= 0){
      stop("exp_ret_score_tilt_eta must be a single positive numeric value.")
    }
  }

  #Check that exp_ret_score_tilt_eta is provided if exp_ret_score_tilt is 'inner' or 'final'
  if(exp_ret_score_tilt %in% c("inner", "final") && is.null(exp_ret_score_tilt_eta)){
    stop("exp_ret_score_tilt_eta must be provided when exp_ret_score_tilt is 'inner' or 'final'.")
  }

  invisible(TRUE)


}

#' Validate Liquidity Floor Cutoffs
#'
#' Internal function to validate a liquidity_floor_cutoffs data frame.
#'
#' This function checks that the liquidity_floor_cutoffs data frame meets the following requirements:
#' \itemize{
#'   \item It is a data.frame with at least two columns.
#'   \item The first column is named \code{"liquidity_classification"}.
#'   \item It has at most 5 rows.
#'   \item The values in the \code{liquidity_classification} column are among
#'         \code{"micro_caps"}, \code{"small_caps"}, \code{"mid_caps"}, \code{"large_caps"}, or \code{"mega_caps"}
#'         and contain no duplicates.
#'   \item All other columns are numeric and contain no missing values.
#'   \item If \code{main_liquidity_metric} is provided, then it must be one of the non-classification
#'         column names, the data frame must be arranged in ascending order by that metric, and the
#'         ranking (order) of the values across all liquidity metric columns must be identical.
#'   \item The liquidity metric values must not be normalized; that is, it is an error if all values in each
#'         liquidity metric column (all but the first) are between -1 and 1.
#' }
#'
#' @param liquidity_floor_cutoffs A data.frame containing liquidity floor cutoffs.
#' @param main_liquidity_metric Optional character string specifying the column (other than
#'   \code{"liquidity_classification"}) that should be used to check ascending order.
#'
#' @return Invisibly returns \code{TRUE} if the data frame passes all validations.
#'
#' @keywords internal
validate_liquidity_floor_cutoffs <- function(liquidity_floor_cutoffs, main_liquidity_metric = NULL) {

  # Must be a data.frame
  if (!is.data.frame(liquidity_floor_cutoffs)) {
    stop("liquidity_floor_cutoffs must be a data.frame")
  }

  # Must have at least 2 columns
  if (ncol(liquidity_floor_cutoffs) < 2) {
    stop("liquidity_floor_cutoffs must have at least 2 columns")
  }

  # First column must be "liquidity_classification"
  if (colnames(liquidity_floor_cutoffs)[1] != "liquidity_classification") {
    stop("liquidity_floor_cutoffs must have liquidity_classification as the first column")
  }

  # Must have at most 5 rows
  if (nrow(liquidity_floor_cutoffs) > 5) {
    stop("liquidity_floor_cutoffs must have at most 5 rows")
  }

  # liquidity_classification values must have no duplicates
  if (any(duplicated(liquidity_floor_cutoffs$liquidity_classification))) {
    stop("liquidity_classification must not have duplicates")
  }

  # Check that liquidity_classification values are supported
  allowed_categories <- c("micro_caps", "small_caps", "mid_caps", "large_caps", "mega_caps")
  if (any(!liquidity_floor_cutoffs$liquidity_classification %in% allowed_categories)) {
    stop("liquidity_classification must be one of micro_caps, small_caps, mid_caps, large_caps or mega_caps")
  }

  # All columns except the first must be numeric
  if (!all(sapply(liquidity_floor_cutoffs[, -1, drop = FALSE], is.numeric))) {
    stop("liquidity_floor_cutoffs elements (except liquidity_classification) must be numeric")
  }

  # There must be no missing values
  if (any(is.na(liquidity_floor_cutoffs))) {
    stop("liquidity_floor_cutoffs must not contain NAs")
  }

  # If a main liquidity metric is provided, check that:
  if (!is.null(main_liquidity_metric)) {
    # (1) It is present among the non-classification columns
    if (!main_liquidity_metric %in% colnames(liquidity_floor_cutoffs)[-1]) {
      stop("main_liquidity_metric must be present in liquidity_floor_cutoffs")
    }
    # (2) The data.frame is arranged in ascending order according to that metric
    ordered_df <- dplyr::arrange(liquidity_floor_cutoffs, !!rlang::sym(main_liquidity_metric))
    if (!identical(ordered_df, liquidity_floor_cutoffs)) {
      stop("liquidity_floor_cutoffs is not in ascending order according to main_liquidity_metric")
    }
    # (3) Check that the ranking order across all liquidity metric columns is identical.
    #       Compute, for each liquidity metric column, the order (i.e. ranking of row indices)
    order_matrix <- sapply(liquidity_floor_cutoffs[, -1, drop = FALSE], order)
    # For each row in the order matrix, the ordered indices should be the same across columns.
    if (!all(apply(order_matrix, 1, function(x) length(unique(x)) == 1))) {
      stop("liquidity metrics orders in liquidity_floor_cutoffs are conflicting")
    }
  }

  # Check if the liquidity metric values appear normalized.
  #     If every non-classification column has all values between -1 and 1, assume they are normalized.
  normalized <- sapply(liquidity_floor_cutoffs[, -1, drop = FALSE], function(x) all(x >= -1 & x <= 1))
  if (any(normalized)) {
    stop("liquidity_floor_cutoffs values must not be normalized")
  }

  invisible(TRUE)
}



#' Check for Consistent Dates in a Vector (Allowing NULLs)
#'
#' Checks whether all non-NULL date values in a given vector or list are equal.
#'
#' @param current_dates A list or vector of dates. Can include `NULL` or `NA` values.
#'
#' @return Invisibly returns `TRUE` if all non-NULL, non-NA dates are identical;
#' otherwise, throws an error listing the differing dates.
#'
#'
#' @export
check_consistent_dates <- function(current_dates) {
  # Remove NULLs and NAs
  valid_dates <- current_dates[!vapply(current_dates, function(x) is.null(x) || is.na(x), logical(1))]

  unique_dates <- unique(valid_dates)

  if (length(unique_dates) > 1) {
    stop(
      "Inconsistent current_date values found: ",
      paste(as.character(as.Date(as.numeric(unique_dates), origin = "1970-01-01")), collapse = ", ")
    )
  }

  invisible(TRUE)
}



#' Validate Updated Backtest Objects
#'
#' @description
#' Checks that each named `_m_df` or `_m_xts` object in \code{new_objects_list}
#' satisfies the following conditions:
#' \itemize{
#'   \item Its internal \code{meta_dataframe_name} or \code{meta_xts_name} matches
#'         the expected name in \code{old_objects_names_list[[arg_name]]}.
#'   \item It provides new dates beyond those in \code{dates_covered}.
#'   \item Unless it is a daily returns object (named `"daily_stock_returns_m_xts"`
#'         or `"daily_bench_returns_m_xts"`), it starts exactly one month after
#'         the last date in \code{dates_covered}.
#'   \item The total number of new dates matches the required \code{n_update}
#'         (taken from \code{config@n_update} inside the function).
#' }
#'
#' @param new_objects_list A named list of `_m_df` or `_m_xts` objects. Each object
#'   must have:
#'   \itemize{
#'     \item A \code{meta_dataframe_name} or \code{meta_xts_name} slot (depending
#'           on whether it’s an \code{_m_df} or \code{_m_xts} object).
#'     \item A \code{@data} slot containing the underlying data (a \code{data.frame}
#'           in the case of an \code{_m_df}, or an \code{xts} object for an \code{_m_xts}).
#'     \item A \code{@current_date} slot (optional for your checks, but used in
#'           some places).
#'   }
#' @param old_objects_names_list A named list or vector that maps each \code{arg_name}
#'   in \code{new_objects_list} to the “official” or expected name. For example:
#'   \code{old_objects_names_list[["signals_m_df"]]} might be \code{"my_signals"}.
#' @param old_objects_dates_covered_list A named list of dates that have already been covered by previous
#'   backtest data. The function checks that the new objects contain dates strictly
#'   after these.
#' @param n_update The number of new dates that should be present in the updated objects.
#'
#' @return
#' Returns \code{TRUE} invisibly if all checks pass. Otherwise, it raises an error
#' via \code{stop()}.
#'
check_update_backtest_objects <- function(new_objects_list, old_objects_names_list, old_objects_dates_covered_list, n_update) {

  ##Initial Prep
  ###############

    ###Helper function: remove "_m_df" or "_m_xts" from the name
    remove_suffix <- function(x) {
      sub("(_m_df|_m_xts)$", "", x)
    }

  ###############

  ##Loop through each object, detect suffix, check object name and dates
  ###############
  for (arg_name in names(new_objects_list)) {

    obj <- new_objects_list[[arg_name]]
    old_dates_covered <- old_objects_dates_covered_list[[arg_name]]

    ###If NULL, skip
    if (is.null(obj)) next

    ###Identify whether argument ends in _m_df or _m_xts
    if (grepl("_m_df$", arg_name)) {
      ####Extract meta name
      meta_name <- obj@meta_dataframe_name #Suffix is _m_df => check meta_dataframe_name
      expected_name <- old_objects_names_list[[arg_name]]
      ####Extract dates for m_df
      new_obj_dates <- obj@data %>% dplyr::pull(dates) %>% unique() %>% sort() #Suffix is _m_df => acess underlying data.frame
      new_current_date <- obj@current_date
    } else if (grepl("_m_xts$", arg_name)) {
      ####Extract meta name
      meta_name <- obj@meta_xts_name #Suffix is _m_xts => check meta_xts_name
      expected_name <- old_objects_names_list[[arg_name]]
      ####Extract dates for m_xts
      new_obj_dates <- zoo::index(obj@data)
      new_current_date <- obj@current_date
    } else {
      # If object name doesn't end in _m_df or _m_xts, skip
      next
    }

    ###Check meta_name vs workflow
    ####Derive the prefix by removing the suffix
    prefix <- remove_suffix(arg_name)  # e.g. "signals_m_df" => "signals"
    workflow_field <- paste0(prefix, "_obj_name") #The workflow field is "<prefix>_obj_name". E.g. "signals_obj_name"

    ####Compare
    if (meta_name != expected_name) {
      stop(sprintf(
        "Updated %s does not match object name in port_backtest_workflow.\nExpected: %s, got: %s",
        arg_name, expected_name, meta_name
      ))
    }

    ###Check dates
    ####Check if new object is somehow shorter than the last date covered
    if (length(new_obj_dates) <= length(old_dates_covered)) {
      stop(sprintf("No new dates to cover for %s!", arg_name))
    }

    ####Check if new date is within dates covered
    first_new_date <- new_obj_dates[length(old_dates_covered) + 1]

    if (first_new_date %in% old_dates_covered) {
      stop(sprintf(
        "The first new date of %s is already covered by the existing backtest results.",
        arg_name
      ))
    }

    ###Check if new_current_date is n_update months ahead of old_current_date


    ####Check if new date is within expected range
    #####Get last_dates_covered
    last_date_covered <- old_dates_covered[length(old_dates_covered)]

    if (!arg_name %in% c("daily_stock_returns_m_xts", "daily_bench_returns_m_xts")){
    expected_next_date <- lubridate::add_with_rollback(last_date_covered, months(1))
    if (first_new_date != expected_next_date) {
      stop(sprintf(
        paste0("The first new date of %s does not match the expected date.\n",
               "Expected: %s\nGot: %s"),
        arg_name, expected_next_date, first_new_date
      ))
    }

    ####Check if total new # of dates is consistent with n_update
    if ((length(new_obj_dates) - length(old_dates_covered)) != n_update) {
      stop(sprintf(
        paste0("The new dates in %s do not conform to the expected n_update.\n",
               "Expected total length: %s\nGot total length: %s"),
        arg_name,
        length(old_dates_covered) + n_update,
        length(new_obj_dates)
      ))
    }
   }
  }
  ###############

  return(invisible(TRUE))

}


#' Validate portfolio construction methods and parameters
#'
#' @description
#' Validates consistency and allowed values for **MVO**, **RP/HRP**, and **MMAF**
#' (including macro/micro variants), plus optional **ridge penalties** with a
#' target portfolio. Errors on invalid configurations; otherwise returns `TRUE`
#' invisibly.
#'
#' @param port_construction_method Character. One of `"ew","sw","cw","cs","rp","hrp","mvo","mmaf"`.
#' @param micro_port_construction_method Character or `NULL`. Micro-level method (when `port_construction_method == "mmaf"`).
#' @param macro_port_construction_method Character or `NULL`. Macro-level method (when `port_construction_method == "mmaf"`).
#' @param opt_method,random_ports_method,n_random_ports,opt_objective,n_resamples,
#'   exp_ret_score_jitter,cov_eigval_jitter MVO (micro) controls; see function body for constraints.
#' @param macro_opt_method,macro_random_ports_method,macro_n_random_ports,macro_opt_objective,
#'   macro_n_resamples,macro_exp_ret_score_jitter,macro_cov_eigval_jitter MVO (macro) controls; see constraints.
#' @param exp_ret_score_tilt,exp_ret_score_tilt_eta RP/HRP (micro) tilt config; see constraints.
#' @param macro_exp_ret_score_tilt,macro_exp_ret_score_tilt_eta RP/HRP (macro) tilt config; see constraints.
#' @param mmaf_group_col Character or `NULL`. Grouping column name for MMAF.
#' @param stock_groups_m_df `data.frame` or `NULL`. Must contain `mmaf_group_col` for MMAF.
#' @param mmaf_method Character or `NULL`. One of `"bottom_up","top_down"` for MMAF.
#' @param top_down_proxy_port_method Character or `NULL`. If `mmaf_method == "top_down"`, one of `"ew","sw","cs","rp","hrp"`.
#' @param ridge_pen,macro_ridge_pen Numeric or `NULL`. Non-negative ridge penalties (micro/macro). Require MVO and a valid `target_port_m_df`.
#' @param target_port_m_df `data.frame`/`meta_dataframe` or `NULL`. Target weights for ridge penalty (no NAs; column 4 must be `target_weights`).
#' @param signals_m_df `data.frame`. Used to verify ID coverage vs `target_port_m_df`.
#' @param dates_m_vector `Date` vector. Used with `initial_buffer_period` to filter `signals_m_df`.
#' @param initial_buffer_period Integer index into `dates_m_vector`.
#'
#' @return Invisibly returns `TRUE` if all checks pass.
#' @keywords internal
validate_port_construction_methods <- function(
    port_construction_method,
    micro_port_construction_method = NULL,
    macro_port_construction_method = NULL,
    opt_method = NULL,
    random_ports_method = NULL,
    n_random_ports = NULL,
    opt_objective = NULL,
    n_resamples = NULL,
    exp_ret_score_jitter = NULL,
    cov_eigval_jitter = NULL,
    macro_opt_method = NULL,
    macro_random_ports_method = NULL,
    macro_n_random_ports = NULL,
    macro_opt_objective = NULL,
    macro_n_resamples = NULL,
    macro_exp_ret_score_jitter = NULL,
    macro_cov_eigval_jitter = NULL,
    exp_ret_score_tilt = NULL,
    exp_ret_score_tilt_eta = NULL,
    macro_exp_ret_score_tilt = NULL,
    macro_exp_ret_score_tilt_eta = NULL,
    mmaf_group_col = NULL,
    stock_groups_m_df = NULL,
    mmaf_method = NULL,
    top_down_proxy_port_method = NULL,
    ridge_pen = NULL,
    macro_ridge_pen = NULL,
    target_port_m_df = NULL,
    signals_m_df = NULL,
    dates_m_vector = NULL,
    initial_buffer_period = NULL
){

  ## -----------------
  ## Meta Objs
  ## -----------------
    ### target_port_m_df
    if (!is.null(ridge_pen) || !is.null(macro_ridge_pen)) {

    ## target_port_m_df must exist
    if (is.null(target_port_m_df)) {
      stop("target_port_m_df must be provided when ridge_pen is not NULL")
    }

    ## port_construction method must be mvo
    if (!is.null(ridge_pen) && port_construction_method != "mvo" &&
       (is.null(micro_port_construction_method) || micro_port_construction_method != "mvo")) {
      stop("ridge_pen can only be used for 'mvo'.")
    }

    ## macro_port_construction must be mvo for macro_ridge_pen
    if (!is.null(macro_ridge_pen) &&
        (!identical(macro_port_construction_method, "mvo"))) {
      stop("macro_ridge_pen can only be used when macro_port_construction_method is 'mvo'.")
    }

    ## Check coercibility
    if (!is_coercible_to_meta_dataframe(target_port_m_df)) {
      stop("target_port_m_df should be coercible to meta_dataframe object")
    }

    ## Check structure between target_port_m_df and signals_m_df
    if (!is.null(signals_m_df) && !is.null(dates_m_vector) && !is.null(initial_buffer_period)) {
      ids_after_buffer <-
        signals_m_df |>
        dplyr::filter(.data$dates >= dates_m_vector[initial_buffer_period]) |>
        dplyr::pull(.data$id)

      target_ids <- target_port_m_df |> dplyr::pull(.data$id)

      if (any(!(ids_after_buffer %in% target_ids))) {
        stop("all id's from signals_m_df after initial_buffer_period must have a correspondence in target_port_m_df")
      }
    }

    ## Check for NAs
    if (any(is.na(target_port_m_df))) {
      stop("target_port_m_df should not have NAs")
    }

    ## Check for target_weights column in 4th position
    if (colnames(target_port_m_df)[4] != "target_weights") {
      stop("target_port_m_df should have a column named target_weights")
    }

    ## Check weights are within [0,1]
    if (any(target_port_m_df$target_weights < 0 | target_port_m_df$target_weights > 1)) {
      stop("weights in target_port_m_df should be between 0 and 1")
    }

    ## Sum of weights by date must be ~1 (tolerance 0.02)
    target_weights_sum <-
      target_port_m_df |>
      dplyr::group_by(.data$dates) |>
      dplyr::summarise(dplyr::across(dplyr::where(is.numeric), ~ sum(., na.rm = TRUE), .names = "sum_{col}"), .groups = "drop")

    if (any(apply(as.data.frame(target_weights_sum[, -1, drop = FALSE]), 2,
                  function(x) any(abs(x - 1) > 0.02)))) {
      stop("weights in target_port_m_df should sum to 1 in every date.")
    }

    ## Check ridge_pen scalars
    if (!is.null(ridge_pen) && (!is.numeric(ridge_pen) || length(ridge_pen) != 1 || ridge_pen < 0)) {
      stop("ridge_pen should be a single non-negative numeric value")
    }
    if (!is.null(macro_ridge_pen) && (!is.numeric(macro_ridge_pen) || length(macro_ridge_pen) != 1 || macro_ridge_pen < 0)) {
      stop("macro_ridge_pen should be a single non-negative numeric value")
    }
  }

  invisible(TRUE)

  ## ---------------------------
  ## MVO: micro or main method
  ## ---------------------------
  if (port_construction_method == "mvo" ||
      (!is.null(micro_port_construction_method) && micro_port_construction_method == "mvo")) {

    if (!is.null(opt_method) && !opt_method %in% c("random")) {
      stop("Currently, 'opt_method' must be 'random'.")
    }
    if (!is.null(random_ports_method) && !random_ports_method %in% c("sample", "simplex", "grid")) {
      stop("random_ports_method must be one of 'sample', 'simplex', 'grid'.")
    }
    if (!is.null(n_random_ports) && (n_random_ports < 1)) {
      stop("n_random_ports must be at least 1.")
    }
    if (!is.null(opt_objective) && !opt_objective %in% c("return", "risk", "sharpe")) {
      stop("opt_objective must be one of 'return', 'risk', 'sharpe'.")
    }
    if (!is.null(n_resamples) && (n_resamples < 0 || length(n_resamples) != 1 || n_resamples != round(n_resamples))) {
      stop("n_resamples must be a non-negative integer.")
    }
    if (!is.null(exp_ret_score_jitter) && (exp_ret_score_jitter < 0 || length(exp_ret_score_jitter) != 1)) {
      stop("exp_ret_score_jitter must be a non-negative numeric value.")
    }
    if (!is.null(cov_eigval_jitter) && (cov_eigval_jitter < 0 || length(cov_eigval_jitter) != 1)) {
      stop("cov_eigval_jitter must be a non-negative numeric value.")
    }
    if (!is.null(n_resamples) && !is.null(exp_ret_score_jitter) && !is.null(cov_eigval_jitter)) {
      if (n_resamples > 0 && exp_ret_score_jitter == 0 && cov_eigval_jitter == 0) {
        stop(paste(
          "n_resamples > 0, but no jitter is being applied (exp_ret_score_jitter = 0 and cov_eigval_jitter = 0).",
          "Consider setting a positive jitter value."
        ))
      }
      if (n_resamples == 0 && (exp_ret_score_jitter > 0 || cov_eigval_jitter > 0)) {
        stop(paste(
          "n_resamples = 0, but jitter is being applied (exp_ret_score_jitter > 0 or cov_eigval_jitter > 0).",
          "Consider setting n_resamples to a positive integer."
        ))
      }
    }
  }

  ## ---------------------------------------------------
  ## MVO: macro level (macro_port_construction_method)
  ## ---------------------------------------------------
  if (!is.null(macro_port_construction_method) && macro_port_construction_method == "mvo") {

    if (!is.null(macro_opt_method) && !macro_opt_method %in% c("random")) {
      stop("Currently, 'macro_opt_method' must be 'random'.")
    }
    if (!is.null(macro_random_ports_method) && !macro_random_ports_method %in% c("sample", "simplex", "grid")) {
      stop("macro_random_ports_method must be one of 'sample', 'simplex', 'grid'.")
    }
    if (!is.null(macro_n_random_ports) && (macro_n_random_ports < 1)) {
      stop("macro_n_random_ports must be at least 1.")
    }
    if (!is.null(macro_opt_objective) && !macro_opt_objective %in% c("return", "risk", "sharpe")) {
      stop("macro_opt_objective must be one of 'return', 'risk', 'sharpe'.")
    }
    if (!is.null(macro_n_resamples) && (macro_n_resamples < 0 || length(macro_n_resamples) != 1 || macro_n_resamples != round(macro_n_resamples))) {
      stop("macro_n_resamples must be a non-negative integer.")
    }
    if (!is.null(macro_exp_ret_score_jitter) && (macro_exp_ret_score_jitter < 0 || length(macro_exp_ret_score_jitter) != 1)) {
      stop("macro_exp_ret_score_jitter must be a non-negative numeric value.")
    }
    if (!is.null(macro_cov_eigval_jitter) && (macro_cov_eigval_jitter < 0 || length(macro_cov_eigval_jitter) != 1)) {
      stop("macro_cov_eigval_jitter must be a non-negative numeric value.")
    }
    if (!is.null(macro_n_resamples) && !is.null(macro_exp_ret_score_jitter) && !is.null(macro_cov_eigval_jitter)) {
      if (macro_n_resamples > 0 && macro_exp_ret_score_jitter == 0 && macro_cov_eigval_jitter == 0) {
        stop(paste(
          "macro_n_resamples > 0, but no jitter is being applied (macro_exp_ret_score_jitter = 0 and macro_cov_eigval_jitter = 0).",
          "Consider setting a positive jitter value."
        ))
      }
      if (macro_n_resamples == 0 && (macro_exp_ret_score_jitter > 0 || macro_cov_eigval_jitter > 0)) {
        stop(paste(
          "macro_n_resamples = 0, but jitter is being applied (macro_exp_ret_score_jitter > 0 or macro_cov_eigval_jitter > 0).",
          "Consider setting macro_n_resamples to a positive integer."
        ))
      }
    }
  }

  ## --------------------
  ## RP / HRP (micro)
  ## --------------------

  if (!port_construction_method %in% c("rp", "hrp") &&
      (is.null(micro_port_construction_method) || (!is.null(micro_port_construction_method) && !micro_port_construction_method %in% c("rp", "hrp"))) &&
      !is.null(exp_ret_score_tilt)) {
    stop("exp_ret_score_tilt must be provided only for 'rp' or 'hrp'")
  }

  if (!port_construction_method %in% c("rp", "hrp") &&
      (is.null(micro_port_construction_method) || (!is.null(micro_port_construction_method) && !micro_port_construction_method %in% c("rp", "hrp"))) &&
      !is.null(exp_ret_score_tilt_eta)) {
    stop("exp_ret_score_tilt_eta must be provided only for 'rp' or 'hrp'")
  }

  if (port_construction_method %in% c("rp", "hrp") ||
      (!is.null(micro_port_construction_method) && micro_port_construction_method %in% c("rp", "hrp"))) {

    if (!is.null(exp_ret_score_tilt) && !(exp_ret_score_tilt %in% c("none", "inner", "final"))) {
      stop("exp_ret_score_tilt must be one of 'none', 'inner' or 'final'")
    }
    if (!is.null(exp_ret_score_tilt_eta) &&
        (!is.numeric(exp_ret_score_tilt_eta) || length(exp_ret_score_tilt_eta) != 1 || exp_ret_score_tilt_eta <= 0)) {
      stop("exp_ret_score_tilt_eta should be a single positive numeric value")
    }
    if (is.null(exp_ret_score_tilt) && !is.null(exp_ret_score_tilt_eta)) {
      stop("exp_ret_score_tilt_eta should be NULL when exp_ret_score_tilt is NULL")
    }
    if (!is.null(exp_ret_score_tilt) && exp_ret_score_tilt == "none" && !is.null(exp_ret_score_tilt_eta)) {
      stop("exp_ret_score_tilt_eta should be NULL when exp_ret_score_tilt = 'none'")
    }
  }

  ## --------------------
  ## RP / HRP (macro)
  ## --------------------
  if ((!is.null(macro_port_construction_method) && !macro_port_construction_method %in% c("rp", "hrp")) &&
      !is.null(macro_exp_ret_score_tilt)) {
    stop("macro_exp_ret_score_tilt must be provided only when macro_port_construction_method is 'rp' or 'hrp'")
  }

  if ((!is.null(macro_port_construction_method) && !macro_port_construction_method %in% c("rp", "hrp")) &&
      !is.null(macro_exp_ret_score_tilt_eta)) {
    stop("macro_exp_ret_score_tilt_eta must be provided only when macro_port_construction_method is 'rp' or 'hrp'")
  }

  if (!is.null(macro_port_construction_method) && macro_port_construction_method %in% c("rp", "hrp")) {

    if (!is.null(macro_exp_ret_score_tilt) && !(macro_exp_ret_score_tilt %in% c("none", "inner", "final"))) {
      stop("macro_exp_ret_score_tilt must be one of 'none', 'inner' or 'final'")
    }
    if (!is.null(macro_exp_ret_score_tilt_eta) &&
        (!is.numeric(macro_exp_ret_score_tilt_eta) || length(macro_exp_ret_score_tilt_eta) != 1 || macro_exp_ret_score_tilt_eta <= 0)) {
      stop("macro_exp_ret_score_tilt_eta should be a single positive numeric value")
    }
    if (is.null(macro_exp_ret_score_tilt) && !is.null(macro_exp_ret_score_tilt_eta)) {
      stop("macro_exp_ret_score_tilt_eta should be NULL when macro_exp_ret_score_tilt is NULL")
    }
    if (!is.null(macro_exp_ret_score_tilt) && macro_exp_ret_score_tilt == "none" && !is.null(macro_exp_ret_score_tilt_eta)) {
      stop("macro_exp_ret_score_tilt_eta should be NULL when macro_exp_ret_score_tilt = 'none'")
    }
  }

  ## -----------
  ## MMAF
  ## -----------
  if (port_construction_method == "mmaf") {

    if (is.null(micro_port_construction_method)) {
      stop("micro_port_construction_method can't be missing if port_construction_method is 'mmaf'")
    }
    if (is.null(macro_port_construction_method)) {
      stop("macro_port_construction_method can't be missing if port_construction_method is 'mmaf'")
    }
    if (!micro_port_construction_method %in% c("ew", "sw", "cw", "cs", "rp", "hrp", "mvo")) {
      stop("micro_port_construction_method must be one of 'ew', 'sw', 'cw', 'cs', 'rp', 'hrp' or 'mvo'")
    }
    if (!macro_port_construction_method %in% c("ew", "sw", "cw", "cs", "rp", "hrp", "mvo")) {
      stop("macro_port_construction_method must be one of 'ew', 'sw', 'cw', 'cs', 'rp', 'hrp' or 'mvo'")
    }
    if (is.null(mmaf_group_col)) {
      stop("mmaf_group_col can't be NULL for 'mmaf'")
    }
    if (is.null(stock_groups_m_df) || !(mmaf_group_col %in% colnames(stock_groups_m_df))) {
      stop("groups_m_df must be provided and mmaf_group_col must be present in groups_m_df for 'mmaf'")
    }
    if (is.null(mmaf_method) || !mmaf_method %in% c("bottom_up", "top_down")) {
      stop("mmaf_method must be one of 'bottom_up' or 'top_down'")
    }
    if (mmaf_method == "top_down" && is.null(top_down_proxy_port_method)) {
      stop("top_down_proxy_port_method must be provided when mmaf_method is 'top_down'")
    }
    if (mmaf_method == "top_down" && !top_down_proxy_port_method %in% c("ew", "sw", "cs", "rp", "hrp")) {
      stop("top_down_proxy_port_method must be one of 'ew', 'sw', 'cs', 'rp' or 'hrp'")
    }
  }


}



#validate_sub_port_config-------------------------------------------------------
#' Validate a Sub Portfolio Configuration
#'
#' @description
#' Validates a `sub_port_config` (or any class extending it, such as
#' `mmaf_sub_port_config`). It is the single validity contract shared by every layered
#' (`*af`) portfolio construction method, so that a sub-portfolio is specified the same
#' way regardless of which method builds it.
#'
#' @param object An object of class `sub_port_config` or of a class extending it.
#'
#' @return `TRUE` invisibly if the configuration is valid. Stops with an informative
#' message otherwise.
#'
#' @details
#' Checks performed:
#' \itemize{
#'   \item `port_construction_method` is a single, non-`NA` character among the methods
#'         a sub-portfolio may use ('ew', 'sw', 'cw', 'cs', 'rp', 'hrp', 'mvo').
#'         Layered methods are excluded on purpose: nesting one layered method inside
#'         another is not supported.
#'   \item the parameter object matching that method, when supplied, has the expected S4
#'         class. Parameter objects that do not match the method are left untouched
#'         (they are inert, not invalid).
#' }
validate_sub_port_config <- function(object){

  ## Method must be a single, usable character
  ###################
  port_construction_method <- object@port_construction_method

  if (length(port_construction_method) != 1 ||
      !is.character(port_construction_method) ||
      is.na(port_construction_method)){
    stop("port_construction_method must be a single non-NA character string.")
  }

  ### Layered methods are deliberately absent: a sub-portfolio may not itself be layered
  if (!port_construction_method %in% c("ew", "sw", "cw", "cs", "rp", "hrp", "mvo")){
    stop("port_construction_method must be one of 'ew', 'sw', 'cw', 'cs', 'rp', 'hrp' or 'mvo'.")
  }
  ###################

  ## Parameter object matching the method must have the expected class
  ###################
  ### Only the parameters of the chosen method are consulted, so a mismatched
  ### (but well-formed) parameter object stays inert rather than invalid.
  parameter_slot <- c(mvo = "mvo_parameters",
                      rp  = "rp_parameters",
                      hrp = "hrp_parameters")
  parameter_class <- c(mvo = "mvo_parameters",
                       rp  = "rp_parameters",
                       hrp = "hrp_parameters")

  if (port_construction_method %in% names(parameter_slot)){

    slot_name <- parameter_slot[[port_construction_method]]
    expected_class <- parameter_class[[port_construction_method]]
    supplied_parameters <- methods::slot(object, slot_name)

    if (!is.null(supplied_parameters) && !methods::is(supplied_parameters, expected_class)){
      stop(paste0(slot_name, " must be of class '", expected_class,
                  "' when port_construction_method is '", port_construction_method, "'."))
    }
  }
  ###################

  invisible(TRUE)
}


#validate_slsaf_parameters------------------------------------------------------
#' Validate SLSAF Parameters
#'
#' @description
#' Validates an `slsaf_parameters` object, the configuration of the Simulated Long-Short
#' Allocation Framework.
#'
#' @param object An object of class `slsaf_parameters`.
#'
#' @return `TRUE` invisibly if the configuration is valid. Stops with an informative
#' message otherwise.
validate_slsaf_parameters <- function(object){

  ## Long leg configuration
  ###################
  ### The short leg has no method to configure: it is always signal weighted on the
  ### badness score, so only the long leg carries a sub-portfolio configuration.
  if (is.null(object@long_port_config)){
    stop("long_port_config is required for slsaf portfolios.")
  }
  if (!methods::is(object@long_port_config, "sub_port_config")){
    stop("long_port_config must be of class 'sub_port_config'.")
  }
  validate_sub_port_config(object@long_port_config)

  ### A ridge penalty on the long leg is accepted by the config but cannot run. The
  ### target_weights column is joined into the universe by classify_investment_universe()
  ### only when the top-level ridge_pen is set, and under slsaf that stays NULL because
  ### the MVO parameters travel inside long_port_config. The recursive MVO call would then
  ### select a column that was never joined. Routing a target into the long block is not a
  ### matter of plumbing: the target is defined over the whole universe while the long
  ### block is a strict subset, so it would have to be renormalized, which changes what
  ### the penalty shrinks towards. Reject until that contract is designed.
  if (!is.null(object@long_port_config@mvo_parameters) &&
      !is.null(object@long_port_config@mvo_parameters@ridge_pen)){
    stop("ridge_pen is not supported for the slsaf long leg: no target portfolio is routed to the long block.")
  }
  ###################

  ## Score exponents
  ###################
  if (length(object@bench_weight_tilt_eta) != 1 || !is.finite(object@bench_weight_tilt_eta)){
    stop("bench_weight_tilt_eta must be a single finite numeric value.")
  }
  if (length(object@badness_tilt_eta) != 1 || !is.finite(object@badness_tilt_eta)){
    stop("badness_tilt_eta must be a single finite numeric value.")
  }

  ### A negative badness exponent would grant the largest underweight to the names with
  ### the best scores, which inverts the meaning of the leg
  if (object@badness_tilt_eta < 0){
    stop("badness_tilt_eta must be non-negative: a negative exponent would underweight the best-scoring names the most.")
  }
  ###################

  ## Active budget ceiling
  ###################
  if (!is.null(object@max_short_budget)){
    if (!is.numeric(object@max_short_budget) || length(object@max_short_budget) != 1 ||
        !is.finite(object@max_short_budget) ||
        object@max_short_budget <= 0 || object@max_short_budget > 1){
      stop("max_short_budget must be NULL or a single numeric value in (0, 1].")
    }
  }
  ###################

  invisible(TRUE)
}
